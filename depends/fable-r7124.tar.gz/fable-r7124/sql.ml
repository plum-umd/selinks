(** Contains the definition of an sql statement. *)

open Num
open List
open Printf
  (*open Query*)

module type S =
sig
  module Query : Mkquery.Q

  val string_of_query : Query.query -> string
  val conjunction : Query.expression list -> Query.expression
  val disjunction : Query.expression list -> Query.expression
  val negation : Query.expression -> Query.expression
  val simplify : Query.expression -> Query.expression
end

module Make (Q : Mkquery.Q) =
struct 
  module Query = Q
    
  open Query

  let sorting_to_sql = function
    | `Asc (table, col)  -> table ^ "." ^ col ^ " ASC" 
    | `Desc (table, col) -> table ^ "." ^ col ^ " DESC"
        
  let rec string_of_expression : expression -> string = function
    | Field (table, field)     -> table ^"."^ field
        (*   | NamedField field         -> field *)
    | Variable name            -> "VARIABLE:"^ name
    | Null                     -> "NULL"
    | Integer value            -> string_of_num value
    | Float value              -> string_of_float value
    | Boolean value            -> string_of_bool value
    | LikeExpr v               -> Query.like_as_string v
    | Text value               -> "\'"^ value ^"\'"
    | Binary_op (symbol, l, r) -> 
        sprintf "(%s %s %s)" (string_of_expression l) symbol (string_of_expression r)
    | Unary_op (symbol, expr)  -> sprintf "(%s %s)" symbol (string_of_expression expr)
    | Funcall (fname, args)    -> 
        let argstr = List.fold_right 
          (fun arg s -> 
             if (String.length s  == 0) then (string_of_expression arg)
             else ((string_of_expression arg) ^ ", " ^ s)) args "" in
        fname ^ "(" ^ argstr ^ ")"
    | Case branches            -> 
        let branches = List.fold_right (
          fun (guard, expr) s -> 
            let ge = string_of_expression guard in
            let te = string_of_expression expr in
            sprintf "WHEN (%s) THEN %s %s" ge te s)
          branches "" 
        in "(CASE " ^ branches ^ " END)"
    | Query query -> "("^ string_of_query query ^")"
  and string_of_table_spec = function
    | `TableName name -> name
    | `TableVariable vrbl -> "VARIABLE:" ^ vrbl
    | `Subquery query -> "(" ^ string_of_query query ^ ")"
  and string_of_condition cond = match string_of_expression cond with
    | "true" -> ""
    | where  -> " WHERE " ^ where 
  and string_of_query (qry:query) : string =
    let {distinct_only = distinct; result_cols = selects;
         tables = tables; condition = where; sortings = order; projections=colnames} = qry 
    in
    let tab_alias = (match tables with 
                         [(_, alias)] -> Some alias
                       | _ -> None) in
    (* let s = Utility.mapstrcat ", " (function (`TableName tn, alias) *)
    (* | (`TableVariable tn, alias) -> "(" ^tn^ ", " ^alias^ ")") tables in *)
    (* failwith ("SQL joins with multiple tables are not currently supported: " ^s)) in *)

    let string_of_col = function
      | Utility.Left col -> sprintf "%s.%s AS %s" col.table_alias col.name col.col_alias
      | Utility.Right ce -> 
          sprintf "%s AS %s" (string_of_expression ce.expression) ce.exprcol_alias
    in

    let string_of_table (table, rename) = string_of_table_spec table ^ " AS " ^ rename in

    let sel_cols_from = 
      let dist = if distinct then "DISTINCT" else "" in
      let cols = match selects with
        | [] -> "NULL as null"
        | _ -> Utility.mapstrcat ", " string_of_col qry.result_cols
      in
      let tables = Utility.mapstrcat ", " string_of_table tables in
      sprintf "SELECT %s%s FROM %s" dist cols tables
    in

    let where_clause = string_of_condition where in
    let qualifiers = (
      match order with
        | [] -> "" 
        | orders -> " ORDER BY " ^ Utility.mapstrcat ", " sorting_to_sql orders)
      ^ (match qry.max_rows with
           | None   -> ""
           | Some m -> " LIMIT " ^ string_of_expression m)
      ^ " OFFSET " ^ string_of_expression qry.offset in

    let projstr = match colnames with 
      | [] -> "*"
      | _ -> List.fold_right (fun n l -> 
                                if String.length l = 0 then n
                                else n ^ ", " ^ l) colnames "" in
    match tab_alias with
      | None -> sel_cols_from ^ where_clause ^ qualifiers
      | Some tab_alias -> 
          sprintf "SELECT %s FROM (%s) AS %s %s%s"
            projstr sel_cols_from tab_alias where_clause qualifiers
            
  (** conjunction, disjunction
      These routines should form simplified SQL expressions out of a
      list of SQL exprs.
  *)
            
  let rec conjunction = function
    | [] -> Boolean true
    | (Boolean true :: ts) -> conjunction ts
    | (Boolean false :: _) -> Boolean false
    | (t :: ts) -> match conjunction ts with
          Boolean true -> t
        | Boolean false -> Boolean false
        | rhs -> Binary_op("AND", t, rhs)

  let rec disjunction = function
    | [] -> Boolean false
    | (Boolean true :: _) -> Boolean true
    | (Boolean false :: ts) -> disjunction ts
    | (t :: ts) -> match disjunction ts with
          Boolean true -> Boolean true
        | Boolean false -> t
        | rhs -> Binary_op("OR", t, rhs)

  let rec negation = function
      Boolean true -> Boolean false
    | Boolean false -> Boolean true
    | Unary_op("NOT", t) -> t
    | t -> Unary_op("NOT", t)

  open Utility

  type 'a yesno = Yes of 'a | No of 'a
    (* deriving (Show, Eq, Typeable, Pickle, Shelve) *)
    
  let fromYN : 'a yesno -> 'a = function
    | Yes  y -> y
    | No n -> n

  let newYes x = Yes x
  let newNo x  = No x

  let makeYes = fromYN ->- newYes
  let makeNo = fromYN ->- newNo

  let flipYN = function
    | Yes x -> No x
    | No x -> Yes x

  let applyYN f = function
    | Yes x -> Yes (f x)
    | No x -> No (f x)

  let orYN : ('a yesno * 'b yesno) -> ('a * 'b) yesno = function
    | (No x, No y) -> No (x, y)
    | (x, y) -> Yes (fromYN x, fromYN y)

  let rec simplify (* : Query.Expression -> Query.Expression yesno *) = 
    function
      | Unary_op("NOT", Unary_op("NOT", expr)) -> (simplify ->- makeYes) expr
      | Binary_op("AND", lhs, Boolean true) -> (simplify ->- makeYes) lhs
      | Binary_op("AND", Boolean true, rhs) -> (simplify ->- makeYes) rhs
      | Binary_op("OR", lhs, Boolean false) -> (simplify ->- makeYes) lhs
      | Binary_op("OR", Boolean false, rhs) -> (simplify ->- makeYes) rhs
      | Binary_op("=", lhs, rhs) when lhs == rhs -> Yes (Boolean true)
          
      | Unary_op(op, expr) -> 
          applyYN (fun e -> Unary_op(op, e)) (simplify expr)
      | Binary_op(op, lhs, rhs) -> 
          let lr = orYN (simplify lhs, simplify rhs) in
          applyYN (fun (l,r) -> Binary_op(op, l, r)) lr

      | expr -> No expr

  let simplify = simplify ->- fromYN

end

