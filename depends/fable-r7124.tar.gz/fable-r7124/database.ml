open Num
open List

open Result
open Expression

let convert_nulls = Settings.add_bool ("convert_nulls", false, `User)

class virtual db_args from_str = object
  val strval : string = from_str
  method virtual from_string : string -> unit
end

(** Convert database-supplied value to appropriate Links type
    Inverse of Library.value_as_string.
    Handles bool, int, float, string, and anything with custom um.
    (um = unmarshaling?)
 *)
let value_of_db_string (value:string) (um_opt : (string -> result) option) (t:Types.datatype) = 
  let unsupported_datatype () =  
    failwith ("value_of_db_string: unsupported datatype: '"
              ^ Printsyntax.string_of_datatype t ^"' (value: '"
              ^ value ^ "')") in
  (* convert null values to a default value *)
  if Settings.get_value convert_nulls && value = "null" then begin
    match t.Types.ltype with
      | `Primitive `Bool          -> Result.bool false
      | `Primitive `Int           -> Result.int (num_of_int 0)
      | `Primitive `Float         -> Result.float 0.0
      | `Primitive `Char          -> Result.char ' '
      | `Application ("String",_)
      | `Application ("List",_)   -> Result.string_as_charlist ""
	  | _ -> unsupported_datatype ()
  end 
  else
    match um_opt with 
        Some um -> um value
      | None -> begin
	      match t.Types.ltype with 
              (* bjc: I changed comparison from "true" to "t" to match
                 PostgreSQL syntax, but this should really be defined
                 per-database in *_database.ml *)
	        | `Primitive `Bool -> Result.bool (value = "t")
 	        | `Primitive `Int  -> Result.int (num_of_string value)
	        | `Primitive `Float -> (
                if value = "" then Result.float 0.00      (* HACK HACK *)
			    else Result.float (float_of_string value))
 	        | `Primitive `Char  -> Result.char (String.get value 0)
	        | `Application ("String", l)
	        | `Application ("List", l) -> begin
		        match List.map (fun x-> x.Types.ltype) l with 
		            [] 
		          | [`Primitive `Char] -> Result.string_as_charlist value
		          | _ -> unsupported_datatype ()
		      end
            | `Application (_, []) -> begin
                (* bjc: hack to read in pg-style labels. 
                   Using test_pvar.links example:
                   value : string = "Acl(Brian,Acl(Nik,Nil))"
                   t : datatype = {ltype = `Application ("AclLabel", []);
                   ftype = `Kind LKind} *)
                (* let ftype = t.Expression.Types.ftype in *)
                try 
                  (* bjc: the line below fails on some types;
                     commenting it out fixes the problem, but I haven't
                     figured out the details. *)
                  (* let _ = Fable.get_label_type_expr ftype in *)
                  LabelParse.label_of_string value
                with Not_found -> unsupported_datatype ()
              end
	        | _ -> unsupported_datatype ()
	    end
	    

(* NIK : Unused*)
(* let datatype_of_db_type =  *)
(*   let ldatatype_of_db_type = function *)
(*     | BoolField -> `Primitive `Bool *)
(*     | TextField -> `Application ("String", []) *)
(*     | IntField -> `Primitive `Int *)
(*     | FloatField -> `Primitive `Float *)
(*     | _ -> failwith "datatype_of_db_type: unsupported datatype" in *)
(*     Types.def_fable_annot -<- ldatatype_of_db_type *)

let handle_sql_error query msg =
  let error = "An error occurred executing the query:<br/>\n" ^
    query ^ "<br/>\n" ^ "Error msg: " ^ msg
  in raise (Runtime_error error)

let execute_command  (query:string) (db: database) : result =
  let result = (db#exec query) in
  match result#status with
    | QueryOk -> `Record []
    | QueryError msg -> handle_sql_error query msg

let execute_insert (table_name, field_names, vss) db =
  let query = db#make_insert_query (table_name, field_names, vss) in
  prerr_endline ("RUNNING INSERT QUERY:\n" ^ query);
  execute_command query db

type field_unmarshall_type = 
    (string * (Types.datatype * (string -> Result.result) option))

(** get list of fields from dbresult *)
let get_field_list (field_types:field_unmarshall_type list) (result:dbresult) 
    : (string * db_field_type * 
         (Types.datatype * (string -> Result.result) option)
      ) list =
  let get_field count =
    let fname = result#fname count in
    let ftype = result#ftype count in
    let fieldtype = assoc fname field_types in
    (fname, ftype, fieldtype) 
  in

  let rec get_fields n = 
    if n < result#nfields 
    then get_field n :: get_fields (n+1)
    else []
  in
    get_fields 0

(* helper function for execute_select *)
let select_ok result field_types query db =
  let row_fields = get_field_list field_types result in

  (* is result null (with extraneous checks) *)
  let is_null (name, db_type, (real_type, _)) =
    if name = "null" then true
    else if mem_assoc name field_types then
      if db#equal_types real_type db_type then
        false
	  else raise (Runtime_error
                    ("Database did not provide results compatible with "
                     ^ "specified type (query was '" ^ query ^ "')"))
    else assert false in

  (* convert db-supplied row to Links record *)
  let row_to_record rowvalue = 
    `Record 
      (map2 
         (fun (name, _, (real_type, um_opt)) fldvalue -> 
			name, value_of_db_string fldvalue um_opt real_type)
         row_fields rowvalue) 
  in
  
  if not (Settings.get_value convert_nulls) 
    && exists is_null row_fields then
    (* if any field is null, return list of empty records *)
    `List (map (fun _ -> `Record []) result#get_all_lst)
  else
  `List (map row_to_record result#get_all_lst)
        
let execute_select (field_types:field_unmarshall_type list) (query:string) (db: database) 
    : result =
  let result = (db#exec query) in
  match result#status with
    | QueryOk -> select_ok result field_types query db
    | QueryError msg -> handle_sql_error query msg
      
      
