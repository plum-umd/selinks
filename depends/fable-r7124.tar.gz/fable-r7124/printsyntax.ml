open Expression
open Expression.Types
open FableType
(* open Show *)


(* I think this is the wrong notation *)
let string_of_kind = function
    | MKind -> "::M"
    | UKind -> ""   (* we may want to suppress this *)


let string_of_expression = Syntax.string_of_expression 

(* not sure about relationship between 'a fable_qualifier and 'a fq *)
let rec string_of_fq : 'a fable_qualifier -> string -> string =
  fun fq ltype -> 
    match fq with 
    | `Empty -> ltype
    | `Kind kind -> 
        ltype ^ string_of_kind kind
    | `KindVar kv -> 
        string_of_kind_var_basis (Unionfind.find kv) ltype
    | `Name (name, fq) -> 
        name ^ "<-" ^ string_of_fq fq ltype
    | `Labeling (expr, fq) -> 
        (* expr is of type ('a,'a) expression' *)
        Printf.sprintf "%s{%s}" 
          (string_of_fq fq ltype) 
          (string_of_expression expr) 
    | `Label (fexpr, fq) -> 
        Printf.sprintf "%s is lab%s" 
          (string_of_fq fq ltype)
          (string_of_triopt fexpr) 
    | `Phantom (_, fq) -> (* ???: this never seems to occur *)
        "Phantom (...) " ^ string_of_fq fq ltype

and string_of_kind_var_basis kvb ltype = 
  match kvb with 
  | `FlexKind (_,kind) -> (* bound *)
      ltype ^ (string_of_kind kind)
  | `FixedKind fq ->
      string_of_fq fq ltype

and string_of_triopt = function
  | `Nothing -> ""
  | `Inferred lbasis -> 
      begin
        match (Unionfind.find lbasis) with 
        | `Something expr -> (* not sure about the syntax *)
            (* example: Foo; *)
            "." ^ string_of_expression expr
        | `Nothing -> "" (* not sure about the syntax *)
      end
  | `Required expr -> "." ^ string_of_expression expr

let string_of_datatype : 'a datatype' -> string =
  fun t ->  
    (* insert new pp for fable types *)
    let dictionary = {Types.dictionary with s_of_fq = string_of_fq} in
    Types.string_of_datatype dictionary t

let string_of_datatype_raw : 'a datatype' -> string =
  fun t -> 
    Types.string_of_datatype_raw dictionary t
    
let string_of_row : 'a row' -> string =
  fun t -> 
    Types.string_of_row dictionary t
    
let string_of_row_var : row_var -> string =
  fun t -> 
    Types.string_of_row_var t
    
let string_of_assumption : 'a assumption' -> string =
  fun t -> 
    Types.string_of_assumption dictionary t
