-- replace /fs/macdonald/piotrm/sesense/pgsql-label/label with the location of label.so, excluding the ".so"
-- example: /fs/macdonald/selinks/sesense/fable_strap/pgsql/label

-- SQL Label, Tuple, and List defintions
-- Depends on label.so
CREATE FUNCTION label_in(cstring) 
  RETURNS label 
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION label_out(label) 
  RETURNS cstring 
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION label_abs_eq(label, label)
  RETURNS bool
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION label_abs_neq(label, label)
  RETURNS bool
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION tuple_in(cstring) 
  RETURNS tuple 
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION tuple_out(tuple) 
  RETURNS cstring
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION list_in(cstring) 
  RETURNS list 
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION list_out(list) 
  RETURNS cstring
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE TYPE label (
  internallength = variable, 
  input = label_in, 
  output = label_out,
  alignment = int4
);

CREATE TYPE tuple (
  internallength = variable, 
  input = tuple_in, 
  output = tuple_out,
  alignment = int4
);

CREATE TYPE list (
  internallength = variable, 
  input = list_in, 
  output = list_out,
  alignment = int4
);

CREATE OPERATOR = (
   leftarg = label, rightarg = label, procedure = label_abs_eq,
   commutator = = ,
   negator = <> ,
   restrict = eqsel, join = eqjoinsel
);

CREATE OPERATOR <> (
   leftarg = label, rightarg = label, procedure = label_abs_neq,
   commutator = <> ,
   negator = = ,
   restrict = neqsel, join = neqjoinsel
);

-- label functions --

CREATE FUNCTION label_init(text, anyelement) RETURNS label
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION label_get_tuple(label) RETURNS tuple
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION label_get_appl(label) RETURNS label
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION label_get_name(label) RETURNS text
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label'
  LANGUAGE C IMMUTABLE STRICT;

-- tuple functions --

CREATE FUNCTION tuple_tail(tuple) RETURNS tuple
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION tuple_get_int(tuple, int4) RETURNS int4
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION tuple_get_str(tuple, int4) RETURNS text
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION tuple_get_bool(tuple, int4) RETURNS bool
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION tuple_get_lab(tuple, int4) RETURNS label
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION tuple_get_list(tuple, int4) RETURNS list
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION tuple_num_args(tuple) RETURNS int4
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

-- list functions --

CREATE FUNCTION list_tl(list) RETURNS list
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION list_head_int(list) RETURNS int4
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION list_head_bool(list) RETURNS bool
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION list_head_str(list) RETURNS text
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION list_head_lab(list) RETURNS label
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION list_len(list) RETURNS int4
  AS '/fs/macdonald/piotrm/sesense/pgsql-label/label' 
  LANGUAGE C IMMUTABLE STRICT;

CREATE OPERATOR CLASS label_abs_ops
  DEFAULT FOR TYPE label USING btree AS
    OPERATOR        1       = ,
    OPERATOR        2       <> ;

--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: -
--

CREATE PROCEDURAL LANGUAGE plpgsql;
