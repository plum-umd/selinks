(*pp deriving *)
open Utility


module type FableType =
sig
  type 'a expression'
  type 'a datatype'
  type untyped_data
  type typed_data

  exception Bad_fable_type of string

  type kind = MKind | UKind 
      deriving (Eq, Show, Pickle, Typeable, Shelve)

  type 'a lbasis = [ `Nothing | `Something of 'a]
      deriving (Eq, Show, Pickle, Typeable, Shelve)

  type 'a triopt = 
      [ `Nothing  
      | `Inferred of 'a lbasis Unionfind.point 
      | `Required of 'a]
	deriving (Eq, Show, Pickle, Typeable, Shelve)
	 
  type 'a fable_qualifier = 
      [ `Empty
      | `KindVar of 'a kind_var_basis Unionfind.point
      | `Kind of kind 
      | `Name of string * 'a fable_qualifier
      | `Labeling of 'a expression' * 'a fable_qualifier
      | `Label of 'a expression' triopt * 'a fable_qualifier
      | `Phantom of string list * 'a fable_qualifier ]
  and 'a kind_var_basis = 
      [ `FlexKind of int * kind (*bound*)
      | `FixedKind of 'a fable_qualifier ]
(*       deriving (Eq, Show, Pickle, Typeable, Shelve) *)
	
  type untyped_expression = untyped_data expression'
  and unchecked_fable_type = untyped_data fable_qualifier 
	
  type typed_expression = typed_data expression'
  and fable_type = typed_data fable_qualifier
	     
  val kind_leq : (kind*kind) -> bool
  val kind_qual : 'a fable_qualifier -> kind
  val kind_join : (kind*kind) -> kind
  val well_formed_fq : 'a fable_qualifier -> bool
  val instantiate : 'a fable_qualifier -> 'a fable_qualifier ->'a fable_qualifier
  val combine : 'a fable_qualifier -> 'a fable_qualifier ->'a fable_qualifier
  val def_annot : unit -> 'a fable_qualifier
  val name_annot : string -> 'a fable_qualifier
  val labeling_annot : 'a expression' -> 'a fable_qualifier 
  val label_annot : 'a expression' triopt -> 'a fable_qualifier 
  val phantom_annot : string list -> 'a fable_qualifier 
  val string_as_kind : string -> kind
  val kind_as_annot : kind -> 'a fable_qualifier

end

type 'a stringmap = 'a Utility.StringMap.t
type 'a field_env = 'a stringmap deriving (Eq, Pickle, Typeable, Show, Shelve)

module type T = 
sig
  type typed_data
  type untyped_data
  type kind
  type 'a fq
    
  (* type var sets *)
  module TypeVarSet : Utility.INTSET

  (* points *)
  type 'a point = 'a Unionfind.point 
      
  (*   module Show_point (A : Show.Show) : Show.Show with type a = A.a Unionfind.point *)
  module Pickle_point (A : Pickle.Pickle) : Pickle.Pickle with type a = A.a Unionfind.point
      
  type primitive = [ `Bool | `Int | `Char | `Float 
                   | `XmlItem | `DB | `Abstract | `NativeString]
      deriving (Eq, Typeable, Show, Pickle, Shelve)


  type 'a datatype' = {ltype: 'a ldatatype'; ftype : 'a fq}
  and meta_type_var_basis = Flexible of int
			    | Rigid of int
			    | UncheckedRecursive of (int * untyped_data datatype')
			    | Recursive of (int * typed_data datatype')
			    | Body of typed_data datatype'
  and meta_row_var_basis  = ClosedRow
			    | FlexibleRow of int
			    | RigidRow of int
			    | RecursiveRow of (int * typed_data row')
			    | BodyRow of typed_data row'
  and 'a ldatatype' =
      [ `Not_typed
      | `Primitive of primitive
      | `Function of ('a datatype' * 'a datatype' * 'a datatype')
      | `Record of 'a row'
      | `Variant of 'a row'
      | `Table of 'a datatype' * 'a datatype'
      | `Application of (string * ('a datatype') list)
      | `MetaTypeVar of meta_type_var]
  and 'a field_spec' = [ `Present of 'a datatype' | `Absent ]
  and 'a field_spec_map' = 'a field_spec' field_env
  and 'a row' = 'a field_spec_map' * row_var
  and row_var = meta_row_var_basis point
  and meta_type_var = meta_type_var_basis point

  (* Abbreviations *)
  type datatype = typed_data datatype'
  and  row = typed_data row'
  and  ldatatype = typed_data ldatatype'
  and  field_spec = typed_data field_spec'
  and  field_spec_map = typed_data field_spec_map'

  type u_datatype = untyped_data datatype'
  and  u_ldatatype = untyped_data ldatatype'
  and  u_field_spec = untyped_data field_spec'
  and  u_field_spec_map = untyped_data field_spec_map'
  and  u_row = untyped_data row'
      
  val concrete_type : datatype -> datatype

  type type_variable = [`TypeVar of int | `RigidTypeVar of int | `RowVar of int]
      deriving (Typeable, Show, Pickle)
  type quantifier = type_variable * kind
      deriving (Typeable, Show, Pickle)
      
  type 'a assumption' = (quantifier list * 'a datatype')
  type u_assumption = untyped_data assumption'
  type assumption =  (quantifier list * datatype)
(*       deriving (Show) *)

  val def_fable_annot : 'a ldatatype' -> 'a datatype'
  val fable_annot : 'a ldatatype' -> 'a fq -> 'a datatype'
  val add_fable_annot : 'a datatype' -> 'a fq  -> 'a datatype'
    
  (* useful types *)
  val unit_type : unit -> 'a datatype'
  val bool_type : unit -> 'a datatype'
  val string_type : unit -> 'a datatype'
  val xml_type : unit -> 'a datatype'
  val native_string_type : unit -> 'a datatype'

  (* get type variables *)
  val free_type_vars : datatype -> TypeVarSet.t
  val free_row_type_vars : row -> TypeVarSet.t

  val free_bound_type_vars : datatype -> TypeVarSet.t
  val free_bound_row_type_vars : row -> TypeVarSet.t

  (* used to freshen mailboxes in typename aliases *)
  val freshen_mailboxes : datatype -> datatype

  (** Fresh type variables *)
  val fresh_raw_variable : unit -> int

  val bump_variable_counter : int -> unit

  (* type variable construction *)
  val make_type_variable : int -> datatype
  val make_rigid_type_variable : int -> datatype
  val make_row_variable : int -> row_var
    
  (* fresh type variable generation *)
  val fresh_type_variable : unit -> datatype
  val fresh_rigid_type_variable : unit -> datatype

  val fresh_row_variable : unit -> row_var
  val fresh_rigid_row_variable : unit -> row_var

  (** rows *)
  (* empty row constructors *)
  val make_empty_closed_row : unit -> 'a row'
  val make_empty_open_row : unit -> 'a row'

  (* singleton row constructors *)
  val make_singleton_closed_row : (string * 'a field_spec') -> 'a row'
  val make_singleton_open_row : (string * 'a field_spec') -> 'a row'

  (* row predicates *)
  val is_closed_row : 'a row' -> bool
  val is_absent_from_row : string -> 'a row' -> bool

  (* row_var retrieval *)
  val get_row_var : row -> int option

  (* row update *)
  val row_with : (string * 'a field_spec') -> 'a row' -> 'a row'

  (* constants *)
  val empty_field_env : unit -> 'a field_spec_map'
  val closed_row_var : unit -> row_var

  val make_tuple_type : datatype list -> datatype
  val make_tuple_utype : u_datatype list -> u_datatype
    
  val field_env_union : ('a field_spec_map' * 'a field_spec_map') -> 'a field_spec_map'

  val contains_present_fields : 'a field_spec_map' -> bool

  val is_canonical_row_var : row_var -> bool
  val is_rigid_row : row -> bool

  val is_rigid_row_with_var : int -> row -> bool

  val is_flattened_row : row -> bool
  val is_empty_row : row -> bool

  (** Convert a row to the form (field_env, row_var)
      where row_var is of the form:
      [ `Closed
      | `Flexible var
      | `Rigid var
      | `Recursive
      ]
  *)
  val flatten_row : row -> row

  (**
     As flatten_row except if the flattened row_var is of the form:

     `Recursive (var, rec_row)

     then it is unwrapped. This ensures that all the fields are exposed
     in field_env.

     Also returns the outermost `Recursive that was unwrapped if it exists,
     or None otherwise.
  *)
  val unwrap_row : row -> (row * row_var option)
  val unwrap_row' : 'a row' -> (row * row_var option)

  type type_alias_set = Utility.StringSet.t

  val type_aliases : datatype -> type_alias_set
  val row_type_aliases : row -> type_alias_set
    
  type dictionary = 
      { s_of_fq : 'a.'a fq -> string -> string;
	    s_of_d : 'a. dictionary -> TypeVarSet.t -> string IntMap.t -> 'a datatype' -> string;
        s_of_r : 'a. dictionary -> string -> TypeVarSet.t -> string IntMap.t -> 'a row' -> string;
        is_closed_row : 'a. dictionary -> TypeVarSet.t -> 'a row' -> bool;}
  val dictionary : dictionary
    
  (* pretty printing *)
  val string_of_datatype : dictionary -> 'a datatype' -> string
  val string_of_datatype_raw : dictionary -> 'a datatype' -> string
  val string_of_row : dictionary -> 'a row' -> string
  val string_of_row_var : row_var -> string
  val string_of_assumption : dictionary -> 'a assumption' -> string
    
  val make_fresh_envs : datatype -> datatype Utility.IntMap.t * row_var Utility.IntMap.t
  val make_rigid_envs : datatype -> datatype Utility.IntMap.t * row_var Utility.IntMap.t
  val make_wobbly_envs : datatype -> datatype Utility.IntMap.t * row_var Utility.IntMap.t
    
  val functor_type : ('a fq -> 'b fq) -> 'a datatype' -> 'b datatype'
  val functor_row : ('a fq -> 'b fq) -> 'a row' -> 'b row'

end

module Make (F : FableType) = 
struct
  
  (* Functor types *)
  type untyped_data = F.untyped_data
  type typed_data = F.typed_data
  type kind = F.kind
      deriving (Eq, Show, Pickle, Typeable, Shelve)

  type 'a fq = 'a F.fable_qualifier

  module FieldEnv = Utility.StringMap

  (* type var sets *)
  module TypeVarSet = Utility.IntSet

  (* points *)
  type 'a point = 'a Unionfind.point deriving (Eq, Typeable, Shelve, Show)
      
  (*   module Show_point (S : Show.Show) = Show.Show_unprintable(struct type a = S.a point end) *)
  module Pickle_point (S : Pickle.Pickle) = Pickle.Pickle_unpicklable(struct type a = S.a point let tname = "point" end)

  type primitive = [ `Bool | `Int | `Char | `Float | `XmlItem | `DB
  | `Abstract | `NativeString ]
      deriving (Eq, Typeable, Show, Pickle, Shelve)


  type 'a datatype' = {ltype: 'a ldatatype'; ftype : 'a fq}
  and meta_type_var_basis = Flexible of int
			    | Rigid of int
			    | UncheckedRecursive of (int * untyped_data datatype')
			    | Recursive of (int * typed_data datatype')
			    | Body of typed_data datatype'
  and meta_row_var_basis  = ClosedRow
			    | FlexibleRow of int
			    | RigidRow of int
			    | RecursiveRow of (int * typed_data row')
			    | BodyRow of typed_data row'
  and 'a ldatatype' =
      [ `Not_typed
      | `Primitive of primitive
      | `Function of ('a datatype' * 'a datatype' * 'a datatype')
      | `Record of 'a row'
      | `Variant of 'a row'
      | `Table of 'a datatype' * 'a datatype'
      | `Application of (string * ('a datatype') list)
      | `MetaTypeVar of meta_type_var]
  and 'a field_spec' = [ `Present of 'a datatype' | `Absent ]
  and 'a field_spec_map' = 'a field_spec' field_env
  and 'a row' = 'a field_spec_map' * row_var
  and row_var = meta_row_var_basis point
  and meta_type_var = meta_type_var_basis point

  (* Abbreviations *)
  type datatype = typed_data datatype'
  and  row = typed_data row'
  and  ldatatype = typed_data ldatatype'
  and  field_spec = typed_data field_spec'
  and  field_spec_map = typed_data field_spec_map'

  type u_datatype = untyped_data datatype'
  and  u_ldatatype = untyped_data ldatatype'
  and  u_field_spec = untyped_data field_spec'
  and  u_field_spec_map = untyped_data field_spec_map'
  and  u_row = untyped_data row'
      
  type type_variable = [`TypeVar of int | `RigidTypeVar of int | `RowVar of int]
      deriving (Eq, Typeable, Show, Pickle, Shelve)

  type quantifier = type_variable * kind
      deriving (Eq, Typeable, Show, Pickle, Shelve)

  type 'a assumption' = (quantifier list * 'a datatype')
  type u_assumption = untyped_data assumption'
  type assumption =   (quantifier list * datatype)
(*       deriving (Show) *)


  (* fable annotations *)
  let def_fable_annot (dt' : 'a ldatatype') : 'a datatype' = {ltype = dt'; ftype = F.def_annot ()}
  let fable_annot lt ft = {ltype = lt; ftype = ft}
  let add_fable_annot dt fq = {ltype = dt.ltype; ftype = F.combine fq dt.ftype}
    
  (* Generation of fresh type variables *)
  let type_variable_counter = ref 0

  let fresh_raw_variable : unit -> int =
    function () -> 
      incr type_variable_counter; !type_variable_counter

  let bump_variable_counter i = type_variable_counter := !type_variable_counter+i

  (* Caveat: Map.fold behaves differently between Ocaml 3.08.3 and 3.08.4

     let map_fold_increasing = ocaml_version_atleast [3; 8; 4]
  *)
  (*
    [NOTE]
    
    We use Map.fold and Set.fold too often to support OCaml versions prior to 3.08.4
  *)
  let _ =
    if not (ocaml_version_atleast [3; 8; 4]) then
      failwith ("Links requires OCaml version 3.08.4 or later")
    else
      ()

  (* type ops stuff *)
  let empty_field_env _ = FieldEnv.empty
  let closed_row_var _ = Unionfind.fresh ClosedRow
    

  let make_type_variable_annot a var = 
    let ltype = `MetaTypeVar (Unionfind.fresh (Flexible var)) in
      {ltype=ltype; ftype = a}
  let make_type_variable var = def_fable_annot (`MetaTypeVar (Unionfind.fresh (Flexible var)))
  let make_rigid_type_variable var = def_fable_annot (`MetaTypeVar (Unionfind.fresh (Rigid var)))
  let make_row_variable var = Unionfind.fresh (FlexibleRow var)
  let make_rigid_row_variable var = Unionfind.fresh (RigidRow var)

  type dictionary = 
      { s_of_fq : 'a.'a fq -> string -> string;
	s_of_d : 'a. dictionary -> TypeVarSet.t -> string IntMap.t -> 'a datatype' -> string;
        s_of_r : 'a. dictionary -> string -> TypeVarSet.t -> string IntMap.t -> 'a row' -> string;
        is_closed_row : 'a. dictionary -> TypeVarSet.t -> 'a row' -> bool;}

  let rec is_closed_row dict rec_vars (_, row_var) =
    match Unionfind.find row_var with
      | ClosedRow -> true
      | RigidRow _
      | FlexibleRow _ -> false
      | BodyRow row ->
          dict.is_closed_row dict rec_vars row
      | RecursiveRow (var, row) ->
          ((TypeVarSet.mem var rec_vars) or (dict.is_closed_row dict (TypeVarSet.add var rec_vars) row))
            
  let is_absent_from_row : dictionary -> string -> 'a row' -> bool =
    fun dict label (field_env, _ as row) -> 
      if FieldEnv.mem label field_env then
        FieldEnv.find label field_env = `Absent
      else
        dict.is_closed_row dict TypeVarSet.empty row
        
  let get_row_var : row -> int option = fun (_, row_var) ->
    let rec get_row_var' = fun rec_vars -> function
      | ClosedRow -> None
      | FlexibleRow var
      | RigidRow var -> Some var
      | RecursiveRow (var, (_, row_var')) ->
          if TypeVarSet.mem var rec_vars then
            None
          else
            get_row_var' (TypeVarSet.add var rec_vars) (Unionfind.find row_var')
      | BodyRow (_, row_var') ->
          get_row_var' rec_vars (Unionfind.find row_var')
    in
      get_row_var' TypeVarSet.empty (Unionfind.find row_var)
        
  let fresh_type_variable_annot a = make_type_variable_annot a (fresh_raw_variable ())
  let fresh_type_variable = make_type_variable -<- fresh_raw_variable
  let fresh_rigid_type_variable = make_rigid_type_variable -<- fresh_raw_variable
  let fresh_row_variable () = make_row_variable (fresh_raw_variable ())
  let fresh_rigid_row_variable () = make_rigid_row_variable (fresh_raw_variable ())

  let make_empty_closed_row () = empty_field_env (), closed_row_var ()
  let make_empty_open_row () = empty_field_env (), fresh_row_variable ()

  let make_singleton_closed_row (label, field_spec) =
    FieldEnv.add label field_spec (empty_field_env ()), (closed_row_var ())
  let make_singleton_open_row (label, field_spec) =
    FieldEnv.add label field_spec (empty_field_env ()), (fresh_row_variable ())

  let row_with : (string * 'a field_spec') -> 'a row' -> 'a row' = 
    fun (label, f) (field_env, row_var) -> 
      FieldEnv.add label f field_env, row_var

  (*** end of type_basis ***)


  (* remove any top-level `MetaTypeVars from a type *)
  let rec concrete_type t =
    match t.ltype with
      | `MetaTypeVar point ->
          begin
            match Unionfind.find point with
                | Body t -> concrete_type t
                | _ -> t
          end
      | _ -> t 
          
  module S = TypeVarSet 
  let rec free_type_vars' : S.t -> datatype -> S.t = fun rec_vars t ->
    match t.ltype with
      | `Not_typed               -> S.empty
      | `Primitive _             -> S.empty
      | `Function (f, m, t)      ->
          S.union_all [free_type_vars' rec_vars f; free_type_vars' rec_vars m; free_type_vars' rec_vars t]
      | `Record row
      | `Variant row             -> free_row_type_vars' rec_vars row
      | `Table (r, w)            -> S.union (free_type_vars' rec_vars r) (free_type_vars' rec_vars w)
      | `Application (_, datatypes) -> S.union_all (List.map (free_type_vars' rec_vars) datatypes)
      | `MetaTypeVar point       ->
          begin
            match Unionfind.find point with
              | Flexible var
              | Rigid var -> S.singleton(var)
              | Recursive (var, body) ->
                  if S.mem var rec_vars then
                    S.empty
                  else
                    free_type_vars' (S.add var rec_vars) body
              | Body t ->
                  free_type_vars' rec_vars t
          end
  and free_row_type_vars' : S.t -> row -> S.t = 
    fun rec_vars (field_env, row_var) ->
      let field_vars =
        FieldEnv.fold (fun _ t field_vars ->
                         match t with
                           | `Present t ->
                               S.union field_vars (free_type_vars' rec_vars t)
                           | `Absent ->
                               field_vars) field_env S.empty in
      let row_vars =
        match Unionfind.find row_var with
          | FlexibleRow var
          | RigidRow var -> S.singleton(var)
          | RecursiveRow (var, body) ->
              if S.mem var rec_vars then
                S.empty
              else
                free_row_type_vars' (S.add var rec_vars) body
          | BodyRow row ->
                free_row_type_vars' rec_vars row
          | ClosedRow -> S.empty
      in
        S.union field_vars row_vars
          
  let free_type_vars t = free_type_vars' S.empty t 
  and free_row_type_vars r = free_row_type_vars' S.empty r

  let field_env_union : ('a field_spec_map' * 'a field_spec_map') -> 'a field_spec_map' =
    fun (env1, env2) ->
      FieldEnv.fold (fun label field_spec env' ->
        FieldEnv.add label field_spec env') env1 env2

  let contains_present_fields field_env =
    FieldEnv.fold
      (fun _ field_spec present ->
         match field_spec with
           | `Present _ -> true
           | `Absent -> present
      ) field_env false
      
  let is_canonical_row_var row_var =
    match Unionfind.find row_var with
      | ClosedRow
      | FlexibleRow _
      | RigidRow _ -> true
      | RecursiveRow _
      | BodyRow _ -> false

  let foo x = ()

  let is_rigid_row : row -> bool =
    let rec is_rigid rec_vars (_, row_var) =
      match Unionfind.find row_var with
         | ClosedRow  -> true
         | RigidRow x -> foo x; true
         | FlexibleRow x -> foo x; false
         | RecursiveRow (var, row) ->
             ((TypeVarSet.mem var rec_vars) or (is_rigid (TypeVarSet.add var rec_vars) row))
         | BodyRow row ->
             is_rigid rec_vars row
    in
      is_rigid TypeVarSet.empty

  (* is_rigid_row_with_var var row
     returns true if row is rigid and has var as its row var
  *)
  let is_rigid_row_with_var : int -> row -> bool =
    fun var ->
      let rec is_rigid rec_vars (_, row_var) =
         match Unionfind.find row_var with
          | ClosedRow
          | FlexibleRow _ -> false
          | RigidRow var' -> var=var'
          | RecursiveRow (var', row) ->
              ((TypeVarSet.mem var' rec_vars) or (is_rigid (TypeVarSet.add var' rec_vars) row))
          | BodyRow row ->
              is_rigid rec_vars row
      in
        is_rigid TypeVarSet.empty


  let is_flattened_row : row -> bool =
    let rec is_flattened =
      fun rec_vars (_, row_var) ->
         match Unionfind.find row_var with
          | ClosedRow
          | FlexibleRow _
          | RigidRow _ -> true
          | BodyRow _ -> false
          | RecursiveRow (var, rec_row) ->
              if TypeVarSet.mem var rec_vars then true
              else is_flattened (TypeVarSet.add var rec_vars) rec_row
    in
      is_flattened TypeVarSet.empty

  let is_empty_row : row -> bool =
    let rec is_empty = fun rec_vars -> fun (field_env, row_var) ->
      FieldEnv.is_empty field_env &&
         begin
          match Unionfind.find row_var with
            | ClosedRow
            | RigidRow _
            | FlexibleRow _ -> true
            | RecursiveRow (var, _) when TypeVarSet.mem var rec_vars -> true
            | RecursiveRow (var, rec_row) -> is_empty (TypeVarSet.add var rec_vars) rec_row
            | BodyRow row -> is_empty rec_vars row
         end
    in
      is_empty TypeVarSet.empty

  module rec FunctorType : sig
    val functor_row : ('a fq -> 'b fq) -> IntSet.t ->  'a row' -> 'b row'
    val functor_field_env : ('a fq -> 'b fq) -> IntSet.t ->  'a field_spec_map' -> 'b field_spec_map'
    val functor_type : ('a fq -> 'b fq) -> IntSet.t ->  'a datatype' -> 'b datatype'
  end = struct 
    let adapt_empty : untyped_data fq -> typed_data fq = fun _ ->  `Empty
      
    let rec functor_row (adapter : 'a fq -> 'b fq) rec_vars : 'a row' -> 'b row' = fun (fsm, rv) ->
      (functor_field_env adapter rec_vars fsm, rv)
    and functor_field_env adapter rec_vars : 'a field_spec_map' -> 'b field_spec_map' = fun fsm -> 
      StringMap.fold (fun label fs fsm' -> match fs with 
                        `Absent -> StringMap.add label `Absent fsm'
                      | `Present t -> StringMap.add label (`Present (functor_type adapter rec_vars t)) fsm'
                   ) fsm StringMap.empty 
    and functor_type (adapter : ('a fq -> 'b fq)) rec_vars :  'a datatype' -> 'b datatype' = 
      let rec func_type : 'a datatype' -> 'b datatype' =
	fun {ltype = lt; ftype = ft} -> {ltype = func_ltype lt; ftype = adapter ft}
      and func_ltype  : 'a ldatatype' -> 'b ldatatype' = function
	| `Not_typed -> `Not_typed
	| `Primitive p -> `Primitive p
	| `Function (arg, mb, ret) -> `Function (func_type arg, func_type mb, func_type ret)
	| `Record row -> `Record (functor_row adapter rec_vars row)
	| `Variant row -> `Variant (functor_row adapter rec_vars row)
	| `Table (dt1, dt2) -> `Table (func_type dt1, func_type dt2) 
	| `Application (s, dtl) -> `Application (s, List.map func_type dtl) 
	| `MetaTypeVar mtv -> 
            match Unionfind.find mtv with
		UncheckedRecursive (i, t) -> 
                  if IntSet.mem i rec_vars then
                    `MetaTypeVar mtv
                  else
                    let rec_vars = IntSet.add i rec_vars in
                    let t' = FunctorType.functor_type adapt_empty rec_vars t in
                      Unionfind.change mtv (Recursive(i, t'));
		      `MetaTypeVar mtv
              | _ -> `MetaTypeVar mtv 
      in
	func_type
  end
    
  let functor_row (a : 'a fq -> 'b fq) (r :'a row') : 'b row' = FunctorType.functor_row a IntSet.empty r
  let functor_field_env a fe = FunctorType.functor_field_env a IntSet.empty fe
  let functor_type (a : 'a fq -> 'b fq) (t :'a datatype') : 'b datatype' = FunctorType.functor_type a IntSet.empty t
	
  (* 
     convert a row to the form (field_env, row_var)
     where Unionfind.find row_var is of the form:
     `Closed
     | `Rigid var
     | `Flexible var
     | `Recursive (var, body)
  *)
  let flatten_row : row -> row =
    let rec flatten_row' = 
      fun rec_env ((field_env, row_var) as row) ->
        let row' =
          match Unionfind.find row_var with
            | ClosedRow
            | FlexibleRow _
            | RigidRow _ -> row
            | RecursiveRow (var, rec_row) ->
                if IntMap.mem var rec_env then
                  row
                else
                  (let row_var' =
                     Unionfind.fresh (RecursiveRow (var, (FieldEnv.empty,
                                                        Unionfind.fresh (FlexibleRow var)))) in
                   let rec_row' = flatten_row' (IntMap.add var row_var' rec_env) rec_row in
                     Unionfind.change row_var' (RecursiveRow (var, rec_row'));
                     field_env, row_var')                 
            | BodyRow row' ->
                let field_env', row_var' = flatten_row' rec_env row' in
                  field_env_union (field_env, field_env'), row_var'
        in
          assert (is_flattened_row row');
          row'
    in
      flatten_row' IntMap.empty


  module rec UnwrapRow : sig
    val unwrap_row' : row_var IntMap.t -> 'a row' -> (row * row_var option)
    val unwrap_row : row_var IntMap.t -> row -> (row * row_var option)
  end = struct
	
    let adapter _ = `Kind F.UKind
    
    (*
      As flatten_row except if the flattened row_var is of the form:
      
      `Recursive (var, body)
      
      then it is unwrapped. This ensures that all the fields are exposed
      in field_env.
    *)
    let unwrap_row' rec_env (((field_env, row_var) as row) : 'a row') =
      match Unionfind.find row_var with
        | ClosedRow
        | FlexibleRow _
        | RigidRow _ -> functor_row adapter row, None
        | RecursiveRow (var, body) ->
            if IntMap.mem var rec_env then
              functor_row adapter row, Some row_var
            else
              begin
                let point =
                  Unionfind.fresh (RecursiveRow (var, body)) in
                let unwrapped_body, _ = UnwrapRow.unwrap_row' (IntMap.add var point rec_env) body in
                  Unionfind.change point (RecursiveRow (var, unwrapped_body));
                  let field_env', row_var' = unwrapped_body in
                  let field_env = functor_field_env adapter field_env in
                    (field_env_union (field_env, field_env'), row_var'), Some point
              end
        | BodyRow row' ->
            let (field_env', row_var'), rec_row = UnwrapRow.unwrap_row' rec_env row' in
              (field_env_union (functor_field_env adapter field_env, field_env'), row_var'), rec_row
		
    let rec unwrap_row rec_env ((field_env, row_var) as row) =
      let row' =
        match Unionfind.find row_var with
          | ClosedRow
          | FlexibleRow _
          | RigidRow _ -> row, None
          | RecursiveRow (var, body) ->
              if IntMap.mem var rec_env then
		row, Some row_var
              else
                begin
                  let point =
                    Unionfind.fresh (RecursiveRow (var, body)) in
                  let unwrapped_body, _ = unwrap_row (IntMap.add var point rec_env) body in
                    Unionfind.change point (RecursiveRow (var, unwrapped_body));
                    let field_env', row_var' = unwrapped_body in
                      (field_env_union (field_env, field_env'), row_var'), Some point
                end
          | BodyRow row' ->
              let (field_env', row_var'), rec_row = unwrap_row rec_env row' in
                (field_env_union (field_env, field_env'), row_var'), rec_row
      in
        assert (is_flattened_row (fst row'));
        row'
  end

  let unwrap_row = UnwrapRow.unwrap_row IntMap.empty
  let unwrap_row' x = UnwrapRow.unwrap_row' IntMap.empty x

  (* useful types *)
  let annot_ukind lt = fable_annot lt (`Kind F.UKind)
  let unit_type _ = annot_ukind (`Record (make_empty_closed_row ()))
  let bool_type _ = annot_ukind (`Primitive `Bool)
  let string_type _ = annot_ukind (`Application ("String", []))
  let xml_type _ = annot_ukind (`Application ("Xml", []))
  let native_string_type _ = annot_ukind (`Primitive `NativeString)

  (* --------------------------------------------------------------------------------
     This skeleton is here as a code template for use where necessary; 
     it's not actually called anywhere 
     --------------------------------------------------------------------------------*)
  (* skeleton for performing a fold over (inference) datatypes *)
  (*   let rec datatype_skeleton :  TypeVarSet.t -> 'a datatype' -> 'a datatype' = fun rec_vars -> *)
  (*     fun dt -> *)
  (*       let dt_skel = function  *)
  (*     | `Not_typed -> `Not_typed *)
  (*     | `Primitive p -> `Primitive p *)
  (*     | `Function (f, m, t) -> *)
  (*             `Function (datatype_skeleton rec_vars f, datatype_skeleton rec_vars m, datatype_skeleton rec_vars t) *)
  (*     | `Record row -> `Record (row_skeleton rec_vars row) *)
  (*     | `Variant row -> `Variant (row_skeleton rec_vars row) *)
  (*     | `Table (r, w) -> `Table (datatype_skeleton rec_vars r, datatype_skeleton rec_vars w) *)
  (*     | `Application (s, ts) -> `Application (s, List.map (datatype_skeleton rec_vars) ts) *)
  (*     | `MetaTypeVar point -> *)
  (*             `MetaTypeVar *)
  (*            (Unionfind.fresh *)
  (*                   (match Unionfind.find point with *)
  (*                      | `Flexible var -> `Flexible var *)
  (*                      | `Rigid var -> `Rigid var *)
  (*                      | `Recursive (var, t) -> *)
  (*                         if TypeVarSet.mem var rec_vars then *)
  (*                           `Recursive (var, t) *)
  (*                         else *)
  (*                           `Recursive (var, datatype_skeleton (TypeVarSet.add var rec_vars) t) *)
  (*                      | `Body t -> `Body (datatype_skeleton rec_vars t))) in *)
  (*    fable_annot (dt_skel (ltype dt)) (ftype dt) *)
  (*   and field_spec_skeleton = fun rec_vars -> *)
  (*     function *)
  (*       | `Present t -> `Present (datatype_skeleton rec_vars t) *)
  (*       | `Absent -> `Absent *)
  (*   and field_spec_map_skeleton = fun rec_vars field_env -> *)
  (*     FieldEnv.map (field_spec_skeleton rec_vars) field_env *)
  (*   and row_skeleton = fun rec_vars row -> *)
  (*     let field_env, row_var = row in (\*flatten_row row in*\) *)
  (*     let field_env' = field_spec_map_skeleton rec_vars field_env in *)
  (*     let row_var' = *)
  (*       Unionfind.fresh *)
  (*     (match Unionfind.find row_var with *)
  (*           | `Closed -> `Closed *)
  (*           | `Flexible var -> `Flexible var *)
  (*           | `Rigid var -> `Rigid var *)
  (*           | `Recursive (var, rec_row) -> *)
  (*            if TypeVarSet.mem var rec_vars then *)
  (*                 `Recursive (var, rec_row) *)
  (*            else *)
  (*                 `Recursive (var, row_skeleton (TypeVarSet.add var rec_vars) rec_row) *)
  (*           | `Body row -> *)
  (*            `Body (row_skeleton rec_vars row)) *)
  (*     in *)
  (*       field_env', row_var' *)
    

  (* whether to display mailbox annotations on arrow types
     [NOTE]
     unused mailbox parameters are never shown
  *)
  let show_mailbox_annotations = Settings.add_bool("show_mailbox_annotations", true, `User)
    
  (* pretty-print type vars as raw numbers rather than letters *)
  let show_raw_type_vars = Settings.add_bool("show_raw_type_vars", false, `User)

  (* Type printers *)

  exception Not_tuple

(*   let string_of_primitive : primitive -> string = function *)
(*     | `Bool -> "Bool"  | `Int -> "Int"  | `Char -> "Char"  | `Float   -> "Float"   *)
(*     | `XmlItem -> "XmlItem" | `DB -> "Database" | `Abstract -> "(abstract)" | `NativeString -> "NativeString" *)

  let string_of_primitive = Show_primitive.show
	
  let rec string_of_datatype' dict rec_vars vars datatype = 
    (*     let sd dt = dict.s_of_d dict rec_vars vars dt in *)
    
    let string_of_mailbox_arrow mailbox_type =
      begin
        if Settings.get_value(show_mailbox_annotations) then
          "-{" ^  dict.s_of_d dict rec_vars vars mailbox_type ^ "}->"
        else
          "->"
      end in
      
    let unwrap r = (fst (unwrap_row' r)) in
      (* precondition: the row is unwrapped *)
    let is_tuple ?(allow_onetuples=false) (field_env, rowvar) =
         match Unionfind.find rowvar with
                | ClosedRow ->
                let n = StringMap.size field_env in
                let b =
                      n = 0
                      ||
                      (List.for_all
                          (fun i ->
                         let name = string_of_int i in
                              FieldEnv.mem name field_env
                              && (match FieldEnv.find (string_of_int i) field_env with
                                | `Present _ -> true
                                | `Absent -> false))
                          (fromTo 1 n))
                in
                (* 0/1-tuples are displayed as records *)
                b && (allow_onetuples || n <> 1)
          | _ -> false
      in
         (* precondition: the row is unwrapped *)
      let string_of_tuple (field_env, row_var) =
         let tuple_env =
          FieldEnv.fold
            (fun i t tuple_env ->
                match t with
                | `Present t -> IntMap.add (int_of_string i) t tuple_env
                | `Absent -> assert false) field_env IntMap.empty in
         let ss = List.rev (IntMap.fold (fun _ t ss -> (dict.s_of_d dict rec_vars vars t) :: ss) tuple_env [])
         in
          "(" ^ String.concat ", " ss ^  ")"
      in
      let string_of_ldatatype = function
        | `Not_typed       -> "not typed"
        | `Primitive p     -> string_of_primitive p
        | `MetaTypeVar point ->
            begin
              match Unionfind.find point with
                | Flexible var
                | Rigid var -> IntMap.find var vars
		        | UncheckedRecursive(var, body) -> 
                    if TypeVarSet.mem var rec_vars then
                      IntMap.find var vars
                    else
                      "mu " ^ IntMap.find var vars ^ " . " ^
                        (dict.s_of_d dict (TypeVarSet.add var rec_vars) vars body)
                | Recursive (var, body) ->
                    if TypeVarSet.mem var rec_vars then
                      IntMap.find var vars
                    else
                      "mu " ^ IntMap.find var vars ^ " . " ^
                        (dict.s_of_d dict (TypeVarSet.add var rec_vars) vars body)
                | Body t ->  dict.s_of_d dict rec_vars vars t
            end
        | `Function (args, mailbox_type, t) ->
            let arrow =
              match mailbox_type.ltype with 
                  `MetaTypeVar point -> 
                    begin
                      match Unionfind.find point with 
                          Body t -> 
                            begin
                              match (concrete_type t).ltype with 
                                | `Application ("Mailbox", [t]) ->
                                    string_of_mailbox_arrow (t)
                                | _ -> "->"
                            end
                        | t' -> "->" 
                    end
                | `Application ("Mailbox", [t]) ->
                    string_of_mailbox_arrow (t)
                | _ -> "->" in
            begin
              match args.ltype with
                | `MetaTypeVar point -> 
                    begin
                      match Unionfind.find point with 
                          Body b -> 
                            begin
                              match (concrete_type b).ltype with 
                                | `Record row when is_tuple ~allow_onetuples:true row ->
                                  string_of_tuple row ^ " " ^arrow ^ " " ^ dict.s_of_d dict rec_vars vars t
                                | _ ->
                                    "*" ^  dict.s_of_d dict rec_vars vars args ^ " " ^arrow ^ " " ^  dict.s_of_d dict rec_vars vars t
                            end
                        | _ ->
                            "*" ^  dict.s_of_d dict rec_vars vars args ^ " " ^arrow ^ " " ^  dict.s_of_d dict rec_vars vars t
                    end
                      
                | `Record row when is_tuple ~allow_onetuples:true row ->
                  string_of_tuple row ^ " " ^arrow ^ " " ^ dict.s_of_d dict rec_vars vars t
                | _ -> 
                    "*" ^  dict.s_of_d dict rec_vars vars args ^ " " ^arrow ^ " " ^  dict.s_of_d dict rec_vars vars t
            end               
        | `Record row      ->
            let row = unwrap row in
            (if is_tuple row then string_of_tuple row
             else "(" ^ dict.s_of_r dict "," rec_vars vars row ^ ")")
        | `Variant row    -> "[|" ^ dict.s_of_r dict "|" rec_vars vars row ^ "|]"
        | `Table (r, w)   ->
            "TableHandle(" ^
              dict.s_of_d dict rec_vars vars r ^ "," ^
              dict.s_of_d dict rec_vars vars w ^ ")"
              (*
                [QUESTION]
                How should we render the types [Char] and [XmlItem]?

                  It isn't clear what the right thing to do here is.

                  Option 1 - as lists
                  Then
                  ['a', 'b', 'c] : [Char]
                  but
                  "abc" ++ "def" : [Char]

                  Option 2 - as typenames
                  Then
                  "abc" ++ "def" : String
                  but
                  ['a', 'b', 'c] : String

                  What do GHCi and SML/NJ Do?
                  *)
                  (*
                  | `Application ("List", [`Primitive `Char]) -> "String"
                  | `Application ("List", [`Primitive `XmlItem]) -> "Xml"
                  *)
          | `Application ("List", [elems])              ->  "["^  dict.s_of_d dict rec_vars vars elems ^"]"
          | `Application (s, []) -> s
          | `Application (s, ts) ->  s ^ " ("^ String.concat "," (List.map  (dict.s_of_d dict rec_vars vars) ts) ^")"
          | _ -> raise Impos in
	  (dict.s_of_fq datatype.ftype) (string_of_ldatatype datatype.ltype)
	  
  and string_of_row' dict sep rec_vars vars (field_env, row_var) =
    let show_absent =
      if dict.is_closed_row dict TypeVarSet.empty (field_env, row_var) then
        (fun _ x -> x) (* don't show absent fields in closed rows *)
      else
        (fun label (present_strings, absent_strings) -> present_strings, (label ^ "- ") :: absent_strings) in
      
    let present_strings, absent_strings =
      FieldEnv.fold (fun label t (present_strings, absent_strings) ->
        match t with
          | `Present t ->
              (label ^ ":" ^ dict.s_of_d dict rec_vars vars t) :: present_strings, absent_strings
          | `Absent ->
              show_absent label (present_strings, absent_strings)) field_env ([], []) in

    let row_var_string = string_of_row_var' dict sep rec_vars vars row_var in
      (String.concat sep (List.rev (present_strings) @ List.rev (absent_strings))) ^
        (match row_var_string with
          | None -> ""
          | Some s -> "|"^s)
  and string_of_row_var' dict sep rec_vars vars row_var = 
    match Unionfind.find row_var with
      | ClosedRow -> None
      | FlexibleRow var
      | RigidRow var ->
          Some (IntMap.find var vars)
      | RecursiveRow (var, row) ->
          if TypeVarSet.mem var rec_vars then
            Some (IntMap.find var vars)
          else
            Some ("(mu " ^ IntMap.find var vars ^ " . " ^
                    dict.s_of_r dict sep (TypeVarSet.add var rec_vars) vars row ^ ")")
      | BodyRow row -> Some (dict.s_of_r dict sep rec_vars vars row)

  let make_names vars =
    if Settings.get_value (show_raw_type_vars) then
      TypeVarSet.fold (fun var (name_map) -> IntMap.add var (string_of_int var) name_map) vars IntMap.empty
    else
      begin
         let first_letter = int_of_char 'a' in
         let last_letter = int_of_char 'z' in
         let num_letters = last_letter - first_letter + 1 in
          
         let string_of_ascii n = Char.escaped (char_of_int n) in
          
         let rec num_to_letters n =
          let letter = string_of_ascii (first_letter + (n mod num_letters)) in
            letter ^
                (if n >= num_letters then (num_to_letters (n / num_letters))
                  else "")
         in
          
         let (_, name_map) = 
          TypeVarSet.fold (fun var (n, name_map) -> (n+1, IntMap.add var (num_to_letters n) name_map)) vars (0, IntMap.empty)
         in
          name_map
      end

  (* freshen uninstantiated mailbox types

     precondition:
     the input type is closed (apart from free mailbox types)
  *)
  let rec freshen_mailboxes rec_vars t : 'a datatype' = 
    let fmb = freshen_mailboxes rec_vars in
    let fmb_ldt t = match t with
      | `Not_typed  
      | `Primitive _ -> t
      | `MetaTypeVar point ->
          begin
            match Unionfind.find point with
              | Flexible _
              | Rigid _ -> t
              | Recursive (var, body) ->
                  if TypeVarSet.mem var rec_vars then
                    t
                  else
                    `MetaTypeVar
                      (Unionfind.fresh
                         (Recursive (var, freshen_mailboxes (TypeVarSet.add var rec_vars) body)))
              | Body t -> (fmb t).ltype
          end 
      | `Function (f, m, t) ->
          `Function (
            fmb  f,
            begin
              match m.ltype with
                | `MetaTypeVar point ->
                    begin
                      match Unionfind.find point with
                        | Flexible var ->
                            fresh_type_variable_annot m.ftype
                        | _ -> fmb m
                    end
                | _ -> fmb  m
            end,
            fmb  t)
      | `Record row -> `Record (row_freshen_mailboxes rec_vars row)
      | `Variant row -> `Variant (row_freshen_mailboxes rec_vars row)
      | `Table (r, w) -> `Table (fmb r, fmb w)
      | `Application (name, datatypes) -> `Application (name, List.map fmb datatypes) in
      {ltype = (fmb_ldt (t.ltype)); ftype = t.ftype}
  and row_freshen_mailboxes rec_vars (field_env, row_var) =
    (FieldEnv.map (fun t ->
      match t with
         | `Present t ->
            `Present (freshen_mailboxes rec_vars t)
         | `Absent ->
            `Absent) field_env,
    row_var_freshen_mailboxes rec_vars row_var)
  and row_var_freshen_mailboxes rec_vars row_var = 
    match Unionfind.find row_var with
      | ClosedRow
      | FlexibleRow _
      | RigidRow _ -> row_var
      | RecursiveRow (var, row) ->
          if TypeVarSet.mem var rec_vars then
            row_var
          else
            Unionfind.fresh
                (RecursiveRow (var,
                          row_freshen_mailboxes (TypeVarSet.add var rec_vars) row))
      | BodyRow row ->
          Unionfind.fresh
            (BodyRow (row_freshen_mailboxes rec_vars row))
            
  let freshen_mailboxes x = freshen_mailboxes TypeVarSet.empty x
  let row_freshen_mailboxes x = row_freshen_mailboxes TypeVarSet.empty x
  let row_var_freshen_mailboxes x = row_var_freshen_mailboxes TypeVarSet.empty x

  (* find all free and bound type variables in a  *)
  let rec free_bound_type_vars : TypeVarSet.t -> datatype -> TypeVarSet.t = fun rec_vars t ->
    let fbtv = free_bound_type_vars rec_vars in
      match t.ltype with
        | `Not_typed               -> TypeVarSet.empty
        | `Primitive _             -> TypeVarSet.empty
        | `MetaTypeVar point ->
            begin
              match Unionfind.find point with
                | Flexible var
                | Rigid var -> TypeVarSet.singleton var
                | Recursive (var, body) ->
                    if TypeVarSet.mem var rec_vars then
                      TypeVarSet.empty
                    else
                      TypeVarSet.add var (free_bound_type_vars (TypeVarSet.add var rec_vars) body)
                | Body t -> fbtv t
            end
        | `Function (f, m, t)      ->
            TypeVarSet.union
              (TypeVarSet.union (fbtv f) (fbtv t))
              (fbtv m)
        | `Record row
        | `Variant row -> free_bound_row_type_vars rec_vars row
        | `Table (r, w) -> TypeVarSet.union (fbtv r) (fbtv w)
        | `Application (_, datatypes) -> List.fold_right TypeVarSet.union (List.map fbtv datatypes) TypeVarSet.empty
  and free_bound_row_type_vars rec_vars (field_env, row_var) =
    let field_type_vars =
      FieldEnv.fold (fun _ t tvs ->
                       match t with
                         | `Present t ->
                             TypeVarSet.union tvs (free_bound_type_vars rec_vars t)
                         | `Absent ->
                             tvs) field_env TypeVarSet.empty in
    let row_var = free_bound_row_var_vars rec_vars row_var in
      TypeVarSet.union field_type_vars row_var  
  and free_bound_row_var_vars rec_vars row_var = 
    match Unionfind.find row_var with
      | ClosedRow -> TypeVarSet.empty
      | FlexibleRow var
      | RigidRow var ->
          TypeVarSet.singleton var
      | RecursiveRow (var, row) ->
          if TypeVarSet.mem var rec_vars then
            TypeVarSet.empty
          else
            TypeVarSet.add var
              (free_bound_row_type_vars (TypeVarSet.add var rec_vars) row)
      | BodyRow row -> free_bound_row_type_vars rec_vars row

  let free_bound_type_vars x = free_bound_type_vars TypeVarSet.empty x
  let free_bound_row_type_vars x = free_bound_row_type_vars TypeVarSet.empty x
  let free_bound_row_var_vars x = free_bound_row_var_vars TypeVarSet.empty x

  let rec type_aliases : TypeVarSet.t -> datatype -> StringSet.t = fun rec_vars t ->
    let tas = type_aliases rec_vars in
      match t.ltype with
         | `Not_typed
         | `Primitive _ -> StringSet.empty
         | `MetaTypeVar point ->
            begin
                match Unionfind.find point with
                | Flexible var
                | Rigid var -> StringSet.empty
                | Recursive (var, body) ->
                    if TypeVarSet.mem var rec_vars then
                         StringSet.empty
                    else
                         type_aliases (TypeVarSet.add var rec_vars) body
                | Body t -> tas t
            end
         | `Function (f, m, t) ->
            StringSet.union
                (StringSet.union (tas f) (tas t))
                (tas m)
         | `Record row
         | `Variant row -> row_type_aliases rec_vars row
         | `Table (r, w) -> StringSet.union (tas r) (tas w)
         | `Application (alias, datatypes) -> List.fold_right StringSet.union (List.map tas datatypes) (StringSet.singleton alias)
  and row_type_aliases rec_vars (field_env, row_var) =
    let field_type_aliases = 
      FieldEnv.fold (fun _ t ftas ->
        match t with
          | `Present t ->
              StringSet.union ftas (type_aliases rec_vars t)
          | `Absent ->
              ftas) field_env StringSet.empty in
    let row_var = row_var_type_aliases rec_vars row_var in
      StringSet.union field_type_aliases row_var  
  and row_var_type_aliases rec_vars row_var = 
    match Unionfind.find row_var with
      | ClosedRow
      | FlexibleRow _
      | RigidRow _ -> StringSet.empty
      | RecursiveRow (var, row) ->
          if TypeVarSet.mem var rec_vars then
            StringSet.empty
          else
            row_type_aliases (TypeVarSet.add var rec_vars) row
      | BodyRow row -> row_type_aliases rec_vars row

  (* type aliases *)
  type type_alias_set = Utility.StringSet.t

  let type_aliases  = type_aliases TypeVarSet.empty
  let row_type_aliases = row_type_aliases TypeVarSet.empty

  let dictionary = {
    s_of_fq = (fun _ -> fun _ -> "");
    s_of_d = string_of_datatype';
    s_of_r = string_of_row';
    is_closed_row = is_closed_row;
  }
    
  let is_closed_row : 'a row' -> bool = 
    fun r -> 
      dictionary.is_closed_row dictionary TypeVarSet.empty r
        
  let is_absent_from_row : string -> 'a row' -> bool =
    fun s r -> 
      is_absent_from_row dictionary s r

  (* string conversions *)
  (* TODO ... fix `Empty functorization; use dictionary.s_of_fq *)
  let string_of_datatype dictionary (datatype : 'a datatype')  = 
    dictionary.s_of_d dictionary TypeVarSet.empty (make_names (free_bound_type_vars (functor_type (fun x -> `Empty) datatype))) datatype
      
  let string_of_datatype_raw dictionary datatype = 
    dictionary.s_of_d dictionary
      TypeVarSet.empty (TypeVarSet.fold
			  (fun var name_map -> IntMap.add var (string_of_int var) name_map)
			  (free_bound_type_vars (functor_type (fun x -> `Empty) datatype)) IntMap.empty) datatype
      
      
  let string_of_row dictionary row =
    dictionary.s_of_r dictionary "," TypeVarSet.empty (make_names (free_bound_row_type_vars (functor_row (fun x -> `Empty) row))) row
      
  let string_of_row_var row_var =
    match string_of_row_var' dictionary "," TypeVarSet.empty (make_names (free_bound_row_var_vars row_var)) row_var with
      | None -> ""
      | Some s -> s

  let string_of_quantifier (v,_) = match v with
    | `TypeVar var -> string_of_int var
    | `RigidTypeVar var -> string_of_int var
    | `RowVar var -> "'" ^ string_of_int var
  let string_of_assumption dictionary = function
    | [], datatype -> string_of_datatype dictionary datatype
    | assums, datatype -> "forall " ^ (String.concat ", " (List.map string_of_quantifier assums)) ^" . "^ string_of_datatype dictionary datatype

  let make_fresh_envs : datatype -> datatype IntMap.t * row_var IntMap.t =
    let module M = IntMap in
    let empties = M.empty, M.empty in 
    let union2 a b = M.fold M.add a b in
    let union2both (l,r) (ll,rr) = (union2 l ll, union2 r rr) in
    let union = List.fold_left union2both empties in
    let rec makeEnv recvars dt = match dt.ltype with 
      | `Not_typed
      | `Primitive _             -> empties
      | `Function (f, m, t)      -> union [makeEnv recvars f; makeEnv recvars m; makeEnv recvars t]
      | `Record row              
      | `Variant row             -> makeEnvR recvars row
      | `Table (l,r)             -> union [makeEnv recvars l; makeEnv recvars r]
      | `Application (_, ds)     -> union (List.map (makeEnv recvars) ds)
      | `MetaTypeVar point       ->
          begin
            match Unionfind.find point with
              | Rigid var -> let l,r = empties in
                                    (M.add var (fresh_rigid_type_variable ()) l, r)
              | Flexible var -> let l, r = empties in
                                        (M.add var (fresh_type_variable ()) l, r)
              | Recursive (l, _) when List.mem l recvars -> empties
              | Recursive (l, b) -> makeEnv (l::recvars) b
              | Body t -> makeEnv recvars t
          end
    and makeEnvR recvars ((field_env, row_var):row) =
      let field_vars = 
         FieldEnv.fold (fun _ t envs ->
          match t with 
              `Present t -> union [envs; makeEnv recvars t]
            | `Absent -> envs) field_env empties
      and row_vars = 
         match Unionfind.find row_var with
          | ClosedRow -> empties
          | FlexibleRow var -> let l, r = empties in
                                   (l, M.add var (fresh_row_variable ()) r)
          | RigidRow var -> let l, r = empties in
                                (l, M.add var (fresh_rigid_row_variable ()) r)
          | RecursiveRow (l, _) when List.mem l recvars -> empties
          | RecursiveRow (l, row) -> makeEnvR (l::recvars) row
          | BodyRow row -> makeEnvR recvars row
      in union [field_vars; row_vars]
    in makeEnv []

  let make_rigid_envs datatype : datatype IntMap.t * row_var IntMap.t =
    let tenv, renv = make_fresh_envs datatype in
      (IntMap.map (fun _ -> fresh_rigid_type_variable ()) tenv,
      IntMap.map (fun _ -> fresh_rigid_row_variable ()) renv)

  let make_wobbly_envs datatype : datatype IntMap.t * row_var IntMap.t =
    let tenv, renv = make_fresh_envs datatype in
      (IntMap.map (fun _ -> fresh_type_variable ()) tenv,
       IntMap.map (fun _ -> fresh_row_variable ()) renv)

  let make_tuple_ltype (ts : 'a datatype' list) : 'a ldatatype' =
    let ecr : 'a row' = make_empty_closed_row () in
      `Record
        (snd
           (List.fold_left
              (fun (n, row) t -> n+1, row_with (string_of_int n, `Present t) row)
              (1, ecr)
              ts))
        
  let make_tuple_utype (ts : u_datatype list) : u_datatype =
    annot_ukind ((make_tuple_ltype : u_datatype list -> u_ldatatype) ts)
      
  let make_tuple_type (ts : datatype list) : datatype =
    annot_ukind (make_tuple_ltype ts)    
      
end
  
