#!/bin/bash
perl -ne 'if (/include "(.*)"/) { open FILE, ("./" . $1); print while (<FILE>); } else {print}' $1
