(** Provides utility function to transform database queries.
	@version 2.0
	@author Gilles Dubochet *)

open Num
open List

open Syntax
open Expression
open Expression.Expr
open Utility
open Syntax.Sql
open Query

let call_stored_procs = Settings.add_bool("call_stored_procs", true, `User)

let col_unique_name = Utility.gensym ~prefix:"col"

(** Restricts the columns to be selected from a table query by
      specifying all columns to keep. Fails if at least one
      of the column to keep was not selected in the original
      query.
    @param projs A list of the columns to keep in the query.
    @param query The query to modify.
    @return The modified query. *)
let rec project (projs:string list) (query:query) : query =
  match projs with 
      [] -> query
    | _ -> 
	let required_cols = List.filter (function 
					   | Left col -> mem col.col_alias projs 
					   | _   -> false) query.result_cols in
	let col_names = List.map (function Left col -> col.col_alias) required_cols in
	  {query with projections = col_names}
	    
(* Types involved in backtracing variable origins *)

type projection_source = {field_name : string; field_var : string;
                          etc_var : string; source_var : string}

(** A variable declaration stub. *)
type binding = [
| `Table_loop of (string * query)
    (** The variable is the looping variable for a loop on a
        table. Second field is the SQL name of the table. *)
| `Selected of projection_source
    (** The variable comes from a record selection operation with {ol
        {li the extracted field,} {li the variable bound to the field,}
        {li the variable bound to the row,} {li the source variable.} } *)
| `Calculated of (string * Syntax.expression)
    (** The variable is calculated (that is, NOT a simple record selection 
        on a variable) *)
| `QCalculated of (string * Query.expression)
    (** The variable that has already be calculated into a query expression *)
| `Unavailable of string
]

(** bindings
    A list of bindings. This list can be used to reconstruct a record
    selection tower. *)
type bindings = binding list

(** The required precondition values to calculate a variable.  *)
type origin = [
  | `Table_field of (string * string) (** The variable is a field of the table loop *)
  | `Table of Query.query (** The variable represents a whole row of the given table *)
  | `Earlier of (string * projection_source list) (** The variable is based on a variable defined before the bindings start, but requires the given list of selections before it can be used. *)
  | `QCalculated of Query.expression
  | `Unavailable (** The variable cannot be used in a query *)
]

(** Finds a binding for a particular variable name in a binding list.
	@param bindings The binding list to search.
	@param name The name of the variable to lookup.
	@return The binding or `Unbound if nothing could be found. *)
let rec variable_binding (name:string) (bindings:bindings) : [`Unbound | binding] =
  match bindings with
    | [] -> `Unbound
    | (`Table_loop (variable, _) as binding) :: _ when variable = name -> binding
    | (`Selected s as binding) :: _ when s.etc_var = name -> binding
    | (`Selected s as binding) :: _ when s.field_var = name -> binding
    | (`Calculated (variable, _) as binding) :: _ when variable = name -> binding
    | (`QCalculated (variable, _) as binding) :: _ when variable = name -> binding
    | (`Unavailable variable as binding) :: _ when variable = name -> binding
    | _ :: bindings -> variable_binding name bindings

exception ColumnNotInQuery of string

(** query_field_for_var
    Given a query and a field name (an AS name), tell me which table
    (using its AS name) and which column (using its REAL name) it
    corresponds to.
*)
let query_field_for_var query field =
  try
  find ((<>) `Unavailable)
    (map (function
            | Left col when col.col_alias = field ->
                `Table_field (col.table_alias, col.name)
            | Left _ -> `Unavailable
            | Right ec when ec.exprcol_alias = field -> 
                `Table_field (ec.exprcol_table_alias, ec.exprcol_alias)
	    | Right _ -> `Unavailable)
       query.result_cols)
  with Not_found -> raise(ColumnNotInQuery(field))
    
(** trace_variable
    Finds the origin of a given variable according to a given binding.
    @param name The name of the variable to lookup.
    @param bindings The binding list to search.
    @return  *)
(*  TODO: Support calculated variables *)
(*  TODO: Use new variable names for origin trace *)
let rec trace_variable (name:string) (bindings:bindings) : origin =
  let rec field_from_trace trace_list = (
    match trace_list with
      | `Selected s :: _ when s.field_var = name -> `Field s.field_name
      | `Selected _ :: trace_list -> field_from_trace trace_list
      | `Table_row _ :: _ -> `Row
      | _ -> `Unavailable
  ) in
  let rec selects_from_trace trace_list select_list = (
    match trace_list with
      | [] -> (name, select_list)
      | `Selected s :: trace_list ->
	  selects_from_trace trace_list (s :: select_list)
      | _ -> failwith "TR087"
  ) in
  let rec trace_back name trace_list = (
    match (variable_binding name bindings) with
      | `Table_loop (_, query) ->
          `Table_row query :: trace_list
      | `Selected s as frame ->
	  trace_back s.source_var (frame :: trace_list)
      | `Calculated e -> `Unavailable :: trace_list
      | `QCalculated (_, e) -> `QCalculated e :: trace_list
      | `Unavailable _ -> `Unavailable :: trace_list
      | `Unbound -> `Unbound :: trace_list
  ) in
    match (trace_back name []) with
      | `Table_row query :: trace_list ->
 	  (match (field_from_trace trace_list) with
             | `Field field -> query_field_for_var query field
	     | `Unavailable -> `Table query (* BROKEN? could it truly be unavailable? *)
	     | _ -> `Unavailable)
      | `Unbound :: trace_list -> `Earlier (selects_from_trace trace_list [])
      | [`QCalculated e] -> `QCalculated e
      | `Unavailable :: _ -> `Unavailable
      | [] -> `Earlier (name, [])
      | `Selected _ :: _ -> failwith "TR105"

(** sep_assgmts
    Given an expression that consists of several assignments (lets or
    record_selections) wrapped around an inner expression, sep_assgmts
    returns a pair of the inner expression with a list that shows
    where each bound variable came from. Currently it only handles
    trivial projections of the form x.a where x is a variable term;
    all other assignments are considered "unavailable".

    @param expr The candidate syntax expression.
    @param bindings The bindings available where the expression occures.
    @return {i true} if the expression can be used, {i false} otherwise. *)
(*  TODO: Support calculated variables *)
let rec sep_assgmts (bindings:bindings) (expr:Syntax.expression) : (bindings * Syntax.expression) =
  match expr with
    | Expression.Expr.Let (_, Expression.Expr.Variable _, _, _) ->
	failwith "TR115 (renaming declarations should have been removed by earlier optimisations)"
    | Expression.Expr.Let (variable, _, body, _) ->
	sep_assgmts ((`Unavailable variable)::bindings) body (* restored queuing behavior *)
	  (*         failwith "Internal error: Let in sep_assgmts" (\* was queueing `Unavailable variable onto bindings & continuing *\) *)
    | Expression.Expr.Record_selection (label, label_variable, variable, Expression.Expr.Variable (name, _), body, _) ->
	(sep_assgmts (`Selected {field_name = label; field_var = label_variable; etc_var = variable; source_var = name} :: bindings) body)
    | Expression.Expr.Record_selection (_, _, _, _, body, _) ->
	(sep_assgmts bindings body)
          (* FIXME: This next case is unused. Why is it here? *)
    | Expression.Expr.Record_selection (_, _, variable, _, body, _) ->
	(sep_assgmts (`Unavailable variable :: bindings) body)
    | expr -> (bindings, expr)

let rec is_free var expr = mem var (freevars expr)


(* Compile a regular expression to a string suitable for passing to
   the SQL "like" operator.

   (NB: this assumes that '%' can be quoted as '\\%' in a like
    expression, which may turn out to be false.)
*)
(* TODO: make this less appalling, somehow. *)
let likify_regex bindings (e : 'a Expression.Expr.expression') : (like_expr * projection_source list) option = 
  let rec likify_regex' bindings e =
    let unpair : 'a Expression.Expr.expression' -> ('a Expression.Expr.expression' * 'a Expression.Expr.expression') option  = function
      | Record_intro (fields, None, _)
      | Record_intro (fields, None, _)
        when StringMap.mem "1" fields
            && StringMap.mem "2" fields
            && StringMap.size fields == 2
        -> Some (StringMap.find "1" fields, StringMap.find "2" fields)
    | _ -> None in
  let rec unlist = function
    | List_of (x,_) -> [x]
    | Concat (l, r,_) -> unlist l @ unlist r 
    | Nil _ -> [] in
  let quote = Str.global_replace (Str.regexp_string "%") "\\%" in
  let visitor default : 'a Expression.Expr.expression' -> (like_expr * projection_source list) option = function
    | Variant_injection ("Repeat", pair, _) -> 
        (match unpair pair with 
           | Some (Variant_injection ("Star", _, _), Variant_injection ("Any", _, _)) ->  
	       Some (`percent, [])
           | _ -> None)
    | Variant_injection ("Any", _, _) -> Some(`underscore, [])
    | Variant_injection ("StartAnchor", _, _) -> Some(`caret, [])
    | Variant_injection ("EndAnchor", _, _) -> Some(`dollar, [])
    | Variant_injection ("Simply", HasType(Constant(String s, _), _, _),  _) 
    | Variant_injection ("Simply", Constant(String s, _), _) -> 
	Some (`string (quote s), [])
    | Variant_injection ("Simply", HasType(Expression.Expr.Variable (name, _), _, _), _) 
    | Variant_injection ("Simply", Expression.Expr.Variable (name, _), _) -> 
	(match trace_variable name bindings with
	   | `Earlier (rename, origin) ->
	       Some (`variable rename, origin) (*where origins come from*)
           | `Table_field (tn, cn) -> failwith "Internal error: Table_field in regexes not yet implemented"
	   | _ ->  failwith "Internal error: Invalid expression in regex"
        )
    | Variant_injection ("Seq", rs, _) -> 
        let x = opt_sequence (List.map (likify_regex' bindings) (unlist rs)) in 
        (match x with
           | None -> None
           | Some s -> let a, b = split s in 
                         Some (`seq a, List.concat b))
    | other -> default other
  and combiner (_, (l : (like_expr * projection_source list) option list)) : (like_expr * projection_source list) option =  
    let f s =
      let likes, origin_lists = split s in
        (`seq likes, List.concat origin_lists) 
    in opt_map f (opt_sequence l)
  in Syntax.reduce_expression visitor combiner e in
  let maybe_unanchor = function
      None -> None
    | Some(like, origin_lists) -> 
	let rec flatten_like_expr accum = function
	  |  [] -> accum
	  | `seq rs::tl -> flatten_like_expr (flatten_like_expr accum rs) tl
	  |  hd::tl ->  flatten_like_expr (hd::accum) tl in
	let revlike = flatten_like_expr [] [like] in
	let flike = match revlike with `dollar::tl -> rev tl | l -> rev (`percent::l) in
	let flike = match flike with `caret::tl -> tl | _ -> `percent::flike in
	(Some(`seq flike, origin_lists)) in
  maybe_unanchor (likify_regex' bindings e) 

      
(** make_sql
    Converts an expression from the constant/variable sublanguage into
    an SQL expression (with respect to the given environment,
    `bindings')
*)
    
let rec make_sql bindings expr =
  match expr with
    | Expression.Expr.Constant(Expression.Boolean value, _) -> Some (Boolean value, [])
    | Expression.Expr.Constant(Expression.Integer value, _) -> Some (Integer value, [])
    | Expression.Expr.Constant(Expression.Float value, _) -> Some (Float value, [])
    | Expression.Expr.Constant(Expression.String value, _) -> Some (Text value, [])
    | Expression.Expr.Variable (name, _) ->
	let make_var name = match (trace_variable name bindings) with
	  | `Table_field (table, field) ->
	      Some (Field (table, field), [])
	  | `Earlier (rename, origin) ->
	      Some (Variable rename, origin) (*where origins come from*)
	  | `QCalculated e -> Some(e, [])
	  | `Table _
	  | `Unavailable -> None in
	  make_var name
(* 	let t = Expression.Types.concrete_type (Syntax.node_datatype expr) in *)
(* 	  (match t.Expression.Types.ltype with  *)
(* 	       `Primitive `Bool *)
(* 	     | `Primitive `Int *)
(* 	     | `Primitive `Float  *)
(* 	     | `Application("String", []) -> make_var name *)
(* 	     | _ ->  *)
(* 		 (try  *)
(* 		    let _ = Fable.get_label_type_expr t.Expression.Types.ftype in *)
(* 		      make_var name *)
(* 		  with *)
(* 		      Not_found -> None)) *)
      | Expression.Expr.Apply (Expression.Expr.Variable(fname, `T(_, _, Some "policy")), args, pos)
	  when Settings.get_value call_stored_procs ->  
	  let b_args  = List.map (sep_assgmts bindings) args in
	  let l = List.map (fun (binds, arg) -> make_sql binds arg) b_args in
	    (try 
	       let args, origins = List.fold_left (fun (args, origins) -> function 
						       None -> raise Utility.EmptyOption
						     | Some(sql, origin) -> sql::args, origin @ origins) ([],[]) l in
		 Some(Funcall(fname, List.rev args), List.rev origins)
	     with
		 Utility.EmptyOption -> None)
	      
      | _ -> None
	  (* Resurrect this if we really want to inline label constants *)
	  (* let t = Syntax.node_datatype expr in *)
	  (*   try  *)
	  (* 	    let _ = Fable.get_label_type_expr t.Expression.Types.ftype in *)
	  (* 	      if Utility.StringSet.is_empty (Syntax.freevars expr) then (\* ok ... we have a value; can serialize this right away *\) *)
	  (* 		Some (Text (Syntax.string_of_expression expr), []) *)
	  (* 	      else (\* Not yet a value; have to wait until interpretation before serializing *\) *)
	  (* 		None (\* Note: come back to this. Use an optimiser pass to let-expand this before serializing *\) *)
	  (* 	  with  *)
	  (* 	      Not_found -> None (\* this is not a pure variant; not safe to serialize to DB *\) *)
	  

let make_binop_sql oper left_value right_value =
  match oper with
    | `Equal -> Binary_op ("=", left_value, right_value)
    | `LessEq -> Binary_op ("<=", left_value, right_value)
    | `Less  -> Binary_op ("<", left_value, right_value)
    | `NotEq -> Binary_op ("<>", left_value, right_value)
    | `Tilde  -> Binary_op ("like", left_value, right_value)


        
(** Convert a LIKE expression to a string. *)
let rec like_as_string env le = 
  let quote = Str.global_replace (Str.regexp_string "%") "\\%" in
  let rec like_as_string' env =
    function
      | `percent -> "%"
      | `underscore -> "_"
      | `caret -> ""
      | `dollar -> ""
      | `string s -> quote s
      | `variable v -> quote (Result.unbox_string (assoc v env))
      | `seq rs -> mapstrcat "" (like_as_string' env) rs in
  let result =  like_as_string' env le in
  result

exception UnsupportedLabelPattern 
  
let case_body_to_pattern tuple_var body =
  let module E = Expression.Expr in 
  let rec aux record pattern expr = match expr with
      E.Record_selection (findex_str, fvar, rest, E.Variable(rvar,_), body, _) -> 
	begin
	  try 
	    if not (rvar = record) then raise UnsupportedLabelPattern;
	    let findex = int_of_string findex_str in
	    let pattern = match pattern with 
		[] -> [(findex, fvar)]
	      | (findex', _)::tl when findex' + 1 = findex -> (findex, fvar)::pattern 
	      | _ -> raise UnsupportedLabelPattern in
	      aux rest pattern body  
	  with
	      Failure _ -> raise UnsupportedLabelPattern
	end

    | E.Condition(E.Comparison(E.Variable(rvar,_), `Equal, unit_expr, _), tt, ff, _) -> 
	if (rvar = record) && (Syntax.is_unit unit_expr) then 
	  match ff with 
	      E.Wrong _ -> pattern, tt, None
	    | _ -> 	  pattern, tt, Some ff 
	else
	  raise UnsupportedLabelPattern
	    
    | _ -> pattern, expr, None
  in
    match body with 
	E.Record_selection _ -> aux tuple_var [] body 
      | _ -> [], body, None
	  
    
(** condition_to_sql
    Converts a Links condition into an SQL condition; should only be
    applied to expressions that have boolean type
    
    @param expr The candidate syntax expression.
    @param bindings The bindings available where the expression occurs.
        A `Table_loop element must be present.
    @return Some(condition, projs) if it can transform the input into SQL.
        `condition' is the condition, now in Query.expression format, 
        and projs is a list of record selection descriptors. These
        projections need to be wrapped around the Query in order that 
        the free vars of the Query should be properly bound. Returns 
        None if it can't create such a result. *)
(*  TODO: Support calculated variables *)
let rec condition_to_sql (expr:Syntax.expression) (bindings:bindings)
    : (Query.expression * projection_source list) option =
  let module E = Expression.Expr in
  let (bindings, expr) = (sep_assgmts bindings expr) in
    match expr with
      | E.Constant(Expression.Boolean true, _) -> Some (Boolean true, [])
      | E.Constant(Expression.Boolean false, _) -> Some (Boolean false, [])
      | E.Condition(c, t, e, _) ->
          cond_condition_to_sql bindings c t e
        (*   (\* perhaps this is just an AST-traversal with state?? *\) *)
        (*   let csql = condition_to_sql c bindings in *)
        (*   let tsql = condition_to_sql t bindings in *)
        (*   let esql = condition_to_sql e bindings in *)
        (*     if for_all isSome [csql; tsql; esql] then *)
        (*       let Some (csql, corigins), Some (tsql, torigins), Some (esql, eorigins) = csql, tsql, esql in *)
		(* Some (disjunction([conjunction[csql; tsql]; *)
        (*                            conjunction[negation csql; esql]]), *)
        (*               corigins @ torigins @ eorigins (\* is this at all right?? *\)) *)
        (*     else None *)
      | E.Variable _ -> 
          (match make_sql bindings expr with
             | Some(expr, origin) -> Some(expr, origin)
             | _ -> failwith("Internal error: unintelligible free var in query expression"))
      | E.Apply (E.Variable ("tilde", _), [lhs; rhs], _)  ->
          let left_binds, lhs = sep_assgmts bindings lhs in
          let right_binds, rhs = sep_assgmts bindings rhs in
            (match make_sql left_binds lhs, likify_regex right_binds rhs with
               | (Some (lsql, lorigin), Some (rsql, rorigin)) ->
                   Some (make_binop_sql `Tilde lsql (LikeExpr rsql), lorigin @ rorigin)
               | _ -> None)
	      
      | E.Apply (E.Variable(fname, `T(_, _, Some "policy")), args, pos)
	  when Settings.get_value call_stored_procs ->
	  
	  make_sql bindings expr

      | E.Comparison (lhs, oper, rhs, _) ->
          let left_binds, lhs = sep_assgmts bindings lhs in
          let right_binds, rhs = sep_assgmts bindings rhs in
            (match make_sql left_binds lhs, make_sql right_binds rhs with
               | (Some (lsql, lorigin), Some (rsql, rorigin)) ->
                   Some (make_binop_sql oper lsql rsql, lorigin @ rorigin)
               | _ -> None)
	      
      | E.Variant_selection(E.Variable(vname,_) as var, _, _, _, _, _,  _) ->
	  begin
	    let t = Syntax.node_datatype var in
	      try
		(* let _ = Fable.get_label_type_expr (t.Expression.Types.ftype) in (\* DB only supports discrimination of label-typed exprs *\) *)
		  
		let rec case_bodies branches vname expr = match expr with 
		    E.Variant_selection(E.Variable(vname',_) as var, constr, carg, tbody, not_constr_var, not_constr_body,  _) ->
		      if (vname != vname') then raise UnsupportedLabelPattern;
		      let pattern, expr, maybe_next = case_body_to_pattern carg tbody in
		      let pattern = match pattern with 
			  [] -> [(1, carg)]
			| _ -> pattern in 
			case_bodies (((constr, pattern), expr, maybe_next)::branches) not_constr_var not_constr_body 
		  | E.Variant_selection_empty _ -> List.rev branches, None
		  | default -> List.rev branches, Some default in
		  
		let vexp, vorigins = match make_sql bindings var with 
		    None -> raise UnsupportedLabelPattern
		  | Some (vexp, vorigins) -> vexp, vorigins  in
		let patterns, maybe_default = case_bodies [] vname expr in
		let pattern_to_clause_l ((constr, patvars), expr, maybe_next) = 
		  let argstr,nargs = List.fold_right (fun _ (s,n) -> 
							if (n==0) then "_", n+1
							else  ("_, " ^ s), n+1) patvars ("",0) in
		  let pat = Text (constr ^"((" ^ argstr ^ "))" )in
 		  let guard = Binary_op ("=", vexp, pat) in
		  let bindings = List.fold_left 
		    (fun bindings (index, fvar)  -> (* TODO: reflect type of fvar in the name of function below *)
		       let binding = 
			 `QCalculated(fvar, Funcall("tuple_get_str", [Funcall("label_get_tuple", [vexp]);
								      Integer(Num.num_of_int (index-1))])) in
			 binding::bindings) bindings patvars in
		    match condition_to_sql expr bindings  with 
			Some(sql_expr, origin) -> 
			  begin
			    match maybe_next with 
				None -> [(guard, sql_expr), origin]
			      | Some e -> (match condition_to_sql e bindings with 
					       Some(sql_e, origin_e) -> 
						 let pat = Text (constr ^ "(_)") in
						 let dguard = conjunction [Binary_op ("=", vexp, pat);
									  Binary_op (">", 
										     Funcall("tuple_num_args", 
											     [Funcall("label_get_tuple", [vexp])]),
										     Integer (Num.num_of_int nargs))] in
						   [((dguard, sql_e), origin_e);((guard, sql_expr), origin)]
					     | None -> raise UnsupportedLabelPattern)
			  end
		      | None -> raise UnsupportedLabelPattern in
		  
		let clause_origin_l = match maybe_default with 
		    Some e -> (match condition_to_sql e bindings with
				   None -> raise UnsupportedLabelPattern
				 | Some (sql_e, origin_e) -> 
				     let clause = (Boolean true, sql_e) in
				       [clause, origin_e])
		  | None ->  [] in
		let clause_l, origin_l =List.split (List.fold_right (fun p clauses -> (pattern_to_clause_l p) @ clauses) patterns clause_origin_l) in		  
		  Some(Case(clause_l), List.flatten (vorigins::origin_l))
	      with
		  Not_found
		| UnsupportedLabelPattern -> None
	  end  
      | _ -> None
      
and cond_condition_to_sql bindings c t e =
  (* perhaps this is just an AST-traversal with state?? *)
  let csql = condition_to_sql c bindings in
  let tsql = condition_to_sql t bindings in
  let esql = condition_to_sql e bindings in
  if for_all isSome [csql; tsql; esql] then
    let Some (csql, corigins), Some (tsql, torigins), Some (esql, eorigins) 
      = csql, tsql, esql in
	Some (disjunction([conjunction[csql; tsql];
                       conjunction[negation csql; esql]]),
          corigins @ torigins @ eorigins (* is this at all right?? *))
  else None
  



(** select_by_origin
    Adds the origin selections before an expression.
    @param origin The origin to add to the expression.
    @param expr The expression to modify.
    @return The query with the added origin. *)
let select_by_origin origin expr = 
  fold_left (fun expr origin -> 
               Expression.Expr.Record_selection(origin.field_name, origin.field_var,
                                       origin.etc_var, 
                                       Expression.Expr.Variable(origin.source_var,
                                                       Syntax.no_expr_data),
                                       expr, Syntax.no_expr_data)
            ) expr origin

(** pos_and_neg
    A simple utility that converts (pos, neg) to "pos AND NOT neg"
    One wonders why the (pos, neg) rep'n is used in the first place.
 *)
let pos_and_neg (positives, negatives) =
  conjunction (negation (disjunction negatives) :: positives)

(* TBD: Move this to a simple utility in query.ml *)
(** select
    Adds conditions to a query. If the {! Sql_transform.selectable} method
     is called on every positive and negative condition provided,
     this function should not fail.
    @param positives Conditions that whould be satisfied by any element
      of the result.
    @param negatives Conditions that should not be satisfied by any 
      element of the result.
    @param query The original query.
    @return The query with the added conditions.
    @raise Failure A general programming error has occured. Passing 
      conditions that where not selectable with {! Sql_transform.selectable}
      might cause such exceptions. *)
(* TODO: Support conditions on records *)
let rec select condns (query:query) : query =
  let where = conjunction (query.condition :: condns)
  in {query with condition = where}
         
(** rename_uniquely
    Takes two lists of column names and produces a list of
    unique names, along with the substitutions required to make them
    distinct. Only the `right` argument needs renamings, since the
    `left` values are already distinct anyway.
*)
let append_uniquely
    (left : col_or_expr list)
    (right : col_or_expr list) : (col_or_expr list * (column * string) list) =
  let rename = function
    | Left col -> [(col, {col with col_alias = col_unique_name ()})]
    | Right expr -> [] in
  let (right : (Query.column *Query.column) list) = concat_map rename right in
    (left @ map (snd ->- inLeft) right,
     concat_map (fun (x, y) -> [(x, y.col_alias)]) right)
  
(** join
    Joins two queries into one, over the given condtions. If the
    {! Sql_transform.selectable} method is called on every positive and
    negative condition provided, this function should not fail.
    @param positives Conditions that whould be satisfied by any element of 
       the result.
    @param negatives Conditions that should not be satisfied by any element 
       of the result.
    @param left_query The first original query.
    @param right_query The second original query.
    @return The join between queries with the added conditions.
    @raise Failure A general programming error has occured. Passing 
        conditions that where not selectable with 
    {! Sql_transform.selectable} might cause such exceptions. *)
(* FIXME: This ought to uniquely rename the tables (as well as the columns) *)
let join (condns : Query.expression list)
    ((left, right) : query * query)
    : ((column * string) list * query) =
  if (left.distinct_only <> right.distinct_only) then failwith "TR167";
  let where_clause = simplify 
    (conjunction (left.condition :: right.condition :: condns)) in
  let (columns, col_renamings) = append_uniquely left.result_cols right.result_cols in
  let max_rows = function (None,None) -> None | _ -> 
    failwith "Not yet implemented: take/drop for joined tables" in
  let offset = function 
    | (Integer (Num.Int 0), Integer (Num.Int 0)) -> Integer (Num.Int 0)
    | _ -> failwith "Not yet implemented: take/drop for joined tables" in
  let query = 
    { distinct_only = left.distinct_only;
      result_cols   = columns;
      tables        = left.tables @ right.tables;
      condition     = where_clause;
      sortings      = left.sortings @ right.sortings;
      max_rows      = max_rows (left.max_rows, right.max_rows);
      offset        = offset (left.offset, right.offset);
      projections   = left.projections @ right.projections
    }
  in (col_renamings, query)

        
(** Projects the query on the empty set.
    @param query The query to nullify.
    @return The nullified query. *)
let rec null_query (query:query) : query =
  {query with result_cols = []}
