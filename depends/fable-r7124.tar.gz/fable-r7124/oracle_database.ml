
(* open Occi *)
open Result

(* Oracle_database 
   Implements the Result.database interface
   for Oracle back ends *)

class otherfield (thing : Occi.ora_value) : Result.otherfield =
object (_)
  method show = match thing with
    | Occi.Int _ -> "int"
    | Occi.Date _ -> "date"
    | Occi.Float _ -> "float"
    | Occi.Str _ -> "string"
    | Occi.Null -> "null"
end

let ora_value_to_string result i value =
  let s = Occi.field_to_string value in
  if s = "NULL" then begin
    (* get result type *)
    match (List.hd result).(i) with
      | Occi.Int _ -> "0"
      | Occi.Float _ -> "0.0"
      | Occi.Null -> failwith "ftype: received null type"
      | _ -> ""
  end
  else match ((List.hd result).(i)) with 
    | Occi.Str _ -> 
        (* remove quotes (first and last chars *)
        String.sub s 1 (String.length s - 2)
    | _ -> s

class oracle_result 
  (result:Occi.ora_value array list)
  (row_names:string array)
  (status:db_status) = 
object
  inherit dbresult
  val result = result
  val row_names = row_names
  val status = status

  method status : db_status = status
        
  method nfields : int = match result with 
    | [] -> 0 
    | r::_ -> Array.length r
  method fname : int -> string = 
    fun n -> String.lowercase (Array.get row_names n)
  method ftype : int -> db_field_type = 
    fun n -> match (List.hd result).(n) with
      | Occi.Int _ -> IntField
      | Occi.Date _ -> TextField
      | Occi.Float _ -> FloatField
      | Occi.Str _ -> TextField
      | Occi.Null -> failwith "ftype: received null type"
(*    | fieldtype -> SpecialField (new otherfield fieldtype)*)
    | _ -> TextField
  method get_all_lst : string list list = 
    List.map (fun a -> 
                Array.to_list (Array.mapi (ora_value_to_string result) a)) 
      result

  method error : string = "NYI"
end

let empty_dbresult = new oracle_result [] (Array.make 0 "") QueryOk

class oracle_database dbname user password = object(self)
  inherit database

  val connection =
    Occi.occi_connect user password dbname

  method driver_name () = "oracle"
    
  (* "EXECUTE SA_SESSION.SET_ACCESS_PROFILE('BUSINESS', 'USER1')" *)
  method set_access_profile policy user =
    let stmt = Occi.occi_create_statement connection "" in
    Occi.occi_prepare_plsql stmt 
      "EXECUTE SA_SESSION.SET_ACCESS_PROFILE(:1,:2)" [];
    let params = [(1, Occi.Var_str policy); 
                  (2, Occi.Var_str user)] in
    ignore (Occi.occi_execute_plsql stmt params)

  method exec : string -> dbresult = fun query ->
    (* hack; Oracle doesn't use AS to rename tables *)
    let query = 
      let re = Str.regexp " AS Table_" in
      Str.global_replace re " Table_" query in
    Debug.f "occi query: \"%s\"" query;
    let stmt = Occi.occi_create_statement connection "" in
    try 
      let (cur, names) = Occi.occi_execute_query stmt query in
      let (_, rows) = Occi.ora_fetch_list cur in
      new oracle_result rows names QueryOk
    with Occi.ORA_EXCEPTION (n,_) -> 
      failwith("Oracle returned error #: "^string_of_int n)
  method equal_types (_: Expression.Types.datatype) (_ : db_field_type) : bool = true
  method escape_string s = s            (* TODO *)
  method start_transaction () = empty_dbresult         (* implicit *)
  method rollback_transaction () = Occi.occi_rollback connection; empty_dbresult
  method commit_transaction () = Occi.occi_commit connection; empty_dbresult
  method nextval _ = failwith "nextval: nyi"
end

let driver_name = "oracle"

let parse_args args =
  match Utility.split_string args ':' with
    | (dbname::user::pass::_) ->
        (new oracle_database dbname user pass,
         reconstruct_db_string (driver_name, args))
    | _ -> failwith "Insufficient arguments when establishing Oracle connection"

let _ = register_driver (driver_name, parse_args)
