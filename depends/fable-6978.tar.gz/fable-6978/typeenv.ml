(*pp deriving *)
open Utility
open Mktypes
open Syntax
open Expression
open Expression.Types
open Printsyntax

type environment = (string * Types.assumption) list

type alias_environment = assumption Mktypes.stringmap
    
type typing_environment = environment * alias_environment
    
type gamma_entry =
    | Normal of (string * assumption * bool * location)
    | Phantom of (string * assumption)
    | NoShadow of (string * assumption)
	 
type refinement = (expression * expression)

type omega = {
  gamma : gamma_entry list;
  alias : alias_environment;
  pi : unit; (* Need this for type evaluation relation *)
  refinements : refinement list; (* Type refinement assumptions *)
  phi_phase : bool; (* are we typing term or type-level expressions? *)
  annotation : datatype option; (* expected type of the expr currently being typed *)
  rec_vars : Utility.IntSet.t;
  context : Syntax.location }

exception Shadow_variable of string
exception UndefinedAlias of string
exception AliasMismatch of string

let add_rec_var var e = 
  if IntSet.mem var e.rec_vars then
    raise (Shadow_variable "Attempt to add duplicate recursive variable to an environment")
  else
    {e with rec_vars = IntSet.add var e.rec_vars} 
let contains_rec_var var e = IntSet.mem var e.rec_vars
  
let add_refinement (e1, e2) env = {env with refinements = (e1,e2)::env.refinements}
let refine f e1 env = 
  try 
    let (_, e2) = List.find (fun (e1', e2) -> f e1 e1') env.refinements in
      Some e2
  with
      Not_found -> None
	
let get_type_annotation env = env.annotation
let set_type_annotation_opt env t = {env with annotation = t}
let set_type_annotation env t = set_type_annotation_opt env (Some t)
let clear_type_annotation env = set_type_annotation_opt env None

let set_phantom_phase env = {env with phi_phase = true}
let clear_phantom_phase env = {env with phi_phase = false}

let check_context env chrom = (env.context = chrom)
let set_context env chrom = {env with context = chrom}
let get_context env = env.context
  
let empty = 
  {gamma = [];
   alias = StringMap.empty;
   pi=();
   refinements = [];
   phi_phase = false;
   annotation = None;
   rec_vars = Utility.IntSet.empty;
   context = `Unknown}
    
let initial_env (env, alias) = 
  {gamma = List.map (fun (s,a) -> NoShadow(s,a)) env;
   alias = alias;
   pi=();
   refinements = [];
   phi_phase = false;
   annotation = None;
   rec_vars = Utility.IntSet.empty;
   context = `Unknown}

(* type environment *)
let ge_assumption = function
    Normal(_, a, _, _)
  | Phantom(_, a) 
  | NoShadow(_, a) -> a

let ge_location = function
   Normal(_,_,_, loc) -> loc
  | _ -> `Unknown
   
let lookup_ge n omega =    
  List.find (function
		 Normal(n', _, shadowed, _) when omega.phi_phase -> 
		   if n=n' then 
		     if n = "_MAILBOX_" || not shadowed then 
		       true
		     else 
		       raise Not_found
		   else
		     false
	       | Normal(n', _, _, _) -> n=n'
	       | NoShadow(n',_) -> n = n'
	       | Phantom(n', _) when omega.phi_phase -> n = n'
	       | _ -> false
	    ) omega.gamma 

let lookup n o = ge_assumption (lookup_ge n o)
let lookup_location n o = ge_location (lookup_ge n o)
  
let contains n omega =
  try
    let _ = lookup n (set_phantom_phase omega) in true
  with
      Not_found -> false

let is_shadowed gamma name =
  List.exists (function
		   Normal(n', _, _, _)
		 | NoShadow(n', _)
		 | Phantom(n', _) -> name = n'
	      ) gamma 

let is_noshadow_name gamma name = 
  List.exists (function
		 | NoShadow(n', _)
		 | Phantom(n', _) -> name = n'
		 | _ -> false
	      ) gamma 
	
let add_phantom_binding : string -> assumption -> omega -> omega =
  fun name a omega ->
    if is_shadowed omega.gamma name then
      raise (Shadow_variable (name ^ " already bound in environment"))
    else	
      {omega with gamma=Phantom(name, a)::omega.gamma}
	
let add_noshadow_binding : string -> assumption -> omega -> omega =
  fun name a omega -> 
    if is_shadowed omega.gamma name then
      raise (Shadow_variable (name ^ " already bound in environment"))
    else	
      {omega with gamma=NoShadow(name, a)::omega.gamma}
      
let add_normal_binding ?(location=`Unknown) : string -> assumption -> omega -> omega =
  fun name a omega ->
    if omega.phi_phase then
      add_noshadow_binding name a omega
    else
      if is_noshadow_name omega.gamma name then
	raise (Shadow_variable (name ^ " already bound in environment and cannot be rebound"))
      else
	if is_shadowed omega.gamma name then
	  {omega with gamma=Normal(name, a, true, location)::omega.gamma}
	else	
	  {omega with gamma=Normal(name, a, false, location)::omega.gamma}
	    
(* alias environment *)
let alias_env omega = omega.alias

let register_alias (typename, var_kinds, datatype) omega = 
  let alias_env = omega.alias in 
  let _ =
    if StringMap.mem typename alias_env then
      failwith ("Duplicate typename: "^typename) in
  let aliases = Types.type_aliases datatype in
  let free_aliases =
    StringSet.filter (fun alias -> not (StringMap.mem alias alias_env)) aliases
  in
  let alias' =
    if not (StringSet.is_empty free_aliases) then
      failwith ("Undefined typename(s) in type declaration: "^String.concat "," (StringSet.elements free_aliases))
    else
      StringMap.add typename ((List.map (fun (var, k) -> `TypeVar var, k) var_kinds), datatype) alias_env in 
    {omega with alias=alias'}

let lookup_alias_old (s, ts) alias_env =
  let vars, alias =
    if StringMap.mem s alias_env then
	 StringMap.find s alias_env
    else
      raise (AliasMismatch ("Unbound typename "^s))
  in
    if List.length vars <> List.length ts then
	 raise (AliasMismatch
                  ("Alias '"^s^"' takes "^string_of_int(List.length vars)^" arguments but is applied to "^
			 string_of_int(List.length ts)^" arguments ("^String.concat "," (List.map string_of_datatype ts)^")"))
    else
      vars, alias

let lookup_alias a omega = lookup_alias_old a omega.alias

module FieldEnv = Utility.StringMap

let rec free_alias_check alias_env = fun rec_vars ->
  let fac = free_alias_check alias_env in
    fun dt -> match dt.ltype with
      | `Not_typed 
      | `Primitive _ -> ()
      | `Function (f, m, t) -> fac rec_vars f; fac rec_vars m; fac rec_vars t
      | `Record row -> free_alias_check_row alias_env rec_vars row
      | `Variant row -> free_alias_check_row alias_env rec_vars row
      | `Table (r, w) -> fac rec_vars r; fac rec_vars w
      | `Application (s, ts) ->
          if StringMap.mem s alias_env then
	     List.iter (fac rec_vars) ts
          else
	     raise (UndefinedAlias ("Unbound alias: "^s))
      | `MetaTypeVar point ->
          begin
	     match Unionfind.find point with
              | Flexible _
              | Rigid _ -> ()
              | Recursive (var, t) ->
                  if TypeVarSet.mem var rec_vars then
			 ()
                  else
		      fac (TypeVarSet.add var rec_vars) t
              | Body t -> fac rec_vars t
          end
and free_alias_check_field_spec alias_env = fun rec_vars ->
  function
    | `Present t -> free_alias_check alias_env rec_vars t
    | `Absent -> ()
and free_alias_check_field_spec_map alias_env = fun rec_vars field_env ->
  FieldEnv.iter (fun _ -> free_alias_check_field_spec alias_env rec_vars) field_env
and free_alias_check_row alias_env = fun rec_vars row ->
  let field_env, row_var = row
  in
    free_alias_check_field_spec_map alias_env rec_vars field_env;
    match Unionfind.find row_var with
      | ClosedRow
      | FlexibleRow _
      | RigidRow _ -> ()
      | RecursiveRow (var, rec_row) ->
          if TypeVarSet.mem var rec_vars then
	     ()
          else
	     free_alias_check_row alias_env (TypeVarSet.add var rec_vars) rec_row
      | BodyRow row ->
          free_alias_check_row alias_env rec_vars row
	     
(* interface *)
let free_alias_check omega = free_alias_check omega.alias TypeVarSet.empty
let free_alias_check_row omega = free_alias_check_row omega.alias TypeVarSet.empty

let rec is_mailbox_free alias_env = fun rec_vars t ->
  let imb = is_mailbox_free alias_env rec_vars in
  let imbr = is_mailbox_free_row alias_env rec_vars in
    match t.ltype with
      | `Not_typed 
      | `Primitive _ -> true
      | `Function (f, m, t) -> imb f && imb m && imb t
      | `Record row
      | `Variant row -> imbr row
      | `Table (r, w) -> imb r && imb w
      | `Application ("Mailbox", _) -> false
      | `Application (s, ts) ->
          if StringMap.mem s alias_env then
	     List.for_all imb ts
          else
	     raise (UndefinedAlias ("Unbound alias: "^s))
      | `MetaTypeVar point ->
          begin
	     match Unionfind.find point with
              | Flexible _
              | Rigid _ -> true
              | Recursive (var, t) ->
                  (TypeVarSet.mem var rec_vars) ||
		      (is_mailbox_free alias_env (TypeVarSet.add var rec_vars) t)
              | Body t -> imb t
          end
and is_mailbox_free_field_spec alias_env = fun rec_vars ->
  function
    | `Present t -> is_mailbox_free alias_env rec_vars t
    | `Absent -> true
and is_mailbox_free_field_spec_map alias_env = fun rec_vars field_env ->
  FieldEnv.fold (fun _ field_spec b ->
    b && is_mailbox_free_field_spec alias_env rec_vars field_spec)
    field_env true
and is_mailbox_free_row alias_env = fun rec_vars row ->
  let field_env, row_var = row
  in
    (is_mailbox_free_field_spec_map alias_env rec_vars field_env) &&
      (match Unionfind.find row_var with
        | ClosedRow
        | FlexibleRow _
        | RigidRow _ -> true
        | RecursiveRow (var, rec_row) ->
	     (TypeVarSet.mem var rec_vars) ||
              (is_mailbox_free_row alias_env (TypeVarSet.add var rec_vars) rec_row)
        | BodyRow row ->
	     is_mailbox_free_row alias_env rec_vars row)


(* interface *)
let is_mailbox_free omega = is_mailbox_free omega.alias TypeVarSet.empty
let is_mailbox_free_row omega = is_mailbox_free_row omega.alias TypeVarSet.empty

(* whole environment manipulation *)
let concat_gamma omega omega' = 
  (*   let aux gamma ge =  *)
  (*     let _ = match ge with  *)
  (* 	 Normal(n, _)  *)
  (*       | Phantom(n, _) ->  *)
  (* 	   check_shadow gamma n in *)
  (*       ge::gamma in *)
  (*   let gamma' = List.fold_left aux omega.gamma omega'.gamma in *)
  {omega with gamma=omega.gamma@omega'.gamma}

let concat_alias omega omega' = 
  let alias' =  StringMap.superimpose omega.alias omega'.alias in
    {omega with alias=alias'}
      
let concat_environment : omega -> omega -> omega  = 
  fun o1 o2 -> 
    let omega = concat_gamma o1 o2 in
    let omega = concat_alias omega o2 in
      {omega with phi_phase = omega.phi_phase || o2.phi_phase}
	 
let all_type_vars : omega -> TypeVarSet.t =
  fun omega -> 
    let environment_values gamma = List.map (function Normal(_,(_, t),_, _) | NoShadow(_, (_,t)) | Phantom(_,(_,t)) -> t) gamma 
    in
      TypeVarSet.union_all (List.map Types.free_type_vars (environment_values omega.gamma))
	 
let all_bound_names : omega -> Utility.StringSet.t = 
  fun omega -> 
    let names = List.map (function Normal(n,_,_,_) | NoShadow(n,_) | Phantom(n,_) -> n ) omega.gamma in
      Utility.StringSet.from_list names

(* Coercion: deprecated *)  
let extract_typing_environment omega =
  let as_typing_assumption = function
      Normal(s, a, _, _)
    | NoShadow(s,a)
    | Phantom(s, a) -> (s,a) in
  let env = List.map as_typing_assumption omega.gamma in
    (env, omega.alias)
      
