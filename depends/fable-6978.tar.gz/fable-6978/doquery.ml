(** Runtime evaluation of queries *)

open Str
open Num
open List

open Utility
open Result
open Syntax
open Expression
open Expression.Expr
open Expression.Query

open Unix
open Printf

exception NoSuchField of string

let normalise_variable name db globals env =
  try
    match Library.lookup globals env name with
      | `Bool value -> Query.Boolean value
      | `Int value -> Query.Integer value
      | `Float value -> Query.Float value
      | `List (`Char _::_) as c  
        -> Query.Text (db # escape_string (charlist_as_string c))
      | `List ([]) -> Query.Text ""
      | r -> Query.Text (db # escape_string (Result.string_of_result r))
          (* | r -> failwith("Internal error: variable " ^ name ^ *)
          (*                   " in query "^ Sql.string_of_query qry ^ *)
          (*                   " had unexpected type at runtime: " ^ *)
          (*                   string_of_result r) *)
  with NotFound _-> failwith("Internal error: undefined query variable '"
                             ^ name ^ "'")

let rec normalise_expression db globals env : Query.expression -> Query.expression = 
  fun op -> 
  let normalise_like_expression (l : Query.like_expr): Query.expression = 
    Text (Sql_transform.like_as_string (env @ globals) l) in
  let normalise_expr = normalise_expression db globals env in
  match op with
    | Query.Variable name -> normalise_variable name db globals env
    | Query.Binary_op (symbol, left, right) ->
        Binary_op (symbol, normalise_expr left, normalise_expr right)
    | Query.Unary_op (symbol, expr) ->
        Unary_op (symbol, normalise_expr expr)
    | Query.LikeExpr (like_expr) -> normalise_like_expression like_expr
    | Query.Query qry ->
        Query {qry with condition = normalise_expr qry.condition}
    | Query.Funcall(fname, args) -> 
	    Query.Funcall(fname, List.map normalise_expr args)
    | Query.Case branches -> 
	    Query.Case 
          (List.map (fun (g,t) -> 
                       (normalise_expr g, normalise_expr t)) branches)
    | expr -> expr

(* Convert all TableVariables to TableNames *)
let rec normalise_tablespec globals env db : table_spec -> table_spec =
  function 
    | `TableName t -> `TableName t
    | `TableVariable var ->
        (match Library.lookup globals env var with
           | `Table(_, tableName, _, _) -> `TableName tableName
           | _ -> failwith ("Internal Error: "^
                              "table source was not a table!"))
    | `Subquery q -> `Subquery (normalise_query globals env db q)
        
and normalise_tables globals env db : from_item list -> from_item list =
  let normalise_table (t,a) = (normalise_tablespec globals env db t, a)
  in map normalise_table

(** Substitutes values for the variables in a query,
    and performs interpolation in LIKE expressions. *)
and normalise_query : environment -> environment -> database -> query -> query
  = fun globals env db qry ->
    let normalise_expression = normalise_expression db globals env in
    let normalise_tables = normalise_tables globals env db in
    let normalise_cols cols = 
      List.map 
        (fun lr -> match lr with 
		   | Left _ -> lr
		   | Right ce -> 
               Right {ce with expression 
                        = normalise_expression ce.expression}) cols 
    in
    {qry with
       result_cols = normalise_cols qry.result_cols;
       tables = normalise_tables qry.tables;
       condition = normalise_expression qry.condition;
       offset = normalise_expression qry.offset;
       max_rows = opt_map normalise_expression qry.max_rows}

(** marshall and unmarshall data from the database *)
and row_field_present globals locals field _fields tc t interpret =
  try
	let module E = Expression.Expr in
	let marsh = List.assoc field tc.E.marshallby in
	match marsh with
	  | E.Record_intro(fields, _, _) ->
		  let unmarsh =
			(try
			   StringMap.find "2" fields
			 with
			     NotFound _ -> raise
                   (Runtime_error ("Expected a tuple in table "^
                                     "field marshalling constraint"))) in
		  let unmarshall s =
			let s' = E.Constant (Expression.String s, no_expr_data) in
			let app = E.Apply (unmarsh, [s'], no_expr_data) in
			try
			  interpret globals locals app Result.toplevel_cont
			with
				Library.TopLevel (_,v) -> v in
		  (t, Some unmarshall)
	  | _ -> raise
          (Runtime_error
             ("Expected a tuple in table field marshalling constraint"))
  with
	  Not_found -> (t, None)

let update_column_type col (fields,_) =
  match StringMap.find col.name fields with
    | `Absent -> raise (NoSuchField col.name)
    | `Present t -> 
        match t.Types.ltype with
          | `Primitive _ -> Left col
          | `Application ("String", _) -> Left col
          | `Application ("Xml", _) -> Left col
              (* this may not be the right selection of types *)
          | `Application _ | `Record _ | `Variant _ ->
              let field = Field (col.table_alias, col.name) in
              Right { 
                expression = Funcall ("show_value", [field]);
                exprcol_alias = col.col_alias;
                exprcol_table_alias = col.table_alias
              }
          | _ -> raise (Runtime_error "Cannot retrieve requested type from db") 
          
let update_column_types query table_defs =
  let f e = match e with
    | Left col -> 
        let (row,_) = assoc col.table_alias table_defs
        in update_column_type col row
    | _ -> e
  in
  let cols = query.result_cols in
  let cols' = map f cols
  in { query with result_cols = cols' }
       
(* lookup field in table definition *)
let row_field_type interpret globals locals field : (Types.row * Syntax.table_constr)
    -> (Types.datatype * (string -> result) option)
  = fun ((fields,_), tc) ->
    match StringMap.find field fields with
	  | `Present t -> row_field_present globals locals field fields tc t interpret
 	  | `Absent -> raise (NoSuchField field)

let query_result_types row_field_type : query -> (string * (Types.row * Syntax.table_constr)) list
  -> (string * (Types.datatype * (string -> result) option)) list
  = fun query table_defs -> 
    let get_col = function
      | Left col -> 
          [col.col_alias, row_field_type col.name (assoc col.table_alias table_defs)]
      | Right _ -> []
    in
    try
	  concat_map get_col query.Query.result_cols
    with NoSuchField field ->
      failwith (sprintf "Field %s from %s was not found in tables %s."
                  field (Sql.string_of_query query) (mapstrcat "," fst table_defs))

let time : (unit -> 'a) -> (float -> unit) -> 'a = fun th ft ->
  let t1 = Unix.gettimeofday() in
  let result = th () in
  let t2 = Unix.gettimeofday() in
  ft (t2 -. t1);
  result

(** Run a query *)
let do_query interpret : environment -> environment -> query -> string list -> result list 
  -> result
  = fun globals locals query table_aliases tables ->
    
    (* lookup field in table definition *)
    let row_field_type = row_field_type interpret globals locals in
    let query_result_types = query_result_types row_field_type in
    
    (* translate table into table definitions and a single database *)
    let db, table_defs =
      let get_table_defs = function
        | `Table ((db, _), _table_name, row, tc) -> (db, (row,tc))
        | `View ((_db, _), _view_name, _row, _query) -> 
            failwith "Cannot handle views yet"
        | _ -> assert false
      in
      let (dbs, table_defs) = split (map get_table_defs tables) in
      let db =
        if (all_equiv (=) dbs) then hd(dbs)
        else failwith ("Cannot join across different databases") in
      let table_defs = combine table_aliases table_defs in
      (db, table_defs)
    in
    let result_types = query_result_types query table_defs in
    (* let query = update_column_types query table_defs in *)
    let query = normalise_query globals locals db query in
    let query_string = Sql.string_of_query query in
    Debug.f "RUNNING QUERY:\n%s" query_string;
    time (fun () -> Database.execute_select result_types query_string db)
      (Debug.f "Query took : %fs")
