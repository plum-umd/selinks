(*pp deriving *)

open Utility
open Performance

(*
 Whether to cache programs after the optimization phase
*)
let cache_programs = Settings.add_bool ("cache_programs", false, `User)
let native_includes = Settings.add_bool ("native_includes", true, `User)
let db_mode = Basicsettings.db_mode

let `T (pos, dt, _) = Syntax.no_expr_data

let expunge_source_pos =
  (Expression.DerivingSyntax.Functor_expression'.map
     (fun (`T (_,_,l)) -> `T (pos, dt, l)))

let expunge_all_source_pos =
  Syntax.transform_program expunge_source_pos

let newer f1 f2 = 
   ((Unix.stat f1).Unix.st_mtime > (Unix.stat f2).Unix.st_mtime) 
  
let read_file_cache_with_env : Typeenv.omega -> string
  -> (Typeenv.omega * Syntax.program) 
      = fun env filename ->
   let cachename = filename ^ ".cache" in 
  try
    if newer cachename filename then
      call_with_open_infile cachename ~binary:true
        (fun cachefile ->
          (Marshal.from_channel cachefile 
             : (Typeenv.omega * Syntax.program)))
        (* (OCaml manual recommends putting a type signature on unmarshal 
           calls; not clear whether this actually helps. It seems we get 
           a segfault if the marhsaled data is not the right type.) *)
    else begin
      Debug.f "Precompiled source file out of date: %s" filename;
      raise (Sys_error "Precompiled source file out of date.")
    end
  with (Sys_error _| Unix.Unix_error _) ->
    let program = measure "parse" (Parse.parse_file 
                                     ~pp:(Settings.get_value Basicsettings.pp)
                                     Parse.program) filename in
    let env, program = measure "type" (Inference.type_program env) program in
    let program = measure "optimise" Optimiser.optimise_program (env, program) in
    let program = Syntax.labelize program
    in begin
      Debug.f "Writing cache file: %s" cachename;
	  try (* try to write to the cache *)
        call_with_open_outfile cachename ~binary:true
          (fun cachefile ->
             Marshal.to_channel cachefile 
               (env, expunge_all_source_pos program)
               [Marshal.Closures])
	  with _ -> 
        (* Ignore errors writing the cache file *)
        Debug.f "Error writing cache file: %s" cachename
    end;
    env, program
        
let read_file_cache : string -> (Typeenv.omega * Syntax.program) 
    = read_file_cache_with_env Library.type_env

let dump_cached filename =
  let _, program = read_file_cache filename in
     print_string (Syntax.labelled_string_of_program program)


(* load file *)
(* depending on settings, try to load from cache *)
(* also load any dependent libraries *)
(* problems with this include duplication of file names *)
(* each file is cached with all the previous files... 
   not the files requires itself *)
(* could we keep a set of files included so far? *)
(* let load_file prelude typeenv filename *)
    (* for file *)


let with_prelude prelude (Syntax.Program (defs, body)) =
  Syntax.Program (prelude @ defs, body)

(* Read in and optimise the program *)
let read_and_optimise_program prelude typenv filename = 
  let program = lazy(Parse.parse_file 
                       ~pp:(Settings.get_value Basicsettings.pp) 
                       Parse.program filename)
    <|measure_as|> "parse" in
  let tenv, program = lazy(Inference.type_program typenv program)
    <|measure_as|> "type" in
  let program = 
    (* The prelude is already optimized (via loader.ml) so we don't run 
       it through again. *)
    with_prelude prelude (
      lazy((Optimiser.optimise_program(tenv, program)))
      <|measure_as|> "optimise") in
  let program = Syntax.labelize program in
    tenv, program
              
let read_and_optimise_program' : 
  Syntax.definition list -> Typeenv.omega -> string -> (Typeenv.omega * Syntax.program)
  = fun prelude typenv filename ->
  if Settings.get_value cache_programs then
    read_file_cache_with_env typenv filename
  else
    read_and_optimise_program prelude typenv filename
      
let read_and_optimise_program prelude typenv filename =
  if Settings.get_value native_includes then begin
    let files_to_include = Includes.parse_includes filename in
    let (typenv',defs') =
      List.fold_left
        (fun (typenv,defs) filename -> 
           Debug.f "Including %s" filename;
           let (t,Syntax.Program(defs',_)) = 
             read_and_optimise_program' prelude typenv filename in
           t, List.append defs defs')
        (typenv,[]) files_to_include 
    in 
    let typenv'', Syntax.Program(defs,exp) = 
      read_and_optimise_program' prelude typenv' filename 
    in
    typenv'', Syntax.Program(List.append defs' defs, exp)
  end
  else
    read_and_optimise_program' prelude typenv filename

let read_and_optimise_program prelude typenv filename =
  if Settings.get_value db_mode then
    (* dump db information *)
    let program = Parse.parse_file 
      ~pp:(Settings.get_value Basicsettings.pp) 
      Parse.program filename
    in
    let tenv, program = Inference.type_program typenv program in
    let Syntax.Program (defs, _) = program in 
    let dbdefs = Dbcompile.generate_program_defs defs () in
    (* let dbcode = Dbcompile.gen_dbcode typingenv body in *)
    print_endline (String.concat "\n" dbdefs);
    exit 0
  else
    read_and_optimise_program prelude typenv filename
