open Printf

(* Functions borrowed from the ExtLib Option module *)

module Option = 
struct
  exception No_value

  let is_some = function
    | Some _ -> true
    | None   -> false
        
  let get = function
    | Some x -> x
    | None   -> raise No_value
end

(* Some useful functions for input channels *)

module InputChannel =
  struct
    let id x = x
      
    let rec fold_left f a ch =
      try
        let line = input_line ch in
        let a' = f a line in
        fold_left f a' ch
      with End_of_file -> a
        
    let map f ch =
      let f' a x = f x :: a in
      let xs = fold_left f' [] ch in
      List.rev xs
        
    let iter f ch =
      fold_left f () ch
        
    let lines ch = let tmp = map id ch in close_in ch; tmp
  end

(* PreProcessor functor sig *)

module type PreProcessor = 
sig 
  val pp : string list -> string list
end

(* PreProcessor to enable checked exception syntax *)

module PPChecked : PreProcessor =
struct
  let rChecked = Str.regexp "\\( *\\)checked *$"
  let rAssign  = Str.regexp "\\( *\\)var +\\(.*\\) +<< +\\([^;]+\\);"
    
  let find_close_brace n line =
    let nref = ref n in
    let iref = ref 0 in
    let rref = ref None in
    let doit x = begin
      match x with 
        | '{' | '(' -> incr nref
        | '}' | ')' -> decr nref;
            if !nref = 0 && !rref = None 
            then rref := Some !iref
        | _ -> ()
    end;
      incr iref
    in    
    String.iter doit line;
    !rref, !nref
      
  let rec pp_checked count nbraces trying = function
    | [] -> []
    | line::lines -> 
        if trying then
          let res,nbraces = find_close_brace nbraces line in
          if Option.is_some res then
            let i = Option.get res in
            let fore = String.sub line 0 i in
            let aft  = String.sub line i (String.length line - i) in
            sprintf "%s%s%s" fore (String.make count '}') aft ::
              pp_checked 0 0 false lines
          else if Str.string_match rAssign line 0 then
            let indent = Str.matched_group 1 line in
            let var = Str.matched_group 2 line in
            let expr = Str.matched_group 3 line in
            sprintf "%s%s +>>= fun (%s) { " indent expr var ::
              pp_checked (count+1) nbraces true lines
          else line :: pp_checked count nbraces true lines
        else
          if Str.string_match rChecked line 0 then
            let indent = Str.matched_group 1 line in
            let line' = sprintf "%s# Auto-generated exception code" indent in
            line' :: pp_checked 0 1 true lines
          else
            line :: pp_checked 0 0 false lines
              
  let pp_checked lines = pp_checked 0 0 false lines
  let pp = pp_checked
end

(* Includes preprocessor: this is now handled natively by the compiler *)

(* module PPIncludes : PreProcessor = *)
(* struct *)
(*   exception File_not_found of string *)
    
(*   let rec find_in_path filename = function *)
(*     | [] -> raise (File_not_found filename) *)
(*     | dir::dirs -> *)
(*         let full_filename = dir ^ "/" ^ filename in *)
(*         if Sys.file_exists full_filename then full_filename *)
(*         else find_in_path filename dirs *)
          
(*     let rInclude = Str.regexp "\\include +\\(.*\\\)" *)

(*     let selinks_module_path =  *)
(*       try  *)
(*         let dirs = Sys.getenv "SELINKS_MODULE_PATH" in *)
(*         Str.split (Str.regexp ":") dirs *)
(*       with Not_found -> [] *)
(*     (\* Always include the current directory *\) *)
(*     let selinks_module_path = "." :: selinks_module_path *)

(*     let rec pp_includes prev = function *)
(*       | [] -> [] *)
(*       | line::moreLines ->  *)
(*           if Str.string_match rInclude line 0 then *)
(*             let modname = Str.matched_group 1 line in *)
(*             let (newLines, prev) =  *)
(*               if List.mem modname prev then ([], prev) (\* already imported *\) *)
(*               else *)
(*                 try *)
(*                   (\* this can throw File_not_found *\) *)
(*                   let filename =  *)
(*                     find_in_path (modname ^".links") selinks_module_path in *)
(*                   (\* this can throw errors if file isn't readable *\) *)
(*                   let fd = open_in filename in  *)
(*                   (InputChannel.lines fd, modname :: prev) *)
(*                 with File_not_found _ ->  *)
(*                   fprintf stderr "Could not find module %s. Module path is %s"  *)
(*                     modname (String.concat ":" selinks_module_path); *)
(*                   exit 1 *)
(*                   | _ ->  *)
(*                       fprintf stderr  *)
(*                         "Unknown error ocurred loading module %s" modname; *)
(*                       exit 1 *)

(*             in *)
(*             (\* this isn't efficient *\) *)
(*             pp_includes prev (newLines @ moreLines) *)
(*           else  *)
(*             line :: pp_includes prev moreLines *)
              
(*     let pp = pp_includes [] *)
(*   end *)


(* David's Oracle Label Security (OLS) extensions *)

(* module PPOls : PreProcessor = *)
(*   struct *)
(*     let rOlsDefine =  *)
(*       Str.regexp "olsdefine +\\\"\\(.*\\\)\\\" +with +(\\(.*\\\), *label_col *: *Int *\) +from +\\((.*\)\\)" *)
(*     let rOlsTable = *)
(*       Str.regexp "\\(.*\\\)olstable *(\\\"\\(.*\\\)\\\", *\\(.*\\\))\\(.*\\\)" *)

(*     let rec pp_ols = function *)
(*       | [] -> [] *)
(*       | line::moreLines -> *)
(* if Str.string_match rOlsTable line 0 then *)
(*   let tablename = Str.matched_group 2 line in *)
(*   let dataLabels = Str.matched_group 3 line in *)
(*   let prefix = Str.matched_group 1 line in *)
(*   let suffix = Str.matched_group 4 line in  *)
(*   let output = prefix ^ "refactor_" ^ tablename ^  *)
(*       "(getTableHandle_" ^ tablename ^ "(), " ^ dataLabels ^ ")" ^ suffix in *)
(*     fprintf stderr "%s" output; *)
(*     output :: (pp_ols moreLines) *)

(* else if Str.string_match rOlsDefine line 0 then *)
(*   let tablename = Str.matched_group 1 line in *)
(*   let tableschema = "(" ^ (Str.matched_group 2 line) ^ ")" in *)
(*   let labeledschema = "(" ^ (Str.matched_group 2 line) ^ ", label_col:Int)" in *)
(*   let db = Str.matched_group 3 line in *)
(*   let schema = "Schema" ^ tablename in *)
(*   let osschema = "OSSchema" ^ tablename in *)
(*   let packedschema = "PackedSchema" ^ tablename in *)
(*   let output =  *)
(*     "typename " ^ schema ^ " = " ^ labeledschema ^ ";\n" ^ *)
(*     "typename " ^ osschema ^ " = " ^ tableschema ^ ";\n" ^ *)
(*     "typename " ^ packedschema ^ " = (l<-OSDataLabel is lab, " ^ osschema ^ "{l});\n" ^ *)
(*     "sig toOSRows_" ^ tablename ^  *)
(*       " : ([" ^ schema ^ "], [OSDataLabel]) -> [" ^ packedschema ^ "]\n" ^ *)
(*     "fun toOSRows_" ^ tablename ^ "(rows, dataLabels) policy {\n" ^ *)
(*     " fun toOSRow(row : " ^ schema ^ ") {\n" ^ *)
(*     "  switch(row) {\n" ^ *)
(*     "   case (label_col=tag | a) -> \n" ^ *)
(*     "    var label = findByTag(tag, dataLabels);\n" ^ *)
(*     "    switch(label) {\n" ^ *)
(*     "     case None -> []\n" ^ *)
(*     "     case Some(ld) -> \n" ^ *)
(*     "      var r = relabel(a, ld); \n" ^ *)
(*     "      var rp = pack(ld, r) as " ^ packedschema ^ ";\n" ^ *)
(*     "      [rp] \n" ^ *)
(*     "    }\n" ^ *)
(*     "  }\n" ^ *)
(*     " }\n" ^ *)
(*     " concat(map(toOSRow, rows))\n" ^ *)
(*     "}\n" ^ *)
(*     "sig getTableHandle_" ^ tablename ^ " : () -> TableHandle(" ^ labeledschema ^ *)
(*       ", " ^ labeledschema ^ "){OSInternalLabel}\n" ^ *)
(*     "fun getTableHandle_" ^ tablename ^ "() policy {\n" ^ *)
(*     " var hdl = " ^ *)
(*     "  table \"" ^ tablename ^ "\" with " ^ labeledschema ^ " from " ^ db ^ ";\n" ^ *)
(*     " relabel(hdl, OSInternalLabel)\n" ^ *)
(*     "}\n" ^ *)
(*     "sig refactor_" ^ tablename ^ " : (TableHandle(" ^ labeledschema ^ ", " ^ *)
(*       labeledschema ^ "){OSInternalLabel}, [OSDataLabel]) -> " ^ *)
(*       "[(l<-OSDataLabel is lab, " ^ osschema ^ "{l})]\n" ^ *)
(*     "fun refactor_" ^ tablename ^ "(labeledHandle, dataLabels) policy {\n" ^ *)
(*     " var hdl = unlabel(labeledHandle);\n" ^ *)
(*     " var rows = for (var row <-- hdl) { [row] };\n" ^ *)
(*     " toOSRows_" ^ tablename ^ "(rows, dataLabels)\n" ^ *)
(*     "}\n" *)
(*   in *)
(*     fprintf stderr "%s" output; *)
(*     output :: pp_ols moreLines *)
(* else *)
(*   line :: pp_ols moreLines *)

(*     let pp = pp_ols  *)
(*   end *)

module SELinksPP = 
struct

  let apply_pp lines pps =
    let rec apply_pps x = function
        [] -> x
      | pp::pps -> apply_pps (pp x) pps
    in      
    List.iter print_endline (apply_pps lines pps)
      
  let apply_pp_fd fd pps =
    let lines = InputChannel.lines fd in 
    apply_pp lines pps
      
  (* order matters here! *)
  let pps = [
    (* PPIncludes.pp; *)
    PPChecked.pp;
    (* PPOls.pp; *)
  ]
    
  let test_pp input = 
    let lines = Str.split (Str.regexp "\n") input in
    apply_pp lines pps
      
  let main argv =
    let fd = 
      if Array.length(argv) < 2 then stdin
      else 
        try open_in argv.(1)
        with Sys_error _ -> 
          fprintf stderr "Could not process file \"%s\"" argv.(1); 
          exit 1
    in
    apply_pp_fd fd pps
end
;;

SELinksPP.main Sys.argv
