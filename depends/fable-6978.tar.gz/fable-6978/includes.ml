open Printf

exception File_not_found of string

let rec find_in_path filename = function
  | [] -> raise (File_not_found filename)
  | dir::dirs -> 
      let full_filename = dir ^ "/" ^ filename in
      if Sys.file_exists full_filename then full_filename
      else find_in_path filename dirs

let get_selinks_module_path () = 
  let selinks_module_path = 
    let module_path = Settings.get_value Basicsettings.module_path in
    Str.split (Str.regexp ":") module_path
  in
  (* Always include the current directory *)
  "." :: selinks_module_path

let parse_includes filename =
  Debug.print("Running includes");
  let f = open_in filename in
  (* whitespace or comments *)
  let r_valid = Str.regexp "^[ \t\r]*\\(#.*\\)?$" in
  (* include statements *)
  (* this ignores anything after a space or comment *)
  let r_include = Str.regexp "^include *\\([^# \t]*\\)" in
  
  let module_path = get_selinks_module_path () in

  let rec tryLine f = 
    try 
      let l = input_line f in
      (* check while lines are whitespace or comments *)
      if Str.string_match r_include l 0
      then begin
        let m = Str.matched_group 1 l in
        let filename = 
          try 
            find_in_path (String.uncapitalize m ^ ".links") module_path
          with 
            | File_not_found _ -> 
                Debug.f "Could not find module %s. Module path is %s where . = %s" 
                  m (String.concat ":" module_path) (Sys.getcwd ());
                exit 1
            | _ -> 
                Debug.f "Unknown error occured loading module %s" m;
                exit 1
        in            
        filename :: tryLine f
      end
      else if Str.string_match r_valid l 0 
      then tryLine f
      else []
    with End_of_file -> close_in f; []
  in
  tryLine f
