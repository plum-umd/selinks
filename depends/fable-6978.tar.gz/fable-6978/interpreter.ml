(** Run-time evaluation of programs and expressions *)

open Str
open Num
open List

open Utility
open Result
open Syntax
open Expression
open Expression.Expr
open Expression.Query

open Unix
open Printf

(** [bind_rec env defs] extends [env] with bindings for the [defs],
    where each one defines a function and all the functions are
    mutually recursive. *)
let bind_rec locals defs =
  let new_defs = map (fun (name, _) -> 
                        (name, `RecFunction(defs, locals, name))) defs in
    trim_env (new_defs @ locals)


(** Given a label and a record, returns the value of that field in the record,
    together with the remaining fields of the record. *)
let rec crack_row : (string -> ((string * result) list) -> (result * (string * result) list)) = fun ref_label -> function
        | [] -> raise (Runtime_error("Internal error: no field '" ^ ref_label ^ "' in record"))
        | (label, result) :: fields when label = ref_label ->
            (result, fields)
        | field :: fields ->
            let selected, remaining = crack_row ref_label fields in
              (selected, field :: remaining)

(** Given a Links tuple, returns an Ocaml list of the Links values in that
    tuple. *)
let untuple : result -> result list = 
  let rec aux n output = function
    | [] -> List.rev output
    | fields ->
        match partition (fst ->- (=)(string_of_int n)) fields with
          | [_,r], rest -> aux (n+1) (r::output) rest
          | _ -> assert false
  in function
    | `Record fields -> aux 1 [] fields
    | _ -> assert false
        

(** 0 Web-related stuff *)
let has_client_context = ref false

let serialize_call_to_client (continuation, name, arg) = 
  Json.jsonize_call continuation name arg

let program_source = ref(Program([], Syntax.unit_expression no_expr_data))

let client_call_impl name cont (args:Result.result list) =
  let callPkg = Utility.base64encode(serialize_call_to_client(cont, name, args)) 
  in
    if (not !has_client_context) then 
      begin
        let start_script = "LINKS.invokeClientCall(_start, JSON.parseB64Safe(\"" ^ callPkg ^ "\"))" in
        let Program (defs, _) = !program_source in
          Library.print_http_response ["Content-type", "text/html"]
            (Js.make_boiler_page ~onload:start_script
               (Js.generate_program_defs defs (StringSet.singleton name)))
          ; exit 0
      end
    else begin
      Library.print_http_response ["Content-type", "text/plain"] callPkg;
      exit 0
    end

(** {0 Scheduling} *)

(* could bundle these together with [globals] to get a global
   'interpreter state' that we'd then thread through the whole
   interpreter, making it re-entrant. *)
let process_steps = ref 0
let switch_granularity = 5

let rec switch_context globals = 
  if not (Queue.is_empty Library.suspended_processes) then 
    let (cont, value), pid = Queue.pop Library.suspended_processes in
      Library.current_pid := pid;
      apply_cont globals cont value
  else exit 0

and scheduler globals state stepf = 
  incr process_steps;
  if (!process_steps mod switch_granularity == 0) then 
    begin
      process_steps := 0;
      Queue.push (state, !Library.current_pid) Library.suspended_processes;
      switch_context globals
    end
  else
    stepf()

and ac_recv globals cont value = 
  (* If there are any messages, take the first one and
     apply the continuation to it.  Otherwise, suspend
     the continuation (in the blocked_processes table)
     and let the scheduler choose a different thread.
  *)
  let mqueue = Hashtbl.find Library.messages !Library.current_pid in
  if not (Queue.is_empty mqueue) then
    apply_cont globals cont (Queue.pop mqueue)
  else 
    begin
      Hashtbl.add Library.blocked_processes
        !Library.current_pid
        ((Recv::cont, value), !Library.current_pid);
      switch_context globals
    end

(* Invoke database stored procedure 
   This code assumes that the stored procedure already exists,
   that the defined types perfectly match,
   and that the stored procedure returns a single 1-tuple with the result.
   It is currently PostgreSQL-specific.
*)
and call_dbfun sp_name ret_type =
  fun ((`Database(db,_):result)::args) ->
    (* set the return type *)
    let t = ret_type in
    let types = [(sp_name, (t, None))] in
    (* Translate the parameters to strings *)
    let args = map (Library.value_as_string db) args in
    (* form the SQL query *)
    let query = 
      "SELECT "^sp_name^"("^ String.concat "," args ^")" in
    let res = Database.execute_select types query db in
    (* translate Table Rows into singleton value *)
    ((function
        | `List [x] -> x
        | _ -> failwith "Internal error: expected singleton value")
     ->- recfields ->- hd ->- snd) res


and ac_apply_func globals locals args_rev cont func =
  (* evaluate function *)
  let args = List.rev args_rev in
  begin match func with
    | `RecFunction (defs, fnlocals, name) ->
        let Expression.Expr.Abstr((vars : Syntax.expression list), body, _data) = assoc name defs in
        let vars = List.map (fun (Expression.Expr.Variable(v,_)) -> v) vars in
        let recPeers = (* recursively-defined peers *)
          map(fun (name, Expression.Expr.Abstr(args, body, _)) -> 
                (name, `RecFunction(defs, fnlocals, name))) defs in
        let locals = recPeers @ fnlocals @ locals in
        let locals = fold_left2 Result.bind locals vars args in
        let locals = trim_env locals in
        interpret globals locals body cont
    | `PrimitiveFunction name ->
        apply_cont globals cont (Library.apply_pfun name args)
    | `DBFunction (sp_name, ret_type) -> 
        apply_cont globals cont (call_dbfun sp_name ret_type args)
    | `ClientFunction name ->
        client_call_impl name cont args
	| `Continuation cont ->
        assert (length args == 1);
        apply_cont globals cont (List.hd(args))
    | `Abs f -> 
        apply_cont globals (ArgEvalCont (locals, f, [], [])::cont) 
          (`Record
             (snd 
                (List.fold_right
                   (fun field (n,tuple) ->
                      (n+1,
                       (string_of_int n, field)::tuple))
                   args_rev
                   (1, []))))
    | _ -> raise (Runtime_error ("Applied non-function value: "^
                                   string_of_result func))
  end

and ac_arg_eval_cont globals locals func unevaluated_args evaluated_args cont value =
  (* evaluate arguments *)
  let evaluated_args = value :: evaluated_args in
  match unevaluated_args with
    | [] ->
        apply_cont globals 
          (ApplyCont(locals, evaluated_args) :: cont) func
    | next_expr :: exprs ->
        interpret globals locals next_expr 
          (ArgEvalCont(locals, func, exprs, evaluated_args)::cont)
          

and ac_branch_cont globals locals true_branch false_branch cont value =
  let branch = 
	(match value with
       | `Bool true  -> true_branch
       | `Bool false -> false_branch
       | _ -> raise (Runtime_error("Attempt to test a non-boolean value: "
					               ^ string_of_result value)))
  in interpret globals locals branch cont


and ac_binop_apply globals locals op lhsVal cont value =
  let result = 
    match op with
      | `Equal -> bool (Library.equal lhsVal value)
      | `NotEq -> bool (not (Library.equal lhsVal value))
      | `LessEq -> bool (Library.less_or_equal lhsVal value)
      | `Less -> bool (Library.less lhsVal value)
	  | `Union -> 
          begin match lhsVal, value with
	        | `List (l), `List (r) -> `List (l @ r)
	        | _ -> raise(Runtime_error
                           ("Type error: Concatenation of non-list values: "
					        ^ string_of_result lhsVal ^ " and "
					        ^ string_of_result value))
          end
	  | `RecExt label -> 
		  begin match lhsVal with
		    | `Record fields -> 
		        `Record ((label, value) :: fields)
		    | _ -> assert false
          end
	  | `MkTableHandle (row,tc) ->
		  begin match lhsVal with
			| `Database (db, params) ->
			    apply_cont globals cont 
                  (`Table((db, params), charlist_as_string value, row, tc))
			| _ -> failwith("Runtime type error: argument to table was not a database.")
          end
      | `MkViewHandle (query) ->
          begin match lhsVal with
            | `Database db ->
                apply_cont globals cont
                  (`View (db, charlist_as_string value, locals, query))
			| _ -> failwith("Runtime type error: argument to table was not a database.")
          end
      | `App -> 
          begin match untuple value with
            | [] -> 
                apply_cont globals (ApplyCont(locals, [])::cont) lhsVal
            | _::_ as v -> 
                let firsts, last = unsnoc v in
                apply_cont globals (ArgEvalCont (locals, lhsVal, [], firsts)::cont) last
          end
  in
  apply_cont globals cont result


and ac_unop_apply globals locals op cont value =
  match op with
      MkColl -> apply_cont globals cont (`List [(value)])
	| MkVariant(label) -> 
	    apply_cont globals cont (`Variant (label, value))
    | Result.Abs ->
        apply_cont globals cont (`Abs value)
    | VrntSelect(case_label, case_variable, case_body, variable, body) ->
	    (match value with
           | `Variant (label, value) when label = case_label ->
               (interpret globals (Result.bind locals case_variable value) case_body cont)
           | `Variant (_) as value ->
		       (interpret globals (Result.bind locals (valOf variable) value)
		          (valOf body) cont)
           | _ -> raise (Runtime_error "TF181"))
	| MkDatabase ->
        let result = (
          let driver = charlist_as_string (links_project "driver" value)
		  and name = charlist_as_string (links_project "name" value)
		  and args = charlist_as_string (links_project "args" value) in
		  let params =
			(if args = "" then name
			 else name ^ ":" ^ args)
		  in
          `Database (db_connect driver params)) in
	    apply_cont globals cont result
    | Result.Erase label ->
        apply_cont globals cont (`Record (snd (crack_row label (recfields value))))
    | Result.Project label ->
        apply_cont globals cont (fst (crack_row label (recfields value)))
    | ViewOp -> 
        begin match value with
          | `View (_,_,locals',expr) -> interpret globals locals' expr cont
          | _ -> assert false
        end
    | QueryOp (query, table_aliases) ->
        let result = 
          match value with
            | `List (tbls) ->
                Doquery.do_query interpret globals locals query table_aliases tbls
            | _ -> assert false
        in
        apply_cont globals cont result

(* when called via `for', args are g l var from c body *)
and ac_start_coll_extn globals locals variable expr cont value =
  match value with
    | `List (source_elems) ->
	    (match source_elems with
		   | [] -> apply_cont globals cont (`List [])
	       | (first_elem::other_elems) ->
	           (* bind 'var' to the first element, save the others for later *)
		       interpret globals (Result.bind locals variable first_elem) expr
		         (CollExtn(locals, variable, expr, [], other_elems) :: cont))
	| x -> raise (Runtime_error ("TF197 : " ^ string_of_result x))

and ac_coll_extn globals locals var expr rslts inputs cont value =
  let new_results = match value with
      (* Check that value's a collection, and extract its contents: *)
    | `List (expr_elems) -> expr_elems
    | r -> raise (Runtime_error ("TF183 : " ^ string_of_result r))
  in
  (* Extend rslts with the newest list of results. *)
  let rslts = (List.rev new_results) :: rslts in
  match inputs with
	| [] -> (* no more inputs, collect results & continue *)
		apply_cont globals cont (`List (List.rev (List.concat rslts)))
	| (next_input_expr::inputs) ->
		(* Evaluate next input, continuing with given results: *)
		interpret globals (Result.bind locals var next_input_expr) expr
		  (CollExtn(locals, var, expr, 
				    rslts, inputs) :: cont)

and ac_xml_cont globals locals tag attrtag children attrs elems cont value = 
  let new_children = 
    match attrtag, value with 
        (* FIXME: multiple attrs resulting from one expr? *)
      | Some attrtag, (`List (_) as s) -> 
          [Attr (attrtag, charlist_as_string s)]
      | None, (`List (elems)) ->
          (match elems with
             | [] -> []
             | `XML _ :: _ ->
                 map xmlitem_of elems
             | `Char _ :: _ ->
                 [ Result.Text(charlist_as_string value) ]
             | _ -> failwith("Internal error: unexpected contents in XML construction"))
      | _ -> failwith("Internal error: unexpected contents in XML construction")
  in
  let children = children @ new_children in
  match attrs, elems with
    | [], [] -> 
        let result = listval [xmlnodeval(tag, children)] in
        apply_cont globals cont result
    | ((k,v)::attrs), _ -> 
        interpret globals locals v
          (XMLCont (locals, tag, Some k, children, attrs, elems) :: cont)
    | _, (elem::elems) -> 
        interpret globals locals elem
          (XMLCont (locals, tag, None, children, attrs, elems) :: cont)
          
(** Apply a continuation to a result; half of the evaluator. *)
and apply_cont (globals : environment) : continuation -> result -> result = 
  fun cont value ->
    let stepf() = match cont with
      | [] ->  (* no more continuations; we're done *)
          (if !Library.current_pid == Library.main_process_pid then
             raise (Library.TopLevel(globals, value))
	       else switch_context globals)
      | frame::cont -> apply_frame globals cont value frame
    in scheduler globals (cont, value) stepf

and apply_frame globals cont value = function
  | Definition(env, name) -> 
      (* use the stored environment, add name:value, 
         and continue *)
	  apply_cont (Result.bind env name value) cont value
  | Recv -> ac_recv globals cont value
  | FuncEvalCont([], locals) -> 
      (* apply_cont globals (ApplyCont(locals, [])::cont) value *)
      ac_apply_func globals locals [] cont value
  | FuncEvalCont(param::params, locals) ->
	  (* Just evaluate the first parameter; "value" is in
	     fact a function value which will later be applied *)
      interpret globals locals param
        (ArgEvalCont(locals, value, params, [])::cont)
  | ApplyCont(locals, args_rev) -> 
      ac_apply_func globals locals args_rev cont value
  | ArgEvalCont(locals, func, unevaluated_args, evaluated_args) ->  
      ac_arg_eval_cont globals locals func unevaluated_args evaluated_args
        cont value
  | LetCont(locals, variable, body) ->
	  interpret globals (Result.bind locals variable value) body cont
  | BranchCont(locals, true_branch, false_branch) ->
      ac_branch_cont globals locals true_branch false_branch cont value
  | BinopRight(locals, op, rhsExpr) ->
	  interpret globals locals rhsExpr
        (BinopApply(locals, op, value) :: cont)
        (* FIXME: locals aren't needed here *)
  | BinopApply(locals, op, lhsVal) ->
      ac_binop_apply globals locals op lhsVal cont value
  | UnopApply (locals, op) ->
      ac_unop_apply globals locals op cont value
  | RecSelect (locals, label, label_var, variable, body) ->
	  let field, remaining = crack_row label (recfields value) in
      let new_env = 
        trim_env (Result.bind (Result.bind locals variable
					             (`Record remaining))
				    label_var field) in
      interpret globals new_env body cont
  | StartCollExtn (locals, variable, expr) -> 
      ac_start_coll_extn globals locals variable expr cont value
  | CollExtn (locals, var, expr, rslts, inputs) ->
      ac_coll_extn globals locals var expr rslts inputs cont value 
  | XMLCont (locals, tag, attrtag, children, attrs, elems) ->
      ac_xml_cont globals locals tag attrtag children attrs elems cont value
  | IgnoreDef (locals, def) ->
	  interpret_definition globals locals def cont
  | Ignore (locals, expr) ->
	  interpret globals locals expr cont
          
(* Define a remote call to a DB stored procedure *)
and define_dbfunc globals cont name ret_type =
  (* get return type of type *)
  let func = `DBFunction (name, ret_type) in 
  let globals = Result.bind globals name func in
    apply_cont globals cont (`Record [])
  
and interpret_definition : environment -> environment -> definition -> continuation -> result =
  fun globals locals def cont ->
    match def with
      | Syntax.Define (name, _, `Database, t2) ->
          let `T (_, {Types.ltype=`Function (_, _, ret_type)}, _) = t2 in
          define_dbfunc globals cont name ret_type
      | Syntax.Define (name, expr, _, _) -> 
          interpret globals [] expr (Definition (globals, name) :: cont)
      | Syntax.Alien (lang, name, type_assum, _) when lang == "plpgsql" ->
          let (_, {Types.ltype=`Function (_, _, ret_type)}) = type_assum in
          define_dbfunc globals cont name ret_type
      | Syntax.Alien _
      | Syntax.Alias _ 
      | Syntax.Module _ -> 
          apply_cont globals cont (`Record [])

(* interpret and helpers *)

(* handle Links base types as OCaml types *)
and box_constant = function
  | Expression.Boolean b -> bool b
  | Expression.Integer i -> int i
  | Expression.String s -> string_as_charlist s
  | Expression.Float f -> float f
  | Expression.Char ch -> char ch


and interpret : environment -> environment -> Syntax.expression -> continuation -> result =
  fun globals locals expr cont ->
    (* eval is shorthand for recurvsive call with same arguments *)
    let eval = interpret globals locals in
    (* The main pattern-matching on the type of expression *)
    match (expr : 'a Expression.Expr.expression') with
      | Expression.Expr.Constant (c, _) -> apply_cont globals cont (box_constant c)
      | Expression.Expr.Variable(name, _) -> 
          let value = (Library.lookup globals locals name) in
	      apply_cont globals cont value
      | Expression.Expr.Abs (f, _) ->
          eval f (UnopApply (locals, Result.Abs)::cont)
      | Expression.Expr.App (f, p, _) ->
          eval f (BinopRight (locals, `App, p)::cont)
      | Expression.Expr.Abstr (variable, body, _) as f->
          let value = `RecFunction([("_anon", f)],
                                   retain (Syntax.freevars body) locals,
                                   "_anon") in
          apply_cont globals cont value
      | Expression.Expr.Apply (Expression.Expr.Variable ("recv", _), [], _) ->
          apply_cont globals (Recv::cont) (`Record [])
      | Expression.Expr.Apply (fn, params, _) ->
          eval fn (FuncEvalCont (params, locals)::cont)
      | Expression.Expr.Condition (condition, if_true, if_false, _) ->
          eval condition (BranchCont(locals, if_true, if_false) :: cont)
      | Expression.Expr.Comparison (l, oper, r, _) ->
          eval l (BinopRight(locals, (oper :> Result.binop), r) :: cont)
      | Expression.Expr.Record_pack(variable, value, _, body, _) 
      | Expression.Expr.Let (variable, value, body, _) ->
          eval value (LetCont(locals, variable, body) :: cont)
      | Expression.Expr.Rec (defs, body, _) ->
          let defs' = List.map (fun (n, v, _type) -> (n, v)) defs in
          let new_env = bind_rec locals defs' in
          interpret globals new_env body cont
      | Expression.Expr.Xml_node _ as xml when Forms.islform xml || Forms.islhref xml ->
          eval (Forms.xml_transform locals (Library.lookup globals locals) (interpret_safe globals locals) xml) cont
      | Expression.Expr.Xml_node (tag, [], [], _) -> 
          apply_cont globals cont (listval [xmlnodeval (tag, [])])
      | Expression.Expr.Xml_node (tag, (k, v)::attrs, elems, _) -> 
          eval v (XMLCont (locals, tag, Some k, [], attrs, elems) :: cont)
      | Expression.Expr.Xml_node (tag, [], (child::children), _) -> 
          eval child (XMLCont (locals, tag, None, [], [], children) :: cont)
            
      | Expression.Expr.Record_intro (fields, None, _) ->
          apply_cont
            globals
            (StringMap.fold (fun label value cont ->
                               BinopRight(locals, `RecExt label, value) :: cont) fields cont)
            (`Record [])
      | Expression.Expr.Record_intro (fields, Some record, _) ->
          eval record (StringMap.fold (fun label value cont ->
                                         BinopRight(locals, `RecExt label, value) :: cont) fields cont)
      | Expression.Expr.Record_selection (label, label_variable, variable, value, body, _) ->
          eval value (RecSelect(locals, label, label_variable, variable, body) :: cont)
      | Expression.Expr.Record_unpack(_, _, _, Some e, _) -> 
          eval e cont
      | Expression.Expr.Project (expr, label, _) ->
          eval expr (UnopApply (locals, Result.Project label) :: cont)
      | Expression.Expr.Erase (expr, label, _) ->
          eval expr (UnopApply (locals, Result.Erase label) :: cont)
      | Expression.Expr.Variant_injection (label, value, _) ->
          eval value (UnopApply(locals, MkVariant(label)) :: cont)
      | Expression.Expr.Variant_selection (value, case_label, case_variable, case_body, variable, body, _) ->
          eval value (UnopApply(locals, VrntSelect(case_label, case_variable, case_body, Some variable, Some body)) :: cont)
      | Expression.Expr.Variant_selection_empty (_) ->
          failwith("internal error: attempt to evaluate empty closed case expression")
      | Expression.Expr.Nil _ ->
          apply_cont globals cont (`List [])
      | Expression.Expr.List_of (elem, _) ->
          eval elem (UnopApply(locals, MkColl) :: cont)
      | Expression.Expr.Concat (l, r, _) ->
          eval l (BinopRight(locals, `Union, r) :: cont)
            
      | Expression.Expr.For (expr, var, value, _) ->
          eval value (StartCollExtn(locals, var, expr) :: cont)
      | Expression.Expr.Database (params, _) ->
          eval params (UnopApply(locals, MkDatabase) :: cont)
	        (* FIXME: the datatype should be explicit in the type-erased TableHandle *)
            (*   | Syntax.Table (database, s, query, _) -> *)
            (*       eval database (UnopApply(locals, QueryOp(query)) :: cont) *)
            
      | Expression.Expr.TableHandle (database, table_name, tc, _) ->    (* getting type from inferred type *)
          begin
            match tc.readtype.Types.ltype with
              | `Record row ->
                  eval database (BinopRight(locals, `MkTableHandle (row,tc), table_name) :: cont)
              | _ ->
                  failwith ("table rows must have record type")
          end
            
      | Expression.Expr.TableQuery (ths, query, data) ->
          (* [ths] is an alist mapping table aliases to expressions that
             provide the corresponding TableHandles. We evaluate those
             expressions and rely on them coming through to the continuation
             in the same order. That way we can stash the aliases in the
             continuation frame & match them up later. *)
          let aliases, th_exprs = split ths in
          eval (Syntax.list_expr data th_exprs)
            (UnopApply(locals, QueryOp(query, aliases)) :: cont)
      | Expression.Expr.ViewHandle (db, table_name, query, d) ->
          (* let view = `View (db, view_name, query) in *)
          (* apply_cont globals cont view *)
          (* (\* eval query cont *\) *)
          eval db (BinopRight (locals, `MkViewHandle (query), table_name) :: cont)

      | Expression.Expr.ViewQuery (query_expr, data) ->
          let StartCollExtn (locals, var, gen) :: cont' = cont in
          (* filter is a Condition *)

          (* this is almost a copy of Optimiser.mk_select_all *)
          (* decode gen *)
          (* gen is probably one of Condition | For *)
          (* Actually, we know it's a for. *)
          (* let for_expr = For (expr, var, (ViewQuery (_))) in *)

          (* let outer_var = var in *)
          (* let outer_expr = expr in *)

          (* Apply (Variable ("as_list", _),  *)

          (* real code below? *)

          
          (* var exView = view "ex_view" as (
             for (var r <-- exTable)
               where (r.owner == uid)
               [(owner = r.owner, filename = r.filename)]
             ) from (db)
          *)
          let result_view, tt = match query_expr with
            | Expression.Expr.Variable (var, tt) -> 
                (* evaluate var to a resultant View *)
                (Library.lookup globals locals var, tt)
            | _ -> failwith "BJC: fixme"
          in

          (* pull the table comprehension out of the view *)
          (* for (var r <-- exTable) *)
          (*   where (r.owner == uid) *)
          (*   [(owner = r.owner, filename = r.filename)] *)
          let table_expr = match result_view with
            | `View (dbinfo, name, locals, expr) -> expr
            | _ -> failwith "boohoo"
          in
          
          (* rebuild For expression..? *)
          (* we need to take apart gen! *)
          let inner_expr' = Apply (Expression.Expr.Variable ("asList", data), [table_expr], tt) in

          let inner_expr' =
            match Optimiser.sql_aslist inner_expr' with
              | Some x -> (
                  match Optimiser.sql_joins x with 
                    | Some e -> e
                    | None -> inner_expr'
                )
              | None -> inner_expr'
          in
          let expr' = For (gen, var, inner_expr', data) in

          eval expr' cont'

          (* eval query_expr (UnopApply(locals, ViewOp) :: cont) *)


          (* let query = *)
          (*   { Query.distinct_only = false *)
          (*   ; Query.result_cols = List.map inLeft columns *)
          (*   ; Query.tables = [(`Subquery subquery, table_alias)] *)
          (*   ; Query.condition = Query.Boolean true *)
          (*   ; Query.sortings = [] *)
          (*   ; Query.max_rows = None *)
          (*   ; Query.offset = Query.Integer (Num.Int 0) *)
          (*   ; Query.projections = [] *)
          (*   } *)

          (* let TableQuery _ = expr in *)
          (* (\* BJC: Here a ViewQuery gets changed to a ViewOp. *)
          (*    We've already lost any chance of merging the outside table call? *\) *)
          (* eval query (UnopApply(locals, ViewOp) :: cont) *)
          (* eval query cont *)
          (* begin match expr with *)
          (*   | `View (_, _, _, query) -> eval query cont *)
          (*   | _ -> failwith "ViewQuery requires `View" *)
          (* end *)

      | Expression.Expr.Call_cc(arg, _) ->
          let cc = `Continuation cont in
          eval arg (ApplyCont(locals, [cc]) :: cont)
      | Expression.Expr.SortBy (list, byExpr, d) ->
          eval (Expression.Expr.Apply (Expression.Expr.Variable ("sortBy", d), [byExpr; list], d)) cont
      | Expression.Expr.Wrong (_) ->
          failwith("Went wrong (pattern matching failed?)")
      | Expression.Expr.HasType(expr, _, _) ->
          eval expr cont

(* end of interpret *)
              
and interpret_safe globals locals expr cont =
  try 
    interpret globals locals expr cont
  with
    | Library.TopLevel s -> snd s
    | NotFound _ -> failwith "Internal error: NotFound _ while interpreting."

(* Run a Links program *)
let run_program (globals : environment) locals (Program (defs, body)) : (environment * result)= 
  try (
    (match defs with
       | [] ->
           interpret globals locals body toplevel_cont
       | def :: defs ->
           interpret_definition globals locals def
             (map (fun def -> IgnoreDef([], def)) defs @ [Ignore([], body)]));
    failwith "boom"
  ) with
    | Library.TopLevel s -> s
    | NotFound _ -> failwith "Internal error: NotFound _ while interpreting."

let run_defs (globals : environment) locals defs : environment =
  let env, _ =
    run_program globals locals
      (Program (defs, (Syntax.unit_expression (Syntax.no_expr_data))))
  in
    env

let apply_cont_safe x y z = 
  try apply_cont x y z
  with
    | Library.TopLevel s -> snd s
    | NotFound _ -> failwith "Internal error: NotFound _ while interpreting."
