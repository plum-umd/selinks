(* A simple module to communicate with a remote process over sockets. *)

(* 
   start server (done at init time? This is not a persistent connection)
   
   request/response function
   
*)

let get_host_addr (hostname: string) : Unix.inet_addr =
  let host_entry = Unix.gethostbyname hostname in
  let host_ips = host_entry.Unix.h_addr_list in
    (* get first element of inet_addrs. If none, we need to signal an
       error anyway *)
  let host_ip = host_ips.(0) in
    host_ip
      
type proxy = Proxy of in_channel * out_channel
  
let connect (hostname: string) (port: int) : proxy =
  let ipaddr = get_host_addr hostname in
  let socket_addr = Unix.ADDR_INET (ipaddr, port) in
  let (in_, out_) = Unix.open_connection socket_addr in
    Proxy (in_,out_)
      
let interact (proxy: proxy) (request: string) : string =
  let Proxy (in_,out_) = proxy in
    output_string out_ (request ^ "\n");
    flush out_;
    let response = input_line in_ in
      response
	
let send (proxy: proxy) (request: string) : unit =
  let Proxy (in_,out_) = proxy in
    output_string out_ request;
    flush out_;
    ()

let sendline (proxy: proxy) (request: string) : unit =
    send proxy (request ^ "\n")
    
let readline (proxy: proxy) : string =
  let Proxy (in_,out_) = proxy in
  let response = input_line in_ in
    response

(* TODO: add back in error handling *)
let close (proxy: proxy) : unit =
  let Proxy (in_,out_) = proxy in
    close_in_noerr in_;
    close_out_noerr out_;
    ()
    
let command (hostname: string) (port: int) (request: string) : string =
  let proxy = connect hostname port in
  let response = interact proxy request in
    close proxy;
    response
      
