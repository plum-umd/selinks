(* A simple module to communicate with a remote process over sockets. *)

(* 
   start server (done at init time? This is not a persistent connection)
   
   request/response function
   
 *)

type proxy = Proxy of in_channel * out_channel

let connect (host_ip: string) (port: int) : proxy =
  (* not sure how to translate domain name to an ip address *)
  let ipaddr = Unix.inet_addr_of_string host_ip in
  let socket_addr = Unix.ADDR_INET (ipaddr, port) in

  let (in_, out_) = Unix.open_connection socket_addr in
  Proxy (in_,out_)
  
let interact (proxy: proxy) (request: string) : string =
  let Proxy (in_,out_) = proxy in
  output_string out_ request;
  flush out_;
  let response = input_line in_ in
  response

let close (proxy: proxy) : () =
  let Proxy (in_,out_) = proxy in
  close_out out_;
  close_in in_;
  ()
