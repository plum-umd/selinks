(*pp deriving *)
open Num
open List
open Utility
(* open Show *)
(* open Pickle *)

type 'a point = 'a Unionfind.point
    deriving (Eq, Typeable, Shelve, Show)
    
module Pickle_point (S : Pickle.Pickle) =
  Pickle.Pickle_unpicklable(struct type a = S.a point let tname = "point" end)

type lexpos = Lexing.position 
module Typeable_lexpos = Typeable.Primitive_typeable(struct type t = lexpos end)

module Eq_lexpos : Eq.Eq with type a = lexpos = 
struct
  type a = lexpos
  let eq = (==)
end

(* let print_digest_junk = Settings.add_bool("print_digest_junk", false, `User) *)

module LexposType = struct type a = lexpos let tname = "Syntax.lexpos" end
module Show_lexpos = Show_unprintable (LexposType)
module Pickle_lexpos = Pickle.Pickle_unpicklable (LexposType)
module Shelve_lexpos = struct
  type a = lexpos
  module Typeable = Typeable_lexpos
  module Eq = Eq_lexpos
  let shelve _ = failwith ("attempt to shelve a value of unshelvable type : Syntax.lexpos")
end

type position = lexpos *  (* source line: *) string 
    * (* expression source: *) string
    deriving (Typeable, Show, Eq, Pickle, Shelve)

type label = string
    deriving (Eq, Typeable, Show, Pickle, Shelve)
    (* Q: Can I write my own show for these? I want to base64 it *)
    
type comparison = [`Less | `LessEq | `Equal | `NotEq]
    deriving (Eq, Typeable, Show, Pickle, Shelve)

type constant =
  | Boolean of bool
  | Integer of num
  | Char of char
  | String of string
  | Float of float
      deriving (Eq, Typeable, Show, Pickle, Shelve)


module type PreExpr = sig
  type 'a datatype'
  type query 

  type 'a expression' =
    | Constant of (constant * 'a)       (* constant *)
    | Variable of (string * 'a)         (* variable *)
    | Abs of ('a expression' * 'a)                  (* abs : (((|b)) -> c) -> *(|b) -> c *)
    | App of ('a expression' * 'a expression' * 'a) (* app : (*(|c) -> b, (|c)) -> b  *)*)
    | Apply of ('a expression' * 'a expression' list * 'a) (* internal *)
    | Condition of ('a expression' * 'a expression' * 'a expression' * 'a) (* if/else *)
    | Comparison of ('a expression' * comparison * 'a expression' * 'a) (* ==, >, etc. *)
    | Abstr of ('a expression' list * 'a expression' * 'a) (* internal *)
    | Let of (string * 'a expression' * 'a expression' * 'a) (* let *)
    | Rec of ((string * 'a expression' * 'a datatype' option) list * 'a expression' * 'a) (* recursive rec *)
    | Xml_node of (string * (string * 'a expression') list * 'a expression' list * 'a)
        (* Next two are used to initialize and extend records *)
    | Record_intro of (('a expression') Utility.stringmap * ('a expression') option * 'a)
    | Record_selection of (string * string * string * 'a expression' * 'a expression' * 'a)
        (* Next two types are for packing/unpacking records in Fable *)
    | Record_unpack of ((string * string) list * 'a expression' * 'a expression' * 'a expression' option * 'a)
    | Record_pack of (string * 'a expression' * 'a datatype' * 'a expression' * 'a)
        (* Used to project a record *)
    | Project of ('a expression' * string * 'a)
        (* NYI *)
    | Erase of ('a expression' * string * 'a)
        (* Create a variant *)
    | Variant_injection of (string * 'a expression' * 'a)
        (* Used for pattern-matching variants *)
    | Variant_selection of ('a expression' * string * string * 'a expression' * 
                              string * 'a expression' * 'a)
    | Variant_selection_empty of ('a expression' * 'a)
    | Nil of 'a                         (* [] *)
    | List_of of ('a expression' * 'a)  (* [1,2,3] *)
    | Concat of ('a expression' * 'a expression' * 'a) (* x ++ y *)
    | For of ('a expression' * string * 'a expression' * 'a) (* for *)
    | Database of ('a expression' * 'a)
    | TableQuery of ((string * 'a expression') list * query * 'a)
        (* ([(table_alias, variable)], query, data) *)
    | TableHandle of ('a expression' * 'a expression' * 'a table_constr * 'a)
    | ViewQuery of ('a expression' * 'a)
        (* (db, view_name, tablequery, data) *)
    | ViewHandle of ('a expression' * 'a expression' * 'a expression' * 'a)
    | SortBy of ('a expression' * 'a expression' * 'a)
    | Call_cc of ('a expression' * 'a)
    | Wrong of 'a
    | HasType of ('a expression' * 'a datatype' * 'a) (* x :: a *)
  and 'a table_constr = {
    readtype:'a datatype'; 
    writetype: 'a datatype'; 
    marshallby: (string * 'a expression') list;
    primarykey: string list
  }	
end

type untyped_data' = [`U of position] 
    deriving (Eq, Typeable, Show, Pickle, Shelve)
type untyped_data = untyped_data'
    deriving (Eq, Typeable, Show, Pickle, Shelve)

type 't annotated_data = [`T of (position * 't * label option)] 
    deriving (Eq, Typeable, Show, Pickle, Shelve)

module rec Expr : (PreExpr with type 'a datatype' = 'a Types.datatype'
			   and type query = Query.query) = 
struct
  type 'a datatype' = 'a Types.datatype'
  type query = Query.query
      
  type 'a expression' =
    | Constant of (constant * 'a)
    | Variable of (string * 'a)
    | Abs of ('a expression' * 'a)
    | App of ('a expression' * 'a expression' * 'a)
    | Apply of ('a expression' * 'a expression' list * 'a)
    | Condition of ('a expression' * 'a expression' * 'a expression' * 'a)
    | Comparison of ('a expression' * comparison * 'a expression' * 'a)
    | Abstr of ('a expression' list * 'a expression' * 'a)
    | Let of (string * 'a expression' * 'a expression' * 'a)
    | Rec of ((string * 'a expression' * 'a datatype' option) list * 'a expression' * 'a)
    | Xml_node of (string * (string * 'a expression') list * 'a expression' list * 'a)
    | Record_intro of (('a expression') Utility.stringmap * ('a expression') option * 'a)
    | Record_selection of (string * string * string * 'a expression' * 'a expression' * 'a)
    | Record_unpack of ((string * string) list * 'a expression' * 'a expression' * 'a expression' option * 'a)
    | Record_pack of (string * 'a expression' * 'a datatype' * 'a expression' * 'a)
    | Project of ('a expression' * string * 'a)
    | Erase of ('a expression' * string * 'a)
    | Variant_injection of (string * 'a expression' * 'a)
    | Variant_selection of ('a expression' * string * string * 'a expression' * 
			      string * 'a expression' * 'a)
    | Variant_selection_empty of ('a expression' * 'a)
    | Nil of 'a
    | List_of of ('a expression' * 'a)
    | Concat of ('a expression' * 'a expression' * 'a)
    | For of ('a expression' * string * 'a expression' * 'a)
    | Database of ('a expression' * 'a)
    | TableQuery of ((string * 'a expression') list * query * 'a)
    | TableHandle of ('a expression' * 'a expression' * 'a table_constr * 'a)
    | ViewQuery of ('a expression' * 'a)
    | ViewHandle of ('a expression' * 'a expression' * 'a expression' * 'a)
    | SortBy of ('a expression' * 'a expression' * 'a)
    | Call_cc of ('a expression' * 'a)
    | Wrong of 'a
    | HasType of ('a expression' * 'a datatype' * 'a)
  and 'a table_constr = {readtype:'a datatype'; writetype: 'a datatype'; marshallby: (string * 'a expression') list; primarykey: string list}
      
end
  
and Query : (Mkquery.Q with type datatype = Types.datatype) = 
  Mkquery.Make (
    struct type datatype = Types.datatype
	   module Eq_datatype = DerivingSyntax.Eq_datatype
	   module Show_datatype = DerivingSyntax.Show_datatype
	   module Pickle_datatype = DerivingSyntax.Pickle_datatype
	   module Typeable_datatype = DerivingSyntax.Typeable_datatype
	   module Shelve_datatype = DerivingSyntax.Shelve_datatype
	     (* 	       deriving (Eq, Show, Pickle, Typeable, Shelve) *)
    end)
    
and Types : (
  Mktypes.T with type 'a fq = 'a FableType.fable_qualifier
		    and type kind = FableType.kind
		    and type typed_data = FableType.typed_data
		    and type untyped_data = FableType.untyped_data
	    )  = Mktypes.Make (FableType)
  
and FableType : (
  Mktypes.FableType with type 'a expression' = 'a Expr.expression'
				    and type 'a datatype' = 'a Types.datatype'
				    and type untyped_data = untyped_data'
				    and type typed_data = Types.datatype annotated_data) =

struct
  type kind = MKind | UKind 
      deriving (Eq, Show, Pickle, Typeable, Shelve)

  type 'a lbasis = [ `Nothing | `Something of 'a]
      deriving (Eq, Show, Pickle, Typeable, Shelve)
      
  type 'a triopt = 
      [ `Nothing  
      | `Inferred of 'a lbasis point 
      | `Required of 'a]
	deriving (Eq, Show, Pickle, Typeable, Shelve)

  type 'a expression' = 'a Expr.expression'

  type 'a fable_qualifier = 
      [ `Empty
      | `KindVar of 'a kind_var_basis Unionfind.point
      | `Kind of kind 
      | `Name of string * 'a fable_qualifier
      | `Labeling of 'a expression' * 'a fable_qualifier
      | `Label of 'a expression' triopt * 'a fable_qualifier
      | `Phantom of string list * 'a fable_qualifier ]
  and 'a kind_var_basis = 
      [ `FlexKind of int * kind (*bound*)
      | `FixedKind of 'a fable_qualifier ]
(*       deriving (Eq, Show, Pickle, Typeable, Shelve) *)
	
  type 'a datatype' = 'a Types.datatype'
  type untyped_data = untyped_data'
  type typed_data = Types.datatype annotated_data

  type untyped_expression = untyped_data expression' 
  and typed_expression = typed_data expression'
  and unchecked_fable_type = untyped_data fable_qualifier 
  and fable_type = typed_data fable_qualifier

  exception Bad_fable_type of string

  let rec kind_join (k1,k2) = match (k1,k2) with
    | _, MKind 
    | MKind, _ -> MKind
    | _ -> UKind
	
  let kind_leq (k1, k2) = kind_join (k1,k2) = k2

  (*  When is a fable_qualifier syntactically well-formed? *)
  (* 1. No duplicate `Name binders *)
  (* 2. `Phantom, if present, must be the top-level qualifier *)
  (* 3. `Name must be at the root, or beneath a `Phantom *)
  (* 4. All labelings must be aggregated into a single `Labeling constructor *)
  (* 5. `Label must be a leaf *)
  let well_formed_fq : 'a fable_qualifier -> bool =
    let rec aux seen = function
	`Empty
      | `KindVar _ 
      | `Kind _ -> true
      | `Label (_, t) -> aux (`Label::seen) t
      | `Labeling (_, t) ->
          if ((not (List.mem `Labeling seen)) || 
		match seen with
                    `Labeling::_ -> true
		  | _ -> false)  then
	    aux (`Labeling::seen) t
	  else
	    false
      | `Name (_, t) ->
          if not (seen = [] || seen = [`Phantom]) then
	    false
	  else
            aux (`Name::seen) t
      | `Phantom(_, t) ->
          if not (seen = []) then
	    false 
	  else 
            aux [`Phantom] t
      | _ -> false in
      fun ft -> aux [] ft

  let combine : 'a fable_qualifier -> 'a fable_qualifier -> 'a fable_qualifier = 
    let fail _ = raise (Bad_fable_type ("Illegal combination of fable annotations: combine " )) in
    let rec aux fq1 fq2 = match fq1, fq2 with 
      | _, `Empty -> fq1
      | `Empty, _ -> fq2
      | `Kind k1, `Kind k2 -> `Kind (kind_join (k1, k2))
      | `Label(e, q), _ -> `Label(e, aux q fq2) 
      | `Labeling(e, q), _ -> `Labeling(e, aux q fq2)
      | `Name(e, q), _ -> `Name(e, aux q fq2)
      | `Phantom(e, q), _ -> `Phantom(e, aux q fq2)
      | _ -> fail () in 
    fun fq1 fq2 -> 
      let fq = aux fq1 fq2 in
	if well_formed_fq fq then 
	  fq
	else
	  raise (Bad_fable_type ("Illegal combination of fable annotations; result is not well-formed"))

  let rec kind_qual : 'a fable_qualifier -> kind = function
      `Empty -> UKind
    | `KindVar v -> 
	(match Unionfind.find v with 
	     `FlexKind (_, k) -> k
	   | `FixedKind k -> kind_qual k)
    | `Labeling(_, _) -> MKind
    | `Kind k -> k
    | `Label(_, _) -> UKind
    | `Phantom(_, u) 
    | `Name(_,u) -> kind_qual u

  let instantiate fq1 fq2 : 'a fable_qualifier = 
    let fail _ = raise (Bad_fable_type ("Illegal instantiation of fable annotations")) in
    let rec aux fq1 fq2 : 'a fable_qualifier = match fq1 with 
      | `Empty -> fq2
      | `Kind k1 -> 
	  (match fq2 with 
	     | `Kind k2 -> if kind_leq (k2, k1) then fq2 else fail ()
	     | `KindVar kv ->
		 (match Unionfind.find kv with
		      `FlexKind (_, k2) when kind_leq (k2, k1) -> fq2
		    | `FixedKind k2 when kind_leq (kind_qual k2, k1) -> fq2
		    | _ -> fail())
	     | _ -> 
		 if (kind_leq ((kind_qual fq2), k1)) then 
		   fq2
		 else fail ())
	    
      | `KindVar p1 -> 
	  (match Unionfind.find p1 with 
	       `FixedKind k1 -> aux k1 fq2
	     | `FlexKind(_, k1) -> aux (`Kind k1) fq2)
      | `Label(e, q) -> `Label(e, aux q fq2) 
      | `Labeling(e, q) -> `Labeling(e, aux q fq2)
      | `Name(e, q) -> `Name(e, aux q fq2)
      | `Phantom(e, q) -> `Phantom(e, aux q fq2)
(*       | _ ->  *)
(* 	      match fq2 with  *)
(* 	          `Empty -> fq1 *)
(* 	        | _ -> fail() *)
    in
    let fq = aux fq1 fq2 in
      if well_formed_fq fq then 
	fq
      else
	raise (Bad_fable_type ("Illegal combination of fable annotations; result is not well-formed"))

  let def_annot _ = (`Kind UKind)
  let name_annot = fun n -> `Name (n,`Empty)
  let labeling_annot = fun ue -> `Labeling (ue, `Empty)
  let label_annot = fun ue -> `Label (ue, `Empty)
  let phantom_annot = fun pvs ->  `Phantom (pvs, `Empty)
  let string_as_kind = function
    | "M" -> MKind
    | "U" -> UKind
    | x -> raise (Bad_fable_type ("Bad kind : " ^x))
  let kind_as_annot k = `Kind k
end

(* All the manual deriving stuff is in this module *)

and DerivingSyntax : sig
  module Eq_datatype : Eq with type a = Types.datatype
  module Show_datatype : Show with type a = Types.datatype
  module Pickle_datatype : Pickle with type a = Types.datatype
  module Typeable_datatype : Typeable with type a = Types.datatype
  module Shelve_datatype : Shelve with type a = Types.datatype

  module Show_ldatatype : Show with type a = Types.ldatatype

  module Eq_row : Eq with type a = Types.row
  module Show_row : Show with type a = Types.row
  module Pickle_row : Pickle with type a = Types.row
  module Typeable_row : Typeable with type a = Types.row
  module Shelve_row : Shelve with type a = Types.row

  module Eq_typed_expression : Eq with type a = FableType.typed_expression
  module Show_typed_expression : Show with type a = FableType.typed_expression
  module Show_debug_expression : Show with type a = FableType.typed_expression
  module Pickle_typed_expression : Pickle with type a = FableType.typed_expression
  module Typeable_typed_expression : Typeable with type a = FableType.typed_expression
  module Shelve_typed_expression : Shelve with type a = FableType.typed_expression

  module Eq_u_datatype : Eq with type a = Types.u_datatype
  module Show_u_datatype : Show with type a = Types.u_datatype
  module Eq_untyped_expression : Eq with type a = FableType.untyped_expression
  module Show_untyped_expression : Show with type a = FableType.untyped_expression

  module Show_stripped_expression : Show with type a = unit Expr.expression'
  module Show_assumption : Show with type a = Types.assumption 
  module Show_u_assumption : Show with type a = Types.u_assumption 
  module Show_fable_type : Show with type a = FableType.fable_type

  module Show_table_constr : Show with type a = FableType.typed_data Expr.table_constr

  module Functor_expression' : sig
    val map : ('a -> 'b) -> 'a Expr.expression' -> 'b Expr.expression'
  end
  
  module Rewrite_expression' (T : sig type a end) : 
    Rewrite.Rewrite with type t = T.a Expr.expression'

end = struct

(* ******************************  DUMMY VERSION Start  ****************************** *)      

  exception UnimplementedDeriving of string

  module type AnyArg = sig 
    type a 
    val name : unit -> string
  end

  open Eq
  open Show
  open Typeable
  open Pickle
  open Shelve

  module Eq_all (V0 : AnyArg) : Eq with type a = V0.a =
    (Eq_defaults
     (struct
	type a = V0.a
	let rec eq _ _ = raise (UnimplementedDeriving (V0.name ()))
      end))

    module Show_any (V0 : AnyArg) : Show with type a = V0.a =
      struct
      include
        (ShowDefaults
           (struct
              type a = V0.a
	      let format f x = () (*   raise (UnimplementedDeriving (V0.name ())) *)
	    end
	   ))
      end

    module Pickle_any (V0 : AnyArg) : 
      Pickle with type a = V0.a = 
      (Pickle_defaults
         (struct
            type a = V0.a
            let rec pickle _ = raise (UnimplementedDeriving (V0.name ()))
	    let unpickle _ = raise (UnimplementedDeriving (V0.name ()))
	  end) : 
	 Pickle with type a = V0.a)

    module Typeable_any (V0 : AnyArg): Typeable with type a = V0.a = 
        Typeable_defaults
          (struct
             type a = V0.a 
             let typeRep _ =  raise (UnimplementedDeriving (V0.name ()))
           end)

    module Shelve_any (V0: AnyArg) : Shelve with type a = V0.a = 
    struct
      module Typeable = Typeable_any (V0)
      module Eq = Eq_all (V0) 
      module Comp = Dynmap.Comp (Typeable) (Eq)
      type a = V0.a
      let rec shelve _ = 
	raise (UnimplementedDeriving (V0.name()))
    end


  module AnyDatatype = struct 
    type a = Types.datatype
    let name _ = "Types.datatype"
  end

  module AnyLDatatype = struct 
    type a = Types.ldatatype
    let name _ = "Types.datatype"
  end

  module AnyFableType = struct 
    type a = FableType.fable_type
    let name _ = "Types.datatype"
  end

  module AnyUDatatype = struct 
    type a = Types.u_datatype
    let name _ = "Types.datatype"
  end

  module AnyRow = struct 
    type a = Types.row
    let name _ = "Types.datatype"
  end

  module AnyTypedExpr = struct 
    type a = FableType.typed_expression
    let name _ = "Types.datatype"
  end

  module AnyUntypedExpr = struct 
    type a = FableType.untyped_expression
    let name _ = "Types.datatype"
  end


(*   module Eq_datatype : Eq with type a = Types.datatype =  *)
(*     Eq_all(AnyDatatype) *)
(*   module Eq_row : Eq with type a = Types.row *)
(* =    Eq_all(AnyRow) *)

(*   module Eq_typed_expression : Eq with type a = FableType.typed_expression *)
(* =    Eq_all(AnyTypedExpr) *)

(*   module Eq_u_datatype : Eq with type a = Types.u_datatype *)
(* =    Eq_all(AnyUDatatype) *)

(*   module Eq_untyped_expression : Eq with type a = FableType.untyped_expression *)
(* =    Eq_all(AnyUntypedExpr) *)


(*   module Show_datatype : Show with type a = Types.datatype =  *)
(*     Show_any(AnyDatatype) *)

(*   module Show_ldatatype : Show with type a = Types.ldatatype = *)
(*     Show_any(AnyLDatatype) *)

(*   module Show_row : Show with type a = Types.row *)
(*  =   Show_any(AnyRow) *)

(*   module Show_typed_expression : Show with type a = FableType.typed_expression *)
(* =    Show_any(AnyTypedExpr) *)


(*   module Show_u_datatype : Show with type a = Types.u_datatype *)
(* =    Show_any(AnyUDatatype) *)

(*   module Show_untyped_expression : Show with type a = FableType.untyped_expression *)
(* =    Show_any(AnyUntypedExpr) *)

(*   module Show_stripped_expression = *)
(*     Show_any (struct *)
(* 		type a = (unit, FableType.fable_type) Expr.expression' *)
(* 		let name _ = "Show_stripped_expression" *)
(* 	      end) *)

(*   module Show_assumption : Show with type a = Types.assumption  *)
(* =    Show_any (struct *)
(* 		type a = Types.assumption *)
(* 		let name _ = "Show_assumption" *)
(* 	      end) *)

(*   module Show_fable_type : Show with type a = FableType.fable_type *)
(* =    Show_any (struct *)
(* 		type a = FableType.fable_type *)
(* 		let name _ = "Show_fable_type" *)
(* 	      end) *)
    

(*   module Pickle_datatype : Pickle with type a = Types.datatype *)
(*     =Pickle_any(AnyDatatype) *)

(*   module Pickle_row : Pickle with type a = Types.row *)
(*   =  Pickle_any(AnyRow) *)

(*   module Pickle_typed_expression : Pickle with type a = FableType.typed_expression *)
(* =    Pickle_any(AnyTypedExpr) *)



  module Typeable_datatype : Typeable with type a = Types.datatype
=    Typeable_any(AnyDatatype)

  module Typeable_row : Typeable with type a = Types.row
   = Typeable_any(AnyRow)

  module Typeable_typed_expression : Typeable with type a = FableType.typed_expression
=    Typeable_any(AnyTypedExpr)



  module Shelve_datatype : Shelve with type a = Types.datatype
 =   Shelve_any(AnyDatatype)

  module Shelve_row : Shelve with type a = Types.row
    =Shelve_any(AnyRow)

  module Shelve_typed_expression : Shelve with type a = FableType.typed_expression
=    Shelve_any(AnyTypedExpr)




(* ******************************  DUMMY VERSION End  ****************************** *)      


  open Expr
  open FableType
  open Types
  open Eq
  open Primitives

  type 'a stringmap = 'a Utility.StringMap.t
  type 'a field_env = 'a stringmap deriving (Eq, Pickle, Typeable, Show, Shelve)
    
(* ******************************  deriving (Eq) START  ****************************** *)

    module rec Eq_fable_type :
      Eq with type a = typed_data fable_qualifier =
      (Eq_defaults
         (struct
            type a = typed_data fable_qualifier
                let rec eq l r =
                  match l, r with
                    `Empty, `Empty -> true
                  | `KindVar l, `KindVar r ->
                      let module M = Unionfind.Eq_point (Eq_typed_kind_var_basis)
                      in
                      M.eq l r
                  | `Kind l, `Kind r -> let module M = Eq_kind in M.eq l r
                  | `Name l, `Name r ->
                      let module M = Eq_2 (Eq_string) (Eq_fable_type)
                      in
                      M.eq l r
                  | `Labeling l, `Labeling r ->
                      let module M =
                        Eq_2 (Eq_typed_expression) (Eq_fable_type)
                      in
                      M.eq l r
                  | `Label l, `Label r ->
                      let module M =
                        Eq_2 (Eq_triopt (Eq_typed_expression))
                          (Eq_fable_type)
                      in
                      M.eq l r
                  | `Phantom l, `Phantom r ->
                      let module M =
                        Eq_2 (Eq_list (Eq_string)) (Eq_fable_type)
                      in
                      M.eq l r
                  | _ -> false
              end) :
           Eq with type a = typed_data fable_qualifier)
        and Eq_typed_kind_var_basis : Eq with type a = typed_data kind_var_basis =
          (Eq_defaults
             (struct
                type a = typed_data kind_var_basis
                let rec eq l r =
                  match l, r with
                    `FlexKind l, `FlexKind r ->
                      let module M = Eq_2 (Eq_int) (Eq_kind) in M.eq l r
                  | `FixedKind l, `FixedKind r ->
                      let module M = Eq_fable_type in M.eq l r
                  | _ -> false
              end) :
           Eq with type a = typed_data kind_var_basis)

    and Eq_unchecked_fable_type :
      Eq with type a = untyped_data fable_qualifier =
      (Eq_defaults
         (struct
            type a = untyped_data fable_qualifier
                let rec eq l r =
                  match l, r with
                    `Empty, `Empty -> true
                  | `KindVar l, `KindVar r ->
                      let module M = Unionfind.Eq_point (Eq_untyped_kind_var_basis)
                      in
                      M.eq l r
                  | `Kind l, `Kind r -> let module M = Eq_kind in M.eq l r
                  | `Name l, `Name r ->
                      let module M = Eq_2 (Eq_string) (Eq_unchecked_fable_type)
                      in
                      M.eq l r
                  | `Labeling l, `Labeling r ->
                      let module M =
                        Eq_2 (Eq_untyped_expression) (Eq_unchecked_fable_type)
                      in
                      M.eq l r
                  | `Label l, `Label r ->
                      let module M =
                        Eq_2 (Eq_triopt (Eq_untyped_expression))
                          (Eq_unchecked_fable_type)
                      in
                      M.eq l r
                  | `Phantom l, `Phantom r ->
                      let module M =
                        Eq_2 (Eq_list (Eq_string)) (Eq_unchecked_fable_type)
                      in
                      M.eq l r
                  | _ -> false
              end) :
           Eq with type a = untyped_data fable_qualifier)
        and Eq_untyped_kind_var_basis : Eq with type a = untyped_data kind_var_basis =
          (Eq_defaults
             (struct
                type a = untyped_data kind_var_basis
                let rec eq l r =
                  match l, r with
                    `FlexKind l, `FlexKind r ->
                      let module M = Eq_2 (Eq_int) (Eq_kind) in M.eq l r
                  | `FixedKind l, `FixedKind r ->
                      let module M = Eq_unchecked_fable_type in M.eq l r
                  | _ -> false
              end) :
           Eq with type a = untyped_data kind_var_basis)


  and Eq_datatype : Eq with type a = Types.datatype =
    (Eq_defaults
       (struct
          type a = Types.datatype
          let rec eq l r =
            let module M = Eq_ldatatype
                in
              M.eq l.Types.ltype r.Types.ltype
	      &&
		(let module M = Eq_fable_type in M.eq l.Types.ftype r.Types.ftype && true)
        end) :
       Eq with type a = Types.datatype)
  and Eq_meta_type_var_basis :
    Eq with type a = Types.meta_type_var_basis =
    (Eq_defaults
       (struct
          type a = Types.meta_type_var_basis
                let rec eq l r =
                  match l, r with
                    Types.Flexible l, Types.Flexible r ->
                      let module M = Eq_int in M.eq l r
                  | Types.Rigid l, Types.Rigid r -> let module M = Eq_int in M.eq l r
                  | Types.UncheckedRecursive l, Types.UncheckedRecursive r ->									       
                      let module M =
                        Eq_2 (Eq_int) (Eq_u_datatype)
                      in
                        M.eq l r		      
                  | Types.Recursive l, Types.Recursive r ->
                      let module M =
                        Eq_2 (Eq_int) (Eq_datatype)
                      in
                        M.eq l r
                  | Types.Body l, Types.Body r ->
                      let module M = Eq_datatype in M.eq l r
                  | _ -> false
              end) :
           Eq with type a = Types.meta_type_var_basis)
    and Eq_meta_row_var_basis : Eq with type a = Types.meta_row_var_basis =
          (Eq_defaults
             (struct
                type a = Types.meta_row_var_basis
                let rec eq l r =
                  match l, r with
                    Types.ClosedRow, Types.ClosedRow -> true
                  | Types.FlexibleRow l, Types.FlexibleRow r ->
                      let module M = Eq_int in M.eq l r
                  | Types.RigidRow l, Types.RigidRow r ->
                      let module M = Eq_int in M.eq l r
                  | Types.RecursiveRow l, Types.RecursiveRow r ->
                      let module M = Eq_2 (Eq_int) (Eq_row)
                      in
                      M.eq l r
                  | Types.BodyRow l, Types.BodyRow r ->
                      let module M = Eq_row in M.eq l r
                  | _ -> false
              end) :
           Eq with type a = Types.meta_row_var_basis)
     and Eq_ldatatype : Eq with type a = Types.ldatatype =
 	(Eq_defaults
           (struct
              type a = Types.ldatatype
              let rec eq l r =
		match l, r with
                    `Not_typed, `Not_typed -> true
        	  | `Primitive l, `Primitive r when l=r -> true
                  | `Function l, `Function r ->
                      let module M =
                        Eq_3 (Eq_datatype) (Eq_datatype) (Eq_datatype)
                      in
			M.eq l r
                  | `Record l, `Record r ->
		      let module M = Eq_row in M.eq l r
                  | `Variant l, `Variant r ->
                      let module M = Eq_row in M.eq l r
                  | `Table l, `Table r ->
                      let module M = Eq_2 (Eq_datatype) (Eq_datatype)
                      in
			M.eq l r
                  | `Application l, `Application r ->
                      let module M = Eq_2 (Eq_string) (Eq_list (Eq_datatype))
                      in
			M.eq l r
		  | `MetaTypeVar l, `MetaTypeVar r ->
		      let module M = Eq_meta_type_var in M.eq l r
                  | _ -> false
            end) :
           Eq with type a = Types.ldatatype)
     and Eq_field_spec : Eq with type a = Types.field_spec =
          (Eq_defaults
             (struct
                type a = Types.field_spec
                let rec eq l r =
                  match l, r with
                    `Present l, `Present r ->
                      let module M = Eq_datatype in M.eq l r
                  | `Absent, `Absent -> true
                  | _ -> false
              end) :
           Eq with type a = Types.field_spec)
     and Eq_field_spec_map : Eq with type a = Types.field_spec_map =
         Mktypes.Eq_field_env (Eq_field_spec)
     and Eq_row : Eq with type a = Types.row =
         Eq_2 (Eq_field_spec_map) (Eq_row_var)
     and Eq_row_var : Eq with type a = Types.row_var =
         Eq_point (Eq_meta_row_var_basis)
     and Eq_meta_type_var : Eq with type a = Types.meta_type_var =
         Eq_point (Eq_meta_type_var_basis)
 (* TODO: consider using a more reasonable Eq_u_datatype *)
     and Eq_u_datatype : Eq with type a = Types.u_datatype =
    (Eq_all (struct
		 type a = Types.u_datatype
		 let name _ = "Eq_u_datatype"
	       end))
      
    and Eq_typed_data : Eq with type a = Types.datatype annotated_data
	= (* (Eq_annotated_data (Eq_datatype)) *)
    (Eq_defaults
       (struct 
	      type a = Types.datatype annotated_data
	      let rec eq l r = match l,r with
	          `T(_, _, _), `T(_, _, _) -> true (* Eq_datatype.eq dtl dtr *)
	    end))
			   
    and Eq_u_table_constr : Eq with type a = untyped_data table_constr
      =
      (Eq_defaults
	 (struct 
	    type a = untyped_data table_constr
	    let rec eq l r = 
	      let module M = Eq_list (Eq_2 (Eq_string) (Eq_untyped_expression)) in
		Eq_u_datatype.eq l.readtype r.readtype &&
		  Eq_u_datatype.eq l.writetype r.writetype &&
		  M.eq l.marshallby r.marshallby
	  end))


    and Eq_table_constr : Eq with type a = typed_data table_constr
      =
      (Eq_defaults
	 (struct 
	    type a = typed_data table_constr

	    let rec eq l r = 
	      let module M = Eq_list (Eq_2 (Eq_string) (Eq_typed_expression)) in
		Eq_datatype.eq l.readtype r.readtype &&
		  Eq_datatype.eq l.writetype r.writetype &&
		  M.eq l.marshallby r.marshallby
	  end))

    and Eq_untyped_expression :
      Eq with type a = untyped_expression =
      (Eq_defaults
         (struct
            type a = untyped_expression
            let rec eq l r =
              match l, r with
                  Constant l, Constant r ->
                    let module M = Eq_2 (Eq_constant) (Eq_untyped_data) in M.eq l r
                | Variable l, Variable r ->
                    let module M = Eq_2 (Eq_string) (Eq_untyped_data) in M.eq l r
                  | Abs l, Abs r ->
                      let module M = Eq_2 (Eq_untyped_expression) (Eq_untyped_data) in M.eq l r
                  | App l, App r ->
                      let module M =
                        Eq_3 (Eq_untyped_expression) (Eq_untyped_expression) (Eq_untyped_data)
                      in
                      M.eq l r
                  | Apply l, Apply r ->
                      let module M =
                        Eq_3 (Eq_untyped_expression) (Eq_list (Eq_untyped_expression)) (Eq_untyped_data)
                      in
                      M.eq l r
                  | Condition l, Condition r ->
                      let module M =
                        Eq_4 (Eq_untyped_expression) (Eq_untyped_expression)
                          (Eq_untyped_expression) (Eq_untyped_data)
                      in
                      M.eq l r
                  | Comparison l, Comparison r ->
                      let module M =
                        Eq_4 (Eq_untyped_expression) (Eq_comparison) (Eq_untyped_expression)
                          (Eq_untyped_data)
                      in
                      M.eq l r
                  | Abstr l, Abstr r ->
                      let module M =
                        Eq_3 (Eq_list (Eq_untyped_expression)) (Eq_untyped_expression) (Eq_untyped_data)
                      in
                      M.eq l r
                  | Let l, Let r ->
                      let module M =
                        Eq_4 (Eq_string) (Eq_untyped_expression) (Eq_untyped_expression)
                          (Eq_untyped_data)
                      in
                      M.eq l r
                  | Rec (l:((string * untyped_expression * u_datatype option) list * untyped_expression * untyped_data)),
		      Rec r ->
                      let module M =
                        Eq_3
                          (Eq_list
                             (Eq_3 (Eq_string) (Eq_untyped_expression)
                                (Eq_option (Eq_u_datatype))))
                          (Eq_untyped_expression) (Eq_untyped_data)
                      in
                      M.eq l r
                  | Xml_node l, Xml_node r ->
                      let module M =
                        Eq_4 (Eq_string)
                          (Eq_list (Eq_2 (Eq_string) (Eq_untyped_expression)))
                          (Eq_list (Eq_untyped_expression)) (Eq_untyped_data)
                      in
                      M.eq l r
                  | Record_intro l, Record_intro r ->
                      let module M =
                        Eq_3 (Utility.Eq_stringmap (Eq_untyped_expression))
                          (Eq_option (Eq_untyped_expression)) (Eq_untyped_data)
                      in
                      M.eq l r
                  | Record_selection l, Record_selection r ->
                      let module M =
                        Eq_6 (Eq_string) (Eq_string) (Eq_string)
                          (Eq_untyped_expression) (Eq_untyped_expression) (Eq_untyped_data)
                      in
                      M.eq l r
                  | Record_unpack l, Record_unpack r ->
                      let module M =
                        Eq_5 (Eq_list (Eq_2 (Eq_string) (Eq_string)))
                          (Eq_untyped_expression) (Eq_untyped_expression) 
			  (Eq_option (Eq_untyped_expression))
			  (Eq_untyped_data)
                      in
                      M.eq l r
                  | Record_pack l, Record_pack r ->
                      let module M =
                        Eq_5 (Eq_string) (Eq_untyped_expression) 
			  (Eq_u_datatype) (Eq_untyped_expression) (Eq_untyped_data)
                      in
                      M.eq l r
                  | Project l, Project r ->
                      let module M = Eq_3 (Eq_untyped_expression) (Eq_string) (Eq_untyped_data)
                      in
                      M.eq l r
                  | Erase l, Erase r ->
                      let module M = Eq_3 (Eq_untyped_expression) (Eq_string) (Eq_untyped_data)
                      in
                      M.eq l r
                  | Variant_injection l, Variant_injection r ->
                      let module M = Eq_3 (Eq_string) (Eq_untyped_expression) (Eq_untyped_data)
                      in
                      M.eq l r
                  | Variant_selection l, Variant_selection r ->
                      let module M =
                        Eq_7 (Eq_untyped_expression) (Eq_string) (Eq_string)
                          (Eq_untyped_expression) (Eq_string) (Eq_untyped_expression) (Eq_untyped_data)
                      in
                      M.eq l r
                  | Variant_selection_empty l, Variant_selection_empty r ->
                      let module M = Eq_2 (Eq_untyped_expression) (Eq_untyped_data) in M.eq l r
                  | Nil l, Nil r -> let module M = Eq_untyped_data in M.eq l r
                  | List_of l, List_of r ->
                      let module M = Eq_2 (Eq_untyped_expression) (Eq_untyped_data) in M.eq l r
                  | Concat l, Concat r ->
                      let module M =
                        Eq_3 (Eq_untyped_expression) (Eq_untyped_expression) (Eq_untyped_data)
                      in
                      M.eq l r
                  | For l, For r ->
                      let module M =
                        Eq_4 (Eq_untyped_expression) (Eq_string) (Eq_untyped_expression)
                          (Eq_untyped_data)
                      in
                      M.eq l r
                  | Database l, Database r ->
                      let module M = Eq_2 (Eq_untyped_expression) (Eq_untyped_data) in M.eq l r
                  | TableQuery l, TableQuery r ->
                      let module M =
                        Eq_3 (Eq_list (Eq_2 (Eq_string) (Eq_untyped_expression)))
                          (Query.Eq_query) (Eq_untyped_data)
                      in
                      M.eq l r
                  | TableHandle l, TableHandle r ->
                      let module M =
                        Eq_4 (Eq_untyped_expression) (Eq_untyped_expression)
                          (Eq_u_table_constr) (Eq_untyped_data)
                      in
                      M.eq l r
                  | ViewQuery l, ViewQuery r ->
                      let module M =
                        Eq_2 (Eq_untyped_expression) (Eq_untyped_data)
                      in
                      M.eq l r
                  | ViewHandle l, ViewHandle r ->
                      let module M =
                        Eq_4 (Eq_untyped_expression) (Eq_untyped_expression)
                          (Eq_untyped_expression) (Eq_untyped_data)
                      in
                      M.eq l r
                  | SortBy l, SortBy r ->
                      let module M =
                        Eq_3 (Eq_untyped_expression) (Eq_untyped_expression) (Eq_untyped_data)
                      in
                      M.eq l r
                  | Call_cc l, Call_cc r ->
                      let module M = Eq_2 (Eq_untyped_expression) (Eq_untyped_data) in M.eq l r
                  | Wrong l, Wrong r -> let module M = Eq_untyped_data in M.eq l r
                  | HasType l, HasType r ->
                      let module M =
                        Eq_3 (Eq_untyped_expression) (Eq_u_datatype) (Eq_untyped_data)
                      in
                      M.eq l r
                  | _ -> false
              end) :
           Eq with type a = untyped_expression)

     and Eq_typed_expression :
      Eq with type a = typed_expression =
      (Eq_defaults
         (struct
            type a = typed_expression
            let rec eq l r =
              match l, r with
                  Constant l, Constant r ->
                    let module M = Eq_2 (Eq_constant) (Eq_typed_data) in M.eq l r
                | Variable l, Variable r ->
                    let module M = Eq_2 (Eq_string) (Eq_typed_data) in M.eq l r
                  | Abs l, Abs r ->
                      let module M = Eq_2 (Eq_typed_expression) (Eq_typed_data) in M.eq l r
                  | App l, App r ->
                      let module M =
                        Eq_3 (Eq_typed_expression) (Eq_typed_expression) (Eq_typed_data)
                      in
                      M.eq l r
                  | Apply l, Apply r ->
                      let module M =
                        Eq_3 (Eq_typed_expression) (Eq_list (Eq_typed_expression)) (Eq_typed_data)
                      in
                      M.eq l r
                  | Condition l, Condition r ->
                      let module M =
                        Eq_4 (Eq_typed_expression) (Eq_typed_expression)
                          (Eq_typed_expression) (Eq_typed_data)
                      in
                      M.eq l r
                  | Comparison l, Comparison r ->
                      let module M =
                        Eq_4 (Eq_typed_expression) (Eq_comparison) (Eq_typed_expression)
                          (Eq_typed_data)
                      in
                      M.eq l r
                  | Abstr l, Abstr r ->
                      let module M =
                        Eq_3 (Eq_list (Eq_typed_expression)) (Eq_typed_expression) (Eq_typed_data)
                      in
                      M.eq l r
                  | Let l, Let r ->
                      let module M =
                        Eq_4 (Eq_string) (Eq_typed_expression) (Eq_typed_expression)
                          (Eq_typed_data)
                      in
                      M.eq l r
                  | Rec l, Rec r ->
                      let module M =
                        Eq_3
                          (Eq_list
                             (Eq_3 (Eq_string) (Eq_typed_expression)
                                (Eq_option (Eq_datatype))))
                          (Eq_typed_expression) (Eq_typed_data)
                      in
                      M.eq l r
                  | Xml_node l, Xml_node r ->
                      let module M =
                        Eq_4 (Eq_string)
                          (Eq_list (Eq_2 (Eq_string) (Eq_typed_expression)))
                          (Eq_list (Eq_typed_expression)) (Eq_typed_data)
                      in
                      M.eq l r
                  | Record_intro l, Record_intro r ->
                      let module M =
                        Eq_3 (Utility.Eq_stringmap (Eq_typed_expression))
                          (Eq_option (Eq_typed_expression)) (Eq_typed_data)
                      in
                      M.eq l r
                  | Record_selection l, Record_selection r ->
                      let module M =
                        Eq_6 (Eq_string) (Eq_string) (Eq_string)
                          (Eq_typed_expression) (Eq_typed_expression) (Eq_typed_data)
                      in
                      M.eq l r
                  | Record_unpack l, Record_unpack r ->
                      let module M =
                        Eq_5 (Eq_list (Eq_2 (Eq_string) (Eq_string)))
                          (Eq_typed_expression) (Eq_typed_expression) 
			  (Eq_option (Eq_typed_expression))
			  (Eq_typed_data)
                      in
                      M.eq l r
                  | Record_pack l, Record_pack r ->
                      let module M =
                        Eq_5 (Eq_string) (Eq_typed_expression) 
			  (Eq_datatype) (Eq_typed_expression) (Eq_typed_data)
                      in
                      M.eq l r
                  | Project l, Project r ->
                      let module M = Eq_3 (Eq_typed_expression) (Eq_string) (Eq_typed_data)
                      in
                      M.eq l r
                  | Erase l, Erase r ->
                      let module M = Eq_3 (Eq_typed_expression) (Eq_string) (Eq_typed_data)
                      in
                      M.eq l r
                  | Variant_injection l, Variant_injection r ->
                      let module M = Eq_3 (Eq_string) (Eq_typed_expression) (Eq_typed_data)
                      in
                      M.eq l r
                  | Variant_selection l, Variant_selection r ->
                      let module M =
                        Eq_7 (Eq_typed_expression) (Eq_string) (Eq_string)
                          (Eq_typed_expression) (Eq_string) (Eq_typed_expression) (Eq_typed_data)
                      in
                      M.eq l r
                  | Variant_selection_empty l, Variant_selection_empty r ->
                      let module M = Eq_2 (Eq_typed_expression) (Eq_typed_data) in M.eq l r
                  | Nil l, Nil r -> let module M = Eq_typed_data in M.eq l r
                  | List_of l, List_of r ->
                      let module M = Eq_2 (Eq_typed_expression) (Eq_typed_data) in M.eq l r
                  | Concat l, Concat r ->
                      let module M =
                        Eq_3 (Eq_typed_expression) (Eq_typed_expression) (Eq_typed_data)
                      in
                      M.eq l r
                  | For l, For r ->
                      let module M =
                        Eq_4 (Eq_typed_expression) (Eq_string) (Eq_typed_expression)
                          (Eq_typed_data)
                      in
                      M.eq l r
                  | Database l, Database r ->
                      let module M = Eq_2 (Eq_typed_expression) (Eq_typed_data) in M.eq l r
                  | TableQuery l, TableQuery r ->
                      let module M =
                        Eq_3 (Eq_list (Eq_2 (Eq_string) (Eq_typed_expression)))
                          (Query.Eq_query) (Eq_typed_data)
                      in
                      M.eq l r
                  | TableHandle l, TableHandle r ->
                      let module M =
                        Eq_4 (Eq_typed_expression) (Eq_typed_expression)
                          (Eq_table_constr) (Eq_typed_data)
                      in
                      M.eq l r
                  | ViewQuery l, ViewQuery r ->
                      let module M =
                        Eq_2 (Eq_typed_expression) (Eq_typed_data)
                      in
                      M.eq l r
                  | ViewHandle l, ViewHandle r ->
                      let module M =
                        Eq_4 (Eq_typed_expression) (Eq_typed_expression)
                          (Eq_typed_expression) (Eq_typed_data)
                      in
                      M.eq l r
                  | SortBy l, SortBy r ->
                      let module M =
                        Eq_3 (Eq_typed_expression) (Eq_typed_expression) (Eq_typed_data)
                      in
                      M.eq l r
                  | Call_cc l, Call_cc r ->
                      let module M = Eq_2 (Eq_typed_expression) (Eq_typed_data) in M.eq l r
                  | Wrong l, Wrong r -> let module M = Eq_typed_data in M.eq l r
                  | HasType l, HasType r ->
                      let module M =
                        Eq_3 (Eq_typed_expression) (Eq_datatype) (Eq_typed_data)
                      in
                      M.eq l r
                  | _ -> false
              end) :
           Eq with type a = typed_expression)

(* ******************************  deriving (Eq) END ****************************** *)

(* ******************************  deriving (Show) START **************************** *)
    open Show

        module rec Show_fable_type :
          Show with type a = typed_data fable_qualifier =
          struct
            include
              (ShowDefaults
                 (struct
                    type a = typed_data fable_qualifier
                    let rec format formatter =
                      function
                        `Empty ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Empty ";
                          begin let module S = Show_0
                            in S.format formatter ()
                          end;
                          Format.pp_close_box formatter ()
                      | `KindVar v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`KindVar ";
                          begin let module S =
                            Show_1
                              (Unionfind.Show_point (Show_typed_kind_var_basis))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Kind v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Kind ";
                          begin let module S = Show_1 (Show_kind)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Name v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Name ";
                          begin let module S =
                            Show_1
                              (Show_2 (Show_string) (Show_fable_type))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Labeling v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Labeling ";
                          begin let module S =
                            Show_1
                              (Show_2 (Show_typed_expression)
                                 (Show_fable_type))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Label v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Label ";
                          begin let module S =
                            Show_1
                              (Show_2
                                 (Show_triopt (Show_typed_expression))
                                 (Show_fable_type))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Phantom v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Phantom ";
                          begin let module S =
                            Show_1
                              (Show_2 (Show_list (Show_string))
                                 (Show_fable_type))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                  end) :
               Show with type a = typed_data fable_qualifier)
            let format f = format f
          end
        and Show_typed_kind_var_basis : Show with type a = typed_data kind_var_basis =
          struct
            include
              (ShowDefaults
                 (struct
                    type a = typed_data kind_var_basis
                    let rec format formatter =
                      function
                        `FlexKind v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`FlexKind ";
                          begin let module S =
                            Show_1 (Show_2 (Show_int) (Show_kind))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `FixedKind v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`FixedKind ";
                          begin let module S = Show_1 (Show_fable_type)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                  end) :
               Show with type a = typed_data kind_var_basis)
            let format f = format f
          end

        and Show_unchecked_fable_type :
          Show with type a = untyped_data fable_qualifier =
          struct
            include
              (ShowDefaults
                 (struct
                    type a = untyped_data fable_qualifier
                    let rec format formatter =
                      function
                        `Empty ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Empty ";
                          begin let module S = Show_0
                            in S.format formatter ()
                          end;
                          Format.pp_close_box formatter ()
                      | `KindVar v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`KindVar ";
                          begin let module S =
                            Show_1
                              (Unionfind.Show_point (Show_untyped_kind_var_basis))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Kind v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Kind ";
                          begin let module S = Show_1 (Show_kind)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Name v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Name ";
                          begin let module S =
                            Show_1
                              (Show_2 (Show_string) (Show_unchecked_fable_type))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Labeling v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Labeling ";
                          begin let module S =
                            Show_1
                              (Show_2 (Show_untyped_expression)
                                 (Show_unchecked_fable_type))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Label v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Label ";
                          begin let module S =
                            Show_1
                              (Show_2
                                 (Show_triopt (Show_untyped_expression))
                                 (Show_unchecked_fable_type))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Phantom v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Phantom ";
                          begin let module S =
                            Show_1
                              (Show_2 (Show_list (Show_string))
                                 (Show_unchecked_fable_type))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                  end) :
               Show with type a = untyped_data fable_qualifier)
            let format f = format f
          end
        and Show_untyped_kind_var_basis : Show with type a = untyped_data kind_var_basis =
          struct
            include
              (ShowDefaults
                 (struct
                    type a = untyped_data kind_var_basis
                    let rec format formatter =
                      function
                        `FlexKind v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`FlexKind ";
                          begin let module S =
                            Show_1 (Show_2 (Show_int) (Show_kind))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `FixedKind v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`FixedKind ";
                          begin let module S = Show_1 (Show_unchecked_fable_type)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                  end) :
               Show with type a = untyped_data kind_var_basis)
            let format f = format f
          end

    and Show_datatype : Show with type a = typed_data datatype' =
    struct
      include
        (ShowDefaults
           (struct
              type a = typed_data Types.datatype'
              let format formatter obj =
                Format.pp_print_char formatter '{';
                begin
                  begin let module S = Show_ldatatype
                  in
                    Format.pp_open_box formatter 0;
                    Format.pp_print_string formatter "ltype=";
                    S.format formatter obj.ltype;
                    Format.pp_print_string formatter "; ";
                    Format.pp_close_box formatter ()
                  end;
                  let module S = Show_fable_type
                  in
                    Format.pp_open_box formatter 0;
                    Format.pp_print_string formatter "ftype=";
                    S.format formatter obj.ftype;
                    ();
                    Format.pp_close_box formatter ()
                end;
                Format.pp_print_char formatter '}'
            end) :
           Show with type a = typed_data datatype')
      let format f = format f
    end
    and Show_meta_type_var_basis :
      Show with type a = meta_type_var_basis =
    struct
      include
        (ShowDefaults
           (struct
              type a = meta_type_var_basis
              let rec format formatter =
                function
                        Flexible v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Flexible";
                          Format.pp_print_break formatter 1 2;
                          begin let module S = Show_1 (Show_int)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Rigid v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Rigid";
                          Format.pp_print_break formatter 1 2;
                          begin let module S = Show_1 (Show_int)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | UncheckedRecursive v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "UncheckedRecursive";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_2 (Show_int)
                                 (Show_u_datatype))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Recursive v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Recursive";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_2 (Show_int)
                                 (Show_datatype))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Body v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Body";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_datatype)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                  end) :
               Show with type a = meta_type_var_basis)
            let format f = format f
          end
        and Show_meta_row_var_basis :
          Show with type a = meta_row_var_basis =
          struct
            include
              (ShowDefaults
                 (struct
                    type a = meta_row_var_basis
                    let rec format formatter =
                      function
                        ClosedRow ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "ClosedRow";
                          Format.pp_print_break formatter 1 2;
                          begin let module S = Show_0
                            in S.format formatter ()
                          end;
                          Format.pp_close_box formatter ()
                      | FlexibleRow v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "FlexibleRow";
                          Format.pp_print_break formatter 1 2;
                          begin let module S = Show_1 (Show_int)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | RigidRow v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "RigidRow";
                          Format.pp_print_break formatter 1 2;
                          begin let module S = Show_1 (Show_int)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | RecursiveRow v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "RecursiveRow";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_2 (Show_int)
                                 (Show_row))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | BodyRow v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "BodyRow";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_row)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                  end) :
               Show with type a = meta_row_var_basis)
            let format f = format f
          end
        and Show_ldatatype : Show with type a = typed_data ldatatype' =
          struct
            include
              (ShowDefaults
                 (struct
                    type a = typed_data ldatatype'
                    let rec format formatter =
                      function
                        `Not_typed ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Not_typed ";
                          begin let module S = Show_0
                            in S.format formatter ()
                          end;
                          Format.pp_close_box formatter ()
                      | `Primitive v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Primitive ";
                          begin let module S = Show_1 (Show_primitive)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Function v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Function ";
                          begin let module S =
                            Show_1
                              (Show_3 (Show_datatype) (Show_datatype)
                                 (Show_datatype))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Record v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Record ";
                          begin let module S = Show_1 (Show_row)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Variant v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Variant ";
                          begin let module S = Show_1 (Show_row)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Table v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Table ";
                          begin let module S =
                            Show_1 (Show_2 (Show_datatype) (Show_datatype))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Application v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Application ";
                          begin let module S =
                            Show_1
                              (Show_2 (Show_string)
                                 (Show_list (Show_datatype)))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `MetaTypeVar v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`MetaTypeVar ";
                          begin let module S = Show_1 (Show_meta_type_var)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                  end) :
               Show with type a = typed_data ldatatype')
            let format f = format f
          end
        and Show_field_spec : Show with type a = typed_data field_spec' =
          struct
            include
              (ShowDefaults
                 (struct
                    type a = typed_data field_spec'
                    let rec format formatter =
                      function
                        `Present v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Present ";
                          begin let module S = Show_1 (Show_datatype)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Absent ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Absent ";
                          begin let module S = Show_0
                            in S.format formatter ()
                          end;
                          Format.pp_close_box formatter ()
                  end) :
               Show with type a = typed_data field_spec')
            let format f = format f
          end
        and Show_field_spec_map : Show with type a = typed_data field_spec_map' =
          struct
            include Show_field_env (Show_field_spec)
            let format f = format f
          end
        and Show_row : Show with type a = typed_data row' =
          struct
            include Show_2 (Show_field_spec_map) (Show_row_var)
            let format f = format f
          end
        and Show_row_var : Show with type a = row_var =
          struct
            include Show_point (Show_meta_row_var_basis)
            let format f = format f
          end
        and Show_meta_type_var : Show with type a = meta_type_var =
          struct
            include Show_point (Show_meta_type_var_basis)
            let format f = format f
          end

    and Show_u_datatype : Show with type a = untyped_data datatype' =
    struct
      include
        (ShowDefaults
           (struct
              type a = untyped_data datatype'
              let format formatter obj =
                Format.pp_print_char formatter '{';
                begin
                  begin let module S = Show_u_ldatatype
                  in
                    Format.pp_open_box formatter 0;
                    Format.pp_print_string formatter "ltype=";
                    S.format formatter obj.ltype;
                    Format.pp_print_string formatter "; ";
                    Format.pp_close_box formatter ()
                  end;
                  let module S = Show_unchecked_fable_type
                  in
                    Format.pp_open_box formatter 0;
                    Format.pp_print_string formatter "ftype=";
                    S.format formatter obj.ftype;
                    ();
                    Format.pp_close_box formatter ()
                end;
                Format.pp_print_char formatter '}'
            end) :
           Show with type a = untyped_data datatype')
      let format f = format f
    end
    and Show_u_ldatatype : Show with type a = untyped_data ldatatype' =
          struct
            include
              (ShowDefaults
                 (struct
                    type a = untyped_data ldatatype'
                    let rec format formatter =
                      function
                        `Not_typed ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Not_typed ";
                          begin let module S = Show_0
                            in S.format formatter ()
                          end;
                          Format.pp_close_box formatter ()
                      | `Primitive v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Primitive ";
                          begin let module S = Show_1 (Show_primitive)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Function v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Function ";
                          begin let module S =
                            Show_1
                              (Show_3 (Show_u_datatype) (Show_u_datatype)
                                 (Show_u_datatype))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Record v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Record ";
                          begin let module S = Show_1 (Show_u_row)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Variant v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Variant ";
                          begin let module S = Show_1 (Show_u_row)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Table v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Table ";
                          begin let module S =
                            Show_1 (Show_2 (Show_u_datatype) (Show_u_datatype))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Application v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Application ";
                          begin let module S =
                            Show_1
                              (Show_2 (Show_string)
                                 (Show_list (Show_u_datatype)))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `MetaTypeVar v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`MetaTypeVar ";
                          begin let module S = Show_1 (Show_meta_type_var)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                  end) :
               Show with type a = untyped_data ldatatype')
            let format f = format f
          end
        and Show_u_field_spec : Show with type a = untyped_data field_spec' =
          struct
            include
              (ShowDefaults
                 (struct
                    type a = untyped_data field_spec'
                    let rec format formatter =
                      function
                        `Present v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Present ";
                          begin let module S = Show_1 (Show_u_datatype)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | `Absent ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "`Absent ";
                          begin let module S = Show_0
                            in S.format formatter ()
                          end;
                          Format.pp_close_box formatter ()
                  end) :
               Show with type a = untyped_data field_spec')
            let format f = format f
          end
        and Show_u_field_spec_map : Show with type a = untyped_data field_spec_map' =
          struct
            include Show_field_env (Show_u_field_spec)
            let format f = format f
          end
        and Show_u_row : Show with type a = untyped_data row' =
          struct
            include Show_2 (Show_u_field_spec_map) (Show_row_var)
            let format f = format f
          end

    and Show_typed_data : Show with type a = Types.datatype annotated_data
      = (Show_annotated_data(Show_datatype))

    and Show_u_table_constr : Show with type a = untyped_data table_constr
      =	 (ShowDefaults
	       (struct 
		  type a = untyped_data table_constr

		  let format f a = 
	            let module M = 
		      Show_3 (Show_u_datatype) (Show_u_datatype) (Show_list (Show_2 (Show_string) (Show_untyped_expression))) 
		    in M.format f (a.readtype, a.writetype, a.marshallby)

	        end) : Show with type a = untyped_data table_constr
	 )

    and Show_table_constr : Show with type a = typed_data table_constr
      =	 (ShowDefaults
	       (struct 
		  type a = typed_data table_constr

		  let format f a = 
	            let module M = 
		      Show_3 (Show_datatype) (Show_datatype) (Show_list (Show_2 (Show_string) (Show_typed_expression))) 
		    in M.format f (a.readtype, a.writetype, a.marshallby)

	        end) : Show with type a = typed_data table_constr
	 )

    and Show_untyped_expression :
      Show with type a = untyped_expression =
    struct
      include
        (ShowDefaults
           (struct
              type a = untyped_expression
              let rec format formatter =
                function
                    Constant v0 ->
                      Format.pp_open_hovbox formatter 0;
                      Format.pp_print_string formatter "Constant";
                      Format.pp_print_break formatter 1 2;
                      begin let module S =
                        Show_1 (Show_2 (Show_constant) (Show_untyped_data))
                      in S.format formatter v0
                      end;
                      Format.pp_close_box formatter ()
                  | Variable v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Variable";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_2 (Show_string) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Abs v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Abs";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_2 (Show_untyped_expression) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | App v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "App";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_untyped_expression) (Show_untyped_expression)
                                 (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Apply v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Apply";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_untyped_expression)
                                 (Show_list (Show_untyped_expression)) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Condition v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Condition";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_untyped_expression) (Show_untyped_expression)
                                 (Show_untyped_expression) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Comparison v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Comparison";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_untyped_expression) (Show_comparison)
                                 (Show_untyped_expression) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Abstr v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Abstr";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_list (Show_untyped_expression))
                                 (Show_untyped_expression) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Let v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Let";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_string) (Show_untyped_expression)
                                 (Show_untyped_expression) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Rec v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Rec";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3
                                 (Show_list
                                    (Show_3 (Show_string) (Show_untyped_expression)
                                       (Show_option (Show_u_datatype))))
                                 (Show_untyped_expression) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Xml_node v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Xml_node";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_string)
                                 (Show_list
                                    (Show_2 (Show_string) (Show_untyped_expression)))
                                 (Show_list (Show_untyped_expression)) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Record_intro v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Record_intro";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3
                                 (Utility.Show_stringmap (Show_untyped_expression))
                                 (Show_option (Show_untyped_expression)) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Record_selection v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Record_selection";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_6 (Show_string) (Show_string)
                                 (Show_string) (Show_untyped_expression)
                                 (Show_untyped_expression) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Record_unpack v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Record_unpack";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_5 (Show_list (Show_2  (Show_string) (Show_string)))
				 (Show_untyped_expression)
                                 (Show_untyped_expression) 
				 (Show_option (Show_untyped_expression))
				 (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Record_pack v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Record_pack";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_5 (Show_string)
				 (Show_untyped_expression) 
				 (Show_u_datatype) (Show_untyped_expression) 
				 (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Project v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Project";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_untyped_expression) (Show_string) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Erase v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Erase";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_untyped_expression) (Show_string) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Variant_injection v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter
                            "Variant_injection";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_string) (Show_untyped_expression) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Variant_selection v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter
                            "Variant_selection";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_7 (Show_untyped_expression) (Show_string)
                                 (Show_string) (Show_untyped_expression)
                                 (Show_string) (Show_untyped_expression) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Variant_selection_empty v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter
                            "Variant_selection_empty";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_2 (Show_untyped_expression) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Nil v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Nil";
                          Format.pp_print_break formatter 1 2;
                          begin let module S = Show_1 (Show_untyped_data)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | List_of v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "List_of";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_2 (Show_untyped_expression) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Concat v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Concat";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_untyped_expression) (Show_untyped_expression)
                                 (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | For v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "For";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_untyped_expression) (Show_string)
                                 (Show_untyped_expression) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Database v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Database";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_2 (Show_untyped_expression) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | TableQuery v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "TableQuery";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3
                                 (Show_list
                                    (Show_2 (Show_string) (Show_untyped_expression)))
                                 (Query.Show_query) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | TableHandle v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "TableHandle";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_untyped_expression) (Show_untyped_expression)
                                 (Show_u_table_constr)
                                 (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | ViewQuery v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "ViewQuery";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_2
                                 (Show_untyped_expression)
                                 (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | ViewHandle v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "ViewHandle";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_untyped_expression) (Show_untyped_expression)
                                 (Show_untyped_expression)
                                 (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | SortBy v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "SortBy";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_untyped_expression) (Show_untyped_expression)
                                 (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Call_cc v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Call_cc";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_2 (Show_untyped_expression) (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Wrong v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Wrong";
                          Format.pp_print_break formatter 1 2;
                          begin let module S = Show_1 (Show_untyped_data)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | HasType v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "HasType";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_untyped_expression) (Show_u_datatype)
                                 (Show_untyped_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                  end) :
               Show with type a = untyped_expression)
            let format f = format f
    end
(* -------------------------------------------------------------------------------- *)
    and  Show_typed_expression :
      Show with type a = typed_expression =
    struct
      include
        (ShowDefaults
           (struct
              type a = typed_expression
              let rec format formatter =
                function
                    Constant v0 ->
                      Format.pp_open_hovbox formatter 0;
                      Format.pp_print_string formatter "Constant";
                      Format.pp_print_break formatter 1 2;
                      begin let module S =
                        Show_1 (Show_2 (Show_constant) (Show_typed_data))
                      in S.format formatter v0
                      end;
                      Format.pp_close_box formatter ()
                  | Variable v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Variable";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_2 (Show_string) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Abs v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Abs";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_2 (Show_typed_expression) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | App v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "App";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_typed_expression) (Show_typed_expression)
                                 (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Apply v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Apply";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_typed_expression)
                                 (Show_list (Show_typed_expression)) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Condition v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Condition";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_typed_expression) (Show_typed_expression)
                                 (Show_typed_expression) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Comparison v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Comparison";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_typed_expression) (Show_comparison)
                                 (Show_typed_expression) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Abstr v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Abstr";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_list (Show_typed_expression))
                                 (Show_typed_expression) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Let v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Let";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_string) (Show_typed_expression)
                                 (Show_typed_expression) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Rec v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Rec";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3
                                 (Show_list
                                    (Show_3 (Show_string) (Show_typed_expression)
                                       (Show_option (Show_datatype))))
                                 (Show_typed_expression) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Xml_node v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Xml_node";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_string)
                                 (Show_list
                                    (Show_2 (Show_string) (Show_typed_expression)))
                                 (Show_list (Show_typed_expression)) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Record_intro v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Record_intro";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3
                                 (Utility.Show_stringmap (Show_typed_expression))
                                 (Show_option (Show_typed_expression)) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Record_selection v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Record_selection";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_6 (Show_string) (Show_string)
                                 (Show_string) (Show_typed_expression)
                                 (Show_typed_expression) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Record_unpack v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Record_unpack";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_5 (Show_list (Show_2  (Show_string) (Show_string)))
				 (Show_typed_expression)
                                 (Show_typed_expression) 
				 (Show_option (Show_typed_expression))
				 (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Record_pack v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Record_pack";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_5 (Show_string)
				 (Show_typed_expression) 
				 (Show_datatype) 
				 (Show_typed_expression) 
				 (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Project v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Project";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_typed_expression) (Show_string) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Erase v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Erase";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_typed_expression) (Show_string) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Variant_injection v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter
                            "Variant_injection";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_string) (Show_typed_expression) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Variant_selection v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter
                            "Variant_selection";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_7 (Show_typed_expression) (Show_string)
                                 (Show_string) (Show_typed_expression)
                                 (Show_string) (Show_typed_expression) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Variant_selection_empty v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter
                            "Variant_selection_empty";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_2 (Show_typed_expression) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Nil v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Nil";
                          Format.pp_print_break formatter 1 2;
                          begin let module S = Show_1 (Show_typed_data)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | List_of v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "List_of";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_2 (Show_typed_expression) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Concat v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Concat";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_typed_expression) (Show_typed_expression)
                                 (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | For v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "For";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_typed_expression) (Show_string)
                                 (Show_typed_expression) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Database v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Database";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_2 (Show_typed_expression) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | TableQuery v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "TableQuery";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3
                                 (Show_list
                                    (Show_2 (Show_string) (Show_typed_expression)))
                                 (Query.Show_query) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | TableHandle v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "TableHandle";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_typed_expression) (Show_typed_expression)
                                 (Show_table_constr)
                                 (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | ViewQuery v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "ViewQuery";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_2
                                 (Show_typed_expression)
                                 (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | ViewHandle v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "ViewHandle";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_typed_expression) (Show_typed_expression)
                                 (Show_typed_expression)
                                 (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | SortBy v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "SortBy";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_typed_expression) (Show_typed_expression)
                                 (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Call_cc v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Call_cc";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_2 (Show_typed_expression) (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Wrong v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Wrong";
                          Format.pp_print_break formatter 1 2;
                          begin let module S = Show_1 (Show_typed_data)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | HasType v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "HasType";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_typed_expression) (Show_datatype)
                                 (Show_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                  end) :
               Show with type a = typed_expression)
            let format f = format f
    end

    module Skip_typed_data : Show with type a = typed_data 
      = 
      struct
      include
        (ShowDefaults
           (struct
              type a = typed_data
	      let format f x = Format.pp_print_string f "`T" (*   raise (UnimplementedDeriving (V0.name ())) *)
	    end
	   ))
      end

    module rec Show_debug_expression :
      Show with type a = typed_expression =
    struct
      include
        (ShowDefaults
           (struct
              type a = typed_expression
              let rec format formatter =
                function
                    Constant v0 ->
                      Format.pp_open_hovbox formatter 0;
                      Format.pp_print_string formatter "Constant";
                      Format.pp_print_break formatter 1 2;
                      begin let module S =
                        Show_1 (Show_2 (Show_constant) (Skip_typed_data))
                      in S.format formatter v0
                      end;
                      Format.pp_close_box formatter ()
                  | Variable v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Variable";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_2 (Show_string) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Abs v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Abs";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_2 (Show_debug_expression) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | App v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "App";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_debug_expression) (Show_debug_expression)
                                 (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Apply v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Apply";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_debug_expression)
                                 (Show_list (Show_debug_expression)) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Condition v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Condition";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_debug_expression) (Show_debug_expression)
                                 (Show_debug_expression) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Comparison v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Comparison";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_debug_expression) (Show_comparison)
                                 (Show_debug_expression) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Abstr v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Abstr";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_list (Show_debug_expression))
                                 (Show_debug_expression) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Let v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Let";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_string) (Show_debug_expression)
                                 (Show_debug_expression) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Rec v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Rec";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3
                                 (Show_list
                                    (Show_3 (Show_string) (Show_debug_expression)
                                       (Show_option (Show_datatype))))
                                 (Show_debug_expression) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Xml_node v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Xml_node";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_string)
                                 (Show_list
                                    (Show_2 (Show_string) (Show_debug_expression)))
                                 (Show_list (Show_debug_expression)) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Record_intro v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Record_intro";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3
                                 (Utility.Show_stringmap (Show_debug_expression))
                                 (Show_option (Show_debug_expression)) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Record_selection v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Record_selection";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_6 (Show_string) (Show_string)
                                 (Show_string) (Show_debug_expression)
                                 (Show_debug_expression) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Record_unpack v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Record_unpack";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_5 (Show_list (Show_2  (Show_string) (Show_string)))
				 (Show_debug_expression)
                                 (Show_debug_expression) 
				 (Show_option (Show_debug_expression))
				 (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Record_pack v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Record_pack";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_5 (Show_string)
				 (Show_debug_expression) 
				 (Show_datatype) 
				 (Show_debug_expression) 
				 (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Project v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Project";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_debug_expression) (Show_string) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Erase v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Erase";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_debug_expression) (Show_string) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Variant_injection v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter
                            "Variant_injection";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_string) (Show_debug_expression) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Variant_selection v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter
                            "Variant_selection";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_7 (Show_debug_expression) (Show_string)
                                 (Show_string) (Show_debug_expression)
                                 (Show_string) (Show_debug_expression) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Variant_selection_empty v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter
                            "Variant_selection_empty";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_2 (Show_debug_expression) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Nil v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Nil";
                          Format.pp_print_break formatter 1 2;
                          begin let module S = Show_1 (Skip_typed_data)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | List_of v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "List_of";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_2 (Show_debug_expression) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Concat v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Concat";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_debug_expression) (Show_debug_expression)
                                 (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | For v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "For";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_debug_expression) (Show_string)
                                 (Show_debug_expression) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Database v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Database";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_2 (Show_debug_expression) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | TableQuery v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "TableQuery";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3
                                 (Show_list
                                    (Show_2 (Show_string) (Show_debug_expression)))
                                 (Query.Show_query) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | TableHandle v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "TableHandle";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_debug_expression) (Show_debug_expression)
                                 (Show_table_constr)
                                 (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | ViewQuery v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "ViewQuery";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_2
                                 (Show_debug_expression)
                                 (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | ViewHandle v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "ViewHandle";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_4 (Show_debug_expression) (Show_debug_expression)
                                 (Show_debug_expression)
                                 (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | SortBy v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "SortBy";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_debug_expression) (Show_debug_expression)
                                 (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Call_cc v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Call_cc";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1 (Show_2 (Show_debug_expression) (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | Wrong v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "Wrong";
                          Format.pp_print_break formatter 1 2;
                          begin let module S = Show_1 (Skip_typed_data)
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                      | HasType v0 ->
                          Format.pp_open_hovbox formatter 0;
                          Format.pp_print_string formatter "HasType";
                          Format.pp_print_break formatter 1 2;
                          begin let module S =
                            Show_1
                              (Show_3 (Show_debug_expression) (Show_datatype)
                                 (Skip_typed_data))
                            in S.format formatter v0
                          end;
                          Format.pp_close_box formatter ()
                  end) :
               Show with type a = typed_expression)
            let format f = format f
    end

        module Show_assumption : Show with type a = Types.assumption =
          struct
            include
              Show_2 (Show_list (Types.Show_quantifier)) (Show_datatype)
            let format f = format f
          end

    module Show_u_assumption : Show with type a = Types.u_assumption =
    struct
      include
        Show_2 (Show_list (Types.Show_quantifier)) (Show_u_datatype)
      let format f = format f
    end

	module Show_stripped_expression =
	  Show_any (struct
		      type a = unit FableType.expression'
		      let name _ = "Show_stripped_expression"
		    end)


(* ******************************  deriving (Show) END **************************** *)

(* ******************************  deriving (Pickle) START **************************** *)

(*Pickle*)
    open Pickle

    module rec Pickle_fable_type :
      Pickle with type a = typed_data fable_qualifier =
          (Pickle_defaults
             (struct
                type a = typed_data fable_qualifier
                let rec pickle buffer =
                  function
                    `Empty ->
                      Pickle_int.pickle buffer 0;
                      let module S = Pickle_0 in S.pickle buffer ()
                  | `KindVar v0 ->
                      Pickle_int.pickle buffer 1;
                      let module S =
                        Pickle_1
                          (Pickle_point (Pickle_kind_var_basis))
                      in
                      S.pickle buffer v0
                  | `Kind v0 ->
                      Pickle_int.pickle buffer 2;
                      let module S = Pickle_1 (Pickle_kind)
                      in
                      S.pickle buffer v0
                  | `Name v0 ->
                      Pickle_int.pickle buffer 3;
                      let module S =
                        Pickle_1
                          (Pickle_2 (Pickle_string) (Pickle_fable_type))
                      in
                      S.pickle buffer v0
                  | `Labeling v0 ->
                      Pickle_int.pickle buffer 4;
                      let module S =
                        Pickle_1
                          (Pickle_2 (Pickle_typed_expression)
                             (Pickle_fable_type))
                      in
                      S.pickle buffer v0
                  | `Label v0 ->
                      Pickle_int.pickle buffer 5;
                      let module S =
                        Pickle_1
                          (Pickle_2
                             (Pickle_triopt (Pickle_typed_expression))
                             (Pickle_fable_type))
                      in
                      S.pickle buffer v0
                  | `Phantom v0 ->
                      Pickle_int.pickle buffer 6;
                      let module S =
                        Pickle_1
                          (Pickle_2 (Pickle_list (Pickle_string))
                             (Pickle_fable_type))
                      in
                      S.pickle buffer v0
                and unpickle stream =
                  match Pickle_int.unpickle stream with
                    0 -> `Empty
                  | 1 ->
                      let module S =
                        Pickle_point (Pickle_kind_var_basis)
                      in
                      let v0 = S.unpickle stream in `KindVar v0
                  | 2 ->
                      let module S = Pickle_kind
                      in
                      let v0 = S.unpickle stream in `Kind v0
                  | 3 ->
                      let module S =
                        Pickle_2 (Pickle_string) (Pickle_fable_type)
                      in
                      let v0 = S.unpickle stream in `Name v0
                  | 4 ->
                      let module S =
                        Pickle_2 (Pickle_typed_expression)
                          (Pickle_fable_type)
                      in
                      let v0 = S.unpickle stream in `Labeling v0
                  | 5 ->
                      let module S =
                        Pickle_2
                          (Pickle_triopt (Pickle_typed_expression))
                          (Pickle_fable_type)
                      in
                      let v0 = S.unpickle stream in `Label v0
                  | 6 ->
                      let module S =
                        Pickle_2 (Pickle_list (Pickle_string))
                          (Pickle_fable_type)
                      in
                      let v0 = S.unpickle stream in `Phantom v0
                  | c ->
                      failwith
                        (Printf.sprintf
                           "Unexpected tag %d during unpickling of type : %s"
                           c "fable_qualifier")
              end) :
           Pickle with type a = typed_data fable_qualifier)
        and Pickle_kind_var_basis : Pickle with type a = typed_data kind_var_basis =
          (Pickle_defaults
             (struct
                type a = typed_data kind_var_basis
                let rec pickle buffer =
                  function
                    `FlexKind v0 ->
                      Pickle_int.pickle buffer 0;
                      let module S =
                        Pickle_1 (Pickle_2 (Pickle_int) (Pickle_kind))
                      in
                      S.pickle buffer v0
                  | `FixedKind v0 ->
                      Pickle_int.pickle buffer 1;
                      let module S = Pickle_1 (Pickle_fable_type)
                      in
                      S.pickle buffer v0
                and unpickle stream =
                  match Pickle_int.unpickle stream with
                    0 ->
                      let module S = Pickle_2 (Pickle_int) (Pickle_kind)
                      in
                      let v0 = S.unpickle stream in `FlexKind v0
                  | 1 ->
                      let module S = Pickle_fable_type
                      in
                      let v0 = S.unpickle stream in `FixedKind v0
                  | c ->
                      failwith
                        (Printf.sprintf
                           "Unexpected tag %d during unpickling of type : %s"
                           c "kind_var_basis")
              end) :
           Pickle with type a = typed_data kind_var_basis)
      
    and Pickle_datatype : Pickle with type a = typed_data datatype' =
          (Pickle_defaults
             (struct
                type a = typed_data datatype'
                let rec pickle buffer obj =
                  begin let module S = Pickle_ldatatype
                    in S.pickle buffer obj.ltype
                  end;
                  let module S = Pickle_fable_type in S.pickle buffer obj.ftype
                and unpickle stream =
                  let module S = Pickle_ldatatype
                  in
                  let ltype = S.unpickle stream in
                  let module S = Pickle_fable_type
                  in
                  let ftype = S.unpickle stream in
                  {ltype = ltype; ftype = ftype}
              end) :
           Pickle with type a = typed_data datatype')
        and Pickle_meta_type_var_basis :
          Pickle with type a = meta_type_var_basis =
          (Pickle_defaults
             (struct
                type a = meta_type_var_basis
                let rec pickle buffer =
                  function
                    Flexible v0 ->
                      Pickle_int.pickle buffer 0;
                      let module S = Pickle_1 (Pickle_int)
                      in
                      S.pickle buffer v0
                  | Rigid v0 ->
                      Pickle_int.pickle buffer 1;
                      let module S = Pickle_1 (Pickle_int)
                      in
                      S.pickle buffer v0
		  | UncheckedRecursive _ -> failwith "Attempt to pickle a datatype with an unchecked component : UncheckedRecursive"
                  | Recursive v0 ->
                      Pickle_int.pickle buffer 2;
                      let module S =
                        Pickle_1
                          (Pickle_2 (Pickle_int)
                             (Pickle_datatype))
                      in
                      S.pickle buffer v0
                  | Body v0 ->
                      Pickle_int.pickle buffer 3;
                      let module S =
                        Pickle_1 (Pickle_datatype)
                      in
                      S.pickle buffer v0
                and unpickle stream =
                  match Pickle_int.unpickle stream with
                    0 ->
                      let module S = Pickle_int
                      in
                      let v0 = S.unpickle stream in Flexible v0
                  | 1 ->
                      let module S = Pickle_int
                      in
                      let v0 = S.unpickle stream in Rigid v0
                  | 2 ->
                      let module S =
                        Pickle_2 (Pickle_int)
                          (Pickle_datatype)
                      in
                      let v0 = S.unpickle stream in Recursive v0
                  | 3 ->
                      let module S = Pickle_datatype
                      in
                      let v0 = S.unpickle stream in Body v0
                  | c ->
                      failwith
                        (Printf.sprintf
                           "Unexpected tag %d during unpickling of type : %s"
                           c "meta_type_var_basis")
              end) :
           Pickle with type a = meta_type_var_basis)
        and Pickle_meta_row_var_basis :
          Pickle with type a = meta_row_var_basis =
          (Pickle_defaults
             (struct
                type a = meta_row_var_basis
                let rec pickle buffer =
                  function
                    ClosedRow ->
                      Pickle_int.pickle buffer 0;
                      let module S = Pickle_0 in S.pickle buffer ()
                  | FlexibleRow v0 ->
                      Pickle_int.pickle buffer 1;
                      let module S = Pickle_1 (Pickle_int)
                      in
                      S.pickle buffer v0
                  | RigidRow v0 ->
                      Pickle_int.pickle buffer 2;
                      let module S = Pickle_1 (Pickle_int)
                      in
                      S.pickle buffer v0
                  | RecursiveRow v0 ->
                      Pickle_int.pickle buffer 3;
                      let module S =
                        Pickle_1
                          (Pickle_2 (Pickle_int)
                             (Pickle_row))
                      in
                      S.pickle buffer v0
                  | BodyRow v0 ->
                      Pickle_int.pickle buffer 4;
                      let module S =
                        Pickle_1 (Pickle_row)
                      in
                      S.pickle buffer v0
                and unpickle stream =
                  match Pickle_int.unpickle stream with
                    0 -> ClosedRow
                  | 1 ->
                      let module S = Pickle_int
                      in
                      let v0 = S.unpickle stream in FlexibleRow v0
                  | 2 ->
                      let module S = Pickle_int
                      in
                      let v0 = S.unpickle stream in RigidRow v0
                  | 3 ->
                      let module S =
                        Pickle_2 (Pickle_int)
                          (Pickle_row)
                      in
                      let v0 = S.unpickle stream in RecursiveRow v0
                  | 4 ->
                      let module S = Pickle_row
                      in
                      let v0 = S.unpickle stream in BodyRow v0
                  | c ->
                      failwith
                        (Printf.sprintf
                           "Unexpected tag %d during unpickling of type : %s"
                           c "meta_row_var_basis")
              end) :
           Pickle with type a = meta_row_var_basis)
        and Pickle_ldatatype : Pickle with type a = typed_data ldatatype' =
          (Pickle_defaults
             (struct
                type a = typed_data ldatatype'
                let rec pickle buffer =
                  function
                    `Not_typed ->
                      Pickle_int.pickle buffer 0;
                      let module S = Pickle_0 in S.pickle buffer ()
                  | `Primitive v0 ->
                      Pickle_int.pickle buffer 1;
                      let module S = Pickle_1 (Pickle_primitive)
                      in
                      S.pickle buffer v0
                  | `Function v0 ->
                      Pickle_int.pickle buffer 2;
                      let module S =
                        Pickle_1
                          (Pickle_3 (Pickle_datatype) (Pickle_datatype)
                             (Pickle_datatype))
                      in
                      S.pickle buffer v0
                  | `Record v0 ->
                      Pickle_int.pickle buffer 3;
                      let module S = Pickle_1 (Pickle_row)
                      in
                      S.pickle buffer v0
                  | `Variant v0 ->
                      Pickle_int.pickle buffer 4;
                      let module S = Pickle_1 (Pickle_row)
                      in
                      S.pickle buffer v0
                  | `Table v0 ->
                      Pickle_int.pickle buffer 5;
                      let module S =
                        Pickle_1
                          (Pickle_2 (Pickle_datatype) (Pickle_datatype))
                      in
                      S.pickle buffer v0
                  | `Application v0 ->
                      Pickle_int.pickle buffer 6;
                      let module S =
                        Pickle_1
                          (Pickle_2 (Pickle_string)
                             (Pickle_list (Pickle_datatype)))
                      in
                      S.pickle buffer v0
                  | `MetaTypeVar v0 ->
                      Pickle_int.pickle buffer 7;
                      let module S = Pickle_1 (Pickle_meta_type_var)
                      in
                      S.pickle buffer v0
                and unpickle stream =
                  match Pickle_int.unpickle stream with
                    0 -> `Not_typed
                  | 1 ->
                      let module S = Pickle_primitive
                      in
                      let v0 = S.unpickle stream in `Primitive v0
                  | 2 ->
                      let module S =
                        Pickle_3 (Pickle_datatype) (Pickle_datatype)
                          (Pickle_datatype)
                      in
                      let v0 = S.unpickle stream in `Function v0
                  | 3 ->
                      let module S = Pickle_row
                      in
                      let v0 = S.unpickle stream in `Record v0
                  | 4 ->
                      let module S = Pickle_row
                      in
                      let v0 = S.unpickle stream in `Variant v0
                  | 5 ->
                      let module S =
                        Pickle_2 (Pickle_datatype) (Pickle_datatype)
                      in
                      let v0 = S.unpickle stream in `Table v0
                  | 6 ->
                      let module S =
                        Pickle_2 (Pickle_string)
                          (Pickle_list (Pickle_datatype))
                      in
                      let v0 = S.unpickle stream in `Application v0
                  | 7 ->
                      let module S = Pickle_meta_type_var
                      in
                      let v0 = S.unpickle stream in `MetaTypeVar v0
                  | c ->
                      failwith
                      (Printf.sprintf
                           "Unexpected tag %d during unpickling of type : %s"
                           c "ldatatype'")
              end) :
           Pickle with type a = typed_data ldatatype')
        and Pickle_field_spec : Pickle with type a = typed_data field_spec' =
          (Pickle_defaults
             (struct
                type a = typed_data field_spec'
                let rec pickle buffer =
                  function
                    `Present v0 ->
                      Pickle_int.pickle buffer 0;
                      let module S = Pickle_1 (Pickle_datatype)
                      in
                      S.pickle buffer v0
                  | `Absent ->
                      Pickle_int.pickle buffer 1;
                      let module S = Pickle_0 in S.pickle buffer ()
                and unpickle stream =
                  match Pickle_int.unpickle stream with
                    0 ->
                      let module S = Pickle_datatype
                      in
                      let v0 = S.unpickle stream in `Present v0
                  | 1 -> `Absent
                  | c ->
                      failwith
                        (Printf.sprintf
                           "Unexpected tag %d during unpickling of type : %s"
                           c "field_spec'")
              end) :
           Pickle with type a = typed_data field_spec')
        and Pickle_field_spec_map :
          Pickle with type a = typed_data field_spec_map' =
          Pickle_field_env (Pickle_field_spec)
        and Pickle_row : Pickle with type a = typed_data row' =
          Pickle_2 (Pickle_field_spec_map) (Pickle_row_var)
        and Pickle_row_var : Pickle with type a = row_var =
          Pickle_point (Pickle_meta_row_var_basis)
        and Pickle_meta_type_var : Pickle with type a = meta_type_var =
          Pickle_point (Pickle_meta_type_var_basis)

     and Pickle_typed_data : Pickle with type a = datatype annotated_data =
      (Pickle_annotated_data (Pickle_datatype))

     and Pickle_typed_expression :
       Pickle with type a = typed_expression =
          (Pickle_defaults
             (struct
                type a = typed_expression
                let rec pickle buffer =
                  function
                    Constant v0 ->
                      Pickle_int.pickle buffer 0;
                      let module S =
                        Pickle_1 (Pickle_2 (Pickle_constant) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Variable v0 ->
                      Pickle_int.pickle buffer 1;
                      let module S = Pickle_1 (Pickle_2 (Pickle_string) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Abs v0 ->
                      Pickle_int.pickle buffer 2;
                      let module S =
                        Pickle_1 (Pickle_2 (Pickle_typed_expression) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | App v0 ->
                      Pickle_int.pickle buffer 3;
                      let module S =
                        Pickle_1
                          (Pickle_3 (Pickle_typed_expression) (Pickle_typed_expression)
                             (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Apply v0 ->
                      Pickle_int.pickle buffer 4;
                      let module S =
                        Pickle_1
                          (Pickle_3 (Pickle_typed_expression)
                             (Pickle_list (Pickle_typed_expression)) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Condition v0 ->
                      Pickle_int.pickle buffer 5;
                      let module S =
                        Pickle_1
                          (Pickle_4 (Pickle_typed_expression) (Pickle_typed_expression)
                             (Pickle_typed_expression) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Comparison v0 ->
                      Pickle_int.pickle buffer 6;
                      let module S =
                        Pickle_1
                          (Pickle_4 (Pickle_typed_expression) (Pickle_comparison)
                             (Pickle_typed_expression) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Abstr v0 ->
                      Pickle_int.pickle buffer 7;
                      let module S =
                        Pickle_1
                          (Pickle_3 (Pickle_list (Pickle_typed_expression))
                             (Pickle_typed_expression) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Let v0 ->
                      Pickle_int.pickle buffer 8;
                      let module S =
                        Pickle_1
                          (Pickle_4 (Pickle_string) (Pickle_typed_expression)
                             (Pickle_typed_expression) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Rec v0 ->
                      Pickle_int.pickle buffer 9;
                      let module S =
                        Pickle_1
                          (Pickle_3
                             (Pickle_list
                                (Pickle_3 (Pickle_string) (Pickle_typed_expression)
                                   (Pickle_option (Pickle_datatype))))
                             (Pickle_typed_expression) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Xml_node v0 ->
                      Pickle_int.pickle buffer 10;
                      let module S =
                        Pickle_1
                          (Pickle_4 (Pickle_string)
                             (Pickle_list
                                (Pickle_2 (Pickle_string)
                                   (Pickle_typed_expression)))
                             (Pickle_list (Pickle_typed_expression)) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Record_intro v0 ->
                      Pickle_int.pickle buffer 11;
                      let module S =
                        Pickle_1
                          (Pickle_3
                             (Utility.Pickle_stringmap (Pickle_typed_expression))
                             (Pickle_option (Pickle_typed_expression)) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Record_selection v0 ->
                      Pickle_int.pickle buffer 12;
                      let module S =
                        Pickle_1
                          (Pickle_6 (Pickle_string) (Pickle_string)
                             (Pickle_string) (Pickle_typed_expression)
                             (Pickle_typed_expression) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Project v0 ->
                      Pickle_int.pickle buffer 13;
                      let module S =
                        Pickle_1
                          (Pickle_3 (Pickle_typed_expression) (Pickle_string) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Erase v0 ->
                      Pickle_int.pickle buffer 14;
                      let module S =
                        Pickle_1
                          (Pickle_3 (Pickle_typed_expression) (Pickle_string) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Variant_injection v0 ->
                      Pickle_int.pickle buffer 15;
                      let module S =
                        Pickle_1
                          (Pickle_3 (Pickle_string) (Pickle_typed_expression) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Variant_selection v0 ->
                      Pickle_int.pickle buffer 16;
                      let module S =
                        Pickle_1
                          (Pickle_7 (Pickle_typed_expression) (Pickle_string)
                             (Pickle_string) (Pickle_typed_expression)
                             (Pickle_string) (Pickle_typed_expression) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Variant_selection_empty v0 ->
                      Pickle_int.pickle buffer 17;
                      let module S =
                        Pickle_1 (Pickle_2 (Pickle_typed_expression) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Nil v0 ->
                      Pickle_int.pickle buffer 18;
                      let module S = Pickle_1 (Pickle_typed_data) in S.pickle buffer v0
                  | List_of v0 ->
                      Pickle_int.pickle buffer 19;
                      let module S =
                        Pickle_1 (Pickle_2 (Pickle_typed_expression) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Concat v0 ->
                      Pickle_int.pickle buffer 20;
                      let module S =
                        Pickle_1
                          (Pickle_3 (Pickle_typed_expression) (Pickle_typed_expression)
                             (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | For v0 ->
                      Pickle_int.pickle buffer 21;
                      let module S =
                        Pickle_1
                          (Pickle_4 (Pickle_typed_expression) (Pickle_string)
                             (Pickle_typed_expression) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Database v0 ->
                      Pickle_int.pickle buffer 22;
                      let module S =
                        Pickle_1 (Pickle_2 (Pickle_typed_expression) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | TableQuery v0 ->
                      Pickle_int.pickle buffer 23;
                      let module S =
                        Pickle_1
                          (Pickle_3
                             (Pickle_list
                                (Pickle_2 (Pickle_string)
                                   (Pickle_typed_expression)))
                             (Query.Pickle_query) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | TableHandle v0 ->
                      Pickle_int.pickle buffer 24;
                      let module S =
                        Pickle_1
                          (Pickle_4 (Pickle_typed_expression) (Pickle_typed_expression)
                             (Pickle_3 (Pickle_datatype)
                                (Pickle_datatype) (Pickle_list (Pickle_2 (Pickle_string) (Pickle_typed_expression))))
                             (Pickle_typed_data))
                      in
		      let (v01,v02,v03,v04) = v0 in
                      S.pickle buffer (v01, v02, (v03.readtype, v03.writetype, v03.marshallby), v04)
                  | ViewQuery v0 ->
                      Pickle_int.pickle buffer 31;
                      let module S =
                        Pickle_1
                          (Pickle_2
                             (Pickle_typed_expression)
                             (Pickle_typed_data))
                      in
		              let (v01,v02) = v0 in
                      S.pickle buffer (v01, v02)
                  | ViewHandle v0 ->
                      Pickle_int.pickle buffer 31;
                      let module S =
                        Pickle_1
                          (Pickle_4 (Pickle_typed_expression) (Pickle_typed_expression)
                             (Pickle_typed_expression)
                             (Pickle_typed_data))
                      in
		      let (v01,v02,v03,v04) = v0 in
                      S.pickle buffer (v01, v02, v03, v04)
                  | SortBy v0 ->
                      Pickle_int.pickle buffer 25;
                      let module S =
                        Pickle_1
                          (Pickle_3 (Pickle_typed_expression) (Pickle_typed_expression)
                             (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Call_cc v0 ->
                      Pickle_int.pickle buffer 26;
                      let module S =
                        Pickle_1 (Pickle_2 (Pickle_typed_expression) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Wrong v0 ->
                      Pickle_int.pickle buffer 27;
                      let module S = Pickle_1 (Pickle_typed_data) in S.pickle buffer v0
                  | HasType v0 ->
                      Pickle_int.pickle buffer 28;
                      let module S =
                        Pickle_1
                          (Pickle_3 (Pickle_typed_expression)
                             (Pickle_datatype) (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Record_unpack v0 ->
                      Pickle_int.pickle buffer 29;
                      let module S =
                        Pickle_1
                          (Pickle_5 (Pickle_list (Pickle_2 (Pickle_string) (Pickle_string)))
			     (Pickle_typed_expression)
                             (Pickle_typed_expression) (Pickle_option (Pickle_typed_expression))
			     (Pickle_typed_data))
                      in
                      S.pickle buffer v0
                  | Record_pack v0 ->
                      Pickle_int.pickle buffer 30;
                      let module S =
                        Pickle_1
                          (Pickle_5 (Pickle_string) (Pickle_typed_expression)
			     (Pickle_datatype) (Pickle_typed_expression)
			     (Pickle_typed_data))
                      in
                      S.pickle buffer v0

                and unpickle stream =
                  match Pickle_int.unpickle stream with
                    0 ->
                      let module S = Pickle_2 (Pickle_constant) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Constant v0
                  | 1 ->
                      let module S = Pickle_2 (Pickle_string) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Variable v0
                  | 2 ->
                      let module S = Pickle_2 (Pickle_typed_expression) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Abs v0
                  | 3 ->
                      let module S =
                        Pickle_3 (Pickle_typed_expression) (Pickle_typed_expression)
                          (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in App v0
                  | 4 ->
                      let module S =
                        Pickle_3 (Pickle_typed_expression)
                          (Pickle_list (Pickle_typed_expression)) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Apply v0
                  | 5 ->
                      let module S =
                        Pickle_4 (Pickle_typed_expression) (Pickle_typed_expression)
                          (Pickle_typed_expression) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Condition v0
                  | 6 ->
                      let module S =
                        Pickle_4 (Pickle_typed_expression) (Pickle_comparison)
                          (Pickle_typed_expression) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Comparison v0
                  | 7 ->
                      let module S =
                        Pickle_3 (Pickle_list (Pickle_typed_expression))
                          (Pickle_typed_expression) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Abstr v0
                  | 8 ->
                      let module S =
                        Pickle_4 (Pickle_string) (Pickle_typed_expression)
                          (Pickle_typed_expression) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Let v0
                  | 9 ->
                      let module S =
                        Pickle_3
                          (Pickle_list
                             (Pickle_3 (Pickle_string) (Pickle_typed_expression)
                                (Pickle_option (Pickle_datatype))))
                          (Pickle_typed_expression) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Rec v0
                  | 10 ->
                      let module S =
                        Pickle_4 (Pickle_string)
                          (Pickle_list
                             (Pickle_2 (Pickle_string) (Pickle_typed_expression)))
                          (Pickle_list (Pickle_typed_expression)) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Xml_node v0
                  | 11 ->
                      let module S =
                        Pickle_3
                          (Utility.Pickle_stringmap (Pickle_typed_expression))
                          (Pickle_option (Pickle_typed_expression)) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Record_intro v0
                  | 12 ->
                      let module S =
                        Pickle_6 (Pickle_string) (Pickle_string)
                          (Pickle_string) (Pickle_typed_expression)
                          (Pickle_typed_expression) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Record_selection v0
                  | 13 ->
                      let module S =
                        Pickle_3 (Pickle_typed_expression) (Pickle_string) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Project v0
                  | 14 ->
                      let module S =
                        Pickle_3 (Pickle_typed_expression) (Pickle_string) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Erase v0
                  | 15 ->
                      let module S =
                        Pickle_3 (Pickle_string) (Pickle_typed_expression) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Variant_injection v0
                  | 16 ->
                      let module S =
                        Pickle_7 (Pickle_typed_expression) (Pickle_string)
                          (Pickle_string) (Pickle_typed_expression) (Pickle_string)
                          (Pickle_typed_expression) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Variant_selection v0
                  | 17 ->
                      let module S = Pickle_2 (Pickle_typed_expression) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Variant_selection_empty v0
                  | 18 ->
                      let module S = Pickle_typed_data
                      in
                      let v0 = S.unpickle stream in Nil v0
                  | 19 ->
                      let module S = Pickle_2 (Pickle_typed_expression) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in List_of v0
                  | 20 ->
                      let module S =
                        Pickle_3 (Pickle_typed_expression) (Pickle_typed_expression)
                          (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Concat v0
                  | 21 ->
                      let module S =
                        Pickle_4 (Pickle_typed_expression) (Pickle_string)
                          (Pickle_typed_expression) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in For v0
                  | 22 ->
                      let module S = Pickle_2 (Pickle_typed_expression) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Database v0
                  | 23 ->
                      let module S =
                        Pickle_3
                          (Pickle_list
                             (Pickle_2 (Pickle_string) (Pickle_typed_expression)))
                          (Query.Pickle_query) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in TableQuery v0
                  | 24 ->
                      let module S =
                        Pickle_4 (Pickle_typed_expression) (Pickle_typed_expression)
                          (Pickle_4 (Pickle_datatype)
                             (Pickle_datatype) (Pickle_list (Pickle_2 (Pickle_string) (Pickle_typed_expression))) (Pickle_list (Pickle_string)))
                          (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in 
		              let (v01,v02,(v03_1, v03_2, v03_3, v03_4),v04) = v0 in
			          TableHandle (v01, v02, {readtype=v03_1; writetype=v03_2; marshallby=v03_3; primarykey=v03_4}, v04)

                  | 32 ->
                      let module S =
                        Pickle_2
                          (Pickle_typed_expression)
                          (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in 
		              let (v01,v02) = v0 in
			          ViewQuery (v01, v02)
                  | 31 ->
                      let module S =
                        Pickle_4 (Pickle_typed_expression) (Pickle_typed_expression)
                          (Pickle_typed_expression)
                          (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in 
		              let (v01,v02,v03,v04) = v0 in
			          ViewHandle (v01, v02, v03, v04)
                  | 25 ->
                      let module S =
                        Pickle_3 (Pickle_typed_expression) (Pickle_typed_expression)
                          (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in SortBy v0
                  | 26 ->
                      let module S = Pickle_2 (Pickle_typed_expression) (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in Call_cc v0
                  | 27 ->
                      let module S = Pickle_typed_data
                      in
                      let v0 = S.unpickle stream in Wrong v0
                  | 28 ->
                      let module S =
                        Pickle_3 (Pickle_typed_expression) (Pickle_datatype)
                          (Pickle_typed_data)
                      in
                      let v0 = S.unpickle stream in HasType v0
                  | 29 ->
                      let module S =
                          (Pickle_5 (Pickle_list (Pickle_2 (Pickle_string) (Pickle_string)))
			     (Pickle_typed_expression)
                             (Pickle_typed_expression) (Pickle_option (Pickle_typed_expression))
  			     (Pickle_typed_data)) in
                      let v0 = S.unpickle stream in Record_unpack v0
                  | 30 ->
                      let module S =
                        (Pickle_5 (Pickle_string) (Pickle_typed_expression) 
			   (Pickle_datatype) (Pickle_typed_expression) (Pickle_typed_data)) in
                      let v0 = S.unpickle stream in Record_pack v0
                  | c ->
                      failwith
                        (Printf.sprintf
                           "Unexpected tag %d during unpickling of type : %s"
                           c "expression'")
              end) :
             Pickle with type a = typed_expression)
          

(* ******************************  deriving (Pickle) END **************************** *)

(* (\* ******************************  deriving (Typeable) Start **************************** *\) *)

(*     open Typeable *)
(*     module rec Typeable_datatype : Typeable with type a = fable_type datatype' = *)
(*         Typeable_defaults *)
(*           (struct *)
(*              type a = fable_type datatype' *)
(*              let typeRep = *)
(*                let rep = ref None in *)
(*                fun _ -> *)
(*                  match rep.contents with *)
(*                    None -> *)
(*                      let t = TypeRep (Tag.fresh (), [Typeable_fable_type.typeRep ()]) in *)
(*                      rep.contents <- Some t; t *)
(*                  | Some r -> r *)
(*            end) *)
(*     and Typeable_meta_type_var_basis : *)
(*       Typeable with type a = meta_type_var_basis = *)
(*       Typeable_defaults *)
(*         (struct *)
(*            type a = meta_type_var_basis *)
(*            let typeRep = *)
(*              let rep = ref None in *)
(*              fun _ -> *)
(*                match rep.contents with *)
(*                  None -> *)
(*                    let t = TypeRep (Tag.fresh (), []) in *)
(*                    rep.contents <- Some t; t *)
(*                | Some r -> r *)
(*          end) *)
(*     and Typeable_meta_row_var_basis : *)
(*       Typeable with type a = meta_row_var_basis = *)
(*       Typeable_defaults *)
(*         (struct *)
(*            type a = meta_row_var_basis *)
(*            let typeRep = *)
(*              let rep = ref None in *)
(*              fun _ -> *)
(*                match rep.contents with *)
(*                  None -> *)
(*                    let t = TypeRep (Tag.fresh (), []) in *)
(*                    rep.contents <- Some t; t *)
(*                | Some r -> r *)
(*          end) *)
(*     and Typeable_ldatatype : Typeable with type a = fable_type ldatatype' = *)
(*         Typeable_defaults *)
(*           (struct *)
(*              type a = fable_type ldatatype' *)
(*              let typeRep = *)
(*                let rep = ref None in *)
(*                fun _ -> *)
(*                  match rep.contents with *)
(*                    None -> *)
(*                      let t = TypeRep (Tag.fresh (), [Typeable_fable_type.typeRep ()]) in *)
(*                      rep.contents <- Some t; t *)
(*                  | Some r -> r *)
(*            end) *)
(*     and Typeable_field_spec : Typeable with type a = fable_type field_spec' = *)
(*         Typeable_defaults *)
(*           (struct *)
(*              type a = fable_type field_spec' *)
(*              let typeRep = *)
(*                let rep = ref None in *)
(*                fun _ -> *)
(*                  match rep.contents with *)
(*                    None -> *)
(*                      let t = TypeRep (Tag.fresh (), [Typeable_fable_type.typeRep ()]) in *)
(*                      rep.contents <- Some t; t *)
(*                  | Some r -> r *)
(*            end) *)
(*     and Typeable_field_spec_map : Typeable with type a = fable_type field_spec_map' = *)
(*         Typeable_defaults (Typeable_field_env (Typeable_field_spec)) *)
(*     and Typeable_row : Typeable with type a = fable_type row' = *)
(*         Typeable_defaults *)
(*           (Typeable_2 (Typeable_field_spec_map) (Typeable_row_var)) *)
(*     and Typeable_row_var : Typeable with type a = row_var = *)
(*       Typeable_defaults (Typeable_point (Typeable_meta_row_var_basis)) *)
(*     and Typeable_meta_type_var : Typeable with type a = meta_type_var = *)
(*       Typeable_defaults (Typeable_point (Typeable_meta_type_var_basis)) *)

(*     and Typeable_typed_data : Typeable with type a = datatype annotated_data = *)
(*       Typeable_annotated_data (Typeable_datatype) *)
(*     and Typeable_typed_expression : *)
(*         Typeable with type a = typed_expression = *)
(*         Typeable_defaults *)
(*           (struct *)
(*              type a = typed_expression *)
(*              let typeRep = *)
(*                let rep = ref None in *)
(*                fun _ -> *)
(*                  match rep.contents with *)
(*                    None -> *)
(*                      let t = *)
(*                        TypeRep (Tag.fresh (), [Typeable_typed_data.typeRep (); Typeable_datatype.typeRep ()]) *)
(*                      in *)
(*                      rep.contents <- Some t; t *)
(*                  | Some r -> r *)
(*            end) *)
(*     and Typeable_fable_type : Typeable with type a = fable_type = *)
(*       Typeable_defaults (Typeable_fable_qualifier (Typeable_typed_expression)) *)


(* ******************************  deriving (Typeable) END **************************** *)

(* (\* ******************************  deriving (Shelve) Start **************************** *\) *)

(* (\* Shelve *\) *)
(*    open Shelve *)
(*    module rec Shelve_datatype : Shelve with type a = fable_type datatype' = *)
(*           (struct *)
(*              module Typeable = Typeable_datatype *)
(*              module Eq = Eq_datatype *)
(*              module Comp = Dynmap.Comp (Typeable) (Eq) *)
(*              open Shelvehelper *)
(*              type a = fable_type datatype' *)
(*              let rec shelve ({ltype = ltype; ftype = ftype} as obj) = *)
(*                let module M = Shelve_2 (Shelve_ldatatype) (Shelve_fable_type) *)
(*                in *)
(*                M.shelve (ltype, ftype) *)
(*            end : *)
(*            Shelve with type a = fable_type datatype') *)
(*         and Shelve_meta_type_var_basis : *)
(*           Shelve with type a = meta_type_var_basis = *)
(*           (struct *)
(*              module Typeable = Typeable_meta_type_var_basis *)
(*              module Eq = Eq_meta_type_var_basis *)
(*              module Comp = Dynmap.Comp (Typeable) (Eq) *)
(*              open Shelvehelper *)
(*              type a = meta_type_var_basis *)
(*              let rec shelve = *)
(*                function *)
(*                  Flexible v0 as obj -> *)
(*                    let module M = Shelve_int *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:0 [id0])) *)
(*                | Rigid v0 as obj -> *)
(*                    let module M = Shelve_int *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:1 [id0])) *)
(*                | Recursive v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_2 (Shelve_int) *)
(*                        (Shelve_datatype) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:2 [id0])) *)
(*                | Body v0 as obj -> *)
(*                    let module M = Shelve_datatype *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:3 [id0])) *)
(*            end : *)
(*            Shelve with type a = meta_type_var_basis) *)
(*         and Shelve_meta_row_var_basis : *)
(*           Shelve with type a = meta_row_var_basis = *)
(*           (struct *)
(*              module Typeable = Typeable_meta_row_var_basis *)
(*              module Eq = Eq_meta_row_var_basis *)
(*              module Comp = Dynmap.Comp (Typeable) (Eq) *)
(*              open Shelvehelper *)
(*              type a = meta_row_var_basis *)
(*              let rec shelve = *)
(*                function *)
(*                  ClosedRow as obj -> *)
(*                    allocate_store_return (Typeable.makeDynamic obj) Comp.eq *)
(*                      (make_repr ~constructor:0 []) *)
(*                | FlexibleRow v0 as obj -> *)
(*                    let module M = Shelve_int *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:1 [id0])) *)
(*                | RigidRow v0 as obj -> *)
(*                    let module M = Shelve_int *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:2 [id0])) *)
(*                | RecursiveRow v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_2 (Shelve_int) (Shelve_row) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:3 [id0])) *)
(*                | BodyRow v0 as obj -> *)
(*                    let module M = Shelve_row *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:4 [id0])) *)
(*            end : *)
(*            Shelve with type a = meta_row_var_basis) *)
(*         and Shelve_ldatatype : Shelve with type a = fable_type ldatatype' = *)
(*           (struct *)
(*              module Typeable = Typeable_ldatatype *)
(*              module Eq = Eq_ldatatype *)
(*              module Comp = Dynmap.Comp (Typeable) (Eq) *)
(*              open Shelvehelper *)
(*              type a = fable_type ldatatype' *)
(*              let rec shelve = *)
(*                function *)
(*                  `Not_typed as obj -> *)
(*                    allocate_store_return (Typeable.makeDynamic obj) Comp.eq *)
(*                      (make_repr ~constructor:0 []) *)
(*                | `Primitive v0 as obj -> *)
(*                    let module M = Shelve_primitive *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:1 [id0])) *)
(*                | `Function v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_3 (Shelve_datatype) (Shelve_datatype) *)
(*                        (Shelve_datatype) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:2 [id0])) *)
(*                | `Record v0 as obj -> *)
(*                    let module M = Shelve_row *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:3 [id0])) *)
(*                | `Variant v0 as obj -> *)
(*                    let module M = Shelve_row *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:4 [id0])) *)
(*                | `Table v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_2 (Shelve_datatype) (Shelve_datatype) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:5 [id0])) *)
(*                | `Application v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_2 (Shelve_string) (Shelve_list (Shelve_datatype)) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:6 [id0])) *)
(*                | `MetaTypeVar v0 as obj -> *)
(*                    let module M = Shelve_meta_type_var *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:7 [id0])) *)
(*            end : *)
(*            Shelve with type a = fable_type ldatatype') *)
(*         and Shelve_field_spec : Shelve with type a = fable_type field_spec' = *)
(*           (struct *)
(*              module Typeable = Typeable_field_spec *)
(*              module Eq = Eq_field_spec *)
(*              module Comp = Dynmap.Comp (Typeable) (Eq) *)
(*              open Shelvehelper *)
(*              type a = fable_type field_spec' *)
(*              let rec shelve = *)
(*                function *)
(*                  `Present v0 as obj -> *)
(*                    let module M = Shelve_datatype *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:0 [id0])) *)
(*                | `Absent as obj -> *)
(*                    allocate_store_return (Typeable.makeDynamic obj) Comp.eq *)
(*                      (make_repr ~constructor:1 []) *)
(*            end : *)
(*            Shelve with type a = fable_type field_spec') *)
(*         and Shelve_field_spec_map : *)
(*           Shelve with type a = fable_type field_spec_map' = *)
(*           Shelve_field_env (Shelve_field_spec) *)
(*         and Shelve_row : Shelve with type a = fable_type row' = *)
(*           Shelve_2 (Shelve_field_spec_map) (Shelve_row_var) *)
(*         and Shelve_row_var : Shelve with type a = row_var = *)
(*           Shelve_point (Shelve_meta_row_var_basis) *)
(*         and Shelve_meta_type_var : Shelve with type a = meta_type_var = *)
(*           Shelve_point (Shelve_meta_type_var_basis) *)

(*     and Shelve_typed_data : Shelve with type a = datatype annotated_data = *)
(*      (Shelve_annotated_data (Shelve_datatype)) *)
(*     and Shelve_typed_expression : *)
(*       Shelve with type a = typed_expression = *)
(*       (struct *)
(*          module Typeable = Typeable_typed_expression *)
(*          module Eq = Eq_typed_expression *)
(*          module Comp = Dynmap.Comp (Typeable) (Eq) *)
(*          open Shelvehelper *)
(*          type a = typed_expression *)
(*          let rec shelve = *)
(*            function *)
(*                Constant v0 as obj -> *)
(*                    let module M = Shelve_2 (Shelve_constant) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:0 [id0])) *)
(*                | Variable v0 as obj -> *)
(*                    let module M = Shelve_2 (Shelve_string) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:1 [id0])) *)
(*                | Abs v0 as obj -> *)
(*                    let module M = Shelve_2 (Shelve_typed_expression) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:2 [id0])) *)
(*                | App v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_3 (Shelve_typed_expression) (Shelve_typed_expression) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:3 [id0])) *)
(*                | Apply v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_3 (Shelve_typed_expression) *)
(*                        (Shelve_list (Shelve_typed_expression)) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:4 [id0])) *)
(*                | Condition v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_4 (Shelve_typed_expression) (Shelve_typed_expression) *)
(*                        (Shelve_typed_expression) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:5 [id0])) *)
(*                | Comparison v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_4 (Shelve_typed_expression) (Shelve_comparison) *)
(*                        (Shelve_typed_expression) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:6 [id0])) *)
(*                | Abstr v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_3 (Shelve_list (Shelve_typed_expression)) *)
(*                        (Shelve_typed_expression) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:7 [id0])) *)
(*                | Let v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_4 (Shelve_string) (Shelve_typed_expression) *)
(*                        (Shelve_typed_expression) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:8 [id0])) *)
(*                | Rec v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_3 *)
(*                        (Shelve_list *)
(*                           (Shelve_3 (Shelve_string) (Shelve_typed_expression) *)
(*                              (Shelve_option (Shelve_datatype)))) *)
(*                        (Shelve_typed_expression) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:9 [id0])) *)
(*                | Xml_node v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_4 (Shelve_string) *)
(*                        (Shelve_list *)
(*                           (Shelve_2 (Shelve_string) (Shelve_typed_expression))) *)
(*                        (Shelve_list (Shelve_typed_expression)) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:10 [id0])) *)
(*                | Record_intro v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_3 (Utility.Shelve_stringmap (Shelve_typed_expression)) *)
(*                        (Shelve_option (Shelve_typed_expression)) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:11 [id0])) *)
(*                | Record_selection v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_6 (Shelve_string) (Shelve_string) (Shelve_string) *)
(*                        (Shelve_typed_expression) (Shelve_typed_expression) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:12 [id0])) *)
(*                | Project v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_3 (Shelve_typed_expression) (Shelve_string) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:13 [id0])) *)
(*                | Erase v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_3 (Shelve_typed_expression) (Shelve_string) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:14 [id0])) *)
(*                | Variant_injection v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_3 (Shelve_string) (Shelve_typed_expression) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:15 [id0])) *)
(*                | Variant_selection v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_7 (Shelve_typed_expression) (Shelve_string) *)
(*                        (Shelve_string) (Shelve_typed_expression) (Shelve_string) *)
(*                        (Shelve_typed_expression) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:16 [id0])) *)
(*                | Variant_selection_empty v0 as obj -> *)
(*                    let module M = Shelve_2 (Shelve_typed_expression) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:17 [id0])) *)
(*                | Nil v0 as obj -> *)
(*                    let module M = Shelve_typed_data *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:18 [id0])) *)
(*                | List_of v0 as obj -> *)
(*                    let module M = Shelve_2 (Shelve_typed_expression) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:19 [id0])) *)
(*                | Concat v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_3 (Shelve_typed_expression) (Shelve_typed_expression) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:20 [id0])) *)
(*                | For v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_4 (Shelve_typed_expression) (Shelve_string) *)
(*                        (Shelve_typed_expression) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:21 [id0])) *)
(*                | Database v0 as obj -> *)
(*                    let module M = Shelve_2 (Shelve_typed_expression) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:22 [id0])) *)
(*                | TableQuery v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_3 *)
(*                        (Shelve_list *)
(*                           (Shelve_2 (Shelve_string) (Shelve_typed_expression))) *)
(*                        (Query.Shelve_query) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:23 [id0])) *)
(*                | TableHandle v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_4 (Shelve_typed_expression) (Shelve_typed_expression) *)
(*                        (Shelve_2 (Shelve_datatype) *)
(*                           (Shelve_datatype)) *)
(*                        (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:24 [id0])) *)
(*                | SortBy v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_3 (Shelve_typed_expression) (Shelve_typed_expression) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:25 [id0])) *)
(*                | Call_cc v0 as obj -> *)
(*                    let module M = Shelve_2 (Shelve_typed_expression) (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:26 [id0])) *)
(*                | Wrong v0 as obj -> *)
(*                    let module M = Shelve_typed_data *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:27 [id0])) *)
(*                | HasType v0 as obj -> *)
(*                    let module M = *)
(*                      Shelve_3 (Shelve_typed_expression) (Shelve_datatype) *)
(*                        (Shelve_typed_data) *)
(*                    in *)
(*                    ( >>= ) (M.shelve v0) *)
(*                      (fun id0 -> *)
(*                         allocate_store_return (Typeable.makeDynamic obj) *)
(*                           Comp.eq (make_repr ~constructor:28 [id0])) *)
(*            end : *)
(*          Shelve with type a = typed_expression) *)
(*         and Shelve_fable_type : Shelve with type a = fable_type = *)
(*           (Shelve_fable_qualifier (Shelve_typed_expression)) *)

(* (\* ******************************  deriving (Shelve) End **************************** *\) *)

(* ******************************  deriving (Functor) Start **************************** *)

open Functor
open Expr
module Functor_expression' =
struct
  type 'a f = 'a expression' 
  let rec map_expr f =
    function
        Constant x -> Constant ((fun (v0, v1) -> v0, f v1) x)
      | Variable x -> Variable ((fun (v0, v1) -> v0, f v1) x)
      | Abs x ->
          Abs ((fun (v0, v1) -> map_expr f v0, f v1) x)
      | App x ->
            App
              ((fun (v0, v1, v2) ->
                  map_expr f v0,
                  map_expr f v1, f v2)
                 x)
        | Apply x ->
            Apply
              ((fun (v0, v1, v2) ->
                  map_expr f v0,
                  Functor_list.map (map_expr f) v1, f v2)
                 x)
        | Condition x ->
            Condition
              ((fun (v0, v1, v2, v3) ->
                  map_expr f v0,
                  map_expr f v1,
                  map_expr f v2, f v3)
                 x)
        | Comparison x ->
            Comparison
              ((fun (v0, v1, v2, v3) ->
                  map_expr f v0, v1,
                  map_expr f v2, f v3)
                 x)
        | Abstr x ->
            Abstr
              ((fun (v0, v1, v2) ->
                  Functor_list.map (map_expr f) v0,
                  map_expr f v1, f v2)
                 x)
        | Let x ->
            Let
              ((fun (v0, v1, v2, v3) ->
                  v0, map_expr f v1,
                  map_expr f v2, f v3)
                 x)
        | Rec x ->
            Rec
              ((fun (v0, v1, v2) ->
                  Functor_list.map
                    (fun (v0, v1, v2) ->
                       v0, map_expr f v1, (match v2 with Some v2 -> Some(map_type f v2) | _ -> None))
                    v0,
                  map_expr f v1, f v2)
                 x)
        | Xml_node x ->
            Xml_node
              ((fun (v0, v1, v2, v3) ->
                  v0,
                  Functor_list.map
                    (fun (v0, v1) -> v0, map_expr f v1) v1,
                  Functor_list.map (map_expr f) v2, f v3)
                 x)
        | Record_intro x ->
            Record_intro
              ((fun (v0, v1, v2) ->
                  Functor_stringmap.map (map_expr f) v0,
                  Functor_option.map (map_expr f) v1, f v2)
                 x)
        | Record_selection x ->
            Record_selection
              ((fun (v0, v1, v2, v3, v4, v5) ->
                  v0, v1, v2, map_expr f v3,
                  map_expr f v4, f v5)
                 x)
        | Record_unpack x ->
            Record_unpack
              ((fun (v0, v1, v2, v3, v4) ->
                  v0, map_expr f v1, map_expr f v2, 
		  (match v3 with 
		       None -> None
		     | Some v3 -> Some (map_expr f v3)), 
		  f v4) x)
        | Record_pack x ->
            Record_pack
              ((fun (v0, v1, v2, v3, v4) ->
                  v0, map_expr f v1, map_type f v2, map_expr f v3, f v4) x)
        | Project x ->
            Project
              ((fun (v0, v1, v2) -> map_expr f v0, v1, f v2)
                 x)
        | Erase x ->
            Erase
              ((fun (v0, v1, v2) -> map_expr f v0, v1, f v2)
                 x)
        | Variant_injection x ->
            Variant_injection
              ((fun (v0, v1, v2) -> v0, map_expr f v1, f v2)
                 x)
        | Variant_selection x ->
            Variant_selection
              ((fun (v0, v1, v2, v3, v4, v5, v6) ->
                  map_expr f v0, v1, v2,
                  map_expr f v3, v4,
                  map_expr f v5, f v6)
                 x)
        | Variant_selection_empty x ->
            Variant_selection_empty
              ((fun (v0, v1) -> map_expr f v0, f v1) x)
        | Nil x -> Nil (f x)
        | List_of x ->
            List_of ((fun (v0, v1) -> map_expr f v0, f v1) x)
        | Concat x ->
            Concat
              ((fun (v0, v1, v2) ->
                  map_expr f v0,
                  map_expr f v1, f v2)
                 x)
        | For x ->
            For
              ((fun (v0, v1, v2, v3) ->
                  map_expr f v0, v1,
                  map_expr f v2, f v3)
                 x)
        | Database x ->
            Database
              ((fun (v0, v1) -> map_expr f v0, f v1) x)
        | TableQuery x ->
            TableQuery
              ((fun (v0, v1, v2) ->
                  Functor_list.map
                    (fun (v0, v1) -> v0, map_expr f v1) v0,
                  v1, f v2)
                 x)
        | TableHandle x ->
            TableHandle
              ((fun (v0, v1, {readtype=v2; writetype=v2'; marshallby=v2''; primarykey=v2'''}, v3) ->
                  map_expr f v0,
                  map_expr f v1, {readtype=map_type f v2; 
                                  writetype=map_type f v2'; 
                                  marshallby=List.map (fun (s,e) -> (s, map_expr f e)) v2'';
                                  primarykey=v2'''
                                 }, f v3)
                 x)
        | ViewQuery x ->
            ViewQuery
              ((fun (v0, v1) ->
                  map_expr f v0,
                  f v1)
                 x)
        | ViewHandle x ->
            ViewHandle
              ((fun (v0, v1, v2, v3) ->
                  map_expr f v0,
                  map_expr f v1,
                  map_expr f v2,
                  f v3)
                 x)
        | SortBy x ->
            SortBy
              ((fun (v0, v1, v2) ->
                  map_expr f v0,
                  map_expr f v1, f v2)
                 x)
        | Call_cc x ->
            Call_cc ((fun (v0, v1) -> map_expr f v0, f v1) x)
        | Wrong x -> Wrong (f x)
        | HasType x ->
            HasType
              ((fun (v0, v1, v2) -> map_expr f v0, map_type f v1, f v2)
                 x)

  and map_type f typ =
    let lt = typ.ltype in
    let ft = typ.ftype in 
      {ltype=map_ltype f lt; ftype=map_ftype f ft}

  and map_ltype f = function
    | `Not_typed -> `Not_typed
    | `Primitive p -> `Primitive p
    | `Function (fn, m, t) -> `Function (
        map_type f fn,
        map_type f m,
        map_type f t)
    | `Record row -> `Record (map_row f row)
    | `Variant row -> `Variant (map_row f row)
    | `Table (r, w) -> `Table (map_type f r, map_type f w)
    | `Application (n, datatypes) -> 
        `Application (n, List.map (map_type f) datatypes)
    | `MetaTypeVar p -> `MetaTypeVar p
        
  and map_row f (fsm, rv) =
    let map_field_spec_map : ('a field_spec' field_env) -> ('b field_spec' field_env) = 
      let map_field_spec = function
          `Absent -> `Absent
        | `Present (x) -> `Present (map_type f x)
      in fun env -> StringMap.map map_field_spec env
    in
      map_field_spec_map fsm, rv
   
  and map_ftype f = function
      `Empty -> `Empty
    | `KindVar p -> 
        let map_point f p = Unionfind.fresh (f (Unionfind.find p)) in
          `KindVar (map_point (map_kind_var_basis f) p)
    | `Kind k -> `Kind k
    | `Name (n, fq) -> `Name (n, map_ftype f fq)
    | `Labeling (expr, fq) -> `Labeling (map_expr f expr, map_ftype f fq)
    | `Label (expr, fq) -> 
        `Label (map_triopt (map_expr f) expr, map_ftype f fq)
    | `Phantom (xs, fq) -> `Phantom (xs, map_ftype f fq)


  and map_kind_var_basis (f:'a->'b) : 'a FableType.kind_var_basis -> 'b FableType.kind_var_basis
  = function
    `FlexKind (n,k) -> `FlexKind (n,k)
  | `FixedKind fq -> `FixedKind (map_ftype f fq)

  and map_triopt f =
    let map_point f p = Unionfind.fresh (f (Unionfind.find p)) in
    let map_lbasis = 
      function
          `Nothing -> `Nothing
        | `Something x -> `Something (f x)
    in
      function
          `Nothing -> `Nothing
        | `Inferred p -> `Inferred (map_point map_lbasis p)
        | `Required (x) -> `Required (f x)
          

  let map = map_expr

  end

(* ********************  deriving (Functor) End **************************** *)

(* ******************  deriving (Rewriter) Start **************************** *)
  open Rewriter
  open Functor
  module type TwoTypes = sig
    type a
  end
  module Rewrite_expression' (V0 : TwoTypes) =
    Rewrite.Rewrite
      (Rewrite.SimpleRewrite
         ((functor (V0 : TwoTypes) ->
             Rewriter.RewriterDefaults
               (struct
                  type t = V0.a expression'
                  type rewriter = t -> t option
                  let process_children' rewriter v =
                    let changed = ref false in
                    let adapted x =
                      match rewriter x with
                          Some x -> changed.contents <- true; x
                        | None -> x
                    in
                    let rv =
                      match v with
                          Constant _ as p -> p
                        | Variable _ as p -> p
                        | Abs x -> Abs ((fun (v0, v1) -> adapted v0, v1) x)
                        | App x ->
                            App
                              ((fun (v0, v1, v2) ->
                                  adapted v0, adapted v1, v2)
                                 x)
                        | Apply x ->
                            Apply
                              ((fun (v0, v1, v2) ->
                                  adapted v0, Functor_list.map adapted v1, v2)
                                 x)
                        | Condition x ->
                            Condition
                              ((fun (v0, v1, v2, v3) ->
                                  adapted v0, adapted v1, adapted v2, v3)
                                 x)
                        | Comparison x ->
                            Comparison
                              ((fun (v0, v1, v2, v3) ->
                                  adapted v0, v1, adapted v2, v3)
                                 x)
                        | Abstr x ->
                            Abstr
                              ((fun (v0, v1, v2) ->
                                  Functor_list.map adapted v0, adapted v1, v2)
                                 x)
                        | Let x ->
                            Let
                              ((fun (v0, v1, v2, v3) ->
                                  v0, adapted v1, adapted v2, v3)
                                 x)
                        | Rec x ->
                            Rec
                              ((fun (v0, v1, v2) ->
                                  Functor_list.map
                                    (fun (v0, v1, v2) -> v0, adapted v1, v2)
                                    v0,
                                  adapted v1, v2)
                                 x)
                        | Xml_node x ->
                            Xml_node
                              ((fun (v0, v1, v2, v3) ->
                                  v0,
                                  Functor_list.map
                                    (fun (v0, v1) -> v0, adapted v1) v1,
                                  Functor_list.map adapted v2, v3)
                                 x)
                        | Record_intro x ->
                            Record_intro
                              ((fun (v0, v1, v2) ->
                                  Functor_stringmap.map adapted v0,
                                  Functor_option.map adapted v1, v2)
                                 x)
                        | Record_selection x ->
                            Record_selection
                              ((fun (v0, v1, v2, v3, v4, v5) ->
                                  v0, v1, v2, adapted v3, adapted v4, v5)
                                 x)
                        | Record_unpack x ->
                            Record_unpack
                              ((fun (v0, v1, v2, v3, v4) ->
                                  v0, adapted v1, adapted v2, (function Some x -> Some (adapted x) | None -> None) v3, v4)
                                 x)
                        | Record_pack x ->
                            Record_pack
                              ((fun (v0, v1, v2, v3, v4) ->
                                  v0, adapted v1, v2, adapted v3, v4) x)
                        | Project x ->
                            Project
                              ((fun (v0, v1, v2) -> adapted v0, v1, v2) x)
                        | Erase x ->
                            Erase ((fun (v0, v1, v2) -> adapted v0, v1, v2) x)
                        | Variant_injection x ->
                            Variant_injection
                              ((fun (v0, v1, v2) -> v0, adapted v1, v2) x)
                        | Variant_selection x ->
                            Variant_selection
                              ((fun (v0, v1, v2, v3, v4, v5, v6) ->
                                  adapted v0, v1, v2, adapted v3, v4,
                                  adapted v5, v6)
                                 x)
                        | Variant_selection_empty x ->
                            Variant_selection_empty
                              ((fun (v0, v1) -> adapted v0, v1) x)
                        | Nil _ as p -> p
                        | List_of x ->
                            List_of ((fun (v0, v1) -> adapted v0, v1) x)
                        | Concat x ->
                            Concat
                              ((fun (v0, v1, v2) ->
                                  adapted v0, adapted v1, v2)
                                 x)
                        | For x ->
                            For
                              ((fun (v0, v1, v2, v3) ->
                                  adapted v0, v1, adapted v2, v3)
                                 x)
                        | Database x ->
                            Database ((fun (v0, v1) -> adapted v0, v1) x)
                        | TableQuery x ->
                            TableQuery
                              ((fun (v0, v1, v2) ->
                                  Functor_list.map
                                    (fun (v0, v1) -> v0, adapted v1) v0,
                                  v1, v2)
                                 x)
                        | TableHandle x ->
                            TableHandle
                              ((fun (v0, v1, v2, v3) ->
                                  adapted v0, adapted v1, {v2 with marshallby=List.map (fun (s,e) -> (s, adapted e)) v2.marshallby}, v3)
                                 x)
                        | ViewQuery x ->
                            ViewQuery
                              ((fun (v0, v1) ->
                                  adapted v0, v1)
                                 x)
                        | ViewHandle x ->
                            ViewHandle
                              ((fun (v0, v1, v2, v3) ->
                                  adapted v0, adapted v1, adapted v2, v3)
                                 x)
                        | SortBy x ->
                            SortBy
                              ((fun (v0, v1, v2) ->
                                  adapted v0, adapted v1, v2)
                                 x)
                        | Call_cc x ->
                            Call_cc ((fun (v0, v1) -> adapted v0, v1) x)
                        | Wrong _ as p -> p
                        | HasType x ->
                            HasType
                              ((fun (v0, v1, v2) -> adapted v0, v1, v2) x)
                    in
                      rv, changed.contents
                end))
            (V0)))
      (* ******************************  deriving (Rewriter) End **************************** *)
end (* module DerivingSyntax *)

