#define CLASS_CONFLICT
#define DISABLE_XOPEN_NLS

#include <sys/machine.h>		/* ENDIAN definitions for network
								 * communication */
