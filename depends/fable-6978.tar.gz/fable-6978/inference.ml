(*pp deriving *)
open List

open Utility
open Syntax
open Expression
open Expression.Expr
open Expression.Types
open Expression.FableType
open Forms
open Errors
open Instantiate
open Typeenv
open Printsyntax
open Unify

(* debug flags *)
let show_instantiation = Settings.add_bool("show_instantiation", false, `User)
let show_generalisation = Settings.add_bool("show_generalisation", false, `User)

let show_typechecking = Settings.add_bool("show_typechecking", false, `User)
let show_recursion = Instantiate.show_recursion

let rigid_type_variables = Settings.add_bool("rigid_type_variables", true, `User)

(*
  what kind of recursive types to allow
  "all"      - allow all recursive types
  "guarded"  - only allow guarded recursive types
  "positive" - only allow positive recursive types
*)

exception UndefinedVariable of string
exception Bad_fable_type of string
exception Bad_type_annotation of Types.datatype * string

(* a version of unify that doesn't return anything *)
let unify_nr ph omega exp sub ts = ignore (unify ph omega exp sub ts)

let norm_ultype :  Types.u_ldatatype -> ldatatype = 
  fun lt -> let {ltype=lt'; ftype=_} = Sugar.normalize_type {ltype=lt;ftype=`Empty} in lt'
                                                                                         
let db_descriptor_type =
  snd (Parse.parse_string (Parse.checked_datatype Sugar.normalize_type) "(driver:String, name:String, args:String)")

(* extract data from inference_expressions *)
let type_of_expression : expression -> datatype =
  fun exp -> let `T (_, t, _) = expression_data exp in t
let pos_of_expression : expression -> position =
  fun exp -> let `T (pos, _, _) = expression_data exp in pos

(* type typing_environment = environment * alias_environment *)

let rec extract_row_opt : Typeenv.omega -> datatype -> row option = fun omega (* ((env, alias_env) as typing_env)  *) t ->
  match t.ltype with
    | `Record row -> Some row
    | `Variant row -> Some row
    | `MetaTypeVar point ->
        begin
          match Unionfind.find point with
            | Body t -> extract_row_opt omega t
	        | Recursive (_, t) -> extract_row_opt omega t (* The way type annotations are handled means that we must include this case *)
            | _ -> None 
        end
    | `Application (s, ts) ->
        let vars, alias = Typeenv.lookup_alias (s, ts) omega in 
          extract_row_opt omega (instantiate_alias s (Typeenv.alias_env omega) (vars, alias) ts)
    | _ -> None

let extract_row omega dt = 
  match extract_row_opt omega dt with 
      None -> failwith
        ("Internal error: attempt to extract a row from a datatype that is not a record or variant: " ^ (string_of_datatype dt))
    | Some r -> r

let instantiate_assumption : Typeenv.omega -> (quantifier list * datatype) -> datatype =
  fun _ (quantifiers, t) ->
    if quantifiers = [] then
      Subst.rename_bound_vars t
    else
      let _ = Debug.if_set (show_instantiation)
        (fun () -> "Instantiating assumption: " ^ (string_of_assumption (quantifiers, t))) in
      let tenv, renv = List.fold_left
        (fun (tenv, renv) (var, k) ->
           let annot_kind dt =
	         let kv = Fable.fresh_kind_variable k in
	         {ltype = dt.ltype; ftype = `KindVar kv} in  (* preserve tvar kind *)
           match var with
             | `TypeVar var -> IntMap.add var (annot_kind (fresh_type_variable ())) tenv, renv
             | `RigidTypeVar var -> IntMap.add var (annot_kind (fresh_type_variable ())) tenv, renv
             | `RowVar var -> tenv, IntMap.add var (fresh_row_variable ()) renv
        ) (IntMap.empty, IntMap.empty) quantifiers
      in
      Subst.rename_bound_vars (instantiate_datatype (tenv, renv) t)
	  
(** instantiate env var
    Get the type of `var' from the environment, and rename bound typevars.
*)
let instantiate : Typeenv.omega -> string -> datatype = fun omega var ->
  try
    let quantifiers, t = Typeenv.lookup var omega in
      instantiate_assumption omega (quantifiers, t)
  with Not_found ->
    raise (UndefinedVariable ("Variable '"^ var ^"' does not refer to a declaration"))

(*
  get the quantifiers for a datatype
  i.e. the quantifiers required to close a datatype
  
  (the first argument specifies type variables that should remain free)
*)
let rec get_quantifiers : TypeVarSet.t -> datatype -> quantifier list = 
  fun bound_vars dt -> match dt.ltype with 
    | `Not_typed -> failwith "Internal error: Not_typed encountered in get_quantifiers"
    | `Primitive _ -> []
    | `MetaTypeVar point ->
        (match Unionfind.find point with
           | Flexible var
           | Rigid var when TypeVarSet.mem var bound_vars -> []
           | Flexible var -> [`TypeVar var, Fable.kind_qual dt.ftype]
           | Rigid var -> [`RigidTypeVar var, Fable.kind_qual dt.ftype]
           | Recursive (var, body) ->
               Debug.if_set (show_recursion) (fun () -> "rec (get_quantifiers): " ^(string_of_int var));
               if TypeVarSet.mem var bound_vars then
                 []
               else
                 get_quantifiers (TypeVarSet.add var bound_vars) body
           | Body t -> get_quantifiers bound_vars t)
    | `Function (f, m, t) ->
        let from_gens = get_quantifiers bound_vars f
        and mailbox_gens = get_quantifiers bound_vars m
        and to_gens = get_quantifiers bound_vars t in
          unduplicate (=) (from_gens @ mailbox_gens @ to_gens)
    | `Record row
    | `Variant row -> get_row_quantifiers bound_vars row 
    | `Table (r, w) -> unduplicate (=) (get_quantifiers bound_vars r @ get_quantifiers bound_vars w)
    | `Application (_, args) ->
        unduplicate (=) (Utility.concat_map (get_quantifiers bound_vars) args)

and get_row_var_quantifiers : TypeVarSet.t -> row_var -> quantifier list =
  fun bound_vars row_var ->
    match Unionfind.find row_var with
      | ClosedRow -> []
      | FlexibleRow var
      | RigidRow var when TypeVarSet.mem var bound_vars -> []
      | FlexibleRow var
      | RigidRow var -> [`RowVar var, FableType.UKind] (* TODO : row var kinds? *)
      | RecursiveRow (var, rec_row) ->
          Debug.if_set (show_recursion) (fun () -> "rec (get_row_var_quantifiers): " ^(string_of_int var));
          (if TypeVarSet.mem var bound_vars then
             []
           else
             get_row_quantifiers (TypeVarSet.add var bound_vars) rec_row)
      | BodyRow row -> get_row_quantifiers bound_vars row

and get_field_spec_quantifiers : TypeVarSet.t -> field_spec -> quantifier list =
  fun bound_vars ->
    function
      | `Present t -> get_quantifiers bound_vars t
      | `Absent -> []

and get_row_quantifiers : TypeVarSet.t -> row -> quantifier list =
  fun bound_vars (field_env, row_var) ->
    let field_vars = StringMap.fold
      (fun _ field_spec vars ->
         get_field_spec_quantifiers bound_vars field_spec @ vars
      ) field_env [] in
    let row_vars = get_row_var_quantifiers bound_vars (row_var:row_var)
    in
      field_vars @ row_vars

let type_mismatch ~expected ~inferred ~pos ~src msg =
  raise (Type_error (pos, 
                     src ^" has type "^string_of_datatype inferred
                     ^" but is annotated with type "
                     ^ string_of_datatype expected^"\n"^
                       msg))

(** generalise: 
    Universally quantify any free type variables in the expression.
*)
let generalise : Typeenv.omega -> datatype -> assumption = 
  fun omega t ->
    let vars_in_env = Typeenv.all_type_vars omega in 
    let quantifiers = get_quantifiers vars_in_env t in
      Debug.if_set (show_generalisation) (fun () -> "Generalised: " ^ (string_of_assumption (quantifiers, t)));
      (quantifiers, t) 


let annot_ukind lt =
  {ltype=lt; ftype= `Kind UKind}  

let annot_mkind lt =
  {ltype=lt; ftype= `Kind MKind}  

let annot_kindvar lt k =
  let kv = Fable.fresh_kind_variable k in 
    {ltype=lt; ftype= `KindVar kv}

let rec constant_type = 
  let constant_ltype = function
    | Boolean _ -> `Primitive `Bool
    | Integer _ -> `Primitive `Int
    | Float _ -> `Primitive `Float
    | Char _ -> `Primitive `Char 
    | String _ -> failwith "impossible"
  in
  function
      String _ -> string_type ()
    | t -> annot_ukind (constant_ltype t)

let expand_record_open exp var_types = match exp with
  | Record_unpack(fields, value, body, None, _) -> 
      let tmp = Utility.gensym ~prefix:"open" () in
      let value_var = Variable(tmp, `T(dummy_position, type_of_expression value, None)) in
      let body = List.fold_left2 (fun body (fieldname, var) (var', _) ->
				                    if (var <> var') then
				                      raise Impos;
				                    Record_selection(fieldname, var, Utility.gensym ~prefix:"ignore" (),
						                             value_var, body, 
						                             `T(dummy_position, type_of_expression body, None))
				                 ) body fields var_types in
	    Let (tmp, value, body, `T(dummy_position, type_of_expression body, None))
  | _ -> raise Impos



let infer_label_type omega = 
  let rec infer_label_type rec_vars t = 
    let join_status = function
	    _, `Not_label
      | `Not_label, _ -> `Not_label
      | _, `General 
      | `General, _ ->  `General
      | _ -> `Specific in
    try
	  match Fable.get_label_type_expr t.ftype with 
          None -> `General
        | Some _ -> `Specific
    with 
        Not_found -> 
          let t = concrete_type t in 
          match t.ltype with (* if possible, try to give this a label qualifier *)
              _unit when (_unit = (Types.unit_type()).ltype) -> 
                `Specific
		          
		    | `Record row when is_closed_row row ->
                StringMap.fold (fun _ t status -> 
                                  match t, status with 
                                      `Absent, _
					                |  _, `Not_label -> status
					                | `Present t, _  -> 
                                        join_status (status, infer_label_type rec_vars t)
                               ) (fst row) `Specific 

		    | `Variant row when is_closed_row row -> 
                StringMap.fold (fun _ spec status -> match spec with
					                `Absent -> status
                                  | `Present t -> 
                                      join_status (status, infer_label_type rec_vars t)
                               ) (fst row) `Specific
                  
		    | `Application (name, ts) -> 
                let vars, def = Typeenv.lookup_alias (name, ts) omega in
                let inst = 
                  Instantiate.instantiate_alias name (Typeenv.alias_env omega) (vars, def) ts in
                infer_label_type rec_vars inst

		    | `MetaTypeVar pt -> 
                begin
                  match Unionfind.find pt with 
                      Recursive (ix, body) -> 
                        if IntSet.mem ix rec_vars then 
                          `General
                        else
                          infer_label_type (IntSet.add ix rec_vars) body
			        | _ -> `Not_label
                end

		    | _ -> `Not_label in
  infer_label_type IntSet.empty
      
(* let check_label_type env : 'a Types.ldatatype' -> bool =  *)
(*   fun lt ->  *)
(*     let t = {ltype=lt;ftype=`Empty} in *)
(*       match infer_label_type env t with  *)
(*           `Not_label -> raise (Bad_fable_type ("Type "^string_of_datatype t^ *)
(*                                                  " cannot be used as a label")) *)
(*         | _ -> true *)

let check_label_type _ : 'a Types.ldatatype' -> bool = 
  fun _ -> true
;;

let check_no_escaping_names : Typeenv.omega -> Types.datatype -> unit = 
  fun omega d -> match Fable.free_names ~expect_empty:true omega d with
      [] -> ()
    | [name] -> 
	    raise (Bad_fable_type ("The following name escapes its scope : " ^name))
    | l -> 
	    let names = List.fold_right (fun name s -> (name ^ ", " ^s)) l "" in
	      raise (Bad_fable_type ("The following names escape their scope : " ^names))
;;

(* check_type support functions *)

let strip_name_bindings_utype {ltype=lt;ftype=fq} = 
  {ltype=lt; ftype = Fable.strip_name_bindings fq}

let compatible_label_constraint : Typeenv.omega -> expression -> datatype -> unit =
  fun env exp lt ->
    (* TODO: What about rigid vs open rows here? Probably want them both to be rigid *)
    unify_nr [] env None false (Syntax.node_datatype exp, lt)

let rec check_fq_label env lt fq eopt fq' =
  (* TODO: ensure that k' is unifiable with UKind if lt is a type variable *)
  let _, k' = check_fq env lt fq' in 
  let _ = (k'=UKind) in (*  || check_label_type env lt) in  *)
  match eopt with
    | `Nothing -> `Label(`Nothing, `Kind UKind),  UKind
    | `Required e ->
        let e' = type_check_expression env e in 
        let _ = compatible_label_constraint env e' (def_fable_annot lt) in
		`Label(`Required e', `Kind UKind), UKind
	| `Inferred _ -> raise Impos (* should never occur in an unchecked fable type *)
		  
and check_fq_labeling env lt fq e fq' =
  let fq'', _ = check_fq env lt fq' in
  let e' = type_check_expression env e in
  let _ =  (Syntax.node_datatype ->- (fun x-> (Fable.kind_qual x.ftype) = UKind)) e' in 
  (*  = UKind || check_label_type env x.ltype))) e' in *)
  `Labeling(e', fq''), MKind

and check_fq env (lt : ldatatype) fq =
  ignore (FableType.well_formed_fq fq);
  let env = Typeenv.clear_type_annotation env in
  match fq with
	| `Empty -> `Kind UKind, UKind
	| `Kind k -> `Kind k, k
	| `Label(eopt, fq') -> check_fq_label env lt fq eopt fq'
	| `Labeling(e, fq') -> check_fq_labeling env lt fq e fq'
	| _ -> raise Impos (* No name bindings allowed at this level *)

and check_ultype_metatypevar env pt =
  (* Ensure that the kind here is consistent with the kind in the uft arg *)
  match Unionfind.find pt with  
      Flexible _
    | Rigid _ -> 
        (* kind not yet determined; to be fixed during unification *)
        `MetaTypeVar pt, None 
	| UncheckedRecursive (var, t) -> 
		(* Produced during desugaring, without having first being checked *)
		if (Typeenv.contains_rec_var var env) then 
		  `MetaTypeVar pt, None 
		else 
		  let env' = Typeenv.add_rec_var var env in 
		  let t', k = check_type env' t in
		  Unionfind.change pt (Recursive(var, t'));
		  `MetaTypeVar pt, Some k
		    
    (* tv has already been unified with a checked datatype. no check necessary *)		
	| Recursive (_, t) 
    | Body t -> 
		`MetaTypeVar pt, Some (Kinding.datatype_kind (Typeenv.alias_env env) t)

and check_ultype_function env arg mb ret =
  let (phantoms, name) = Fable.get_name_bindings arg.ftype in
  assert_msg (List.for_all (not -<- (flip Typeenv.contains) env) phantoms) 
    "Duplicate phantom name";
  assert_msg (match name with None -> true | Some n -> not (Typeenv.contains n env)) 
    "Duplicate name";
  let env' = Fable.add_phantom_bindings phantoms env in
  let arg = strip_name_bindings_utype arg in
  (* check FV(t)\dom(Omega) = phantoms *)
  let fv_arg = Fable.free_names env arg in
  assert_msg (List.for_all (fun n -> List.mem n phantoms) fv_arg) "Phantom name omitted";
  assert_msg (List.for_all (fun n -> List.mem n fv_arg) phantoms) "Extra phantom name";
  let arg', arg_k = check_type env' arg in
  let env'' = match name with
      None -> env'
    | Some name -> 
        (* Q: is it right to generalize all fvs here? A: No! *)
        Typeenv.add_normal_binding name ([], arg') env in 
  let ret', ret_k = check_type env'' ret in
  let mb', mb_k = check_type env'' mb in (* TODO: revise mailbox typing *)
  `Function(Fable.restore_bindings phantoms name arg', mb', ret'), 
    Some (Kinding.kind_join [arg_k;ret_k;mb_k])
        
and check_ultype_record env ((fsm, rv) as row) =
  (*         let row = flatten_row row in  *)
  let fnames = List.map fst (Fable.row_labels_inorder (fst row)) in 
  let check_one_field ((env, kind), fsm') fn =
    match StringMap.find fn fsm with
      | `Present ({ltype=lt; ftype=fq}) ->
          begin
            match Fable.get_name_bindings fq with
              | [], n ->
                  let lt',lt_k = check_ultype env lt in
                  let fq = Fable.strip_name_bindings fq in
                  let fq', fq_k = check_fq env lt' fq in
                  let field_type' = {ltype=lt'; ftype = fq'} in
                  let env' = match n with
                    | None -> env
                    | Some name -> Typeenv.add_normal_binding name ([], field_type') env in
                  let field_type' = Fable.restore_bindings [] n field_type' in
			      let kinds = match lt_k with 
			          None -> [fq_k;kind]
			        | Some lt_k -> [lt_k;fq_k;kind] in
                  (env', Kinding.kind_join kinds), StringMap.add fn (`Present field_type') fsm' 
              | _ -> raise (Bad_fable_type "Unexpected phantom bindings in a record type")
          end
      | `Absent -> (env, kind), StringMap.add fn `Absent fsm' in 
  let (_, kind), fsm' = List.fold_left check_one_field ((env, UKind), StringMap.empty) fnames in
  `Record(fsm',rv), Some kind

and check_ultype_variant env fsm rv =
  let fsm', kind = StringMap.fold 
    (fun key fs (fsm', kind) -> match fs with
	   | `Absent -> (StringMap.add key `Absent fsm', kind)
	   | `Present t ->
		   let t', k = check_type env t in
		   (StringMap.add key (`Present t') fsm', Kinding.kind_join [kind; k])
	) fsm (StringMap.empty, UKind) in
  let _ = match Unionfind.find rv with
	  ClosedRow
	| FlexibleRow _
	| RigidRow _
	| BodyRow _ -> ()
	| RecursiveRow _ -> raise (Bad_fable_type "Recursive row variables are not supported")
  in `Variant(fsm', rv), Some kind


and check_ultype_application env alias args =
  let args' = List.map (fst -<- (check_type env)) args in
  let assumption = Typeenv.lookup_alias (alias, args') env in
  let _ =  Instantiate.instantiate_alias alias (Typeenv.alias_env env) assumption args' in
  let ldt = `Application(alias, args') in
  (* needs to lookup alias etc. *)
  let kind = Kinding.datatype_kind (Typeenv.alias_env env) {ltype=ldt; ftype=`Empty} in
  ldt, Some kind
	    

and check_ultype env : u_ldatatype -> ldatatype * kind option = function
  | `Primitive p -> `Primitive p, Some UKind
  | `MetaTypeVar pt -> check_ultype_metatypevar env pt
  | `Function(arg, mb, ret) -> check_ultype_function env arg mb ret
  | `Record ((fsm, rv) as row) -> check_ultype_record env row
  | `Variant (fsm, rv) -> check_ultype_variant env fsm rv
  | `Application(alias, args) -> check_ultype_application env alias args
  | `Table (t1, t2) -> 
	  let t1', k1 = check_type env t1 in
	  let t2', k2 = check_type env t2 in
	  `Table(t1', t2'), Some (Kinding.kind_join [k1; k2])
  | `Not_typed -> raise (Bad_fable_type "Unexpected `Not_typed variant")
(*  | ult -> norm_ultype ult, Some UKind  (\* MetaTypeVars *\)  *)


and check_type : Typeenv.omega -> Types.u_datatype -> Types.datatype * FableType.kind =
  fun env {ltype=lt; ftype=fq} -> 	
    let env = Typeenv.set_phantom_phase env in
	ignore (FableType.well_formed_fq fq);
	match Fable.get_name_bindings fq with
	    [], None ->
	      let lt', kind' = check_ultype env lt in
	      let fq', kind = check_fq env lt' fq in
	      let k = match kind' with
		      None -> kind
		    | Some kind' -> Kinding.kind_join [kind; kind'] in
		  {ltype=lt'; ftype=fq'}, k
	  | _ -> raise (Bad_fable_type "Unexpected top-level name bindings")
          
          
and arg_var_mapping_notoplevel omega vlist =
  let (omega, vlist', vtypes) = 
    List.fold_left 
      (fun (omega, vlist, vtypes) -> function
		   Variable(name,`U pos) -> 
			 let t = fresh_type_variable () in
			 let omega' = Typeenv.add_normal_binding name ([], t) omega in
			 let v' = Variable(name, `T(pos, t, None)) in
			 (omega', v'::vlist, t::vtypes)
		 | HasType(Variable(name,`U pos), t, _) -> 
			 let t, _ = check_type omega t in
			 let omega' = Typeenv.add_normal_binding name ([], t) omega in
			 let v' = Variable(name, `T(pos, t, None)) in
			 (omega', v'::vlist, t::vtypes)
		 | _ -> failwith "Bad desugaring of `FunLit variables")
	  (omega, [], []) vlist in
  omega, rev vlist', make_tuple_type (List.rev vtypes), None, None
	    

and arg_var_mapping_noinline t omega vlist =
  let omega = match Fable.get_name_bindings t.ftype with
      [], _ -> omega 
    | phantoms, _ -> Fable.add_phantom_bindings phantoms omega in
  let t = concrete_type t in
  match t.ltype with
    | `Function({ltype =`Record ((fsm, _) as row); ftype = _} as arg, _, return_type) 
        when is_closed_row row -> 
        let fields = 
          StringMap.fold 
            (fun fieldname t accu -> match t with
                 `Present t -> (fieldname, t) :: accu
               | `Absent -> 
                   raise (Bad_fable_type 
                            "Fable type annotations are only permitted on positive records")
            ) fsm [] in
        let fields = rev fields in
        if (length vlist <> length fields) then
          raise (Bad_fable_type "Ascribed signature requires a different number of fields");
        let (omega, vlist', refinement_fsm) =
          List.fold_left2 
            (fun (omega, accu, fsm) (field_name, field_type) -> function
               | Variable (name, `U pos) -> 
                   let fsm' = StringMap.add field_name 
                     (Variable(name, `T(pos, field_type, None))) fsm in
                   let _, nopt = Fable.get_name_bindings field_type.ftype in
                   (* this could be just a warning; but it's most likely an error *)
                   let field_type', omega' = match nopt with  
                       Some n when n <> name -> 
                         raise (Bad_fable_type ("Term/type naming inconsitency : " 
                                                ^ n ^ " <> " ^name))
                     | Some _ -> 
                         let field_type = Fable.strip_name_bindings_type field_type in
                         let field_type = Subst.rename_bound_vars field_type in
                         (field_type,
                          Typeenv.add_noshadow_binding name ([], field_type) omega)
                     | _ -> 
                         let field_type = Subst.rename_bound_vars field_type in
                         (field_type, 
                          Typeenv.add_normal_binding name ([], field_type) omega) in
                   let vexp' =  Variable(name, `T(pos, field_type', None)) in
                   (omega', vexp'::accu, fsm')
               | HasType _ -> raise 
                   (Bad_fable_type 
                      "Cannot mix type signatures with inline type ascriptions")
            ) (omega, [], StringMap.empty) fields vlist in
        let omega =
          match Fable.get_name_bindings arg.ftype with
              phantoms, None -> 
                Fable.add_phantom_bindings phantoms omega
            | phantoms, Some n -> 
                let arg' = Fable.strip_name_bindings_type arg in
                let omega' = Typeenv.add_noshadow_binding n ([],arg') omega in
                let omega' = Fable.add_phantom_bindings phantoms omega' in 
                let namevar = Variable(n, `T(dummy_position, t, None)) in
                StringMap.fold 
                  (fun tupleindex (Variable(_, data) as arg) omega -> 
                     let refinement = (arg, Project(namevar, tupleindex, data)) in
                     Typeenv.add_refinement refinement omega
                  ) refinement_fsm omega'
                  (*  | _ -> omega *) in
        (omega, rev vlist', arg, Some return_type, Some t.ftype)
    | _ -> raise (Bad_fable_type 
                    ("Cannot yet handle ascribed type of the form: " 
                     ^ (DerivingSyntax.Show_datatype.show t)))


and arg_var_mapping omega vlist : datatype option 
    -> (omega * expression list * datatype * datatype option * FableType.fable_type option) 
    = function
      | None -> (* no top-level type annotation; but the annots may be inlined in the vars *)
          arg_var_mapping_notoplevel omega vlist
      | Some t -> (* No inline annotations permitted *)
          arg_var_mapping_noinline t omega vlist

and type_check_expression' : Typeenv.omega -> Syntax.untyped_expression -> expression =
  fun omega -> function
    | Constant (value, `U pos) -> Constant (value, `T (pos, constant_type value, None))
    | Variable (name, `U pos) -> typecheck_variable omega name pos
    | Abs (f, `U pos) -> typecheck_abs omega f pos
    | App (f, p, `U pos) -> typecheck_app omega f p pos
    | Apply (f, ps, `U pos) -> typecheck_apply omega f ps pos
    | Condition (if_, then_, else_, `U pos) -> 
        typecheck_condition omega if_ then_ else_ pos
    | Comparison (l, oper, r, `U pos) -> typecheck_comparison omega l oper r pos
    | Abstr (vars, body, `U pos) -> typecheck_abstr omega vars body pos
    | Let (var, value, body, `U pos) -> typecheck_let omega var value body pos
    | Rec (variables, body, `U pos) -> typecheck_rec omega variables body pos
    | Xml_node (tag, atts, cs, `U pos) -> typecheck_xml_node omega tag atts cs pos
    | Record_intro (bs, r, `U pos) -> typecheck_record_intro omega bs r pos
    | Record_selection (label, label_variable, variable, value, body, `U pos) ->
        typecheck_record_selection omega label label_variable variable value body pos
	| Record_unpack (fields, value, body, None, `U pos) -> (* open a dependent product *)
        typecheck_record_unpack omega fields value body pos
	| Record_pack (v, value, dt, body, `U pos) -> 
        typecheck_record_pack omega v value dt body pos
    | Project (expr, label, `U pos) ->
        typecheck_project omega expr label pos
    | Erase (value, label, `U pos) ->
        typecheck_erase omega value label pos
    | Variant_injection (label, value, `U pos) -> 
        typecheck_variant_injection omega label value pos
    | Variant_selection (value, c_label, c_var, c_body, var, body, `U pos) ->
        typecheck_variant_selection omega value c_label c_var c_body var body pos
    | Variant_selection_empty (value, `U pos) ->
        typecheck_variant_selection_empty omega value pos
    | Nil (`U pos) ->
	    let elt_t = annot_kindvar (fresh_type_variable()).ltype MKind in 
		Nil (`T (pos, annot_ukind (`Application ("List", [elt_t])), None))
    | List_of (elem, `U pos) -> typecheck_list_of omega elem pos
    | Concat (l, r, `U pos) -> typecheck_concat omega l r pos
    | For (expr, var, value, `U pos) ->
        typecheck_for omega expr var value pos
    | Call_cc(arg, `U pos) -> 
        (* TBD: Make this a primitive function (need to pass c.c. to prims). *)
        typecheck_call_cc omega arg pos
    | Database (params, `U pos) ->
        let params = type_check_expression omega params in
        unify_sh omega (type_of_expression params, db_descriptor_type);
        Database (params, `T (pos, annot_ukind (`Primitive `DB), None))
    | TableQuery (ths, query, `U pos) ->
        typecheck_tablequery omega ths query pos
    | TableHandle (db, tableName, tc, `U pos) ->
        typecheck_tablehandle omega db tableName tc pos
    | ViewHandle (db, viewName, iter, `U pos) ->
        typecheck_viewhandle omega db viewName iter pos
    | SortBy(expr, byExpr, `U pos) -> typecheck_sortby omega expr byExpr pos
    | Wrong (`U pos) -> Wrong(`T (pos, fresh_type_variable(), None))
    | HasType(expr, datatype, `U pos) -> typecheck_hastype omega expr datatype pos


(* Wraps type_check_expression above, showing debug messages, catching
   any errors, and doing some additional cleanup *)
and type_check_expression : Typeenv.omega -> Syntax.untyped_expression -> expression =
  fun omega expression -> 
    let exp = try 
      Debug.if_set show_typechecking 
        (fun () -> "Typechecking expression: " ^ string_of_expression expression);
      type_check_expression' omega expression
    with
	  | Bad_type_annotation(t,msg)-> 
          raise 
            (Type_error
               (position expression, 
                "Incompatible type annotation: expected " ^ msg
                ^ "; got " ^ string_of_datatype t))
	  | Instantiate.Type_application_error (_, k, s, kv) -> 
	      raise 
            (Type_error
               (position expression, 
                "Incompatible application of type constructor " ^ s ^
				  ": expected type of kind "^FableType.Show_kind.show kv^
				  "; got "^FableType.Show_kind.show k))
	  | FableType.Bad_fable_type msg
	  | Typeenv.Shadow_variable msg
	  | Bad_fable_type msg
      | Unify_failure msg
      | UndefinedVariable msg
      | UndefinedAlias msg ->
          raise (Type_error(position expression, msg))
    in 
    let exp' = match Typeenv.get_type_annotation omega with
	    None -> exp
	  | Some annot_typ -> 
	      let inferred_typ = Syntax.node_datatype exp in
	      unify_nr [] omega (Some exp) true (inferred_typ, annot_typ);
	      Syntax.set_node_datatype (exp, annot_typ) in
	if Settings.get_value Basicsettings.unsafe_client_mode then 
	  exp'
	else
	  let k = Kinding.datatype_kind (Typeenv.alias_env omega) (Syntax.node_datatype exp') in
	  match Typeenv.get_context omega, k with 
		  `Client, MKind -> 
		    raise (Type_error
                     (position exp',
                      "Client code cannot manipulate M-kinded datatypes"))
	    | _ -> exp'
	        (* end "type_check" *)
		    
and unify_sh omega = unify_nr [] omega None false
and unify_rows_sh omega rows = ignore (Unify.unify_rows omega false rows)
and fannot omega lt = 
  let t = Types.def_fable_annot lt in
  let t', _ = check_type omega t in
  t'

and typecheck_variable omega name pos =
  (* TODO: BJC: this was going off in policy code, and I didn't have
     time to debug it. *)
  (* if ((name="unlabel" || name="relabel") && not (Typeenv.check_context omega `Policy)) then *)
  (*   raise (Bad_fable_type ("Illegal usage of " ^name^ " in non-policy code")) *)
  (* else *)
  let t = instantiate omega name in
  let label = match lookup_location name omega with
	| `Policy -> Some "policy"
	| _ -> None in
  Variable (name, `T (pos, t, label))

and typecheck_abs omega f pos =
  (* TODO: hmmm ... can't understand why this construct is of any use. *)
  (* links> var z = abs fun (x) { x };; *)
  (* z = abs fun : *(|a) -> (|a) *)
  (* links> z (5);; *)
  (* (1=5) : (1:Int) *)
  let omega = Typeenv.clear_type_annotation omega in
  let f = type_check_expression omega f in
  let arg_type = fannot omega (`Record (make_empty_open_row ())) in
  let result_type = fresh_type_variable () in
  let mb_type = fresh_type_variable () in
  let f_ltype = `Function (make_tuple_type [arg_type], 
                           mb_type, 
                           result_type) in
  unify_sh omega (type_of_expression f, annot_ukind f_ltype); (* if we're applying f, then it had better not be labeled *)
  let etype =  `Function (arg_type, mb_type, result_type) in
  Abs (f, `T (pos, annot_ukind etype, None))

and typecheck_app omega f p pos =
  (* Question: Again ... not sure how this differs from Apply or what its purpose is *)
  let omega = Typeenv.clear_type_annotation omega in
  let f = type_check_expression omega f
  and p = type_check_expression omega p 
  and result_type = fresh_type_variable ()
  and mb_type = instantiate omega "_MAILBOX_" 
  in
  (* not really necessary, but might catch some errors *) 
  unify_sh omega (type_of_expression p, def_fable_annot (`Record (make_empty_open_row ())));
  unify_sh omega  (type_of_expression f,
                   annot_ukind (`Function (type_of_expression p, mb_type, result_type)));
  App (f, p, `T (pos, result_type, None))


and typecheck_call_cc omega arg pos =
  let arg = type_check_expression omega arg in
  let contrettype = fresh_type_variable () in
  let anytype = fresh_type_variable () in
  let mailboxtype = instantiate omega "_MAILBOX_" in
  let conttype =
    annot_ukind (`Function (make_tuple_type [contrettype], mailboxtype, anytype)) in
  let argtype = 
    annot_ukind (`Function (make_tuple_type [conttype], mailboxtype, contrettype)) in
  unify_sh omega (argtype, type_of_expression arg);
  Call_cc(arg, `T (pos, contrettype, None))
    
and typecheck_condition omega if_ then_ else_ pos =
  let if_ = type_check_expression (Typeenv.clear_type_annotation omega) if_ in
  let _ = 
    try unify_sh omega (type_of_expression if_, bool_type ())
    with Unify_failure _ -> 
      mistype
        (pos_of_expression if_)
        (if_, type_of_expression if_)
        (fannot omega (`Primitive `Bool)) in
  let then_ = type_check_expression omega then_ in
  let else_ = type_check_expression omega else_ in
  unify_sh omega (type_of_expression then_, type_of_expression else_);
  let result_type = type_of_expression else_ in
  Condition (if_, then_, else_, `T (pos, result_type, None)) 
	
and typecheck_comparison omega l oper r pos =
  let omega = Typeenv.clear_type_annotation omega in
  let l = type_check_expression omega l in
  let r = type_check_expression omega r in
  unify_sh omega (type_of_expression l, type_of_expression r);
  Comparison (l, oper, r, `T (pos, bool_type (), None))
	
and typecheck_abstr omega variables body pos =
  let mb_type = fresh_type_variable () in
  let (body_omega, variables', arg_type, rettype_opt, ftype_opt) 
      = arg_var_mapping omega variables (Typeenv.get_type_annotation omega) in
  let body_omega = Typeenv.add_normal_binding "_MAILBOX_" ([], mb_type) body_omega in
  let body = type_check_expression (Typeenv.set_type_annotation_opt body_omega rettype_opt) body in
  let type' = `Function (arg_type, mb_type, type_of_expression body) in
  let typ = match ftype_opt with
	  Some fq -> {ltype = type'; ftype= fq}
	| _ -> annot_ukind type' in
  Abstr (variables', body, `T (pos, typ, None))
    
and typecheck_let omega variable value body pos =
  let value = type_check_expression (Typeenv.clear_type_annotation omega) value in
  let vtype = (if is_value value then (generalise omega (type_of_expression value))
               else ([], type_of_expression value)) in
  let omega' = Typeenv.add_normal_binding variable vtype omega in
  let body = type_check_expression omega' body in        
  check_no_escaping_names omega (type_of_expression body);
  Let (variable, value, body, `T (pos, type_of_expression body, None))

and typecheck_rec omega variables body pos =
  let annot = Typeenv.get_type_annotation omega in
  let best_omega, vars = 
    type_check_mutually (Typeenv.clear_type_annotation omega) variables in
  let body = type_check_expression (Typeenv.set_type_annotation_opt best_omega annot) body in
  Rec (vars, body, `T (pos, type_of_expression body, None))

and typecheck_xml_node omega tag atts cs pos =
  let separate = partition (is_special -<- fst) in
  let (special_attrs, nonspecial_attrs) = separate atts in
  (* "event" is always in scope for the event handlers *)
  let ev_type = fannot omega (`Application ("Event", [])) in
  let attr_omega = Typeenv.add_normal_binding "event"  ([], ev_type) omega in
  (* extend the env with each l:name bound variable *)
  let attr_omega = Typeenv.add_normal_binding "_MAILBOX_" ([], fresh_type_variable ()) attr_omega in
  let special_attrs = map (fun (name, expr) -> (name, type_check_expression attr_omega expr)) special_attrs in
  (* Check that the bound expressions have type 
     <strike>XML</strike> unit. *)
  let contents = map (type_check_expression omega) cs in
  let omega = Typeenv.clear_type_annotation omega in
  let nonspecial_attrs = map (fun (k,v) -> k, type_check_expression omega v) nonspecial_attrs in
  let attr_type = string_type () in
  (* force contents to be XML, attrs to be strings *)
  List.iter (fun node -> unify_sh omega  (type_of_expression node, xml_type ())) contents;
  List.iter (fun (_, node) -> unify_sh omega (type_of_expression node, attr_type)) nonspecial_attrs;
  let trimmed_node =
    Xml_node (tag, 
              nonspecial_attrs,         (* +--> up here I mean *)
              contents,                 (* | *)
              `T (pos, xml_type (), None))
  in                                    (* | *)
  (* could just tack these on up there ----^ *)
  add_attrs special_attrs trimmed_node

and typecheck_tablequery omega ths query pos =
  let row =
    (List.fold_right
       (fun col env -> 
          match col with 
            | Left col -> StringMap.add col.Query.name (`Present col.Query.col_type) env
            | Right _ -> env)
       query.Query.result_cols StringMap.empty, Unionfind.fresh ClosedRow) in
  let datatype =  `Application ("List", [annot_ukind (`Record row)]) in
  let rrow = make_empty_open_row () in
  let wrow = make_empty_open_row () in
  let ths = alistmap (type_check_expression (Typeenv.clear_type_annotation omega)) ths
  in
  Utility.for_each ths 
    (fun (_, th) -> 
       unify_sh omega (type_of_expression th,
                       annot_ukind (`Table (annot_ukind (`Record rrow), 
                                            annot_ukind (`Record wrow)))));
  unify_rows_sh omega (row, rrow);
  TableQuery (ths, query, `T (pos, annot_ukind datatype, None))

and typecheck_tablehandle omega db tableName tc pos =
  let (readtype,_) = check_type omega tc.readtype in
  let (writetype,_) = check_type omega tc.writetype in
  let check_marshall_functions out (fieldname, e) = 
	(try 
	   let _ = List.assoc fieldname out in 
	   raise (Bad_fable_type ("Repeated field constraint for field " ^ fieldname))
	 with 
		 _ -> ());
	let rftype = match readtype.ltype with
	  | `Record (rfsm, _) ->  
		  begin
			match (StringMap.lookup fieldname rfsm) with 
			    None
			  | Some `Absent -> raise 
                  (Bad_fable_type 
                     ("Marshalling constraint refers to a non-existent field : " ^fieldname))
			  | Some (`Present t) -> t
		  end
	  | _ -> raise (Unify_failure "Expected record types for a table row") in
	let mk_function_type arg ret =
	  let arg = Fable.strip_name_bindings_type arg in
	  let ret = Fable.strip_name_bindings_type ret in
	  let mb = fresh_type_variable () in
	  {ltype = `Function (make_tuple_type [arg], mb, ret); ftype = `Kind UKind} in
	let mtype = make_tuple_type [mk_function_type rftype (string_type());
					             mk_function_type (string_type()) rftype] in
	let e = type_check_expression omega e in 
 	unify_sh omega (mtype, type_of_expression e);
	(fieldname, e)::out in
  let marshallby = List.fold_left check_marshall_functions [] tc.marshallby in
  let datatype =  `Table (readtype , writetype) in
  let db = type_check_expression omega db in
  let tableName = type_check_expression omega tableName in
  unify_sh omega  (type_of_expression db, annot_ukind (`Primitive `DB));
  unify_sh omega (type_of_expression tableName, string_type ()); 
  TableHandle (db, tableName, {readtype=readtype;
                               writetype=writetype;
                               marshallby=marshallby;
                               primarykey=tc.primarykey},
               `T (pos, annot_ukind datatype, None))

and typecheck_viewhandle omega db name iter pos =
  let db' = type_check_expression omega db in
  let name' = type_check_expression omega name in
  unify_sh omega  (type_of_expression db', annot_ukind (`Primitive `DB));
  unify_sh omega (type_of_expression name', string_type ()); 
  let iter' = type_check_expression omega iter in
  let readtype = 
    match (type_of_expression iter').ltype with 
      | `Application ("List", [t]) -> t
      | _ -> failwith "typecheck_viewhandle"
  in
  let writetype = unit_type () in
  let result_type = `Table (readtype, writetype) in
  ViewHandle (db', name', iter',
              `T (pos, annot_ukind result_type, None))

and typecheck_sortby omega expr byExpr pos =
  (* FIXME: the byExpr is typed freely as yet. It could have any
     orderable type, of which there are at least several. How to
     resolve this? Would kill for type classes. *)
  let byExpr = type_check_expression omega byExpr in
  let expr = type_check_expression omega expr in
  SortBy(expr, byExpr, `T (pos, type_of_expression expr, None))

and typecheck_hastype omega expr datatype pos =
  let datatype,_ = check_type omega datatype in
  free_alias_check omega datatype;
  let expr = type_check_expression (Typeenv.set_type_annotation omega datatype) expr in
  let expr_type = type_of_expression expr in
  begin
    try unify_sh omega (expr_type, datatype);
    with Unify_failure msg -> 
      let _,_,src = position expr in
	  type_mismatch
        ~expected:datatype
        ~inferred:expr_type
        ~src:src
        ~pos:pos msg
  end;
  HasType(expr, datatype, `T (pos, datatype, None))

and typecheck_list_of omega elem pos =
  let omega = match Typeenv.get_type_annotation omega with
	  None -> omega
	| Some t -> 
		let rec get_elt_type t = match t.ltype with
		  | `Application("List", [elt_t]) -> elt_t
		  | `Application(alias, args) -> 
			  let vars, def = Typeenv.lookup_alias (alias, args) omega in
			  let t' = Instantiate.instantiate_alias alias (Typeenv.alias_env omega) (vars, def) args in
			  get_elt_type t'
		  | _ -> raise (Bad_type_annotation (t, "List")) in
		let elt_t = get_elt_type t in
		Typeenv.set_type_annotation omega elt_t
  in
  let elem = type_check_expression (Typeenv.clear_type_annotation omega) elem in
  List_of (elem,
           `T (pos, annot_ukind (`Application ("List", [type_of_expression elem])), 
               None))

and typecheck_concat omega l r pos =
  let tvar = annot_kindvar (fresh_type_variable()).ltype MKind in 
  let l = type_check_expression omega l in
  unify_sh omega (type_of_expression l, annot_ukind (`Application ("List", [tvar])));
  let r = type_check_expression omega r in
  unify_sh omega (type_of_expression r, type_of_expression l);
  let type' = `Application ("List", [tvar]) in
  Concat (l, r, `T (pos, annot_ukind type', None))



and typecheck_for omega expr var value pos =
  (* 	      print_string ("List comprehension: " ^(DerivingSyntax.Show_untyped_expression.show expression)^"\n"); *)
  let value_tvar = fresh_type_variable () in
  let expr_tvar = fresh_type_variable () in
  let omega = match Typeenv.get_type_annotation omega with
	| None -> omega 
	| Some t -> match t.ltype with
		| `Application("List", [elt_t]) -> 
			Typeenv.set_type_annotation omega elt_t
		| _ -> raise (Bad_type_annotation (t, "List")) in
  let value = type_check_expression (Typeenv.clear_type_annotation omega) value in
  unify_sh omega (type_of_expression value, 
                  def_fable_annot (`Application ("List", [value_tvar])));
  let expr_omega = Typeenv.add_normal_binding var  ([], value_tvar) omega in
  let expr = type_check_expression (Typeenv.clear_type_annotation expr_omega) expr in
  unify_sh omega (type_of_expression expr, annot_ukind (`Application ("List", [expr_tvar])));
  let type' = type_of_expression expr in
  check_no_escaping_names omega type';
  For (expr, var, value, `T (pos, type', None))

and typecheck_apply omega f ps pos =
  let omega = Typeenv.clear_type_annotation omega in
  let f = type_check_expression omega f in
  let ps,ps' = match f, ps with 
	  Variable("relabel", _), [x; label] -> 
		let x' = type_check_expression omega x in
		let label' = type_check_expression (Typeenv.set_phantom_phase omega) label in
		([x'; label'], 
         (* hacky rewrite to avoid passing phantom labels at runtime *)
		 [x'; unit_expression (Syntax.expression_data label')])
	| _ -> 
		let ps = List.map (type_check_expression omega) ps in
		ps, ps in
  let mb_type = instantiate omega "_MAILBOX_" in
  let f_type = concrete_type (type_of_expression f) in
  let arg_type = make_tuple_type (List.map type_of_expression ps) in
  let return_type =
    try
      match f_type.ltype with
        | `Function (formal, formal_mb, ret) ->
    	    if Fable.kind_qual f_type.ftype <> UKind then
    	      raise (Bad_fable_type "Attempt to apply a labeled function")
    		    (* mistyped_application pos (f, f_type)  *)
                (* (ps, List.map type_of_expression ps) (Some mb_type) *)
    	    else
    	      let phantoms, nopt = Fable.get_name_bindings formal.ftype in
    	      let formal = Fable.strip_name_bindings_type formal in
    	      let arg = Syntax.tuple_expr (`T(pos, arg_type, None)) ps in
    	      let sigma = Unify.unify phantoms omega (Some arg) true (arg_type, formal) in
    	      let sigma = match nopt with
    		      None -> sigma
    		    | Some n -> Subst.extend (n, arg) sigma in
    	      let formal_mb = Subst.apply sigma formal_mb in
    	      let ret = Subst.apply sigma ret in
    	      unify_sh omega (mb_type, formal_mb);
    	      ret
        | _ -> (* must infer f's type... which means it can't have any fable annots
    		      so just unify with the expected type *)
    	    let return_type = fresh_type_variable () in
    	    unify_sh omega (annot_ukind (`Function(arg_type, mb_type, return_type)), f_type);
    	    return_type
    with Unify_failure _ ->
      mistyped_application pos (f, f_type) (ps, List.map type_of_expression ps) (Some mb_type)
  in
  Apply (f, ps', `T (pos, return_type, None))

and typecheck_record_intro omega bs r pos =
  let omega = Typeenv.clear_type_annotation omega in
  let bs, field_env, absent_field_env =
    StringMap.fold 
      (fun label e (bs, field_env, absent_field_env)  ->
         let e = type_check_expression omega e in
         let t = type_of_expression e in
         (StringMap.add label e bs,
          StringMap.add label (`Present t) field_env,
          StringMap.add label `Absent absent_field_env))
      bs (StringMap.empty, StringMap.empty, StringMap.empty) in
  let dresult_type = annot_ukind (`Record (field_env, Unionfind.fresh ClosedRow)) in
  begin
    match r with
      | None ->
          Record_intro (bs, None, `T (pos, dresult_type, None))
      | Some r ->
          let r = type_check_expression omega r in
          let rtype = type_of_expression r in
          (* make sure rtype is a record type! *)
          
          unify_sh omega (rtype, 
                          annot_ukind (`Record (absent_field_env, fresh_row_variable())));
          
          let (rfield_env, rrow_var), _ = unwrap_row (extract_row omega rtype) in
          
          (* attempt to extend field_env with the labels from rfield_env
             i.e. all the labels belonging to the record r
          *)
          let field_env' =
            StringMap.fold 
              (fun label t field_env' ->
                 match t with
                   | `Absent ->
                       if StringMap.mem label field_env then
                         field_env'
                       else
                         StringMap.add label `Absent field_env'
                   | `Present _ ->
                       if StringMap.mem label field_env then
                         failwith ("Could not extend record "^string_of_expression r
                                   ^" (of type "^
                                     string_of_datatype rtype^") with "^
                                     string_of_expression
                                     (Record_intro (bs, None, `T (pos, dresult_type, None)))^
                                     " (of type"^string_of_datatype dresult_type ^
                                     ") because the labels overlap")
                       else
                         StringMap.add label t field_env') rfield_env field_env in
          Record_intro (bs, Some r, `T (pos, annot_ukind 
                                          (`Record (field_env', rrow_var)), None))
  end

and typecheck_record_selection omega label label_variable variable value body pos =
  let value = type_check_expression (Typeenv.clear_type_annotation omega) value in
  (* can only project out of an unlabeled record *)
  let label_variable_type = annot_kindvar (fresh_type_variable ()).ltype MKind in
  unify_sh omega (type_of_expression value, 
                  annot_ukind (`Record (make_singleton_open_row 
                                          (label, `Present (label_variable_type)))));
  let value_row = extract_row omega (type_of_expression value) in
  (match Fable.free_names omega label_variable_type with 
     | [] -> ()
     | _::_ -> raise (Bad_fable_type "Illegal projection from a dependent product; use \"unpack e1 as e2;\" instead"));
  let body_omega = Typeenv.add_normal_binding label_variable 
    ([], label_variable_type) omega in
  let variable_type = annot_ukind (`Record (row_with (label, `Absent) value_row)) in
  let body_omega = Typeenv.add_normal_binding variable ([], variable_type) body_omega in
  let refinement = 
    let fsm = StringMap.add label 
      (Variable(label_variable, `T(pos, label_variable_type, None))) StringMap.empty in
    Record_intro(fsm, Some (Variable(variable, `T(pos, variable_type, None))), 
                 `T(pos, (type_of_expression value), None)) in
  let body_omega = Typeenv.add_refinement (value, refinement) body_omega in
  let body = type_check_expression body_omega body in
  let body_type = type_of_expression body in
  check_no_escaping_names omega body_type;
  Record_selection (label, label_variable, variable, value, body, `T (pos, body_type, None))
    
and typecheck_record_unpack omega fields value body pos = (* open a dependent product *)
  let value = type_check_expression (Typeenv.clear_type_annotation omega) value in 
  let body, ftypes, fields = 
	let value_type = concrete_type (type_of_expression value) in 
	if not (Fable.sub_kind ((Fable.kind_qual value_type.ftype), UKind)) then 
	  raise (Bad_fable_type "Attempt to open a labeled record");
    (* type must be constrained already, since it requires an annotation *)
	match extract_row_opt omega value_type with
		Some row -> 
		  let (field_env, _), _ = unwrap_row row in
          (* List.sort (fun (k1,_) (k2,_) -> compare k1 k2)
             (StringMap.to_alist field_env) in *)
		  let row_fields = Fable.row_labels_inorder field_env in
		  let fields = 
            List.fold_right 
              (fun (k,_) a -> (* rearrange fields in binding order *)
			     let v = try List.assoc k fields
                 with Not_found -> Utility.gensym()
                 in
				 (k,v)::a) row_fields [] in
		  let folder (omega, sigma, vtypes) (k1, var) (k2, spec) =
			if (k1 <> k2) then 
			  raise (Bad_fable_type "Missing field in open record");
			match spec with 
			    `Present t -> 
				  begin
				    match Fable.get_name_bindings t.ftype with
                        (* duplicate name check already done in the pattern compiler *)
				        [], None ->   
					      let t' = Subst.apply sigma t in
					      (Typeenv.add_normal_binding var ([],t') omega, 
                           sigma, 
                           (var, t')::vtypes)
				      | [], Some n -> 
					      let t' = Fable.strip_name_bindings_type t in
					      let t' = Subst.apply sigma t' in
					      let omega' = Typeenv.add_noshadow_binding var ([], t') omega in
					      let sigma' = Subst.extend 
                            (n, Variable(var, `T(dummy_position, t', None))) sigma in
					      omega', sigma', (var, t')::vtypes
                      | _ -> raise Impos
                  end
              | `Absent -> 
                  (* hmm ... maybe ok if k1 <> k2? *) 
                  raise (Bad_fable_type "Cannot open a record with absent fields") 
          in
          let omega', _, ftypes = 
            List.fold_left2 folder (omega, Subst.empty, []) fields row_fields in
          type_check_expression omega' body, ftypes, fields
      | _ -> raise 
          (Bad_fable_type 
             ("The open construct is reserved for dependent records; used here with " ^
                (DerivingSyntax.Show_datatype.show value_type)))
  in
  let collapsed = 
    Record_unpack(fields, value, body, None, `T(pos, type_of_expression body, None)) in
  (* desugar this for the interpreter *)
  let expansion = expand_record_open collapsed (List.rev ftypes) in
  check_no_escaping_names omega (type_of_expression body);
  Record_unpack(fields, value, body, Some expansion, `T(pos, type_of_expression body, None)) 

and typecheck_record_pack omega v value dt body pos =
  let dt',_ = check_type omega dt in
  let value' = type_check_expression (Typeenv.clear_type_annotation omega) value in
  unify_nr [] omega (Some value') false (type_of_expression value', dt');
  let omega' = Typeenv.add_normal_binding v ([], dt') omega in
  let body' = type_check_expression omega' body in
  check_no_escaping_names omega (type_of_expression body');
  Record_pack(v, value', dt', body', `T(pos, type_of_expression body', None))
	
and typecheck_project omega expr label pos =
  let expr = type_check_expression (Typeenv.clear_type_annotation omega) expr in
  let label_variable_type = annot_kindvar (fresh_type_variable ()).ltype MKind in
  unify_sh omega (type_of_expression expr, annot_ukind (`Record (make_singleton_open_row (label, `Present (label_variable_type)))));
  if (Fable.free_names omega label_variable_type <> []) then 
	raise (Bad_fable_type "Illegal projection from a dependent product; use \"unpack e1 as e2;\" instead");
  Project (expr, label, `T (pos, label_variable_type, None))
	
and typecheck_erase omega value label pos =
  (* Unify value type with an unlabeled record type *)
  let value = type_check_expression (Typeenv.clear_type_annotation omega) value in
  let value_row = extract_row omega (type_of_expression value) in
  Erase (value, label, 
         `T (pos, annot_ukind (`Record (row_with (label, `Absent) value_row)), None))

and typecheck_variant_injection omega label value pos =
  let omega = match Typeenv.get_type_annotation omega with 
	  None -> omega
	| Some t -> 
		match (extract_row_opt omega t) with
			None -> raise (Bad_type_annotation (t, "row"))
		  | Some ((fsm, _) as row)-> 
			  try 
			    match StringMap.find label fsm with 
				    `Present t' -> Typeenv.set_type_annotation omega t'
			      | _ -> raise (Bad_type_annotation (t, "constructor " ^label))
			  with
			      Not_found -> 
				    if (is_closed_row row) then 
				      raise (Bad_type_annotation (t, "constructor " ^label))
				    else
				      Typeenv.clear_type_annotation omega in
  let value = type_check_expression omega value in
  let vtype = type_of_expression value in
  let type' = `Variant (make_singleton_open_row (label, `Present vtype)) in
  let maybe_label = match infer_label_type omega vtype with
	  `Not_label -> `Kind UKind
	| `General -> `Label(`Nothing, `Kind UKind)
	| `Specific -> 
		let e = Variant_injection(label, value, `T(pos, annot_ukind type', None)) in
		let pt = Unionfind.fresh (`Something e) in
		let kv = Fable.fresh_kind_variable MKind in
		`Label(`Inferred pt, `KindVar kv) in
  Variant_injection (label, value, `T (pos, Types.fable_annot type' maybe_label, None))
	
and typecheck_variant_selection omega value case_label case_var case_body variable body pos =
  let value = type_check_expression (Typeenv.clear_type_annotation omega) value in
  let value_type = type_of_expression value in
  let case_var_type = annot_kindvar (fresh_type_variable()).ltype MKind in
  let body_row = make_empty_open_row () in
  let variant_type = `Variant (row_with (case_label, `Present case_var_type) body_row) in
  unify_sh omega (value_type, annot_kindvar variant_type UKind); 
  let case_body_omega = Typeenv.add_normal_binding case_var ([], case_var_type) omega in
  let arg_expression = match case_body with 
	  Let("_", _, _, _) -> Syntax.unit_expression (`T (dummy_position, Types.unit_type(), None)) (* compensate for sugar.ml unit hack *)
	| _ -> Variable(case_var, `T(pos,case_var_type,None)) in
  let refinement = Variant_injection(case_label, arg_expression, 
						             `T(pos, value_type, None)) in
  let case_body_omega = Typeenv.add_refinement (value, refinement) case_body_omega in
  let case_body = type_check_expression case_body_omega case_body in
  check_no_escaping_names omega (type_of_expression case_body);
  (*
    We take advantage of absence information to give a more refined type when
    the variant does not match the label i.e. inside 'body'.

    This allows us to type functions such as the following which fail to
    typecheck in OCaml!

    fun f(x) {
    switch x {
    case A(B) -> B;
    case A(y) -> A(f(y));
    }
    }
    
    On the right-hand-side of the second case y is assigned the type:
    [|B - | c|]
    which unifies with the argument to f whose type is:
    [|A:[|B:() | c|] |]
    as opposed to:
    [|B:() | c|]
    which clearly doesn't!
  *)
  let body_var_type = annot_ukind (`Variant (row_with (case_label, `Absent) body_row)) in
  let body_omega = Typeenv.add_normal_binding variable ([], body_var_type) omega in
  let body = type_check_expression body_omega body in
  (* let case_type = type_of_expression case_body in *)
  let body_type = type_of_expression body in
  (* (case_type, body_type); *)
  check_no_escaping_names omega body_type;
  Variant_selection (value, case_label, case_var, case_body, variable, body, 
                     `T (pos, body_type, None))
    

and typecheck_variant_selection_empty omega value pos =
  let value = type_check_expression (Typeenv.clear_type_annotation omega) value in
  let new_row_type = annot_ukind (`Variant (make_empty_closed_row())) in
  unify_sh omega (new_row_type, type_of_expression value);
  Variant_selection_empty (value, `T (pos, fresh_type_variable (), None))



(** type_check_mutually
    Companion to "type_check_expression"; does mutual type-inference

    [QUESTIONS]
    - what are the constraints on the definitions?
    - do the functions have to be recursive?
*)
and type_check_mutually omega (* (env, alias_env) *) 
    (defns : (string * Syntax.untyped_expression * Types.u_datatype option) list) =
  let var_env = 
    (map (fun (name, _, t) ->
            match t with
              | Some t ->
                  (* print_string ("Ascribed u_type: " ^  *)
                  (*                 (DerivingSyntax.Show_u_datatype.show t) ^ "\n"); *)
                  (* flush stdout; *)
			      let t,_ = check_type omega t in 
                  (* print_string ("Ascribed type: "  *)
                  (*     ^ (DerivingSyntax.Show_datatype.show t) ^ "\n"); *)
                  (* flush stdout; *)
 			      let assumption = generalise omega t in
				  (name, assumption)
              | None -> (name, ([], fresh_type_variable ())))
       defns) in
  let inner_omega = List.fold_left 
    (fun omega (name, assumption) -> 
       add_normal_binding name assumption omega) omega var_env in
  let type_check result (name, expr, u_topt) =
    let u_topt' = opt_app ((fun (x,_) -> Some x) -<- check_type omega) None u_topt in
    let inner_omega = Utility.opt_app 
      (Typeenv.set_type_annotation inner_omega) inner_omega u_topt' in
    let expr = type_check_expression inner_omega expr in
    let t' = type_of_expression expr in
    match t'.ltype with
      | `Function _ ->
          let t'' = snd (assoc name var_env) in
          unify_nr [] inner_omega (Some expr) false (t', t'');
          (* print_string ("Inferred type for abstraction " ^name^ ":"  *)
          (*               ^Types.string_of_datatype t'^"\n"); *)
          (* [HACK]
             
             This allows aliases to persist providing no
             mailbox types have been instantiated.
          *)
          let expr = 
            if (Typeenv.is_mailbox_free inner_omega t') then
              set_node_datatype (expr, t'')
            else
              expr
          in
          (name, expr, u_topt') :: result
      | _ -> Errors.letrec_nonfunction (pos_of_expression expr) (expr, t') in
  
  let defns = fold_left type_check [] defns in
  let defns = rev defns in
  
  let omega' = List.fold_left
    (fun omega (name, value, _) -> 
       let assumption = 
         generalise omega (type_of_expression value) in
       Typeenv.add_normal_binding name assumption omega) omega defns
  in omega', defns     
      
let mutually_type_defs
    (env : Typeenv.omega)
    (defs : (string * Syntax.untyped_expression * 'a option) list)
    : (Typeenv.omega * (string * expression * 'c) list) =
  let new_env, new_defs = type_check_mutually env defs
  in (new_env, new_defs)

let type_expression : Typeenv.omega -> Syntax.untyped_expression 
  -> (Typeenv.omega * expression) =
  fun typing_env exp ->
    typing_env, type_check_expression typing_env exp

let type_definition : Typeenv.omega -> untyped_definition -> (Typeenv.omega * definition) =
  fun omega (*env, alias_env*) def ->
    let omega', def' =
      match def with
        | Module (name, `U pos) -> 
            omega, Module (name, `T (pos, unit_type(), None))
        | Define (variable, value, loc, `U pos) ->
            let value = type_check_expression (Typeenv.set_context omega loc) value in
            let value_type = 
              if is_value value then begin
                let dtype = type_of_expression value in
                generalise omega dtype 
              end
              else [], type_of_expression value in
            let omega' = Typeenv.add_normal_binding ~location:loc variable value_type omega in
              omega', Define (variable, value, loc, `T (pos, type_of_expression value, None))
        | Alias (typename, vars, u_datatype, `U pos) ->
	    begin
	      try 
		let datatype,_ = check_type omega u_datatype in
		let omega' = Typeenv.register_alias (typename, vars, datatype) omega in
		  omega',
		Alias (typename, vars, datatype, 
               `T (pos, annot_ukind (`Record (make_empty_closed_row ())), None))
	      with
		  Instantiate.Type_application_error (_, k, s, kv) -> 
		    raise (Type_error(pos, "Incompatible application of type constructor " ^ s ^
					": expected type of kind "^FableType.Show_kind.show kv^
					"; got "^FableType.Show_kind.show k))
	    end
        | Alien (language, name, (q, u_t),  `U pos)  ->
	    let t,_ = check_type omega u_t in
	    let assumption = (q, t) in
            let omega' = Typeenv.add_normal_binding name assumption omega in
              omega', Alien (language, name, assumption, `T (pos, snd assumption, None))
    in
      omega', def'
	
        
let type_program : Typeenv.omega -> untyped_program -> (Typeenv.omega * program) =
  fun typing_env (Program (defs, body)) ->
    let type_group (typing_env, typed_defs) : untyped_definition list ->
      Typeenv.omega * definition list = function
        | [x] -> (* A single node *)
            let typing_env, def = type_definition typing_env x in 
              typing_env, typed_defs @ [def]
        | xs  -> (* A group of potentially mutually-recursive definitions *)
            let defparts = map (fun (Define x) -> x) xs in
            let defbodies = map (fun (name, Rec ([(_, expr, t)], _, _), _, _) -> 
                                   name, expr, t) defparts in
            let (typing_env : Typeenv.omega), defs =
              mutually_type_defs typing_env defbodies in
            let defs = (map2 (fun (name, _, location, _) (_, expr, _) -> 
                                Define(name, expr, location, expression_data expr))
                          defparts defs) in
              typing_env, typed_defs @ defs

    and bothdefs l r = match l, r with
      | Define (_, Rec _, _, _), Define (_, Rec _, _, _) -> true
      | _ ->  false
    in
    let def_seqs = groupBy bothdefs defs in
    let mutrec_groups = (Callgraph.refine_def_groups def_seqs) in
    let typing_env, defs =
      fold_left type_group (typing_env, []) mutrec_groups in
    let ctx = Typeenv.get_context typing_env in
    let typing_env, body = type_expression (Typeenv.set_context typing_env `Client) body in
      (Typeenv.set_context typing_env ctx), (Program (defs, body))

(* Check for duplicate top-level definitions.  This probably shouldn't
   appear in the type inference module.

   (Duplicate top-level definitions are simply not allowed.)

   In future we should probably allow duplicate top-level definitions, but
   only if we implement the correct semantics!
*)
let check_for_duplicate_defs 
    omega
    (defs :  untyped_definition list) =
  let check (env, defined) = function
    | Define (name, _, _, `U position) when StringMap.mem name defined ->
        (env, StringMap.add name (position :: StringMap.find name defined) defined)
    | Define (name, _, _, `U position) when StringSet.mem name env ->
        (env, StringMap.add name [position] defined)
    | Define (name, _, _, _) ->
        (StringSet.add name env, defined)
    | _ -> 
        (env, defined) in 
  let env = Typeenv.all_bound_names omega in 
  let _, duplicates = List.fold_left check (env,StringMap.empty) defs in
    if not (StringMap.is_empty duplicates) then
      raise (Errors.MultiplyDefinedToplevelNames duplicates)

(* Given a datatype that contains no fable annotations other than 
   default typevariable kind annotations, this function walks over the type
   and massages the fable qualifiers into (Kind of tft * kind) qualifiers.
   This is used to initialize the type environment with the types of library functions *)
        

(* [HACKS] *)
(* two pass typing: yuck! *)
let type_program omega (Program (defs, _) as program) =
  check_for_duplicate_defs omega defs;
  Debug.if_set (show_typechecking) (fun () -> "Typechecking program...");
  type_program omega program

let type_expression omega expression =
  Debug.if_set (show_typechecking) (fun () -> "Typechecking expression...");
  type_expression omega expression
