(*pp camlp4o *)
(** An SELinks label parser.
    Primarily used to convert Postgres label type text representation 
    back into native SELinks type.
    This file must be processed by camlp4o

    Author: Brian J. Corcoran <bjc@cs.umd.edu>
*)
open Genlex
open Result


(* Links tuples are implemented as records with sequential, numerical indexes
   ["foo";"bar";"bar"] -> [("1","foo");("2","bar");("3","bar")] *)
let make_tuple : 'a list -> (string * 'a) list = 
  let rec mk_num n = function
    | x :: xs -> (string_of_int n, x) :: mk_num (n+1) xs
    | [] -> [] in
    mk_num 1

(* Lexer *)
let lexer = Genlex.make_lexer [
  "("; 
  ")"; 
  "["; 
  "]"; 
  ","
]

(* Parser *)
(* The biggest problem here is that (()) should be parsed as 
   `Variant (`Record [])
   rather than
   `Record (`Record [])
*)
let rec parse_recs = parser
  | [< v = parse_expr; vs = parse_more_recs >] -> begin match v with 
        `Record [] -> []
      | _ -> v::vs
    end
  | [< >] -> []
and parse_more_recs = parser
    [< 'Kwd ","; vs = parse_recs >] -> vs
  | [< >] -> []
and parse_expr = parser
    [< 'Int n >] -> box_int (Num.num_of_int n)
  | [< 'String s >] -> box_string s
  | [< 'Kwd "("; vs = parse_recs ; 'Kwd ")" >] -> `Record (make_tuple vs)
  | [< 'Kwd "["; vs = parse_recs ; 'Kwd "]" >] -> `List (vs)
  | [< 'Ident v; 'Kwd "("; e = parse_expr ; 'Kwd ")" >] -> `Variant (v, e)

let parse_label = parser [< v = parse_expr; _ = Stream.empty >] -> v


(* Remove illegal characters from string *)
let remove_illegals s =
  let s' = String.copy s in
  let rec replace' i =
    if i < String.length s' then (
      begin match s'.[i] with
        | '0' .. '9' -> s'.[i] <- 'N'
        | 'A' .. 'Z' -> ()
        | 'a' .. 'z' -> ()
        | '(' | ')' | ',' | '_' -> ()
        | _ -> s'.[i] <- '_'
      end;
      replace' (i+1)
    ) in
  replace' 0; s'

(* Parse a string into a label *)
let label_of_string s : result = 
  (* let s = remove_illegals s in *)
  try 
    parse_label(lexer(Stream.of_string s))
  with Stream.Error e -> failwith ("label_of_string failed with error '"^ 
                                     e ^"'; could not parse: "^ s)
    | Stream.Failure -> 
        failwith ("label_of_string failed; could not parse: "^ s)

(* ;; *)

(* print_string (Show_result.show (label_of_string (Sys.argv.(1)))); *)
(* print_newline () *)
