open Postgresql

let db = new connection ~host:"localhost" ~port:"5431" ~dbname:"sewiki_conversion" ~user:"selinks" ()
  
let se_query = 
  "SELECT pageid FROM "^
    "(SELECT Table__g194.label AS label, "^
    "Table__g194.pageid AS pageid, "^
    "Table__g194.text AS text, "^
    "access('Nik', Table__g194.label, Table__g194.text) AS Exprcol__g195 "^
    "FROM stuff AS Table__g194) AS Table__g194 " ^
    "WHERE (CASE "^
    "WHEN ((Table__g194.Exprcol__g195 = 'Grant((_))')) THEN (tuple_get_str(label_get_tuple(Table__g194.Exprcol__g195), 0) like '%%Clinton%%') " ^
    "WHEN (true) THEN false " ^
    "END)"

let query = 
  "SELECT label, pageid, text FROM " ^
   "(SELECT Table__g194.label AS label, " ^
    "Table__g194.pageid AS pageid, " ^
    "Table__g194.text AS text " ^
    "FROM stuff AS Table__g194) AS Table__g194"
    
exception QueryFailed
let run_se_query () = 
  let dbresult = db#exec se_query in
    match dbresult#status with 
	Tuples_ok -> 
	  if dbresult#nfields <> 1 then raise QueryFailed;
	  (match dbresult#ftype 0 with
	       INT4 ->
		 List.fold_left (fun rs [pageid] -> (int_of_string pageid)::rs) [] (dbresult#get_all_lst)
	     | _ -> raise QueryFailed)
      | _ -> raise QueryFailed


let run_query () = 
  let regexpAcl = Str.regexp ".*Nik.*" in
  let regexpText = Str.regexp ".*Clinton.*" in
  let dbresult = db#exec query in
    match dbresult#status with 
	Tuples_ok -> 
	  if dbresult#nfields <> 3 then raise QueryFailed;
	  (match (dbresult#ftype 0, dbresult#ftype 1, dbresult#ftype 2)  with
	       (LABEL, INT4, TEXT) -> 
		 List.fold_left (fun rs [label; pageid; text] -> 
				   if Str.string_match regexpAcl label 0 then
				     if Str.string_match regexpText text 0 then
				       (int_of_string pageid)::rs
				     else
				       rs
				   else
				     rs) [] (dbresult#get_all_lst)
	     | _ -> raise QueryFailed)
      | _ -> raise QueryFailed
	  
let print_result list = let s = String.concat ", " (List.map string_of_int list) in
  print_string s; 
  print_newline;  
  print_newline
    
;;

if Sys.argv.(1) = "se" then 
  print_result (run_se_query ())
else
  print_result (run_query ())
    
