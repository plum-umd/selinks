open Performance
open Getopt
open Utility
open List
open Basicsettings
open Printf

(* Types of built-in primitives.  TODO: purge. *)
let stdenvs = ref([], Library.type_env)

(* bjc: move this to another module *)
let typeeval (_, typingenv) x : string =
  let parse = Parse.parse_string ~pp:(Settings.get_value pp) Parse.program in
  let program = parse x in
  let (_, program) = Inference.type_program typingenv program in
  let Syntax.Program (_,expr) = program in
  x ^ " : " ^ Printsyntax.string_of_datatype (Syntax.node_datatype expr)

(** Definition of the various repl directives *)
let rec directives = 
  let ignore_envs fn envs arg = 
    let _ = fn arg 
    in envs 
  in lazy
  (* lazy so we can have applications on the rhs *)
[
    "directives", 
    (ignore_envs 
       (fun _ -> 
          iter (fun (n, (_, h)) -> Printf.fprintf stderr " @%-20s : %s\n" n h) (Lazy.force directives)),
     "list available directives");
    
    "settings",
    (ignore_envs
       (fun _ -> 
          iter (Printf.fprintf stderr " %s\n") (Settings.print_settings ())),
     "print available settings");
    
    "set",
    (ignore_envs
       (function (name::value::_) -> Settings.parse_and_set_user (name, value)
          | _ -> prerr_endline "syntax : @set name value"),
     "change the value of a setting");
    
    "builtins",
    (ignore_envs 
       (fun _ ->
          iter (fun (n, k) ->
                       Printf.fprintf stderr " %-16s : %s\n" 
                         n (Printsyntax.string_of_datatype (snd k)))
            (fst Library.type_env_old)),
     "list builtin functions and values");

    "quit",
    (ignore_envs (fun _ -> exit 0), "exit the interpreter");

    (* note: argument must be quoted b/c directives may not contain spaces *)
    "type",
    ((fun envs args -> 
        print_endline (typeeval envs (String.concat " " args));
        envs),
     "type expression");

    "typeenv",
    ((fun ((_, omega) as envs) _ ->
      iter (fun (v, k) ->
        Printf.fprintf stderr " %-16s : %s\n"
          v (Printsyntax.string_of_datatype (snd k)))
        (filter (not -<- (flip mem_assoc (fst Library.type_env_old) -<- fst)) 
           (fst (Typeenv.extract_typing_environment omega)));
      envs),
    "display the current type environment");

    "env",
    ((fun ((valenv, _) as envs) _ ->
        iter (fun (v, k) ->
                     Printf.fprintf stderr " %-16s : %s\n"
                       v (Result.string_of_result k))
          (filter (not -<- Library.is_primitive -<- fst)  valenv);
     envs),
     "display the current value environment");

    "load",
    ((fun envs args ->
        match args with
          | [filename] ->
              let library_types, (Syntax.Program (prelude, _) as libraries) =
                (Errors.display_fatal Loader.read_file_cache 
                   (Settings.get_value prelude_file)) in 
              let libraries, _ = 
                Interpreter.run_program [] [] libraries in

              if Settings.get_value Loader.native_includes then
                let typingenv, program =
                  Loader.read_and_optimise_program prelude library_types filename in
                (fst ((Interpreter.run_program libraries []) program), typingenv)
              else                      (* drop back to original code *)
                let program = Parse.parse_file 
                  ~pp:(Settings.get_value pp) Parse.program filename in
                let typingenv, program = Inference.type_program library_types program in
                let program = Optimiser.optimise_program (typingenv, program) in
                let program = Syntax.labelize program in
                (fst ((Interpreter.run_program libraries []) program), typingenv)
          | _ -> prerr_endline "syntax: @load \"filename\""; envs),
     "load in a Links source file, replacing the current environment");

    "withtype",
    ((fun ((_, omega) as envs) args ->
      match args with 
          [] -> prerr_endline "syntax: @withtype type"; envs
        | _ -> let _,t = Parse.parse_string 
            ~pp:(Settings.get_value pp)
            (Parse.checked_datatype Sugar.normalize_type) 
            (String.concat " " args) in
	   let tt = Typeenv.extract_typing_environment omega in 
            ListLabels.iter (fst tt)
                ~f:(fun (id,(_,t')) -> 
                      if id <> "_MAILBOX_" then
                        (try begin
                           let ttype = Printsyntax.string_of_datatype t' in
                           let fresh_envs = Expression.Types.make_fresh_envs t' in
                           let t' = Instantiate.instantiate_datatype fresh_envs t' in 
                             Unify.unify_old omega (t,t');
                             Printf.fprintf stderr " %s : %s\n" id ttype
                        end with _ -> ()))
            ; envs),
    "search for functions that match the given type");
    
    ]
      
let execute_directive (name, args) (valenv, typingenv) = 
  let envs = 
    (try fst (assoc name (Lazy.force directives)) (valenv, typingenv) args; 
     with Not_found -> 
       Printf.fprintf stderr "unknown directive : %s\n" name;
       (valenv, typingenv))
  in
    flush stderr;
    envs
    
(** Print a result (including its type if `printing_types' is [true]). *)
let print_result rtype result = 
  print_string (Result.string_of_result result);
  if Settings.get_value printing_types then 
    print_endline (" : " ^ Printsyntax.string_of_datatype rtype)

(** Compile links file to database stored procedures  *)
let compile_to_db program =
  let Syntax.Program (defs, _) = program in 
  let dbdefs = Dbcompile.generate_program_defs defs () in
  (* let dbcode = Dbcompile.gen_dbcode typingenv body in *)
  print_endline (String.concat "\n" dbdefs);
  exit 0
  
(** type, optimise and evaluate a program *)
let process_program ?(printer=print_result) (valenv, typingenv) program = 
  let typingenv, program = lazy (Inference.type_program typingenv program) 
    <|measure_as|> "type_program" in
    (* Additional phase here ... Fable.type_program typing_env program *)
  let program = lazy (Optimiser.optimise_program (typingenv, program))
    <|measure_as|> "optimise_program" in

  if Settings.get_value db_mode then
    compile_to_db program
  else
    let Syntax.Program (_, body) as program = Syntax.labelize program in
    let valenv, result = lazy (Interpreter.run_program valenv [] program)
      <|measure_as|> "run_program" 
    in
    printer (Syntax.node_datatype body) result;
    (valenv, typingenv), result, program

let parse_defs defs envs =
  let program = Syntax.Program (defs, Syntax.unit_expression (`U Syntax.dummy_position)) in
  let (valenv, _) as envs, _, (Syntax.Program (defs', _)) = 
    process_program ~printer:(fun _ _ -> ()) envs program in
  let print_def = function
    | Syntax.Define (name, _, _, _) as d -> 
        fprintf stderr "%s = %s : %s"
          name
          (Result.string_of_result (List.assoc name valenv))
          (Printsyntax.string_of_datatype (Syntax.def_datatype d))
    | _ -> () (* non-value definition (type, fixity, etc.) *)
  in ListLabels.iter defs' ~f:print_def; 
  envs
                
(* Interactive loop *)
let interact envs =
  let make_dotter ps1 = 
    let dots = String.make (String.length ps1 - 1) '.' ^ " " in
      fun _ -> 
        print_string dots;
        flush stdout in
  let ps1 = Settings.get_value ps1 (* "links> " *) in

  let rec interact envs =
    let evaluate_replitem parse envs input = 
      Errors.display ~default:(fun _ -> envs)
        (lazy
           (match measure "parse" parse input with 
              | `Definitions [] -> envs
              | `Definitions defs -> parse_defs defs envs
              | `Expression expr -> 
                  let (envs, _, _) = process_program envs (Syntax.Program ([], expr)) in envs
              | `Directive directive -> execute_directive directive envs))
    in
    print_string ps1; flush stdout; 
    interact (evaluate_replitem 
                (Parse.parse_channel ~interactive:(make_dotter ps1) Parse.interactive) 
                envs (stdin, "<stdin>"))
  in 
  Sys.set_signal Sys.sigint (Sys.Signal_handle (fun _ -> raise Sys.Break));
  interact envs                       (* loop forever *)

(** Execute a file given on the command line *)
let run_file prelude ((valenv,typingenv) as envs) filename = 
  Settings.set_value interacting false;
  match Utility.getenv "REQUEST_METHOD" with 
    | Some _ -> 
        (Settings.set_value web_mode true;
         Webif.serve_request prelude envs filename)
    | None ->
        let run_program filename = 
          let _, program =
            Loader.read_and_optimise_program prelude typingenv filename in
          let Syntax.Program (_, body) = program in
          let _, result = Interpreter.run_program valenv [] program in
          print_result (Syntax.node_datatype body) result;
          (valenv, typingenv), result, program
        in
        ignore ((Errors.display_fatal run_program) filename)
          
(** Evaluate a string given on the command line *)
let evaluate_string_in envs v =
  Settings.set_value interacting false;
  let parse = Parse.parse_string ~pp:(Settings.get_value pp) Parse.program in
  ignore (Errors.display_fatal (measure "parse" parse ->- process_program envs) v)

let cmd_line_actions = ref []

let run_tests tests () = 
  begin
    Test.run tests;
    exit 0
  end

let no_prelude = Settings.add_bool ("noprelude", false, `User)

let options : opt list = 
  let set setting value = Some (fun () -> Settings.set_value setting value) in
  [
    ('d',     "debug",               set Debug.debugging_enabled true, None);
    ('O',     "optimize",            set Optimiser.optimising true,    None);
    (noshort, "measure-performance", set measuring true,               None);
    ('n',     "no-types",            set printing_types false,         None);
    ('e',     "evaluate",            None,                             Some (fun str -> push_back (`Evaluate str) cmd_line_actions));
    (noshort, "noprelude",           set no_prelude true,              None);
    (noshort, "config",              None,                             Some Settings.load_file);
    (noshort, "dump",                None,                             Some Loader.dump_cached);
    (noshort, "working-tests",       Some (run_tests Tests.working_tests),  None);
    (noshort, "broken-tests",        Some (run_tests Tests.broken_tests),   None);
    (noshort, "failing-tests",       Some (run_tests Tests.known_failures), None);
    (noshort, "db-export",           set db_mode true,                 None);
    (noshort, "pp",                  None, Some (Settings.set_value pp));
    (noshort, "unsafe-clients",      set unsafe_client_mode true, None);
    ]

(** load prelude: *)
let load_prelude prelude_file =
  let prelude_types, (Syntax.Program (prelude, _) as prelude_program) =
	(Errors.display_fatal Loader.read_file_cache prelude_file) in
  
  (* make sure the fresh type variable counter does not clash with any type variables from
	 the prelude
     
	 [BUG]
	 
	 we should really do something similar for term variables
  *)
  ignore (
	let vars = Syntax.free_bound_type_vars_program prelude_program in
	if vars = Expression.Types.TypeVarSet.empty then
	  ()
	else
      (* Horrible hack ... + 10000 ... got burned here. Need to count tvars better *)
	  Expression.Types.bump_variable_counter
	    ((Expression.Types.TypeVarSet.max_elt vars) + 10000)
  );
  let prelude_compiled = Interpreter.run_defs [] [] prelude in
  ignore (
    let (stdvalenv, stdtypeenv) = !stdenvs in
 	stdenvs := 
	  (stdvalenv @ prelude_compiled,
	   Typeenv.concat_environment stdtypeenv prelude_types)
  );
  (prelude, prelude_compiled, prelude_types)

(** Main function *)
let main () =
  let file_list = ref [] in
  Errors.display_fatal_l (lazy (parse_cmdline options (fun i -> push_back i file_list)));
  (* load the prelude, unless --noprelude is given *)
  let prelude, prelude_compiled, prelude_types =
    if Settings.get_value no_prelude then
	  [], [], Library.type_env
    else
      load_prelude (Settings.get_value prelude_file)
  in
  (* evaluate any Links strings given on the command line (via -e) *)
  Utility.for_each !cmd_line_actions
	(function `Evaluate str -> evaluate_string_in !stdenvs str);
  (* TBD: accumulate type/value environment so that "interact" has access *)
  (* interpret and files given on the command line *)
  ListLabels.iter ~f:(run_file prelude (prelude_compiled, prelude_types)) !file_list;
  (* begin toplevel interactive loop, if in interactive mode. *)
  if Settings.get_value interacting then
    begin
      print_endline (Settings.get_value welcome_note);
      interact (prelude_compiled, prelude_types)
    end

