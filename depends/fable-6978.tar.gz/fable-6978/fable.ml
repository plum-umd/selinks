open Utility
open Syntax
open Expression
open Expression.Types
open Expression.Expr
open Expression.FableType
open Typeenv

type uft = unchecked_fable_type
type tft = fable_type
type 'a fq = 'a FableType.fable_qualifier 

let fresh_kind_variable k = Unionfind.fresh (`FlexKind (Types.fresh_raw_variable(), k))
  
let annot k lt = {ltype =lt ; ftype = `Kind k}

let fresh_label_type _ =
  let {ltype=tv; ftype=_} = fresh_type_variable () in
  let tft = `Label (`Nothing, `Kind UKind) in
    {ltype=tv; ftype=tft}

let new_phantom_var pos = Variable(Utility.gensym ~prefix:"phi" (),
                                  `T(pos, fresh_label_type (),None))

let new_var pos = Variable(Utility.gensym (), `U pos)

exception Bad_fable_type of string

let get_quant ltype k = match ltype with 
    `MetaTypeVar p -> 
      (match Unionfind.find p with
	   Rigid v ->  (`RigidTypeVar v, k)
	 | _ -> raise Utility.Impos)
  | _ -> raise Utility.Impos 

(* (||l._:('a{l}) -> 'a) *)
let unlabel_type =
  let Variable(lname, _) as l = new_phantom_var dummy_position in
  let {ltype = tvar; ftype= _} = fresh_rigid_type_variable () in
  let argElt = {ltype = tvar; ftype = `Labeling (l, `Kind MKind)} in
  let {ltype=arg_tuple; ftype = _} = make_tuple_type [argElt] in
  let arg = {ltype = arg_tuple; ftype = `Phantom ([lname], `Kind UKind)} in
  let ret = {ltype = tvar; ftype = `Kind MKind} in
  let {ltype=mb_tvar; ftype=_} as mb = fresh_type_variable () in
  let dt = {ltype = `Function (arg, mb, ret); ftype = `Kind UKind} in
  let quants = [get_quant tvar MKind] in (* ; get_quant mb_tvar UKind] in *)
    quants, dt
      (*  Inference.generalise [] dt *)
      
(* (x:('a, 'b is lab) -> 'a{x.2}) *)
let relabel_type =
  let fst = {ltype=(fresh_rigid_type_variable ()).ltype;
	     ftype=`Kind MKind} in
  let snd = {ltype = (fresh_rigid_type_variable ()).ltype;
	     ftype = `Label (`Nothing, `Kind UKind)} in
  let xname = Utility.gensym () in
  let arg = {ltype=(make_tuple_type [fst;snd]).ltype; 
	     ftype = `Name (xname, `Kind UKind)} in 
  let x = Variable(xname, `T(dummy_position,{ltype=arg.ltype;ftype=`Kind UKind}, None)) in
  let proj = Project(x, "2", `T (dummy_position, snd, None)) in
  let ret = {ltype = fst.ltype; ftype = `Labeling (proj, `Kind MKind)} in
  let mb = fresh_type_variable () in
  let dt = {ltype = `Function (arg, mb, ret); ftype =  `Kind UKind}  in
  let quants = [get_quant fst.ltype MKind; get_quant snd.ltype UKind] in (*  get_quant mb.ltype UKind] in *)
    quants, dt

      
let sub_kind = FableType.kind_leq
      
let kind_qual = FableType.kind_qual
      
let sub_kind_fq (f1, f2) =
  sub_kind (kind_qual f1, kind_qual f2)

let rec get_label_type_expr  = function
    `Empty 
  | `Kind _
  | `KindVar _ -> raise Not_found
  | `Label (e, _) -> 
      begin
	match e with
	    `Nothing -> None
	  | `Required e -> Some e
	  | `Inferred pt -> 
	      match Unionfind.find pt with 
		  `Nothing -> None
		| `Something e -> Some e
      end
  | `Labeling (_, fq) 
  | `Phantom (_, fq)
  | `Name (_, fq) -> get_label_type_expr fq

let get_name_bindings : 'a fq  -> (string list * string option) =
  let rec aux (p_names, name) = function
      `Phantom(pvs, t) ->
        if (p_names != []) then
          raise (Bad_fable_type "Multiple phantom binding qualifiers")
        else
          aux (pvs, name) t
    | `Name(n, t) ->
        if (name != None) then
          raise (Bad_fable_type "Multiple name binding qualifiers")
        else
          aux (p_names, Some n) t
    | _ -> (p_names, name) in 
    fun x -> aux ([], None) x          

let rec strip_name_bindings : 'a fq -> 'a fq = function
    `Phantom(p, ft) -> strip_name_bindings ft
  | `Name(n, ft) -> strip_name_bindings ft (* well-formedness ensures that there's no further bindings in ft *)
  | ft -> ft
let strip_name_bindings_type {ltype=lt; ftype = fq} = {ltype=lt; ftype=strip_name_bindings fq}

let restore_bindings phantoms nopt {ltype=lt; ftype=fq} =
  let tft' = match nopt with
      None -> fq
    | Some(n) -> `Name(n, fq) in
  let tft'' = match phantoms with
      [] -> tft'
    | _ -> `Phantom(phantoms, tft') in
    {ltype=lt; ftype=tft''}

let add_phantom_bindings phantoms env =
  let env', tvs = List.fold_left
    (fun (env,tvs) p ->
       if Typeenv.contains p env then
         raise (Bad_fable_type "Non-unique phantom name")
       else
         let tv = fresh_label_type () in
           (Typeenv.add_phantom_binding p ([], tv) env, tv::tvs))
    (env, []) phantoms in
    env'

module rec FreeNames : sig
  type omega = {outer: Typeenv.omega; inner: Typeenv.omega; expect_empty: bool}
  val free_vars_exp : omega -> 'a expression' -> string list
  val free_vars_fq : omega -> 'a fq -> string list
  val free_vars_record_row : omega -> 'a row' -> string list
  val free_vars_row : omega -> 'a row' -> string list
  val free_vars_typ : omega -> 'a datatype' -> string list
end = struct
  type omega = {outer: Typeenv.omega; inner: Typeenv.omega; expect_empty: bool}
  let dummy_type = {ltype = `Not_typed; ftype = `Kind UKind}
    
  let contains name env   = Typeenv.contains name env.outer  || Typeenv.contains name env.inner
  let add_normal_binding n a env = {env with inner=Typeenv.add_normal_binding n a env.inner}

  let free_vars_exp env e : string list =
    let fvs = Syntax.freevars_list e in
      List.filter (not -<- ((flip contains) env)) fvs
        
  let rec free_vars_fq env : 'a fq -> string list = function
    | `Kind _
    | `Empty -> []
    | `KindVar pt  -> 
	begin
	  match Unionfind.find pt with 
	      `FixedKind fq -> free_vars_fq env fq
	    | `FlexKind _ -> [] (* raise (Bad_fable_type "Unable to determine free names in an unconstrained kind variable") *)
	end
    | `Name (name, t) ->
        assert_msg (not (contains name env)) "Non-unique name";
        free_vars_fq env t
          (* tempting to do this... but name is not in scope in t
             free_vars_fq (add_dummy_name env name) t          *)
    | `Labeling (el,t) ->
        let fvs =  free_vars_exp env el in
        let fvs' = free_vars_fq env t in
          list_union fvs fvs'
    | `Label (`Nothing, t) -> free_vars_fq env t
    | `Label (`Required e, t) ->
        let l1 = free_vars_exp env e in
        let l2 = free_vars_fq env t in
          list_union l1 l2
    | `Label (`Inferred pt, t) ->
	let l1 = match Unionfind.find pt with
	    `Nothing -> []
	  | `Something e -> 
	      begin
		match free_vars_exp env e with
		    [] -> []
		  | l -> 
		      if env.expect_empty then
			(Unionfind.change pt `Nothing; [])
		      else l
	      end in
        let l2 = free_vars_fq env t in
          list_union l1 l2
    | `Phantom (el, t) ->
        let env' = {env with inner=add_phantom_bindings el env.inner} in
          free_vars_fq env' t
            
  let rec free_vars_record_row omega (fsm, row_var) = (* TODO: What to do if row_var is `Recursive? ... seems ok as is*)
    let labels = List.sort compare (StringMap.fold (fun key _ l -> key :: l) fsm []) in
    let _, fvs = List.fold_left (fun (omega, fvs) l -> 
                                   match StringMap.find l fsm with
                                       `Absent -> (omega, fvs)
                                     | `Present t -> 
                                         let phantoms, nameopt = get_name_bindings t.ftype in
                                           (match phantoms with
                                              | [] -> ()
                                              | _ -> raise (Bad_fable_type "Unexpected phantom bindings in record field"));
                                           let t' = strip_name_bindings_type t in
                                           let fvs' = FreeNames.free_vars_typ omega t' in
                                           let omega' = match nameopt with
                                               None -> omega
                                             | Some n -> add_normal_binding n ([], dummy_type) omega in
                                             (omega', fvs@fvs')
                                ) (omega, []) labels  in
      fvs
  and free_vars_row omega (fsm, row_var) =
    StringMap.fold (fun label fs fvs -> match fs with
                        `Absent -> fvs
                      | `Present t -> 
                          let fvs' = FreeNames.free_vars_typ omega t in
                            fvs@fvs') fsm []
  and free_vars_typ env :'a datatype' ->  string list =
    fun {ltype=lt; ftype=fq} ->
      let fvs = FreeNames.free_vars_fq env fq in
      let fvs' = match lt with
        | `Function(argt, mb, ret) ->
            let phantoms, name = get_name_bindings argt.ftype in              
            let env = List.fold_left (fun env name -> add_normal_binding name ([], dummy_type) env) env phantoms in 
            let argt' = strip_name_bindings_type argt in 
            let fvs' = FreeNames.free_vars_typ env argt' in
            let env = match name with
                None -> env
              | Some(name) -> add_normal_binding name ([], dummy_type) env in
            let fvs'' = FreeNames.free_vars_typ env mb in (* TODO : scoping rules for mailbox types *)
            let fvs''' = FreeNames.free_vars_typ env ret in
              fvs'@fvs''@fvs'''
        | `Record row ->  FreeNames.free_vars_record_row env row (* (fst (Types.unwrap_row row)) *) (* TODO : fix unwrap_row and fix this *)
        | `Variant row ->  FreeNames.free_vars_row env row (* (fst (Types.unwrap_row row)) *)
        | `Application (alias, args) -> [] (* TODO: fix this! *)
            (*             failwith "free_vars_type `Application : Not yet implemented" *)
        | _ -> [] in
        list_union fvs fvs' 
end

let free_names ?(expect_empty=false) omega datatype = 
  FreeNames.free_vars_typ {FreeNames.outer=omega; FreeNames.inner=Typeenv.empty; FreeNames.expect_empty=expect_empty} datatype

let is_empty : 'a fq -> bool = function 
    `Empty -> true
  | `Kind k -> true
  | _ -> false 
      
let as_string = Expression.DerivingSyntax.Show_fable_type.show

let row_labels_inorder (fsm_alist : (string * 'a field_spec') list) = 
  let rec exports_name = function
      `Empty
    | `KindVar _ 
    | `Kind _ 
    | `Label _
    | `Labeling _ -> None
    | `Name (n, t) -> Some n
    | `Phantom(_, t) -> exports_name t in
  let rec uses_name n = function
      `Empty
    | `KindVar _ 
    | `Kind _ 
    | `Label _ -> false
    | `Labeling (e, t) -> 
	let fns = FreeNames.free_vars_exp {FreeNames.outer=Typeenv.empty; FreeNames.inner=Typeenv.empty; FreeNames.expect_empty=false} e in
	  if List.mem n fns then 
	    true
	  else
	    uses_name n t
    | `Name (_, t) 
    | `Phantom (_, t) -> uses_name n t in
  let fqual_binding_order fq1 fq2 = match exports_name fq1, exports_name fq2 with
      None, None -> 0
    | Some _, None -> -1
    | None, Some _ -> 1
    | Some n1, Some n2 -> 
	begin
	  match uses_name n1 fq2, uses_name n2 fq1 with 
	      false, false -> 0
	    | true, false -> 1
	    | false, true -> -1
	    | true, true -> raise (Bad_fable_type "Mutually recursive names in a dependent tuple; unable to resolve binding order")
	end in
  let compare_row_labels (l1, fs1) (l2, fs2) = match fs1, fs2 with 
      `Absent, `Absent -> 0
    | `Present _, `Absent -> -1
    | `Absent, `Present _ -> 1
    | `Present t1, `Present t2 -> 
	let res = fqual_binding_order t1.ftype t2.ftype in
	  if res = 0 then
	    String.compare l1 l2
	  else res in
    List.sort compare_row_labels fsm_alist
      
let row_labels_inorder ?(filter_absent=false) (fsm : 'a field_spec_map') = 
(*   if not (is_flattened_row (fsm, rv)) then *)
(*     raise Utility.Impos; *)
  let l = StringMap.to_alist fsm in 
  let l = 
    if filter_absent then
      List.filter (fun (_, s) -> match s with 
		       `Absent -> false
		     | _ -> true) l 
    else l in
    row_labels_inorder l
      
      
