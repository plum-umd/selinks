open Utility
open Expression
open Expression.Types

let show_recursion = Settings.add_bool("show_recursion", false, `User)

exception Type_application_error of (datatype * kind * string * kind)

(*
  instantiation environment:
    for stopping cycles during instantiation
*)
type inst_type_env = meta_type_var IntMap.t
type inst_row_env = row_var IntMap.t
type inst_env = inst_type_env * inst_row_env
    
let instantiate_datatype : (datatype IntMap.t * row_var IntMap.t) -> datatype -> datatype =
  fun (tenv, renv) ->
    let rec inst : inst_env -> datatype -> datatype = fun rec_env datatype ->
      let rec_type_env, rec_row_env = rec_env in
      let preserve_fqual ldt = {ltype=ldt; ftype=datatype.ftype} in
      let combine_fqual dt = {ltype=dt.ltype; ftype=Expression.FableType.combine datatype.ftype dt.ftype} in
      let instantiate_fqual dt = {ltype=dt.ltype; ftype=Expression.FableType.instantiate datatype.ftype dt.ftype} in
      let ldt = datatype.ltype in 
	match ldt with
	   | `Not_typed -> failwith "Internal error: `Not_typed' passed to `instantiate'"
	   | `Primitive _  -> preserve_fqual ldt
	   | `MetaTypeVar point ->
		let t = Unionfind.find point in
		  (match t with
		    | Flexible var
		    | Rigid var ->
			 if IntMap.mem var tenv then
			   let sub_dt = IntMap.find var tenv in
			     instantiate_fqual sub_dt
			 else
			   preserve_fqual ldt
		    | Recursive (var, t) ->
			Debug.if_set (show_recursion) (fun () -> "rec (instantiate)1: " ^(string_of_int var));
			if IntMap.mem var rec_type_env then
			   preserve_fqual (`MetaTypeVar (IntMap.find var rec_type_env))
			else
			   (
			     let var' = fresh_raw_variable () in
			     let point' = Unionfind.fresh (Flexible var') in
			     let t' = inst (IntMap.add var point' rec_type_env, rec_row_env) t in
			     let _ = Unionfind.change point' (Recursive (var', t')) in
				preserve_fqual (`MetaTypeVar point')
			   )
		    | Body t -> combine_fqual (inst rec_env t))
	   | `Function (f, m, t) -> preserve_fqual (`Function (inst rec_env f, inst rec_env m, inst rec_env t))
	   | `Record row -> preserve_fqual (`Record (inst_row rec_env row))
	   | `Variant row -> preserve_fqual ( `Variant (inst_row rec_env row))
	   | `Table (r, w) -> preserve_fqual (`Table (inst rec_env r, inst rec_env w))
	   | `Application (n, elem_type) ->
		preserve_fqual ( `Application (n, List.map (inst rec_env) elem_type))
    and inst_row : inst_env -> row -> row = fun rec_env row ->
      let field_env, row_var = flatten_row row in
	
      let is_closed =
        match Unionfind.find row_var with
          | ClosedRow -> true
          | _ -> false in

      let field_env' = StringMap.fold
	(fun label field_spec field_env' ->
	   match field_spec with
	     | `Present t -> StringMap.add label (`Present (inst rec_env t)) field_env'
	     | `Absent ->
		 if is_closed then field_env'
		 else StringMap.add label `Absent field_env'
	) field_env StringMap.empty in
      let row_var' = inst_row_var rec_env row_var
      in
	field_env', row_var'
          (* precondition: row_var has been flattened *)
    and inst_row_var : inst_env -> row_var -> row_var = fun (rec_type_env, rec_row_env) row_var ->
      match row_var with
	| point ->
	    begin
              match Unionfind.find point with
	        | ClosedRow -> row_var
                | FlexibleRow var
                | RigidRow var ->
		    if IntMap.mem var renv then
		      IntMap.find var renv
		    else
		      row_var
	        | RecursiveRow (var, rec_row) ->
		    if IntMap.mem var rec_row_env then
		      IntMap.find var rec_row_env
		    else
		      begin
		        let var' = fresh_raw_variable () in
		        let point' = Unionfind.fresh (FlexibleRow var') in
		        let rec_row' = inst_row (rec_type_env, IntMap.add var point' rec_row_env) rec_row in
		        let _ = Unionfind.change point' (RecursiveRow (var', rec_row')) in
			  point'
		      end
	        | BodyRow _ -> assert(false)
            end
    in
      inst (IntMap.empty, IntMap.empty)


let instantiate_alias name alias_env (quals, alias) ts =
  let _, tenv =
    List.fold_left (fun (ts, tenv) (tv,tv_k) ->
                      match ts, tv with
                        | (t::ts), `TypeVar var ->
			    let tk = Kinding.datatype_kind alias_env t in 
			      if (FableType.kind_leq (tk, tv_k)) then
				ts, IntMap.add var t tenv
			      else
				raise (Type_application_error (t, tk, name, tv_k))
                        | _ -> assert false) (ts, IntMap.empty) quals
  in
    instantiate_datatype (tenv, IntMap.empty) (freshen_mailboxes alias)
