(*pp deriving *)
(** Database stored procedure code generation.
    Currently only supports PL/pgSQL.
    Based on the Links JavaScript module (Js)

    Author: Brian J. Corcoran <bjc@cs.umd.edu>
*)

open Num
open Netencoding
open List

(* open Pickle *)
open Forms
open Utility
open Syntax
open Expression
open Expression.Expr

let nyi msg = failwith ("Not yet implemented: " ^ msg)

(* database types are required, but are a subset of Links types *)
(* (these are probably defined somewhere else) *)
type dbtype = DBInt | DBString | DBChar | DBBool | DBFloat
              | DBLabel of dbtype | DBTuple of dbtype | DBList of dbtype 
              | DBUnknown | DBAny

(* Convert a dbtype to the Postgres-understandable string *)
let string_of_dbtype = function
  | DBInt -> "integer"
  | DBString -> "text"
  | DBChar -> "character"
  | DBBool -> "boolean"
  | DBFloat -> "float"           
  | DBLabel _ | DBList _ | DBTuple _ -> "bigint"
  (* | DBLabel -> "label" *)
  (* | DBList -> "list" *)
  (* | DBTuple -> "tuple" *)
  | DBAny -> "anyelement"
  | DBUnknown -> "???"

(* A variable is an identifier and a type
   (we need types for PL/pgSQL) *)
type var = (string * dbtype)

(* Intermediate language for database stored procedures *)
type code = [
  | `Var   of var                        (* variable name *)
  | `Lit   of string                     (* any literal *)
  | `Defs  of ((string * code) list)     (* list of definitions *)
  | `Fn of (var list * code * dbtype)    (* args * body * returntype*)
  | `Call  of (code * code list)         (* fn * args *)
  | `Binop of (code * string * code)     (* infix operator *)
  | `Cond  of (code * code * code)       (* if * then * else *)
  | `App   of (string * code)
  | `Dict  of ((string * code) list)      (* dictionary: not sure how to model *)
  | `Bind  of (var * code * code)     (* name * value * body *)
  | `Die   of (string)                   (* error *)
  | `Ret   of code                       (* explicit return (needed in DB) *)
  | `Nothing                             (* Not sure purpose of this *)
  | `Comment of (string * code)  (* A comment *)
]
    (* not yet supported: *)
    (*| Lst   of (code list)    (\* array (model as an array?) *\) *)
    (*| Seq   of (code * code)              (\* tuple? *\) *)

(* convert Links binary operators to Postgres *)
let binop_builtins =
  ["+",  "+";
   "+.", "+";
   "-",  "-";
   "-.", "-";
   "*",  "*";
   "*.", "*";
   "/",  "/";
   "/.", "/";
  ]

let string_of_binop op = 
  try assoc op binop_builtins
  with Not_found -> failwith ("Not found: "^ op)

(* Find all local variables in an expression -
   these need to be explicitly declared in PL/pgSQL
   (Is this only var (Let/Bind) statements?) *)
(* Should eventually write a generic fold for code *)
let rec find_locals : code -> var list = function
  | `Bind (v, e1, e2) -> v :: (find_locals e1 @ find_locals e2)
  | `Cond (e1, e2, e3) -> List.concat (map find_locals [e1;e2;e3])
  | `Binop (e1, _, e2) -> List.concat (map find_locals [e1;e2])
  | `Fn (_, e, _) -> find_locals e
  | `Call  (e1, es) ->                (* not sure if these should be included *)
      List.concat (map find_locals (e1::es))
  | `App (_, e) -> find_locals e
  | `Dict terms -> List.concat (map (snd ->- find_locals) terms)
  | `Comment (_, e) -> find_locals e
  | `Ret e -> find_locals e
        
  | `Var _ | `Lit _ | `Die _ | `Nothing -> []
  | `Defs defs -> List.concat (map (snd ->- find_locals) defs)
      
      
(* Indentation settings *)
let tab_level = 2
let indent n = String.make (n*tab_level) ' '

(* Output DB IR as PL/pgSQL code *)
let rec show c = show_i 0 c
  
(* Show, indenting n tab_levels *)
and show_i n : code -> string = 
  let show0 x = show_i n x in
  let show1 x = show_i (n+1) x in
  let in0 = indent n in
  let in1 = indent (n+1) in
  function
    | `Var (s,_) -> s
    | `Lit s -> s
    | `App (v, e) -> begin
        match e with
            `Lit _ 
          | `Dict [] -> "'"^ v ^"(" ^ show e ^")'"
          | `Var (_,t) -> "label_init('"^ v ^"', "^ show e ^ ")"
          | `App _ -> nyi "show app:app"
          | `Dict _ -> nyi "show app:dict"
          | _ -> "label_init('"^ v ^"', "^ show e ^ ")"
              (* failwith ("show: Application can not contain " ^ show e) *)
      end
    | `Defs (defs) -> String.concat "\n\n" (map show_def defs)
    | `Cond (if_, then_, else_) -> 
        "IF "^ show if_ ^" THEN\n" ^ 
          in1 ^ show1 then_ ^";\n" ^
          in0 ^ "ELSE\n" ^
          in1 ^ show1 else_ ^ ";\n" ^
          in0 ^ "END IF"
    | `Call (fn, args) -> 
        show fn ^"("^ String.concat "," (map show args) ^")"
    | `Binop (l, op, r) -> paren l ^" "^ op ^" "^ paren r
    | `Fn _ as f -> show_func "anonymous" f
    | `Bind ((v,_), e, b) -> 
        v ^" := "^ show e ^";\n" ^
        in0 ^ show0 b
    | `Ret e -> "RETURN "^ show e
    | `Comment (c, e) -> 
        "-- "^ c ^"\n" ^ 
          in0 ^ show0 e
    | `Dict [] -> "()"
    | `Dict terms -> 
        let expand_term (k,v) = k ^"="^ show v in
        "(" ^ String.concat "," (map expand_term terms) ^ ")"
    | `Nothing -> ""
    | `Die msg -> failwith "User Defined-Error: " ^ msg ^ ")"
        
(* Parenthesize a sub-expression *)
and paren = function
  | `Var _ | `Lit _ | `Call _ | `Die _ | `Nothing | `Dict _ as c 
      -> show c
  | c -> "(" ^ show c ^ ")"

(* Output a definition *)
and show_def = function
  | name, (`Fn _ as f) -> show_func name f
  | _ -> nyi "show_def"

(* helper function handling function def overhead *)
and show_func name (`Fn (args, body, rettype)) =
  "CREATE OR REPLACE FUNCTION "^ name ^ "("^ show_args args ^") " ^
    "RETURNS "^ string_of_dbtype rettype ^" AS $$\n" ^
    "DECLARE\n" ^ 
    declare_locals body ^
    "BEGIN\n" ^ 
    indent 1 ^ show_i 1 body ^";\n" ^
    "END;\n$$ LANGUAGE 'plpgsql';\n"

(* show procedure argument name and types *)
and show_args args = 
  let show_arg (var,typ) = var  ^ " " ^ string_of_dbtype typ
  in String.concat ", " (List.map show_arg args)

(* (\* show procedure argument signature *\) *)
(* and show_arg_types args =  *)
(*   String.concat "," (List.map (snd ->- string_of_dbtype) args) *)
 
(* (\* declare procedure arguments *\) *)
(* and declare_args args =  *)
(*   let declare_arg n (var,_) =  *)
(*     indent 1 ^ var ^" ALIAS FOR $"^string_of_int n^";\n" in *)
(*   let rec declare_args' n = function *)
(*     | var::args -> declare_arg n var ^ declare_args' (n1) args *)
(*     | [] -> "" *)
(*   in declare_args' 1 args *)

(* declare all local variables before body *)
and declare_locals body = 
  let locals = find_locals body in
  let declare_local (var,t) = 
    indent 1 ^ var ^" "^string_of_dbtype t^";\n" in
    String.concat "" (map declare_local locals)

(* Get PL/pgSQL type for typed_data *)
let rec get_dbtype : typed_data -> dbtype = 
  fun (`T (_, t, _)) -> dbtype_of_datatype t
    
(* Get PL/pgSQL type for datatype *)
and dbtype_of_datatype : Types.datatype -> dbtype =
  let get_ltype {Types.ltype=t} = t in
  fun t -> match get_ltype t with
    | `Not_typed -> failwith "get_dbtype: not typed"
    | `Primitive p -> begin match p with
        | `Bool -> DBBool
        | `Int  -> DBInt
        | `Char -> DBChar
        | `Float -> DBFloat
        | `XmlItem -> nyi "dbtype_of_datatype: XmlItem"
        | `DB -> nyi "dbtype_of_datatype: DB"
        | `Abstract -> nyi "dbtype_of_datatype: Abstract"
        | `NativeString -> DBString
      end
    | `MetaTypeVar point -> 
        begin
          match Unionfind.find point with
            | Types.Body t -> dbtype_of_datatype t
            | Types.Recursive (_, t) -> dbtype_of_datatype t
            | Types.Rigid n ->
                (* I'm not sure if this is always the case, 
                   but this is sometimes polymorphic *)
                DBAny
            | Types.UncheckedRecursive (n,t) ->
                nyi ("dbtype_of_datatype: MetaTypeVar:UncheckedRecursive "^ 
                       Printsyntax.string_of_datatype t)
            | Types.Flexible n ->
                nyi ("dbtype_of_datatype: MetaTypeVar:Flexible")

        end
    | `Function (_f, _a, t) -> dbtype_of_datatype t
    | `Variant (_,_) -> DBLabel DBUnknown
    | `Record (_,_) -> DBLabel DBUnknown
    | `Application ("String", []) -> DBString
    | `Application ("List", []) -> DBList DBUnknown
    | `Application (_, _) -> DBLabel  DBUnknown (* TODO: this shouldn't grab typenames *)
    | `Table (_, _)             -> nyi "dbtype_of_datatype: Table"

(* Give the correct "getter" to unbox a Postgres Label into a base type *)
let gen_getter var t = 
  let fname,args = match t with
      DBInt    -> "unbox_int", [var]
    | DBString -> "unbox_string", [var]
 (* | DBString -> "unbox_string", [`Call (`Var ("tuple_arg", DBTuple), [var])] *)
    | DBLabel _  -> "tuple_arg", [var; `Lit "1"]
    | DBTuple _ -> "variant_arg", [var]
    | DBBool -> "unbox_bool", [var]
    | DBFloat -> "unbox_float", [var]
    | DBChar -> "unbox_char", [var]
    | DBAny -> nyi "gen_getter: DBAny"
    | DBUnknown -> nyi "gen_getter: DBUnknown"
    | DBList _ -> nyi "gen_getter: DBList"
  in `Call (`Var (fname, DBTuple DBUnknown), args)

(* Generate a DB code AST from the Links AST. 
   The global_names argument is currently ignored. *)
let rec generate global_names : expression -> code =
  let gen expr =  generate global_names expr in
    function
      | HasType (e, _, _) -> gen e
      | Constant (c, _) -> begin
          match c with
            | Integer v  -> `Lit (string_of_num v)
            | Float v    -> `Lit (string_of_float v)
            | Boolean v  -> `Lit (string_of_bool v)
            | Char v     -> `Lit (string_of_char v)
                (* TODO: this string should be db-escaped via
                   db#escape_string, but we don't have access to db *)
            | String v   -> `Lit ("'"^ v ^"'")
        end
      | Condition (Comparison (_, `Equal, Record_intro _, _), then_, _, _) -> 
          gen then_             (* hack to handle Record_intro *)
      | Condition (if_, then_, else_, _) -> 
          `Cond (gen if_, gen then_, gen else_)
      | Variable (v, t) -> `Var (v, get_dbtype t)
      | Comparison (l, op, r, _) -> 
          let string_of_comp = function
              `Less -> "<" | `LessEq -> "<=" 
            | `Equal -> "=" | `NotEq -> "<>" in
          `Binop (gen l, string_of_comp op, gen r)
      | Abstr (arglist, body, t) ->
          let mkvar = function 
              `Var v -> v | _ -> failwith "mkvar requires `Var type" in
          `Fn (map (gen ->- mkvar) arglist, gen body, get_dbtype t)
      | Rec (bindings, Variable (var,_), _) ->
          let lookup = fun (name, _, _) -> name == var in
          let (_, abs, _) = find lookup bindings in 
          gen abs
      | Apply (Variable (op, _), [l; r], _) when mem_assoc op binop_builtins ->
          `Binop (gen l, string_of_binop op, gen r)
            (* ignore label/unlabel calls *)
      | Apply (Variable ("unlabel",_), arg::_, _) -> gen arg
      | Apply (Variable ("relabel",_), arg::_, _) -> gen arg
      | Apply (f, args, _) -> `Call (gen f, map gen args)
      | Let (v, e, b, t) -> `Bind ((v, get_dbtype t), gen e, gen b)
      | Variant_injection (v, e, _) -> `App (v, gen e)
      | Variant_selection (
          src, case_label, case_var, case_body, else_var, else_body, _
        ) ->
          let foo = (else_var, 1) in
          let pattern = `Lit ("'"^ case_label ^"'") in
          let src_code = gen src in
          let src_name = 
            `Call (`Var ("label_get_name", DBString), [src_code]) in
          let case_var_type = DBTuple DBUnknown in
          `Cond (
            `Binop (src_name, "=", pattern), 
            `Bind ((case_var, case_var_type), 
                   gen_getter src_code case_var_type,
                   gen case_body), 
            (* bjc: TODO: lots of extra copying that could be optimized away *)
            `Bind ((else_var, DBLabel DBUnknown), src_code, gen else_body)
          )
            
      | Variant_selection_empty (e, t) -> 
          let gen_e = gen e in
          gen_e

      | Record_intro (bs, r, _) ->
          let dict = 
            `Dict (StringMap.to_list (fun label e -> label, gen e) bs) in
          begin match r with
            | None -> dict
            | Some _ -> nyi "Record_intro: Some case"
          end

      | Record_selection (_, lv, etcv, r, b, _) ->
          let r' = gen r in
          let b' = gen b in
          (* bjc: TODO: this shouldn't always be DBLabel! *)
          let dbtype = dbtype_of_datatype (Syntax.node_datatype r) in
          (* let dbtype = DBLabel in *)
          let get_arg = gen_getter r' dbtype in
          `Bind ((lv,dbtype), get_arg, 
                 `Bind ((etcv,DBTuple DBUnknown), 
                        (* not sure what to do here wrt to new format *)
                        `Call (`Var ("tuple_tail", DBTuple DBUnknown), [r']),
                        b'))
      | Wrong _ -> `Die "Internal Error: Pattern matching failed"

      | x -> failwith ("Internal Error: PL/pgSQL gen failed with " ^
                         "unknown AST object: " ^ 
                         string_of_expression x)

(* PL/pgSQL requires an explicit return statement *)
let rec add_return : code -> code = fun e -> match e with
    `Var _ -> `Ret e
  | `Lit _ -> `Ret e
  | `App _ -> `Ret e
  | `Binop _ -> `Ret e
  | `Cond (e1, e2, e3) -> `Cond (e1, add_return e2, add_return e3)
  | `Bind (v, e1, e2) -> `Bind (v, e1, add_return e2)
  | `Fn (args, e, t) -> `Fn (args, add_return e, t)
  | `Comment (c, e) -> `Comment (c, add_return e)
  | `Call _ -> `Ret e
  | `Dict _ -> `Ret e
  | `Ret _ -> e
  | _ -> e

(* Rename variable identifiers via f *)
let rename_var (f:string -> string) e =
  let rec rename = function
      `Var (v,t) -> `Var (f v,t)
    | `App (n, e) -> `App (n, rename e)
    | `Bind (v, e1, e2) -> `Bind (v, rename e1, rename e2)
    | `Cond (e1, e2, e3) -> `Cond (rename e1, rename e2, rename e3)
    | `Binop (e1, op, e2) -> `Binop (rename e1, op, rename e2)
    | `Fn (vs, e, t) -> `Fn (vs, rename e, t)
    | `Call  (e, es) ->  `Call (rename e, map rename es)
    | `Dict terms -> `Dict (map (fun (v,e) -> (v, rename e)) terms)
    | `Lit v -> `Lit v
    | `Comment (c,e) -> `Comment (c, rename e)
    | `Defs defs -> `Defs (map (fun (v,e) -> (v, rename e)) defs)
    | `Nothing -> `Nothing
    | `Ret e -> `Ret (rename e)
    | `Die m -> `Die m
  in rename e
       
(* Generate a DB code AST from a Links definition.
   Currently, only definitions designated as "database" are used *)
let generate_def global_names : 'a definition' -> code = 
  function
    | Define (n, e, `Policy, _) -> begin
        Printf.fprintf stderr "Exporting %s to PL/pgSQL ...\n%!" n;
        let code = `Defs ([n, (generate global_names ->- add_return) e]) in
        (* In order to support (mututally-)recursive functions, 
           Links defines all possibly recursive functions as a list of 
           renamed bindings along with an entry point.
           PL/pgSQL natively supports recursive functions and doesn't support
           nested functions, so we ignore all the bindings and rename the 
           functions to their original names (via rename_var).
        *)
        match e with 
          | Rec (_, (Variable (var,_)), _) ->
              rename_var (fun x -> if x == var then n else x) code 
          | _ -> code
      end
    | _ -> `Nothing

(* Generate PL/pgSQL source code containing all the Links definitions  
   given in defs (and marked as "database") *)
let generate_program_defs defs _ =
  map (generate_def [] ->- show) defs
