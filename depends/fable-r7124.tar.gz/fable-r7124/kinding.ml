open Syntax
open Expression
open Expression.Types
open Expression.FableType
open Utility
open Typeenv

let kind_join l = 
  List.fold_left (fun a b -> FableType.kind_join (a,b)) UKind l
    
let datatype_kind env dt = 
  let rec datatype_kind rec_vars quants {ltype=lt; ftype=fq} = 
    let lt_k = match lt with 
      | `Not_typed -> raise (Bad_fable_type "Unexpected `Not_typed variant")
      | `Primitive p -> UKind
      | `Function (f, m, t) -> kind_join (List.map (datatype_kind rec_vars quants) [f;m;t])
      | `Record row -> row_kind rec_vars quants row
      | `Variant row -> row_kind rec_vars quants row
      | `Table (r, w) -> datatype_kind rec_vars quants r (* write view is a subset of read view *)
      | `Application (s, ts) -> (* need environment *)
	  let (q, d) = Typeenv.lookup_alias_old (s,ts) env in
	    datatype_kind rec_vars q d
      | `MetaTypeVar point ->
	  begin
            match Unionfind.find point with
	      | Flexible var 
              | Rigid var -> 
		  begin
		    try 
		      let (v, k) =
			List.find (function 
				       (`TypeVar q, _) 
				     | (`RigidTypeVar q, _) -> var = q 
				     | _ -> false) quants  in
			k
		    with
			Not_found -> UKind 
		  end
	      | Recursive (var, t) ->
                  if TypeVarSet.mem var rec_vars then
		    UKind
                  else
                    datatype_kind (TypeVarSet.add var rec_vars) quants t
	      | UncheckedRecursive (var, t) -> UKind (* This case is removed after types are checked *)
              | Body t -> datatype_kind rec_vars quants t
 	  end 
    in
      FableType.kind_join (lt_k, FableType.kind_qual fq)
  and field_spec_kind rec_vars quants key fspec kind = match fspec with
    | `Present t -> 
	let kind' = datatype_kind rec_vars quants t in
	  FableType.kind_join (kind, kind')
    | `Absent -> kind
  and field_spec_map_kind = fun rec_vars quants field_env ->
    StringMap.fold (field_spec_kind rec_vars quants) field_env UKind
  and row_kind = fun rec_vars quants (field_env, row_var) ->
    let fe_kind = field_spec_map_kind rec_vars quants field_env in
    let rv_kind = 
      match Unionfind.find row_var with
        | ClosedRow 
        | FlexibleRow _ 
        | RigidRow _ -> UKind
        | RecursiveRow (var, rec_row) ->
	    if TypeVarSet.mem var rec_vars then
	      UKind
	    else
              row_kind (TypeVarSet.add var rec_vars) quants rec_row
        | BodyRow row ->
	    row_kind rec_vars quants row in
      FableType.kind_join (fe_kind, rv_kind) in
    datatype_kind TypeVarSet.empty [] dt
