(*pp deriving *)
open Utility
open Syntax
open Expression
open Expression.Expr
open Expression.Types
open Expression.FableType
open List 

exception Subst of string 

type subst = (string * expression) list 
    deriving (Show)

let empty = []

let contains d s = 
  List.exists ((=) d -<- fst) s

let lookup d s = 
  let (_, res) = List.find ((=) d -<- fst) s in
    res

(* within the module, permit hiding; need this for substituting bound vars in recursive types *)
let extend (d, v) s = (d,v)::s

let remove v s = remove_assoc v s 

let union s s' =
  List.fold_right (fun (d,v) s' -> extend (d,v) s') s s'
    
let restrict : subst -> string list -> subst = fun s s' ->
  List.fold_left (fun sout l -> 
		    try
		      let v = List.assoc l s in
			(l,v)::sout
		    with 
			Not_found -> sout
		 ) empty s'
    
let domain (sigma: subst) = List.map fst sigma
  
let apply_e : subst -> expression -> expression = 
  let combine sigma (e,l) = 
    let ntails n l = 
      let rec splitter a m l = 
        if n = m then
          (rev a, l)
        else
          let hd::tl = l in
            splitter (hd::a) (m-1) tl in
      let len_l = length l in
        assert (n < len_l);
        splitter [] len_l l in
      match e,l with 
        | Variable(name, _), [] when contains name sigma -> lookup name sigma
            
        (* Zero arg cases *)
        | Constant _, []
        | Nil _, []
        | Wrong _, []
        | Variable _, [] -> e

        (* One arg cases *)
        | Variant_selection_empty (e, data), [e'] -> Variant_selection_empty (e', data)
        | Database (e, data), [e'] -> Database(e', data)
        | Variant_injection (s, e, data), [e'] -> Variant_injection (s, e', data)
        | Project (e, s, data), [e'] -> Project (e', s, data)
        | Erase (e, s, data), [e'] -> Erase(e', s, data)
        | List_of (e, data), [e'] -> List_of(e', data)
        | Call_cc(e, data), [e'] -> Call_cc(e', data)
        | Abs (e, data), [e'] -> Abs(e', data)
        | HasType (e, t, data), [e'] -> HasType(e', t, data)

        (* Two arg cases *)         
        | TableHandle (e1, e2, a, data), [e1';e2'] -> TableHandle(e1',e2',a,data)
        | Comparison (e1, a, e2, data), [e1';e2'] -> Comparison(e1',a,e2',data)
        | Let (a, e1, e2, data), [e1';e2'] -> Let(a,e1',e2',data)
        | Concat (e1, e2, data), [e1';e2'] -> Concat(e1',e2',data)
        | Record_selection (a, b, c, e1, e2, data), [e1';e2'] -> Record_selection (a, b, c, e1', e2', data)
        | Record_unpack (f, e1, e2, None,  data), [e1';e2'] -> Record_unpack (f, e1', e2', None, data)
        | Record_pack (f, e1, dt, e2,  data), [e1';e2'] -> Record_pack (f, e1', dt, e2', data)
        | For (e1, a, e2, data), [e1';e2'] -> For(e1', a, e2', data)
        | App (e1, e2, data), [e1';e2'] -> App(e1',e2',data)
        | SortBy (e1, e2, data), [e1';e2'] -> SortBy(e1',e2', data)
            
        (* Three arg cases *)       
        | Record_unpack (f, e1, e2, Some e3,  data), [e1';e2';e3'] -> Record_unpack (f, e1', e2', Some e3', data)
        | Condition (e1, e2, e3, data), [e1';e2';e3'] -> Condition (e1', e2', e3', data)
        | Variant_selection (e1, a, b, e2, c, e3, data), [e1';e2';e3']  -> Variant_selection (e1', a, b, e2', c, e3', data)

        (* N arg cases *)
        | Abstr (args, e, data), l when length l = (length args + 1) -> 
            let args', [e'] = ntails 1 l in
              Abstr(args', e', data)
                
        | TableQuery (es, q, data), l when length l = length es -> 
            TableQuery ((map2 (fun (s, e) e' -> (s, e')) es l), q, data)

        | Apply (e, es, data), e'::es' -> Apply(e',es',data)

        | Rec (b, e, data), l when (length l = length b + 1) -> 
            let b', [e'] = ntails 1 l in
              Rec (map2 (fun (a, e, b) e' -> (a,e',b)) b b', e', data)
                
        | Xml_node (a, es1, es2, data), l when (length l = length es1 + length es2) -> 
            let es1', es2' = ntails (length es2) l in
              Xml_node(a, map2 (fun (a, e) e' -> (a,e')) es1 es1', es2', data)
                
        | Record_intro (bs, r, data), l when (length l >= StringMap.size bs) ->
            let bs', r' = 
              StringMap.fold (fun key e (bs', (e'::tl)) -> 
                                StringMap.add key e' bs', tl) bs (StringMap.empty, l) in
            let r' = match r,r' with 
                None, [] -> None
              | Some(_), [r'] -> Some r' 
              | _ -> raise Impos in
              Record_intro (bs', r', data)            
        | _ -> raise Impos in
    fun sigma e ->
      Syntax.reduce_expression (fun x -> x) (combine sigma) e
        
type tft = FableType.fable_type

let apply_fq sigma q = 
  let rec apply_q = function
      `Empty -> `Empty
    | `KindVar v -> `KindVar v (* If we ever want to unify against more general fable qualifiers, then descend into the point here *)
    | `Kind k -> `Kind k
    | `Name (s,ft) -> `Name(s, apply_q ft)
    | `Labeling (el, ft) -> `Labeling (apply_e sigma el, apply_q ft)
    | `Label (`Nothing, ft) -> `Label(`Nothing, apply_q ft)
    | `Label (`Required e, ft) -> 
	`Label (`Required (apply_e sigma e), apply_q ft)
    | `Label(`Inferred pt, ft) -> 
	let ft' = apply_q ft in
	let e' = match Unionfind.find pt with
	    `Nothing -> `Inferred pt
	  | `Something e -> 
	      let e' = apply_e sigma e in
		`Inferred(Unionfind.fresh (`Something e')) in
	  `Label(e', ft')
    | `Phantom(sl, ft) -> 
	    if (list_intersect (domain sigma) sl) <> [] then
	      raise (Subst "Bad substitution: captured by bound var");
	    `Phantom(sl, apply_q ft) in
    apply_q q
      
let empty_annot lt = {ltype=lt;ftype=`Empty}
  
let rec apply rec_var_map (sigma : subst) : Types.datatype -> Types.datatype =
  let apply_l dt : Types.datatype = 
    let app = apply rec_var_map sigma in 
      
    let app_record_fsm fsm = 
      let labels = List.sort (fun (k,_) (k',_) -> compare k k') (StringMap.to_alist fsm) in
      let fsm', _ = List.fold_left (fun (fsm', sigma) (label, _) -> match StringMap.find label fsm with
					`Absent -> StringMap.add label `Absent fsm', sigma
				      | `Present t -> 
					  let t' = apply rec_var_map sigma t in
					  let sigma' = 
					    match Fable.get_name_bindings t.ftype with
						[], None -> sigma
					      | [], Some n -> remove n sigma in
					    StringMap.add label (`Present t') fsm', sigma'
				   ) (StringMap.empty, sigma) labels in
	fsm' in
      
    let app_fsm fsm = StringMap.fold (fun k t fsm -> match t with 
					| `Absent -> StringMap.add k `Absent fsm
					| `Present dt -> StringMap.add k (`Present (app dt)) fsm
				     ) fsm (StringMap.empty) in
      match dt.ltype with 
          `Not_typed 
        | `Primitive _ as t -> empty_annot t
        | `Function (arg, mb, ret) -> 
	    let phantoms, nopt = Fable.get_name_bindings arg.ftype in
	    let sigma1 = List.fold_left (fun sigma v -> remove v sigma) sigma phantoms in
	    let arg' = apply rec_var_map sigma1 arg in
	    let sigma2 = match nopt with 
	      | None -> sigma1
	      | Some n -> remove n sigma1 in
	    let mb' = apply rec_var_map sigma2 mb in
	    let ret' = apply rec_var_map sigma2 ret in
	      empty_annot  (`Function (arg', mb', ret'))
        | `Record row -> 
	    let (fsm, rv), rec_var = unwrap_row row in
	    let fsm' = app_record_fsm fsm in
	      (match rec_var with 
		   None -> ()
		 | Some _  -> failwith "Unexpected recursive row");
	      empty_annot (`Record(fsm', rv))
        | `Variant row -> 
	    let (fsm, rv), rec_var = unwrap_row row in
	    let fsm' = app_fsm fsm in
	      (match rec_var with 
		   None -> ()
		 | Some _ -> failwith "Unexpected recursive row");
	      empty_annot(`Variant(fsm', rv))
        | `Table(t1, t2) ->  empty_annot (`Table(app t1, app t2))
        | `Application(s, dtl) -> empty_annot (`Application(s, List.map app dtl))
        | `MetaTypeVar mtv -> 
            match Unionfind.find mtv with 
              | Body t -> app t
              | Recursive (v, t) -> 
		  if list_intersect (Fable.free_names Typeenv.empty t) (domain sigma) <> [] then 
		    failwith "Unexpected free names within recursive type";
		  empty_annot dt.ltype    
		    (* 		  if IntMap.mem v rec_var_map then *)
		    (* 		    empty_annot (IntMap.find v rec_var_map) *)
		    (* 		  else *)
		    (* 		    let var = Types.fresh_raw_variable () in *)
		    (* 		    let point = Unionfind.fresh (Flexible var) in *)
		    (* 		    let result = `MetaTypeVar point in *)
		    (* 		    let rec_var_map' = IntMap.add v result rec_var_map in  *)
		    (* 		    let t' = apply rec_var_map' sigma t in *)
		    (* 		      Unionfind.change point (Recursive(var, t')); *)
		    (* 		      empty_annot result *)
              | _ -> empty_annot dt.ltype
  in
    fun dt -> 
      let dt' = apply_l dt in
      let ft' = FableType.combine (apply_fq sigma dt.ftype) dt'.ftype in
	{ltype=dt'.ltype; ftype=ft'}
	  
let apply (sigma : subst) dt = 
  if sigma = empty then
    dt
  else apply IntMap.empty sigma dt



let rename_bound_vars = 
  let rec rename_vars_fq sigma fq = match fq with
    | `KindVar _
    | `Kind _
    | `Empty -> fq, sigma

    | `Name (name, fq') ->
	let fq', _ = rename_vars_fq sigma fq' in
	let name' = Utility.gensym ~prefix:"fab" () in
	  `Name(name', fq'), (extend (name, Variable(name', `T(dummy_position, Fable.fresh_label_type(), None))) sigma)

    | `Phantom(el, fq) -> 
	let sigma', el' = List.fold_left (fun (sigma, el') name -> 
					    let name' = Utility.gensym ~prefix:"fab" () in
					    let sigma' = extend (name, Variable(name', `T(dummy_position, Fable.fresh_label_type(), None))) sigma  in
					      sigma', name'::el'
					 ) (sigma, []) el in
	let fq', sigma' = rename_vars_fq sigma' fq in
	  `Phantom(List.rev el', fq'), sigma'

    | `Labeling (el,fq) ->
	let fq', _ = rename_vars_fq sigma fq in
	let el' = apply_e sigma el in
	  `Labeling(el', fq'), sigma

    | `Label (`Nothing, fq) -> 
	let fq', _ = rename_vars_fq sigma fq in
	  `Label(`Nothing, fq'), sigma

    | `Label (`Required e, fq) ->
	let fq', _ = rename_vars_fq sigma fq in
	let e' = apply_e sigma e in
	  `Label(`Required e', fq'), sigma 

    | `Label (`Inferred pt, fq) -> 
	let fq', _ = rename_vars_fq sigma fq in
	let e' = match Unionfind.find pt with
	    `Nothing -> `Inferred pt
	  | `Something e -> 
	      let e' = 	apply_e sigma e in
		`Inferred(Unionfind.fresh (`Something e')) in
	  `Label(e', fq'), sigma  in
    
  let rec rename_vars_record_row rec_vars sigma row = 
    let (fsm, row_var), rec_row_var = unwrap_row row in
      (match rec_row_var with
         | None -> ()
         | Some e -> raise (Subst "Don't handle recursive rows yet"));
      let labels = Fable.row_labels_inorder fsm in 
      let fsm', _ = List.fold_left (fun (fsm', sigma) (l,fs) -> 
                                      match fs with
                                          `Absent -> StringMap.add l `Absent fsm', sigma
                                        | `Present t -> 
                                            let t', sigma' = rename_vars_typ rec_vars sigma t in
                                            let fsm' = StringMap.add l (`Present t') fsm' in
                                              fsm', sigma'
                                   ) (StringMap.empty, sigma) labels in
        (fsm', row_var), sigma
  and rename_vars_row rec_vars sigma row : row * subst =
    let (fsm, row_var), rec_row_var = unwrap_row row in
      match rec_row_var with
          None -> 
            let labels = List.sort compare (StringMap.fold (fun key _ l -> key :: l) fsm []) in
            let fsm' = List.fold_left (fun fsm' l -> 
                                         match StringMap.find l fsm with
                                             `Absent -> StringMap.add l `Absent fsm'
                                           | `Present t -> 
                                               let t', _ = rename_vars_typ rec_vars sigma t in
                                               let fsm' = StringMap.add l (`Present t') fsm' in
                                                 fsm'
                                      ) StringMap.empty labels in
              (((fsm', row_var), sigma) : row * subst)
        | Some pt -> match Unionfind.find pt with
            | RecursiveRow (v,r) -> 
                if IntMap.mem v (snd rec_vars) then
                  row, sigma
                else
                  let v' = fresh_raw_variable() in
                  let rv' = make_row_variable v' in
                  let rec_vars' = fst rec_vars, IntMap.add v rv' (snd rec_vars) in
                  let r', sigma = rename_vars_row rec_vars' sigma r in
                    Unionfind.change rv' (RecursiveRow(v', r'));
                    r', sigma
            | _ -> raise Impos 
  and rename_vars_typ rec_vars sigma {ltype=lt; ftype=fq} =
    let fq', sigma = rename_vars_fq sigma fq in
    let lt' = match lt with
      | `Function(argt, mb, ret) ->
          let argt', sigma' = rename_vars_typ rec_vars sigma argt in
          let mb', _ = rename_vars_typ rec_vars sigma' mb in
          let ret', _ = rename_vars_typ rec_vars sigma' ret in
            `Function(argt', mb', ret')
      | `Record row ->  
          let row', _ = rename_vars_record_row rec_vars sigma row in
            `Record row'
      | `Variant row -> 
          let row', _ = rename_vars_row rec_vars sigma row in
            `Variant row'
      | `Application (alias, vars) -> 
          `Application(alias, List.map (fst -<- (rename_vars_typ rec_vars sigma)) vars)
      | `MetaTypeVar pt ->
          begin
            match Unionfind.find pt with
              | Body t -> 
		  let t', _ = rename_vars_typ rec_vars sigma t in 
		    (* 		    t'.ltype *)
		    (*  		  let pt' = Unionfind.fresh (Flexible (fresh_raw_variable ())) in *)
		    Unionfind.change pt (Body t');
		    `MetaTypeVar pt
              | Recursive (i, t) -> 
                  if IntMap.mem i (fst rec_vars) then
                    IntMap.find i (fst rec_vars)
                  else
                    let var = fresh_raw_variable () in
                    let pt' = Unionfind.fresh (Flexible var) in
                    let result  = `MetaTypeVar pt' in
                    let rec_vars' = IntMap.add i result (fst rec_vars), (snd rec_vars) in
                    let t',_ = rename_vars_typ rec_vars' sigma t in
                      Unionfind.change pt' (Recursive (var, t'));
                      result
              | _ -> `MetaTypeVar pt
          end
      | _ -> lt (* TODO: fix this! *) in
      {ltype = lt'; ftype = fq'}, sigma
  in
    fun t -> 
      let t', _ = rename_vars_typ (IntMap.empty, IntMap.empty) empty t in
        t'

(* External interface; no hiding allowed *)
let extend (d, v) s = 
  (* bjc: line below causes errors with deletes and updates *)
  (* if contains d s then *)
  (*   raise (Subst ("Substitution already contains "^d^" in its domain")) *)
  (* else *)
    (d,v)::s

let union s s' =
  List.fold_right (fun (d,v) s' -> extend (d,v) s') s s'
