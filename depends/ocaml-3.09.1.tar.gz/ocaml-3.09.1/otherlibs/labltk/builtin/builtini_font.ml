let cCAMLtoTKfont (s : font) = TkToken s
let cTKtoCAMLfont (s : font) = s

