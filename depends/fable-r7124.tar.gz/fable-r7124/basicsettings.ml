(**
 Whether to run the interactive loop
 (default is true)
*)
let interacting = Settings.add_bool ("interacting", true, `System)

(** [true] if we're in web mode *)
let web_mode = Settings.add_bool ("web_mode", false, `System)

(** [true] if we're in DB export mode *)
let db_mode = Settings.add_bool ("db_mode", false, `System)

(** [true] if we're not enforcing the M-kind restriction on clients *)
let unsafe_client_mode = Settings.add_bool ("unsafe_client_mode", true, `System)

(** Set this to [true] to print types when printing results. *)
let printing_types = Settings.add_bool ("printing_types", true, `User)

(** Name of the file containing the prelude code. *)
let prelude_file = Settings.add_string ("prelude", "prelude.links", `System)

(** The prompt *)
let ps1 = Settings.add_string ("ps1", "links> ", `User)

(** The banner *)
let welcome_note = Settings.add_string ("welcome_note", 
"  .___._____   _     _ __    _ _  __  ___
 /  ___| ___\\ / |   | |  \\  | | |/ / / ._\\
|  /  | |__.  | |   | | , \\ | |   /  \\  \\
 \\. \\ |  __|  | |___| | |\\ \\  | |\\ \\ _\\  \\
___\\  \\ |___, |_____|_|_| \\___|_| \\_|____/
======/====/===============================
Welcome to SELinks version 0.2 (Doughoregan)", `System)

(** Installed preprocessor *)
let pp = Settings.add_string("preprocessor", "", `System)

(** Module path (currently only used by preprocessor *)
let module_path = Settings.add_string("module_path", "", `System)
