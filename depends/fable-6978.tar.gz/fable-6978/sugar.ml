open Num
open List

open Utility
open Syntax
open Expression
open Expression.Expr
open Expression.Types
open Sugartypes

exception ConcreteSyntaxError of (string * (Lexing.position * Lexing.position))
exception PatternDuplicateNameError of (position * string * string)

module LName : sig
  val has_lnames : phrasenode -> bool
  val replace_lname : phrase -> phrase
end = 
struct

  let apply pos name args = `FnAppl ((`Var name,pos), (args,pos)), pos

  let server_use name pos = 
    apply pos "assoc" [(`StringLit name, pos);
                       apply pos"environment" []]
  let client_use id pos = 
    apply pos "getInputValue" [(`StringLit id, pos)]

  let fresh_names = 
    let counter = ref 0 in
    (fun () -> 
       incr counter;
       ("_lnameid_" ^ string_of_int !counter,
        "lname_" ^ string_of_int !counter))

  let desugar_lnames (p : phrase) : phrase * (string * string) StringMap.t = 
    let lnames = ref StringMap.empty in
    let add lname (id,name) = lnames := StringMap.add lname (id,name) !lnames in
    let attr : string * phrase list -> (string * phrase list) list = function
      | "l:name", ([`StringLit v, pos] as rhs) -> 
          let id, name = fresh_names () in
          add v (id,name);
          [("name", [`StringLit name, pos]); ("id", [`StringLit id, pos])]
      | "l:name", _ -> failwith ("Invalid l:name binding")
      | a -> [a] in
    let rec aux (p,pos as node : phrase) = match p with
      | `Xml (tag, attrs, children) ->
          let attrs = concat_map attr attrs
          and children = List.map aux children in
          `Xml (tag, attrs, children), pos
      | _ -> node
    in 
    let p' = aux p in
    p', !lnames

  let rec has_lnames : phrasenode -> bool = function
    | `Xml (_, attrs, children) ->
        List.mem_assoc "l:name" attrs || List.exists (fst ->- has_lnames) children
    | _ -> false

  let let_in pos name rhs body = 
    `Block
      ([`Binding ((`Variable name, pos), rhs), pos], body),
    pos

  let bind_lname_vars pos lnames = function
    | "l:action" as attr, es -> 
        attr, (List.map (StringMap.fold 
                           (fun var (_,name) -> let_in pos var (server_use name pos))
                           lnames) 
                 es)
    | attr, es when start_of attr ~is:"l:on" -> 
      attr, (List.map (StringMap.fold
                         (fun var (id,_) -> let_in pos var (client_use id pos))
                         lnames)
               es)
    | attr -> attr

  let replace_lname = function
    | `Xml (("form"|"FORM") as form, attrs, children), pos ->
        let children, lnames = List.split (List.map desugar_lnames children) in
        let lnames = 
          try List.fold_left StringMap.union_disjoint StringMap.empty lnames 
          with StringMap.Not_disjoint (item, _) ->
            raise (ConcreteSyntaxError ("Duplicate l:name binding: " ^ item, pos)) in
        let attrs = List.map (bind_lname_vars pos lnames) attrs in
        `Xml (form, attrs, children), pos
    | e -> e
end



type pattern = [
| `Any
| `Nil
| `Cons of (P.ppattern * P.ppattern)
| `List of (P.ppattern list)
| `Variant of (string * P.ppattern option)
| `Record of ((string * P.ppattern) list * P.ppattern option)
| `Tuple of (P.ppattern list)
| `Constant of P.phrase
| `Variable of string
| `As of (string * P.ppattern)
| `HasType of P.ppattern * P.ddatatype
]

type fieldconstraint = [ `Readonly | `Marshalledby of P.phrase]
    
(* Beware : this doesn't descend into regexes; 
   the caller has to rig combine to do that separately *)
let fold_reduce_phrase (visitor : (phrase -> 'env -> ('env * 'a)) -> phrase -> 'env -> ('env * 'a))
    (combine : ((phrase * ('env * 'a list)) -> ('env * 'a))) : phrase -> 'env -> ('env * 'a) = 
  let rec visit_children p env =
    let visit_generator g env = match g with
        `List (_,p) 
      | `Table (_,p)
      | `DepTable (_, p) -> visitor visit_children p env in
    let folder (env, pl) p =
      let env, p' = visitor visit_children p env in
      env, (p'::pl) in
    combine 
      (p, match fst p with
           
         (* Nullary cases *)
         | `FloatLit _
         | `IntLit _
         | `StringLit _
         | `BoolLit _
         | `CharLit _
         | `Var _
         | `Foreign _
         | `Include _
         | `InfixDecl
         | `Section _
         | `TypeDeclaration _
         | `TextNode _ 
         | `ConstructorLit (_, None) -> env, []
             
         (* Unary cases *)
         | `UnpackBinding (_, p)
         | `PackBinding ((_,p), _)
         | `Binding (_,p) 
         | `FunLit (_, _, p) 
         | `Spawn p 
         | `Definition (_, p, _) 
         | `Escape (_,p)
         | `UnaryAppl (_, p) 
         | `Projection (p, _) 
         | `TypeAnnotation (p, _) 
         | `FormBinding (p, _)
         | `ConstructorLit (_, Some p) 
         | `DBDelete ((_,p), None) 
         | `DatabaseLit(p, (None, None)) -> 
             let env, p' = visitor visit_children p env in 
             env, [p']
               
         (* Binary cases *)
         | `Formlet (p1, p2) 
         | `InfixAppl (_, p1, p2)
         | `HandleWith (p1, _, p2) 
         | `SortBy_Conc (_, p1, p2)
         | `TableLit (p1, _, _, p2) 
         | `DBInsert (p1, p2)
         | `DBDelete ((_,p1), Some p2) 
         | `DatabaseLit(p1, (Some p2, None))
         | `DatabaseLit(p1, (None, Some p2)) ->  
             let env, p1' = visitor visit_children p1 env in
             let env, p2' = visitor visit_children p2 env in
             env, [p1'; p2']
               
         (* Ternary cases *)               
         | `ViewLit (p1, p2, p3)
         | `Conditional (p1, p2, p3) 
         | `DatabaseLit(p1, (Some p2, Some p3)) -> 
             let env, p1' = visitor visit_children p1 env in
             let env, p2' = visitor visit_children p2 env in
             let env, p3' = visitor visit_children p3 env in
             env, [p1'; p2';p3']
               
         (* N-ary cases *)
         | `ListLit pl
         | `TupleLit pl -> 
             let env, pl' = List.fold_left folder (env,[]) pl in
             env, List.rev pl'
               
         (* special cases *)               
         | `Receive bl ->
             let env, pl' = List.fold_left (flip ((flip folder) -<- snd)) (env,[]) bl in
             env, List.rev pl'
               
         | `Block (pl, p) 
         | `FnAppl (p, (pl, _)) -> 
             let env, pl' = List.fold_left folder (env, []) (p::pl) in
             env, List.rev pl'
               
         | `RecordLit (npl, Some p)
         | `With (p, npl)  ->
             let env, p' = visitor visit_children p env in
             let env, pl' = List.fold_left (flip ((flip folder) -<- snd)) (env,[]) npl in
             env, (p'::(List.rev pl'))                       
               
         | `RecordLit (npl, None) -> 
             let env, pl' = List.fold_left (flip ((flip folder) -<- snd)) (env,[]) npl in
             env, List.rev pl'
               
         | `Switch(p, bl) -> 
             let env, p' = visitor visit_children p env in
             let env, pl' = List.fold_left (flip ((flip folder) -<- snd)) (env,[]) bl in
             env, (p'::(List.rev pl'))                       
               
         | `Iteration (generator, p, None, None) -> 
             let env, pg = visit_generator generator env in
             let env, p' = visitor visit_children p env in
             env, [pg; p']
               
         | `Iteration (generator, p1, Some p2, None) 
         | `Iteration (generator, p1, None, Some p2) -> 
             let env, pg = visit_generator generator env in
             let env, p1' = visitor visit_children p1 env in
             let env, p2' = visitor visit_children p2 env in
             env, [pg; p1'; p2']
               
         | `Iteration (generator, p1, Some p2, Some p3) ->
             let env, pg = visit_generator generator env in
             let env, p1' = visitor visit_children p1 env in
             let env, p2' = visitor visit_children p2 env in
             let env, p3' = visitor visit_children p3 env in
             env, [pg; p1'; p2'; p3']
               
         | `DBUpdate ((_,p), None, npl) ->
             let env, p' = visitor visit_children p env in
             let env, pl' = List.fold_left (flip ((flip folder) -<- snd)) (env,[]) npl in
             env, (p'::(List.rev pl'))                       
               
         | `DBUpdate ((_,p1), Some p2, npl) -> 
             let env, p1' = visitor visit_children p1 env in
             let env, p2' = visitor visit_children p2 env in
             let env, pl' = List.fold_left (flip ((flip folder) -<- snd)) (env,[]) npl in
             env, (p1'::p2'::(List.rev pl'))                         
               
         | `Xml (_, npl_l, pl) -> 
             let env, pl_l' = List.fold_left (fun (env, pl_l') (_, pl) -> 
							                    let env, pl' = List.fold_left folder (env,[]) pl in
							                    (env, pl'::pl_l')) (env, []) npl_l in
             let env, pl' = List.fold_left folder (env,[]) pl in			 
			 env, List.concat (List.rev (pl'::pl_l'))
               
         (* Note: be careful about this. *)                
         | `Regex regex -> env, []) in
  visitor visit_children    

let default_combine : (phrase * ('a * phrase list)) -> ('a * phrase) = fun (phrase, (env, pl)) ->
  let split_n_m n l = 
    let rec splitter a m l = 
      if n = m then
        (rev a, l)
      else
        let hd::tl = l in
        splitter (hd::a) (m+1) tl in
    let len_l = length l in
    assert (n < len_l);
    splitter [] 0 l in
  let combine_generator g p' = match g with
      `List (x,p) -> `List(x,p')
    | `Table (x,p) -> `Table(x,p')
    | `DepTable (x, p) -> `DepTable (x, p') in

  let node,pos = phrase in 
  let node' = match node, pl with
      (* Nullary cases *)
    | `FloatLit _, []
    | `IntLit _, []
    | `StringLit _, []
    | `BoolLit _, []
    | `CharLit _, []
    | `Var _, []
    | `Foreign _, []
    | `Include _, []
    | `InfixDecl, []
    | `Section _, []
    | `TypeDeclaration _, []
    | `TextNode _, []
    | `ConstructorLit (_, None), [] -> node
        
    (* Unary cases *)
    | `UnpackBinding (x, p), [p'] -> `UnpackBinding (x, p')
    | `PackBinding ((x,p), y), [p'] -> `PackBinding ((x,p'), y)
    | `Binding (x,p), [p'] -> `Binding (x,p')
    | `FunLit (x, y, p), [p'] -> `FunLit(x,y,p') 
    | `Spawn p, [p'] -> `Spawn p'
    | `Definition (x, p, y), [p'] -> `Definition (x, p', y)
    | `Escape (x,p), [p'] -> `Escape (x,p')
    | `UnaryAppl (x, p), [p'] ->  `UnaryAppl (x, p')
    | `Projection (p, x), [p'] -> `Projection (p', x) 
    | `TypeAnnotation (p, x), [p'] -> `TypeAnnotation (p', x) 
    | `FormBinding (p, x), [p'] -> `FormBinding (p', x)
    | `ConstructorLit (x, Some p), [p'] -> `ConstructorLit (x, Some p') 
    | `DBDelete ((x,p), None), [p'] -> `DBDelete ((x,p'), None)
    | `DatabaseLit(p, (None, None)), [p'] -> `DatabaseLit(p', (None, None))
        
    (* Binary cases *)
    | `Formlet (p1, p2), [p1';p2'] ->  `Formlet (p1', p2')
    | `InfixAppl (x, p1, p2), [p1';p2'] -> `InfixAppl (x, p1', p2')
    | `HandleWith (p1, x, p2), [p1';p2'] ->  `HandleWith (p1', x, p2')
    | `SortBy_Conc (x, p1, p2), [p1';p2'] -> `SortBy_Conc (x, p1', p2')
    | `TableLit (p1, x, y, p2), [p1';p2'] ->  `TableLit (p1', x, y, p2')
    | `DBInsert (p1, p2), [p1';p2'] -> `DBInsert (p1', p2')
    | `DBDelete ((x,p1), Some p2), [p1';p2'] ->  `DBDelete ((x,p1'), Some p2')
    | `DatabaseLit(p1, (Some p2, None)), [p1';p2'] -> `DatabaseLit(p1', (Some p2', None))
    | `DatabaseLit(p1, (None, Some p2)), [p1';p2'] ->  `DatabaseLit(p1', (None, Some p2'))
        
    (* Ternary cases *)                    
    | `ViewLit (p1, p2, p3), [p1';p2';p3'] ->  `ViewLit (p1', p2', p3')
    | `Conditional (p1, p2, p3), [p1';p2';p3'] -> `Conditional (p1', p2', p3')
    | `DatabaseLit(p1, (Some p2, Some p3)), [p1';p2';p3'] -> 
        `DatabaseLit(p1', (Some p2', Some p3'))
        
    (* N-ary cases *)
    | `ListLit pl, pl' -> `ListLit pl'
    | `TupleLit pl, pl' -> `TupleLit pl'
        
    (* Special cases *)                    
    | `Receive bl, pl' -> `Receive (List.map2 (fun (b,p) p' -> (b,p')) bl pl)

        
    | `Block (pl, p), p'::pl' ->`Block (pl', p')
    | `FnAppl (p, (pl, x)), p'::pl' -> `FnAppl (p', (pl', x))

    | `RecordLit (npl, Some p), p'::pl' -> 
        let npl' = List.map2 (fun (n,p) p' -> (n,p')) npl pl' in
        `RecordLit (npl', Some p')
          
    | `With (p, npl), p'::pl'  ->
        let npl' = List.map2 (fun (n,p) p' -> (n,p')) npl pl' in
        `With (p', npl')
          
    | `RecordLit (npl, None), pl' -> 
        let npl' = List.map2 (fun (n,p) p' -> (n,p')) npl pl' in
        `RecordLit (npl', None)
          
    | `Switch(p, bl), p'::pl' -> 
        let bl' =  List.map2 (fun (b,p) p' -> (b,p')) bl pl' in
        `Switch(p', bl')
          
    | `Iteration (g, p, None, None), [pg;p'] -> 
        `Iteration (combine_generator g pg, p', None, None)

    | `Iteration (g, p1, Some p2, None), [pg;p1';p2'] -> 
        `Iteration (combine_generator g pg, p1', Some p2', None)

    | `Iteration (g, p1, None, Some p2), [pg;p1';p2'] -> 
        `Iteration (combine_generator g pg, p1', None, Some p2')

    | `Iteration (g, p1, Some p2, Some p3), [pg;p1';p2';p3'] -> 
        `Iteration (combine_generator g pg, p1', Some p2', Some p3')
          
    | `DBUpdate ((x,p), None, npl), p'::pl' ->
        let npl' = List.map2 (fun (n,p) p' -> (n,p')) npl pl' in
        `DBUpdate ((x,p'), None, npl')

    | `DBUpdate ((x,p1), Some p2, npl), p1'::p2'::pl' -> 
        let npl' = List.map2 (fun (n,p) p' -> (n,p')) npl pl' in
        `DBUpdate ((x,p1'), Some p2', npl')

    | `Xml (x, npl_l, pl), pll' -> 
	    let (npl_l', pl') = 
	      List.fold_left (fun (npl_l', pll') (n, pl) -> 
			                let (pl', pll') = split_n_m (length pl) pll' in
				            (n,pl')::npl_l', pll') ([], pll') npl_l in
	    `Xml (x, List.rev npl_l', pl')
          
    (* Note: be careful about this. *)                     
    | `Regex regex, [] -> `Regex regex in
  env, (node', pos)
    

(* Internal representation for patterns. 

   This is slightly easier for the pattern compiler to work with than
   what comes out of the parser, which contains lots of n-ary
   patterns (e.g.  {x=a,y=b|z}).
*)
type 'r a_pattern = [
| `Nil
| `Cons of ('r * 'r)
| `Variant of (string * 'r)
| `Record of (string * 'r * 'r)
| `Constant of untyped_expression
| `Variable of string
| `As of (string * 'r)
| `HasType of ('r * Types.u_datatype)
]

let appPrim pos name args = 
  Apply (Variable (name, pos), args, pos)

type simple_pattern = simple_pattern a_pattern * Expression.untyped_data

let mk_variable name data = function
    None -> Variable(name, data)
  | Some(t) -> HasType(Variable(name, data), t, data)

let is_variable_pattern : simple_pattern -> bool = function
    `Variable _, _
  | `HasType((`Variable _, _), _), _ -> true
  | _ -> false

(** Construct a Links list out of a list of Links expressions; all
    will have the source position [pos].
*)
let make_links_list pos elems =
  let concat_expr l r = Concat(l, r, pos) in
  fold_right concat_expr elems (Nil pos)

(** Returns a (Syntax-format) function that plugs some given XML in as
    the contents of an XML element having the given tag name and attributes. *)
let make_xml_context tag (attrs:(string * untyped_expression) list) data = 
  let hole = gensym() in
  Abstr([mk_variable hole data None], Xml_node(tag, attrs, [Variable(hole, data)], data), data)

(* Various specializations of [gensym] *)
let unique_name () = Utility.gensym ()
let db_unique_name = Utility.gensym ~prefix:"Table"

let list_head expr pos = 
  Apply(Variable ("hd", pos), [expr], pos)

let list_tail expr pos = 
  Apply(Variable ("tl", pos), [expr], pos)

let show_desugared = Settings.add_bool("show_desugared", false, `User)
let show_sugared = Settings.add_bool("show_sugared", false, `User)

let unit_hack = Settings.add_bool("pattern_unit_hack", false, `User)
let cons_unit_hack = Settings.add_bool("pattern_cons_unit_hack", true, `User)

exception RedundantPatternMatch of Expression.position
module PatternCompiler =
  (*** pattern matching compiler ***)
  (*
    This is similar to the pattern matching compiler described by
    Phil Wadler in Chapter 5 of 'The Implementation of Functional
    Programming Languages, Simon Peyton Jones, 1987'.
    
    It is not yet optimised and can result in duplication of terms. In
    order to improve the pattern matching implementation, we may need
    to adjust our intermediate language.
  *)
  (struct
     let show_pattern_compilation = Settings.add_bool("show_pattern_compilation", false, `User)

     type annotation = string list * Types.u_datatype list
     type annotated_pattern = annotation * simple_pattern

     type ('a, 'b) equation_basis = 'a list * 'b

     type raw_equation = (simple_pattern, untyped_expression) equation_basis
     type equation = (annotated_pattern, (untyped_expression * bool ref)) equation_basis
     type annotated_equation = annotation * equation

     let string_of_equation = string_of_expression -<- fst -<- snd

     type pattern_env = untyped_expression StringMap.t

     type bound_expression = pattern_env -> untyped_expression

     type pattern_type = [ | `List | `Variant | `Record | `Constant | `Variable ]

     let rec get_pattern_type : simple_pattern -> pattern_type = 
       fun (p,_) -> match p with
         | `Nil | `Cons _ -> `List
         | `Variant _ -> `Variant
         | `Record _ -> `Record
         | `Constant _ -> `Constant
         | `Variable _ -> `Variable
         | `As (_, pattern) -> get_pattern_type pattern
         | `HasType (pattern, _) -> get_pattern_type pattern

     let get_equation_pattern_type : equation -> pattern_type =
       fun ((_, pattern)::_, _) -> get_pattern_type pattern

     let get_equations_pattern_type : equation list -> pattern_type =
       fun (((_, pattern)::_, _)::_) -> get_pattern_type pattern

     let string_of_constant =
       let soc = function    
         | Expression.Boolean v -> string_of_bool v
         | Expression.Integer v -> string_of_num v
         | Expression.Char v -> string_of_char v
         | Expression.String v -> v
         | Expression.Float v -> string_of_float v
       in
       function
         | Expression.Expr.Constant (c, _) -> soc c
         | Expression.Expr.Record_intro (fields, None, _) when StringMap.is_empty fields -> "()"

     (* compile away top-level As and HasType patterns *)
     let rec reduce_pattern : simple_pattern -> annotated_pattern = function
       | `As (name, pattern), _ ->
           let (names, datatypes), pattern = reduce_pattern pattern in
           (name::names, datatypes), pattern
       | `HasType (pattern, datatype), _ ->
           let (names, datatypes), pattern = reduce_pattern pattern in
           (names, datatype::datatypes), pattern
       | pattern -> ([], []), pattern

     let reduce_equation : raw_equation -> equation =
       fun (ps, body) ->
         (map reduce_pattern ps, (body, ref false))

     (* partition equations sequentially by pattern type *)
     let partition_equations : equation list -> (equation list) list =
       function
         | [] -> []
         | equations ->
             let (_, es, ess) =
               List.fold_right
                 (fun equation (t, es, ess) ->
                    let t' = get_equation_pattern_type equation in
                    let es', ess' =
                      (* group non-variable patterns of the same type *)
                      if es = [] || ((t' = t) && (t' <> `Variable)) then
                        equation::es, ess
                      else
                        [equation], es::ess
                    in
                    (t', es', ess')) equations (`Variable, [], [])
             in
             es::ess

     (* partition list equations by constructor *)
     let partition_list_equations : equation list -> (annotated_equation list * annotated_equation list) =
       fun equations ->
         List.fold_right (fun (ps, body) (nil_equations, cons_equations) ->
                            match ps with
                              | (annotation, (`Nil,_))::ps ->
                                  (annotation, (ps, body))::nil_equations, cons_equations
                              | (annotation, (`Cons (px, pxs),_))::ps ->
                                  let px = reduce_pattern px in 
                                  let pxs = reduce_pattern pxs in
                                  nil_equations, (annotation, (px::pxs::ps, body))::cons_equations
                              | _ -> assert false) equations ([], [])

     (* Question: But what about the ordering of equations? *)
     (* Answer: This only reorders equations in which the constructors are different; 
	    order between equations with the same constructor is preserved ... and that's what matters *)
     (* partition variant equations by constructor *)
     let partition_variant_equations
         : equation list -> (string * ((string * string) * annotated_equation list)) list =
       fun equations ->
         StringMap.to_alist 
           (List.fold_right 
              (fun (ps, body) env ->
                 match ps with
                   | (annotation, (`Variant (name, pattern),_))::ps ->
                       let vars, annotated_equations = 
                         if StringMap.mem name env then
                           StringMap.find name env
                         else
                           (unique_name (), unique_name ()), [] in
                       let pattern = reduce_pattern pattern
                       in
                       StringMap.add name (vars, (annotation, (pattern::ps, body))::annotated_equations) env
                   | _ -> assert false
              ) equations StringMap.empty)

     (* partition record equations by label *)
     let partition_record_equations
         : equation list -> (string * ((string * string) * annotated_equation list)) list =
       fun equations ->
         StringMap.to_alist
           (List.fold_right
              (fun (ps, body) env ->
                 match ps with
                   | (annotation, (`Record (name, pattern, ext_pattern),_))::ps ->
                       let vars, annotated_equations =
                         if StringMap.mem name env then
                           StringMap.find name env
                         else
                           (unique_name (), unique_name ()), [] in
                       let pattern = reduce_pattern pattern in
                       let ext_pattern = reduce_pattern ext_pattern
                       in
                       StringMap.add name (vars, (annotation, (pattern::ext_pattern::ps, body))::annotated_equations) env
                   | _ -> assert false
              ) equations StringMap.empty)

     (* partition constant equations by constant value *)
     let partition_constant_equations
         : equation list -> (string * (untyped_expression * annotated_equation list)) list =
       fun equations ->
         StringMap.to_alist
           (List.fold_right
              (fun (ps, body) env ->
                 match ps with
                   | (annotation, (`Constant exp,_))::ps ->
                       let name = string_of_constant exp in
                       let exp, annotated_equations = 
                         if StringMap.mem name env then
                           StringMap.find name env
                         else
                           exp, []
                       in
                       StringMap.add name (exp, (annotation, (ps, body))::annotated_equations) env
                   | _ -> assert false
              ) equations StringMap.empty)

     (* 
        create a let binding,
        inlining it if the bound expression is a variable
     *)
     let bind_or_subst (var, exp, body, pos) =
       match exp with
         | Variable (var', _) ->
             Syntax.rename_free var var' body
         | _ -> Let (var, exp, body, pos)

     (* 
        apply an annotation to an expression
        - rename variables
        - move type annotations into the expression
     *)
     let apply_annotation : Expression.untyped_data -> untyped_expression -> annotation * untyped_expression -> untyped_expression =
       fun pos exp ((names, datatypes), body) ->
         let body = List.fold_right (fun name body ->
                                       bind_or_subst (name, exp, body, pos)) names body in
         let body = List.fold_right (fun datatype body ->
                                       Let ("_", HasType (exp, datatype, pos), body, pos)) datatypes body
         in
         body

     (* apply annotations in an annotated equation list *)
     let apply_annotations : Expression.untyped_data -> untyped_expression -> annotated_equation list -> equation list =
       fun pos exp annotated_equations ->
         map (fun (annotation, (ps, (body, used))) ->
                (ps, (apply_annotation pos exp (annotation, body), used))) annotated_equations

     (*
       [TODO]
       - better error messages
     *)
     (*
       Redundant patterns
       ------------------
       
       We say that an equation or pattern matching clause is redundant
       if its continuation can never be invoked. We only care about
       redundancy of the raw equations passed as input to the
       pattern matching compiler (i.e. the clauses of a switch
       statement in the source code). We say that a switch statement is
       redundant if at least one of its clauses is redundant.

       Two kinds of redundancy can arise in pattern matching:
       - control-flow:
       when it can be proven that a continuation can never be
       invoked, by a static analysis of the control flow
       - type-oriented:
       when it can be proven that a continuation can never be
       invoked, using type information

       The pattern-matching compiler is deliberately designed *not* to
       take into account type information, in order that it can be used
       effectively with static typing disabled. Therefore we do not
       attempt to detect type-oriented redundancy here.

       We do detect (and report as an error) control-flow redundancy.
       Control-flow redundancy checking is implemented by attaching a
       'used' flag to the body of each continuation. The used flag is
       initialised to false, and set to true whenever a continuation
       is used in the compiled program. After compiling the equations
       a check is made to ensure that all continuations have been used.

       Control-flow redundancy arises when two consecutive patterns
       are equivalent under the assumption that variables in the first
       pattern can be instantiated to any pattern.

       Examples:
       - switch (x) { case(x,1) -> 1; case (0,1) -> 2;}
       is redundant because 0 in the second pattern has already been
       matched by x in a context where all the other sub-patterns are
       identical
       
       -  switch (x) { case(A(B(C(1,2,3)))) -> 0; case(A(B(C(1,2,3)))) -> 1;}
       is redundant because the two patterns are identical

       An example of type-oriented redundancy:
       - switch (x) { case(true) -> 0; case(false) -> 1; case(x) -> 2 }
       The third clause is redundant as true and false cover the whole
       of the type Bool.
     *)

     (*
       Nonexhaustive matches
       ---------------------
       
       We do not attempt to detect non-exhaustive matches as this
       requires a type-directed analysis. However, the way we handle
       variant matching ensures that non-exhaustive matches of
       variants will be ill-typed.

       Non-exhaustive matches can occur when matching constant or
       list patterns.
     *)

     (*
       [NOTE]
       this abstraction is deliberate as we may want to change it - e.g.
       if we want to share default continuations in the resulting term
       rather than simply inlining them as we do now.
     *)
     let apply_default def env =
       def env

     let lookup var (env : pattern_env) =
       try
         StringMap.find var env
       with
           Not_found -> failwith ("Variable: "^var^" not in environment (lookup)")

     let is_trivial var (env : pattern_env) =
       match lookup var env with
         | Variable (var', _) when var=var' -> true
         | _ -> false

     (* add a binding to the environment
        first applying it to all the other expressions in the environment
     *)
     let extend var exp (env : pattern_env) =
       let env = StringMap.fold
         (fun var' exp' env ->
            StringMap.add var' (Syntax.subst_free var exp exp') env) env StringMap.empty 
       in
       StringMap.add var exp env

     (* extend the environment with a list of trivial bindings
        i.e binding each var_i to Variable(var_i, pos)

        (we assume the bindings do not occur in the existing environment,
        so do not have to traverse the existing environment)
     *)
     let extend_trivial pos vars : pattern_env -> pattern_env =
       List.fold_right (fun var env ->
                          extend var (Variable (var, pos)) env) vars
         
     (* the entry point to the pattern-matching compiler *)
     let rec match_cases
         : Expression.untyped_data -> string list -> equation list ->
       bound_expression -> bound_expression          
       =
       fun pos vars equations def (env : pattern_env) ->
         match vars, equations with 
           | [], [] -> apply_default def (env : pattern_env)
           | [], ([], (body, used))::_ -> used := true; body
               (* identical patterns could be detected here if we wanted *)
               (*           | [], ([], _)::_ -> failwith "Redundant pattern"*)
           | var::vars, _ ->
               let equationss = partition_equations equations in
               List.fold_right
                 (fun equations exp ->
                    (match get_equations_pattern_type equations with
                       | `List ->
                           match_list pos vars (partition_list_equations equations) exp var
                       | `Variant ->
                           match_variant pos vars (partition_variant_equations equations) exp var
                       | `Variable ->
                           match_var pos vars equations exp var
                       | `Record ->
                           match_record pos vars (partition_record_equations equations) exp var
                       | `Constant ->
                           match_constant pos vars (partition_constant_equations equations) exp var)
                 ) equationss def env

     and match_var
         : Expression.untyped_data -> string list -> equation list ->
       bound_expression -> string -> bound_expression
       =
       fun pos vars equations def var (env : pattern_env) ->
         match_cases pos vars
           (List.map (fun ((annotation, pattern)::ps, (body, used)) ->
                        let var_exp = lookup var env in
                        let body = apply_annotation pos var_exp (annotation, body)
                        in
                        match pattern with
                          | (`Variable var',_) ->
                              (ps,
                               (bind_or_subst (var', var_exp, body, pos), used))
                          | _ -> assert false) equations) def env

     and match_list
         : Expression.untyped_data -> string list -> (annotated_equation list * annotated_equation list)
       -> bound_expression -> string -> bound_expression =
       fun pos vars (nil_equations, cons_equations) def var env ->
         let var_exp = lookup var env in

         let nil_equations = apply_annotations pos var_exp nil_equations in
         let cons_equations = apply_annotations pos var_exp cons_equations in
         let nil_branch =
           match nil_equations with
             | [] -> apply_default def env
             | _ ->
                 match_cases pos vars nil_equations def env in
         let cons_branch =
           match cons_equations with
             | [] -> apply_default def env
             | _ ->
                 let x = unique_name () in
                 let xs = unique_name () in
                 let env = extend_trivial pos [x; xs] env
                 in
                 Let(x, list_head var_exp pos,
                     Let(xs, list_tail var_exp pos,
                         match_cases pos (x::xs::vars) cons_equations def env,
                         pos), pos)
         in
         (Condition(Comparison(var_exp, `Equal, Expression.Expr.Nil pos, pos),
                    nil_branch,
                    cons_branch, pos))

     and match_variant
         : Expression.untyped_data -> string list -> ((string * ((string * string) * annotated_equation list)) list) ->
       bound_expression -> string -> bound_expression =
       fun pos vars bs def var env ->
         match bs with
           | [] ->
               apply_default def env
           | (name, ((case_variable, default_variable), annotated_equations))::bs ->
               let var_exp = lookup var env in

               let var_as_exp var = Variable (var, pos) in
               let inject var = Variant_injection(name, var_as_exp var, pos) in
               let empty var = Variant_selection_empty(var_as_exp var, pos) in
               
               let equations = apply_annotations pos (inject case_variable) annotated_equations in
               (*
                 close variant types when possible
                 
                 [NOTE]
                 this has the side-effect of manifesting non-exhaustive matches
                 on polymorphic variants as type errors.
               *)
               let massage_wrong var = function
                 | Wrong _ ->
                     empty var
                 | e -> e in


               let match_branch case_variable =
                 let match_env =
                   extend_trivial pos [case_variable]
                     (extend var (inject case_variable) env)
                 in
                 match_cases pos (case_variable::vars) equations def match_env in
               let default_branch default_variable =
                 let default_env = 
                   extend_trivial pos [default_variable]
                     (extend var (var_as_exp default_variable) env)
                 in
                 massage_wrong default_variable
                   (match_variant pos vars bs def default_variable default_env) (*in*)

               in
               (* is this worth doing here / does it ever happen? *)
               (*
                 match lookup var env with
                 | Variant_injection(name', Variable(case_variable, _), _) ->
                 if name=name' then
                 match_branch case_variable
                 else
                 default_branch default_variable
                 | _ ->
               *)
               Variant_selection(var_exp, name,
                                 case_variable,
                                 match_branch case_variable,
                                 default_variable,
                                 default_branch default_variable,
                                 pos)       
     and match_record
         : Expression.untyped_data -> string list ->
       ((string * ((string * string) * annotated_equation list)) list) ->
       bound_expression -> string -> bound_expression =
       fun pos vars bs def var env ->
         match bs with
           | [] -> apply_default def env
           | (name, ((label_variable, extension_variable), annotated_equations))::bs ->
               let var_exp = lookup var env in
               let equations = apply_annotations pos var_exp annotated_equations in
               (* is this worth doing here / does it ever happen? *)
               (*
                 match var_exp with
                 | Record_intro(StringMap.add name' (Variable (label_variable, _)) StringMap.empty,
                 Some (Variable (extension_variable, _)),
                 _) when name=name' ->
                 match_cases
                 pos
                 (label_variable::extension_variable::vars)
                 equations
                 (match_record pos vars bs def var)
                 env
                 | _ ->
               *)
               let env =
                 extend_trivial pos [label_variable; extension_variable]
                   (extend var (Record_intro(
                                  StringMap.add name (Variable (label_variable, pos)) StringMap.empty,
                                  Some (Variable (extension_variable, pos)),
                                  pos))
                      env)
               in                        
               Record_selection
                 (name,
                  label_variable,
                  extension_variable,
                  var_exp,
                  match_cases
                    pos
                    (label_variable::extension_variable::vars)
                    equations
                    (match_record pos vars bs def var)
                    env,
                  pos)

     and match_constant
         : Expression.untyped_data -> string list -> (string * (untyped_expression * annotated_equation list)) list
       -> bound_expression -> string -> bound_expression =
       fun pos vars bs def var env ->
         match bs with
           | [] -> apply_default def env
           | (name, (exp, annotated_equations))::bs ->
               let var_exp = lookup var env in
               let equations = apply_annotations pos var_exp annotated_equations in
               (match exp with
                  | Record_intro (fields, None, _)
                      when Settings.get_value unit_hack 
                        && StringMap.is_empty fields ->
                      (* 
                         This is the only place in the pattern
                         matching compiler that we do type-directed
                         optimisation. By default unit_hack is
                         disabled and cons_unit_hack is enabled (see
                         the use of cons_unit_hack below for further
                         details).

                         Enabling unit_hack allows the compiler to
                         make the assumption that a comparison with
                         unit will always succeed. This assumption
                         is sound providing we're using static
                         typing.
                      *)
                      Let ("_", HasType (var_exp, Types.unit_type (), pos),
                           match_cases pos vars equations def env, pos)
                  | _ ->
                      (Condition(Comparison(var_exp, `Equal, exp, pos),
                                 match_cases pos vars equations def env,
                                 match_constant pos vars bs def var env,
                                 pos)))
                 
     (* the interface to the pattern-matching compiler *)
     let match_cases
         : (Expression.untyped_data * untyped_expression * raw_equation list) -> untyped_expression =
       fun (`U (p1, _, _) as pos, exp, raw_equations) ->
         Debug.if_set (show_pattern_compilation)
           (fun () -> "Compiling pattern match: "^ p1.Lexing.pos_fname);
         let var, wrap =
           match exp with
             | Variable (var, _) ->
                 var, Utility.identity
             | _ ->
                 let var = unique_name()
                 in
                 var, fun body -> Let (var, exp, body, pos)
         and equations = map reduce_equation raw_equations in
         let initial_env = StringMap.add var (Variable (var, pos)) StringMap.empty in
         let result = wrap (match_cases pos [var] equations (fun _ -> Wrong pos) (initial_env : pattern_env))
         in
         Debug.if_set (show_pattern_compilation)
           (fun () -> "Compiled pattern: "^(string_of_expression result));
         if (List.for_all (fun (_, (_, used)) -> !used) equations) then
           result
         else
           raise (RedundantPatternMatch (Syntax.data_position pos))
   end 
     : 
    sig
      type raw_equation = simple_pattern list * untyped_expression
      val match_cases : (Expression.untyped_data * untyped_expression * raw_equation list) -> untyped_expression
    end)

module Desugarer : sig 
  val normalize_type : Expression.Types.u_datatype -> Expression.Types.datatype
  val desugar_expression : (pposition -> Expression.position) -> phrase -> Syntax.untyped_expression
  val desugar_definitions : (pposition -> Expression.position) -> phrase list -> Syntax.untyped_definition list
  val desugar_datatype : (pposition -> Expression.position) -> Sugartypes.datatype -> Expression.Types.u_assumption
  val fresh_type_variable : unit -> Sugartypes.datatype
end = 
struct
  (* Convert a syntax tree as returned by the parser into core syntax *)
  type quantifier = [`TypeVar of string | `RigidTypeVar of string | `RowVar of string] * Types.kind

  (* Generation of fresh type variables *)
  let type_variable_counter = ref 0
  let fresh_type_variable : unit -> datatype =
    function () -> 
      incr type_variable_counter; TypeVar ("_" ^ string_of_int (!type_variable_counter))
	    
  let raise_data_pos_err pos err = raise (ASTSyntaxError (Syntax.data_position pos, err))

  let rec typevars (kind_decls : (string * Types.kind) list) : datatype -> quantifier list = 
    let lookup_var_kind vk_map t =
      try 
	    let (_, k) = List.find ((=) t -<- fst) vk_map in
	    Some k
      with
	      Not_found -> None
    in
    let rec rvars qlist (fields, rv) =
      let qlist' = match rv with
        | `Closed   -> qlist
        | `Open s -> (* TODO: What about kind annots on RowVars? *)
	        let rv = `RowVar s in
		    (match lookup_var_kind qlist rv with 
		         None -> (rv, FableType.UKind)::qlist
		       | Some k -> qlist)
        | `Recursive (s, r) ->
	        let ql = rvars qlist r in
		    List.filter (fun (rv,_) -> match rv with 
		                     `RowVar s' when s=s' -> false
		                   | _ -> true) ql
      in
	  List.fold_left 
	    (fun ql -> function
		     (_, `Present k) -> tvars ql k
           | _ -> ql) qlist' fields 

    and tvars_TypeVar s qlist = 
	  let tv = `TypeVar s in 
	  match lookup_var_kind qlist tv with 
		| None -> (
		    match lookup_var_kind kind_decls s with
			  | None -> (tv, FableType.UKind)::qlist
			  | Some k -> (tv, k)::qlist
          )
		| Some k -> qlist

    and tvars_RigidTypeVar s m qlist = 
      let tv = `RigidTypeVar s in
      match m with
        | None -> (
	        match lookup_var_kind qlist tv with 
		        None -> (
		          match lookup_var_kind kind_decls s with
			        | None -> (tv, FableType.UKind)::qlist
		            | Some k -> (tv, k)::qlist
                )
		      | Some k -> qlist
          )
        | Some k ->
            let k = FableType.string_as_kind k in
            let err = ConcreteSyntaxError (* TODO: fix position *)
              ("Inconsistent type variable kinds", 
               (Lexing.dummy_pos, Lexing.dummy_pos))
            in
            match lookup_var_kind qlist tv with 
		      | None -> (
		          match lookup_var_kind kind_decls s with 
			        | None -> (tv, k)::qlist
			        | Some k' when k=k' -> (tv, k)::qlist 
			        | _ -> raise err
                )
		      | Some k' when k = k' -> qlist
		      | _ -> raise err

    and tvars qlist = function
      | TypeVar s -> tvars_TypeVar s qlist
      | RigidTypeVar (s, m) -> tvars_RigidTypeVar s m qlist
      | FunctionType (s, m, t) -> 
	      let qlist' = List.fold_left tvars qlist s in
	      tvars (tvars qlist' m) t
      | MuType (v, k) ->
 	      let ql = tvars qlist k in
	      List.filter (fun (tv,_) -> match tv with 
		                   `RigidTypeVar v' when v=v' -> false
		                 | _ -> true) ql
      | TupleType ks -> 
	      List.fold_left tvars qlist ks 
      | RecordType r
      | VariantType r -> rvars qlist r
      | TableType (r, w) -> 
	      let ql' = tvars qlist r in
	      tvars ql' w
      | ListType k -> tvars qlist k
      | TypeApplication (_,ks) -> List.fold_left tvars qlist ks

      | UnitType
      | PrimitiveType _
      | DBType -> qlist
      | PhantomBinding(_, dt) 
      | LabelType (dt, _) 
      | NamedType(_, dt)
      | LabeledType (dt, _) -> tvars qlist dt 
    in
    fun datatype -> tvars [] datatype
	    
  let rec alias_is_closed vars t =
    let aic = alias_is_closed vars in
    match t with
	  | LabeledType(dt, _) 
	  | LabelType(dt, _) 
	  | NamedType(_, dt) 
	  | PhantomBinding(_, dt) -> aic dt
      | TypeVar var
      | RigidTypeVar (var,_) -> StringSet.mem var vars
      | FunctionType (s, m, t) -> 
          List.for_all aic s && (
            match m with
              | TypeVar var -> true
              | _ -> aic m
          ) && aic t
      | MuType (v, k) ->
          alias_is_closed (StringSet.add v vars) k
      | TupleType ks ->
          List.for_all aic ks
      | RecordType r
      | VariantType r -> row_alias_is_closed vars r
      | TableType (r, w) -> aic r && aic w
      | ListType k -> aic k
      | TypeApplication (_,ks) -> List.for_all aic ks
      | UnitType
      | PrimitiveType _
      | DBType -> true

  and row_alias_is_closed vars (fields, rv) =
    List.for_all (
      function
        | (_, `Present k) -> alias_is_closed vars k
        | (_, `Absent) -> true
    ) fields
    && row_var_alias_is_closed vars rv

  and row_var_alias_is_closed vars =
    function
      | `Closed -> true
      | `Open var -> StringSet.mem var vars
      | `Recursive (v, r) ->
          row_alias_is_closed (StringSet.add v vars) r

  type assumption = quantifier list * datatype

  let generalize (k : datatype) : assumption =
    typevars [] k, k

  type var_env =
      (Types.meta_type_var * Types.kind) StringMap.t *
        (Types.row_var  * Types.kind) StringMap.t 

  let generate_var_mapping : quantifier list -> (Types.quantifier list * var_env) =
    fun quals ->
      List.fold_right
        (fun (v,k) (quals, (tenv, renv)) ->
           let var = Types.fresh_raw_variable () in
           match v with
             | `TypeVar name ->
                 ((`TypeVar var, k)::quals,
                  (StringMap.add name
                     (Unionfind.fresh (Flexible var), k) tenv, renv))
             | `RigidTypeVar name ->
                 ((`RigidTypeVar var,k)::quals,
                  (StringMap.add name
                     (Unionfind.fresh (Rigid var), k) tenv, renv))
             | `RowVar name ->
                 ((`RowVar var,k)::quals,
                  (tenv, StringMap.add name
                     (Unionfind.fresh (FlexibleRow var), k) renv))) quals ([], (StringMap.empty, StringMap.empty))

  let rec adapt_fq : FableType.unchecked_fable_type -> FableType.fable_type = 
    let adapt_data : untyped_data -> typed_data = function 
        `U pos -> `T(pos, {ltype=`Not_typed;ftype=`Empty}, None) in
    (*      let adapt_exp : untyped_expression -> expression =  *)
    (*        Expression.DerivingSyntax.Functor_expression'.map_both adapt_data  *)
    (*          (fun _ -> raise (ASTSyntaxError(Syntax.dummy_position, "Type annotations within type-level expressions are not permitted"))) in *)
    let adapt_exp : untyped_expression -> expression = 
      Expression.DerivingSyntax.Functor_expression'.map adapt_data in
    function
        `Empty -> `Empty
      | `KindVar kv -> raise Impos
      | `Kind k -> `Kind k
	  | `Label (`Nothing, fq) -> `Label(`Nothing, adapt_fq fq)
	  | `Label (`Inferred e, fq) -> raise Impos
	  | `Label (`Required e, fq) -> `Label(`Required(adapt_exp e), adapt_fq fq)
      | `Labeling (e, fq) -> `Labeling (adapt_exp e, adapt_fq fq)
      | `Name (s, fq) -> `Name(s, adapt_fq fq)
      | `Phantom(sl, fq) -> `Phantom(sl, adapt_fq fq) 

  let normalize_type dt = Types.functor_type adapt_fq dt
  let normalize_row row = Types.functor_row adapt_fq row

  let rec desugar_datatype lookup_pos = desugar lookup_pos

  and desugar_as_checked_type lookup_pos var_env dt : Types.datatype = 
    let (dt' :  u_datatype) = desugar lookup_pos var_env dt in
    normalize_type dt'

  and desugar lookup_pos ((tenv, renv) as var_env) : Sugartypes.datatype -> u_datatype = 
    let desugar = desugar lookup_pos in
    let lookup_type = flip StringMap.find tenv in
    function
        NamedType(name, dt) -> 
          let dt' = desugar var_env dt in
          let Variable(name, _) = desugar_expression lookup_pos name in
          Types.add_fable_annot dt' (FableType.name_annot name)
      | LabeledType(dt, p) -> 
          let dt' = desugar var_env dt in
          let e = desugar_expression lookup_pos p in
          Types.add_fable_annot dt' (FableType.labeling_annot e)
      | LabelType(dt, popt) -> 
          let dt' = desugar var_env dt in 
          let leopt = match popt with 
              None -> `Nothing
            | Some(p) -> `Required (desugar_expression lookup_pos p) in
          Types.add_fable_annot dt' (FableType.label_annot leopt)
      | PhantomBinding(pvars, dt) -> 
          let dt' = desugar var_env dt in 
          let pvars = List.map ((fun (Variable(n, _)) -> n ) -<- desugar_expression lookup_pos) pvars in
          Types.add_fable_annot dt' (FableType.phantom_annot pvars)
      | TypeVar s -> 
          (try 
             let (mtv, k) = lookup_type s in
             let lt = `MetaTypeVar mtv in
             Types.fable_annot lt (FableType.kind_as_annot k)
           with Not_found -> failwith ("Not found `"^ s ^ "' while desugaring assumption"))
      | RigidTypeVar (s, k) -> 
          (try 
             let (mtv, k) = lookup_type s in
             let lt = `MetaTypeVar mtv in
             Types.fable_annot lt (FableType.kind_as_annot k)
           with Not_found -> failwith ("Not found `"^ s ^ "' while desugaring assumption"))
      | MuType (name, t) ->
          let var = Types.fresh_raw_variable () in
          let point = Unionfind.fresh (Flexible var) in
          let tenv = StringMap.add name (point, FableType.UKind) tenv in (* TODO ... may not always be UKind *)
          let _ = Unionfind.change point (UncheckedRecursive (var, desugar (tenv, renv) t)) in
          let lt = `MetaTypeVar point in
          Types.def_fable_annot lt 
      | dt -> 
          let dt'= desugar_ldt lookup_pos var_env dt in
          Types.def_fable_annot dt'

  and desugar_ldt lookup_pos ((tenv, renv) as var_env) typ =
    let desugar = desugar lookup_pos in
    match typ with
      | FunctionType (f, m, t) ->
          let arg_type = match f with 
              [PhantomBinding _ as f] -> desugar var_env f
            | [NamedType _ as f] -> desugar var_env f
            | _ -> Types.make_tuple_utype (List.map (desugar var_env) f) in
          `Function (arg_type, 
                     desugar var_env m, 
                     desugar var_env t)
      | UnitType -> (Types.unit_type ()).ltype (* TODO : redundancy ... fix *)
      | TupleType ks -> 
          let labels = map string_of_int (Utility.fromTo 1 (1 + length ks)) 
          and unit = Types.make_empty_closed_row ()
          and present (s, x) = (s, `Present x)
          in `Record (fold_right2 (curry (Types.row_with -<- present)) labels (map (desugar var_env) ks) unit)
      | RecordType row -> `Record (desugar_row lookup_pos var_env row)
      | VariantType row -> `Variant (desugar_row lookup_pos var_env row)
      | TableType (r, w) -> `Table (desugar var_env r, desugar var_env w)
      | ListType k -> `Application ("List", [desugar var_env k])
      | TypeApplication (t, k) -> `Application (t, List.map (desugar var_env) k)
      | PrimitiveType k -> `Primitive k
      | DBType -> `Primitive `DB

  and desugar_row lookup_pos ((tenv, renv) as var_env) (fields, rv) =
    let lookup_row = flip StringMap.find renv in
    let seed = match rv with
      | `Closed -> Types.make_empty_closed_row ()
      | `Open rv ->
          let rv', k = lookup_row rv in
          (StringMap.empty, rv')
      | `Recursive (name, r) ->
          let var = Types.fresh_raw_variable () in
          let point = Unionfind.fresh (FlexibleRow var) in
          let renv = StringMap.add name (point, FableType.UKind) renv in (* TODO ... may not always be UKind *)
          let _ = Unionfind.change point (RecursiveRow (var, desugar_as_checked_row lookup_pos (tenv, renv) r)) in
          (StringMap.empty, point)
    and fields = map (fun (k, v) -> match v with
                        | `Absent -> (k, `Absent)
                        | `Present v -> (k, `Present (desugar_datatype lookup_pos var_env v))) fields 
    in fold_right Types.row_with fields seed

  and desugar_as_checked_row lp var_env frv = 
    let row' = desugar_row lp var_env frv in
    normalize_row row'
	  
  and desugar_assumption lookup_pos ((vars, k)  : assumption) : Types.u_assumption = 
    let vars, var_env = generate_var_mapping vars in
    vars, desugar_datatype lookup_pos var_env k
	  
  and get_type_vars p (* : phrase -> quantifier list *) =
    let union = (unduplicate (=)) -<- List.concat in
    (union -<- get_type_vars') p

  and get_type_vars' (s, _) =
    let empty = [] in
    let tv datatype = [typevars  [] datatype] in (* default: no explicit kind declarations *)
    let etv = get_type_vars' in
    let etvs = flatten -<- (List.map get_type_vars') in
    let opt_etv = function
      | None -> empty
      | Some e -> etv e in
    let opt_etv2 = function
      | None -> empty
      | Some (_, e) -> etv e in
    let ptv = get_pattern_type_vars in
    let btv (p, e) = flatten [ptv p; etv e] in
    let btvs = flatten -<- (List.map btv) in
    let gtv = function
      | `List b
      | `Table b
	  | `DepTable b -> btv b in
    let ftv (_, e) = etv e in
    let ftvs = flatten -<- (List.map ftv)
    in
    match s with
      | `FloatLit _
      | `IntLit _
      | `StringLit _
      | `BoolLit _
      | `CharLit _
      | `InfixDecl
      | `Section _
      | `Include _
      | `Regex _
      | `TextNode _
      | `Var _ -> empty

      | `FunLit (_, patterns, body) -> 
          flatten (concat_map (List.map ptv) patterns @ [etv body])
      | `Spawn e -> etv e
      | `ListLit es -> etvs es
      | `Definition (_, e, _) -> etv e
      | `Iteration (generator, body, filter, sort) ->
          flatten [gtv generator; etv body; opt_etv filter; opt_etv sort]
      | `Escape (_, e) ->  etv e
      | `HandleWith (e1, _, e2) -> flatten [etv e1; etv e2]
      | `Conditional (e1, e2, e3) -> flatten [etv e1; etv e2; etv e3]
      | `UnpackBinding b -> btv b
	  | `PackBinding (b,t) -> btv b @ tv t
      | `Binding b -> btv b
      | `Block (es, exp) -> flatten [etvs es; etv exp]
      | `Foreign (_, _, datatype) -> tv datatype
      | `InfixAppl (_, e1, e2) -> flatten [etv e1; etv e2]
      | `UnaryAppl (_, e) -> etv e
      | `FnAppl (fn, (ps, _)) -> flatten [etv fn; etvs ps]
      | `TupleLit fields -> etvs fields
      | `RecordLit (fields, e) ->
          flatten ((List.map (fun (_, field) -> etv field) fields) @ [opt_etv e])
      | `With (e, fields) -> 
          flatten ((List.map (fun (_, field) -> etv field) fields) @ [etv e])
      | `Projection (e, _) -> etv e
      | `SortBy_Conc(pattern, expr, sort_expr) -> flatten [ptv pattern; etv expr; etv sort_expr]
      | `TypeAnnotation(e, k) -> flatten [etv e; tv k]
      | `TypeDeclaration (_, args, datatype) -> 
		  let kind_decls = List.map (fun (n,k) -> (n, FableType.string_as_kind k)) args in
		  [List.map (fun (n,k) -> (`RigidTypeVar n, FableType.string_as_kind k)) args] 
          @ [typevars kind_decls datatype]
      | `ConstructorLit (_, e) -> opt_etv e
      | `Switch (exp, binders) -> flatten [etv exp; btvs binders]
      | `Receive (binders) -> btvs binders
      | `DatabaseLit (name, (opt_driver, opt_args)) -> 
          flatten [etv name; opt_etv opt_driver; opt_etv opt_args]
      | `TableLit (_, datatype, _, db) -> flatten [tv datatype; etv db]
      | `ViewLit (_, iter, db) -> flatten [etv iter; etv db]
      | `DBInsert (e1, e2) -> flatten [etv e1; etv e2]
      | `DBDelete ((p, e1), e2) -> flatten [ptv p; etv e1; opt_etv e2]
      | `DBUpdate ((p, e1), e2, fs) -> flatten [ptv p; etv e1; opt_etv e2; ftvs fs]
      | `Xml (_, attrs, subnodes) ->
          flatten ((List.map (fun (_, es) -> etvs es) attrs) @ [etvs subnodes])
      | `Formlet (e1, e2) -> flatten [etv e1; etv e2]
      | `FormBinding (e, p) -> flatten [etv e; ptv p]
	  | _ -> failwith "Fable constructors not yet handled"

  and get_pattern_type_vars (p, _) = (* fold *)
    match p with 
      | `Any
      | `Nil
      | `Variable _
      | `Variant (_, None)   -> []
      | `Variant (_, Some p)
      | `As (_, p)           -> get_pattern_type_vars p
      | `Cons (l, r)         -> get_pattern_type_vars l @ get_pattern_type_vars r
      | `Record (ps, Some p) -> concat_map (snd ->- get_pattern_type_vars) ps @ get_pattern_type_vars p
      | `Record (ps, None)   -> concat_map (snd ->- get_pattern_type_vars) ps
      | `List ps
      | `Tuple ps            -> concat_map get_pattern_type_vars ps 
      | `Constant pn         -> get_type_vars' pn
      | `HasType (p, t)      -> get_pattern_type_vars p @ [typevars [] t]

  (** With respect to scope of variables bound at the same level the
      rules are these:
      
      * Adjacent function definitions are mutually recursive with
      respect to the scope of their names.
      
      * Other function definitions are simply recursive
      
      * All other RHS can refer to previously established bindings
      (i.e.  bindings occuring textually previously.
  *)
  (* pattern-matching let *)
  and polylet : simple_pattern -> untyped_data -> untyped_expression -> 
    untyped_expression -> untyped_expression = 
    fun pat pos value body ->
      match fst pat with
        | `Nil ->
            (Condition(Comparison(value, `Equal, Expression.Expr.Nil pos, pos),
                       body,
                       Expression.Expr.Wrong pos, pos))
        | `Cons (head, tail) ->
            let name = unique_name () in
            let var = Variable (name, pos) in
            Let(name, value,
                polylet head pos (list_head var pos)
                  (polylet tail pos (list_tail var pos) body), pos)
        | `Variant (name, patt) ->
            let case_variable = unique_name () in
            let variable = unique_name () in
            Variant_selection(value, name,
                              case_variable,
                              (polylet patt pos (Variable (case_variable, pos)) body),
                              variable,
                              Variant_selection_empty(Variable(variable, pos), pos),
                              pos)
        | `Record (label, patt, rem_patt) ->
            let temp_var_field = unique_name () in
            let temp_var_ext = unique_name () in
            Record_selection (label,
                              temp_var_field,
                              temp_var_ext,
                              value,
                              polylet patt pos
                                (Variable (temp_var_field, pos))
                                (polylet rem_patt pos
                                   (Variable (temp_var_ext, pos))
                                   body),
                              pos)
        | `Constant c ->
            (Condition(Comparison(value, `Equal, c, pos),
                       body,
                       Expression.Expr.Wrong pos, pos))
        | `Variable name -> Let (name, value, body, pos)
        | `As (name, pattern) ->
            Let (name, value, polylet pattern pos (Variable (name, pos)) body, pos)
        | `HasType (pat, t) ->
            polylet pat pos (HasType (value, t, pos)) body

  and unpack_dependent_record : simple_pattern -> untyped_data -> untyped_expression 
    -> untyped_expression -> untyped_expression =
    fun pat pos value body ->
      let rec folder accu (pat :simple_pattern)  = match fst pat with 
	    | `Record(label, (`Variable v, _), rem_patt) -> 
	        let accu = (label,v)::accu in
	        (
              match fst rem_patt with 
		        | `Constant u when is_unit u -> List.sort (fun (l1, _) (l2, _) -> compare l1 l2) accu
		        | _ -> folder accu rem_patt
            )
	    | _ -> raise_data_pos_err pos
            "Unexpected pattern when opening dependent record"
      in
      let fields = folder [] pat in
	  Record_unpack(fields, value, body, None, pos)

  and pack_dependent_record : simple_pattern -> u_datatype -> untyped_data -> untyped_expression 
    -> untyped_expression -> untyped_expression =
    fun pat typ pos value body -> match fst pat with
	  | `Variable v -> Record_pack(v, value, typ, body, pos)
      | _ -> raise_data_pos_err pos
          "Unexpected pattern when packing a dependent record; only variables are permitted"
	        
	        
  and polylets (bindings : ([ `Simple of simple_pattern 
                            | `Unpack of simple_pattern 
                            | `Pack of (simple_pattern * Types.u_datatype)] * 
			                  untyped_expression * untyped_data * bool) list) expression =  
    let folder (patt, value, pos, recp) expr = 
      match patt, value, expr, recp with 
        | (`Simple (`Variable s, _)), Abstr _, Rec (bindings, e, p), _ ->  
            Rec ((s, value, None)  :: bindings, e, p) 
        | (`Simple (`Variable s, _)), Abstr _, _, true ->  
            Rec ([s, value, None], expr, pos) 
        | (`Simple patt, _, _, _) ->  
            polylet patt pos value expr 
	    | (`Unpack patt, _, _, _) -> 
	        unpack_dependent_record patt pos value expr 
	    | (`Pack (patt, dt), _, _, _) -> 
	        pack_dependent_record patt dt pos value expr
    in
    fold_right folder bindings expression 


  and string_of_pattern_pos ((pos : Lexing.position), _, expr) = 
    Printf.sprintf "%s:%d:%s" pos.Lexing.pos_fname pos.Lexing.pos_lnum expr
	  
  and check_for_duplicate_names' (env:StringSet.t) (pattern,pos) : StringSet.t =
    let (pos, dpos, expr) = data_position pos in      
    let module S = StringSet in
    let add elt set = 
      if S.mem elt set then
        raise (PatternDuplicateNameError ((pos, dpos, expr), elt, expr))
      else S.add elt set in
    let union = S.fold add in
    let rec names : simple_pattern a_pattern -> StringSet.t = function
      | (`Nil:simple_pattern a_pattern)
      | `Constant _ -> S.empty
      | (`HasType ((p,_), _):simple_pattern a_pattern)
      | `Variant (_, (p,_)) -> names p
      | `Cons ((l,_),(r,_))
      | `Record (_,(l,_),(r,_)) -> union (names l) (names r)
      | `Variable name -> S.singleton name 
      | `As (name, (p,_)) -> add name (names p)
    in union (names pattern) env

  (* give an error if the pattern has duplicate names *)
  and check_for_duplicate_names v =
    check_for_duplicate_names' StringSet.empty v
	  
  and as_list pos = function
    | `List (p, e) -> p, e
    | `Table (p, e) -> p, (`FnAppl ((`Var ("asList"), pos), ([e], pos)), pos)
    | `DepTable _ -> raise Utility.Impos

  and desugar_expression' env lookup_pos (e : phrase) : Syntax.untyped_expression =
    let _, ((tenv, renv) as var_env) = env
    in
    let result = desugar' var_env lookup_pos e in
    (Debug.if_set show_desugared (fun () -> string_of_expression result);
     result)

  and desugar_query ((s, pos'):phrase) : phrase = 
    match s with 
      | `Iteration(`DepTable(p,e), body, where_clause, sort_by) -> (
          match fst p, where_clause with 
            | `Variable rowname, Some where_clause -> 
                let replace_proj_combine : (phrase * (string StringMap.t * (phrase list))) -> (string StringMap.t * phrase) =
			      fun (phrase, (env, pl)) -> match (fst phrase) with 
                    | `Projection ((`Var rowname', _), fieldname) when rowname=rowname' -> 
			            if StringMap.mem fieldname env then
                          env, (`Var (StringMap.find fieldname env), snd phrase)
			            else
                          let sym = Utility.gensym() in
                          let env = StringMap.add fieldname sym env in
                          env, (`Var sym, snd phrase)
                    | _ -> (default_combine (phrase, (env, pl)) : string StringMap.t * phrase) in
                let unpack_env, where_clause' = fold_reduce_phrase (fun x -> x) replace_proj_combine where_clause StringMap.empty in
                let pat : (string * ppattern) list = StringMap.fold (fun (fn:string) vn pat -> ((fn, (`Variable vn, pos'))::pat)) unpack_env [] in
		        let pat : ppattern = `Record(pat, None), pos' in
		        let var : phrase = `Var rowname, pos' in
                let where_clause' : phrase = `Block([`UnpackBinding(pat, var), pos'], where_clause'), pos' in
			    `Iteration(`Table(p,e), body, Some where_clause', sort_by), pos' 
            | _ -> 
                `Iteration(`Table(p,e), body, where_clause, sort_by), pos'
        )
      | _ -> raise Utility.Impos

  and desugar' var_env lookup_pos ((s, pos') : phrase) : Syntax.untyped_expression =
    let pos = `U (lookup_pos pos')
    and patternize = simple_pattern_of_pattern var_env lookup_pos in
    let appPrim = appPrim pos in
    let desugar = desugar' var_env lookup_pos in
    match (s : phrasenode) with
      | `TypeAnnotation(e, k) -> HasType(desugar e, desugar_datatype lookup_pos var_env k, pos)
      | `FloatLit f  -> Constant(Float f, pos)
      | `IntLit i    -> Constant(Integer i, pos)
      | `StringLit s -> HasType(Constant(String  s, pos), Types.string_type (), pos)
      | `BoolLit b   -> Constant(Boolean b, pos)
      | `CharLit c   -> Constant(Char c, pos)
      | `Var v       -> Variable (v, pos)
      | `InfixAppl (`Name ">", e1, e2)  -> Comparison (desugar e2, `Less, desugar e1, pos)
      | `InfixAppl (`Name ">=", e1, e2)  -> Comparison (desugar e2, `LessEq, desugar e1, pos)
      | `InfixAppl (`Name "==", e1, e2)  -> Comparison (desugar e1, `Equal, desugar e2, pos)
      | `InfixAppl (`Name "<", e1, e2)  -> Comparison (desugar e1, `Less, desugar e2, pos)
      | `InfixAppl (`Name "<=", e1, e2)  -> Comparison (desugar e1, `LessEq, desugar e2, pos)
      | `InfixAppl (`Name "<>", e1, e2)  -> Comparison (desugar e1, `NotEq, desugar e2, pos)
      | `InfixAppl (`Name "++", e1, e2)  -> Concat (desugar e1, desugar e2, pos)
      | `InfixAppl (`Name "!", e1, e2)  -> appPrim "send" [desugar e1; desugar e2]
      | `InfixAppl (`Name n, e1, e2)  -> 
          let `U (a,b,_) = pos (* somewhat unpleasant attempt to improve error messages *) in 
          Apply (Variable (n,  `U (a,n,n)), [desugar e1; desugar e2], pos)
      | `InfixAppl (`Cons, e1, e2) -> Concat (List_of (desugar e1, pos), desugar e2, pos)
      | `InfixAppl (`RegexMatch, e1, (`Regex((`Replace(_,_) as r), flags), _)) -> 
          let libfn = 
            if(List.exists (function `RegexNative -> true | _ -> false) flags) then "sntilde" else "stilde" in
          (appPrim libfn
             [desugar e1;desugar (desugar_regex pos' r, pos')])
      | `InfixAppl (`RegexMatch, e1, (`Regex(r, flags), _)) -> 
          let native = (List.exists (function `RegexNative -> true | _ -> false) flags) in
          let libfn = 
            if (List.exists (function `RegexList -> true | _ -> false) flags) then 
              if native then "lntilde" else "ltilde"
            else 
              if native then "ntilde" else "tilde" in
          (appPrim libfn
             [desugar e1;desugar (desugar_regex pos' r, pos')])
      | `InfixAppl (`RegexMatch, _, _) -> raise_data_pos_err pos
          "Internal error: unexpected rhs of regex operator"
      | `InfixAppl (`FloatMinus, e1, e2)  -> appPrim "-." [desugar e1; desugar e2]
      | `InfixAppl (`Minus, e1, e2)  -> appPrim "-" [desugar e1; desugar e2]
      | `InfixAppl (`And, e1, e2) -> Condition (desugar e1, desugar e2, Constant(Boolean false, pos), pos)
      | `InfixAppl (`Or, e1, e2)  -> Condition (desugar e1, Constant(Boolean true, pos), desugar e2, pos)
      | `InfixAppl (`App, e1, e2) -> App (desugar e1, desugar e2, pos)
      | `ConstructorLit (name, None) -> Variant_injection (name, unit_expression pos, pos)
      | `ConstructorLit (name, Some s) -> Variant_injection (name, desugar s, pos)
      | `Escape (name, e) -> 
          Expression.Expr.Call_cc(Abstr([mk_variable name pos None], desugar e, pos), pos)
      | `Spawn e -> desugar 
          (`FnAppl ((`Var "spawn", pos'), ([`FunLit (None, [[]], e),  pos'], pos')), pos')

      | `Section (`FloatMinus) -> Variable ("-.", pos)
      | `Section (`Minus) -> Variable ("-", pos)
      | `Section (`Project name) -> (let var = unique_name () in
                                     desugar (`FunLit (None, [[`Variable var, pos']], 
                                                       ((`Projection ((`Var var, pos'), name), pos'):Sugartypes.phrase)), pos'))
      | `Section (`Name name) -> Variable (name, pos)
      | `Conditional (e1, e2, e3) -> Condition (desugar e1, desugar e2, desugar e3, pos)
      | `Projection (e, name) -> begin
          let s = unique_name ()
          in Record_selection (name, 
                               s, 
                               unique_name (), 
                               desugar e, 
                               Variable (s, pos), 
                               pos)
        end
      | `With (e, fields) -> 
          ListLabels.fold_right ~init:(desugar e) fields 
            ~f:(fun (label, value) record ->
                  let rvar = gensym () in
                  Record_intro (StringMap.add label (desugar value) StringMap.empty,
                                Some (Record_selection (label, gensym(), rvar, record,
                                                        Variable (rvar,pos), pos)),
                                pos))
      | `TableLit (name, datatype, constraints, db) -> 
          desugar_TableLit desugar pos lookup_pos var_env name datatype constraints db
      | `ViewLit (name, iter, db) ->
          ViewHandle (desugar db, desugar name, desugar iter, pos)
      | `UnaryAppl (`Minus, e)      -> appPrim "negate" [desugar e]
      | `UnaryAppl (`FloatMinus, e) -> appPrim "negatef" [desugar e]
      | `UnaryAppl (`Name n, e) -> appPrim n [desugar e]
      | `UnaryAppl (`Abs, e) -> Abs (desugar e, pos)
      | `ListLit  [] -> Nil (pos)
      | `ListLit  (e::es) -> Concat (List_of (desugar e, pos), desugar (`ListLit (es), pos'), pos)
      | `DBDelete (db, condition) -> desugar_DBDelete desugar pos' db condition
      | `DBInsert (table, rows) -> desugar_DBInsert desugar pos' table rows
      | `DBUpdate (db, condition, row) -> desugar_DBUpdate desugar pos' db condition row
      | `DatabaseLit (name, opts) -> desugar_DatabaseLit desugar pos pos' name opts
      | `RecordLit (fields, r) -> desugar_RecordLit desugar pos fields r
      | `TupleLit [field] -> desugar field
      | `TupleLit fields -> desugar_TupleLit desugar pos' fields

      (* (\* Not hastily removed because it may have some value. *\) *)
      (* | HandleWith (e1, name, e2) ->  *)
      (*     Syntax.Call_cc *)
      (*       (Abstr *)
      (*          ("return",  *)
      (*           Let (name,  *)
      (*                Syntax.Call_cc *)
      (*                  (Abstr("handler", *)
      (*                         Apply (Variable ("return", pos),  *)
      (*                                desugar e1, pos), pos), pos), desugar e2, pos), pos), pos) *)

      | `FnAppl (fn, (ps, ppos))  -> Apply (desugar fn, List.map desugar ps, pos)
      | `FunLit (mname, patterns_lists, body) -> 
          desugar_FunLit desugar pos pos' patternize patterns_lists body mname
      | `Block (es, exp) -> desugar_Block desugar pos patternize var_env lookup_pos es exp
      | `SortBy_Conc (patt, expr, sort_expr) -> 
          desugar_SortBy_Conc desugar pos patternize patt expr sort_expr
      | `Iteration (gen, body, filter, sort) -> 
          desugar_Iteration desugar pos pos' patternize s (gen, body, filter, sort)
	      (* | `Iteration(`DepTable _, _, _, _) -> desugar (desugar_query (s, pos')) *)

      (* | `Iteration (generator, body, None, None) -> *)
      (*     let pattern, from = as_list pos' generator *)
      (*     in *)
      (*     (match patternize pattern with *)
      (*        | `Variable var, _ -> For (desugar body, var, desugar from, pos) *)
      (*        | pattern -> (let var = unique_name () in *)
      (*                      For (polylet pattern pos (Variable (var, pos)) (desugar body), *)
      (*                           var, desugar from, pos))) *)

      (* | `Iteration (generator, body, filter_cond, Some sort_expr) ->  *)
      (*     let pattern, from = as_list pos' generator *)
      (*     in *)
      (*     desugar (`Iteration (`List (pattern, (`SortBy_Conc(pattern, from, sort_expr), pos')), *)
      (*                          body, filter_cond, None), *)
      (*              pos') *)

      (* | `Iteration (generator, body, Some exp, sort_expr) -> *)
      (*     desugar (`Iteration (generator,  *)
      (*                          (`Conditional (exp, *)
      (*                                         body, *)
      (*                                         (`ListLit [], pos')), pos'),  *)
      (*                          None, sort_expr), *)
      (*              pos') *)
          
	  | `PackBinding _
      | `UnpackBinding _ 
      | `Binding _ -> raise_data_pos_err pos "Unexpected binding outside a block"
      | `Switch (exp, patterns) ->
          PatternCompiler.match_cases
            (pos, desugar exp, 
             (List.map (fun (patt, body) -> ([patternize patt], desugar body)) patterns))
      | `Receive patterns -> 
          desugar (`Switch ((`FnAppl ((`Var "recv", pos'), ([], pos')), pos'),
                            patterns), pos')

      (*  TBD: We should die if the XML text literal has bare ampersands or
          is otherwise ill-formed. It should also be made to properly handle
          CDATA. Where's a good place to do so? 
      *)
      | `TextNode s -> appPrim "stringToXml" [Constant(String s, pos)]
      | `Xml (("form"|"FORM"), _, _) as x when LName.has_lnames x ->
          desugar (LName.replace_lname (x, pos'))
      | `Xml (tag, attrs, subnodes) -> 

          let rec coalesce : (Sugartypes.phrase list -> Sugartypes.phrase list)
              = function 
                  [] -> []
                | [x] -> [x]

                | ((`TextNode s1, d1)::(`TextNode s2, d2)::xs) ->
                    coalesce((`TextNode (s1^s2), d1) :: xs)

                | x::xs -> x :: coalesce xs in

          let concat a b = 
            Concat (desugar a, b, pos) in
          let desugar_attr = function
            | [] -> Constant(String "", pos)
            | [x] -> desugar x
            | xs  -> (fold_right concat xs (Nil (pos))) in
          if (tag = "#") then
            begin
              if List.length attrs != 0 then
                raise_data_pos_err pos "XML forest literals cannot have attributes"
              else
                List.fold_right
                  (fun node nodes ->
                     Concat (desugar node, nodes, pos)) subnodes (HasType (Nil pos, Types.xml_type (), pos))
            end
          else
            Xml_node (tag, alistmap desugar_attr attrs,
                      map desugar (coalesce subnodes), pos)

      | `Formlet (formExpr, formHandler) ->
          fst (forest_to_form_expr var_env lookup_pos [formExpr] (Some formHandler) pos pos')
      | `Definition _
      | `TypeDeclaration _
      | `FormBinding _
      | `HandleWith _
      | `InfixDecl
      | `Regex _
      | `Foreign _ 
      | `Include _ -> assert false
	  | _ -> failwith "Fable constructors not yet handled"



  and forest_to_form_expr var_env lookup_pos trees yieldsClause 
      (pos:Expression.untyped_data) 
      (trees_ppos:Sugartypes.pposition)
      : (Syntax.untyped_expression * Sugartypes.ppattern list list) = 
    (* We pass over the forest finding the bindings and construct a
       term-context representing all of the form/yields expression
       except the `yields' part (the handler). Here bindings
       is a list of lists, each list representing a tuple returned
       from an inner instance of forest_to_form_expr--or, if it's a
       singleton, a single value as bound by a binder.  *)
    let ctxt, bindings =
      fold_right
        (fun l (ctxt, bs) -> 
           let l_unsugared, bindings = desugar_form_expr var_env lookup_pos l in
           (fun r -> appPrim pos "@@@"  [l_unsugared; ctxt r]),
           bindings @ bs) 
        trees
        (identity, []) in
    (* Next we construct the handler body from the yieldsClause,
       if any.  The yieldsClause is the user's handler; if it is
       None then we construct a default handler that just bundles
       up all the bound variables and returns them as a tuple.
       Here we also form a list of the values we're
       returning. returning_bindings is a list of lists,
       representing a list of tuples of values.  *)
    let handlerBody, bindings, returning_bindings = 
      match yieldsClause with
          Some formHandler -> 
            formHandler, bindings, ([]:Sugartypes.ppattern list list)
        | None ->
            let fresh_bindings = map (map (fun (_, ppos) -> `Variable (unique_name ()), ppos)) bindings in
            let variables = map (fun (`Variable x, ppos) -> `Var x, ppos) (flatten fresh_bindings) in
            ((`TupleLit variables, (Lexing.dummy_pos, Lexing.dummy_pos)),
             fresh_bindings,
             [flatten bindings])
    in
    let _, ppos = handlerBody in
    (* The handlerFunc is simply formed by abstracting the
       handlerBody with all the binding names, appropriately
       destructing tuples. *)
    (* Note: trees_ppos will become the position for each tuple;
       the position of the tuple is what's reported when duplicate
       bindings are present within one form. *)
    let handlerFunc =  `FunLit (None,
                                map (function
                                       | [b] -> [b]
                                       | bs -> [`Tuple bs, trees_ppos]) (rev bindings),
                                handlerBody), trees_ppos in
    ctxt (Apply(Variable("pure", pos), [desugar' var_env lookup_pos handlerFunc], pos)), 
    returning_bindings
      
  and desugar_form_expr var_env lookup_pos (formExpr, ppos) : untyped_expression * ppattern list list =
    let forest_to_form_expr = forest_to_form_expr var_env lookup_pos in
    let pos = `U(lookup_pos ppos) in
    let desugar = desugar' var_env lookup_pos in
    let appPrim = appPrim pos in
    if not (has_form_binding (formExpr,ppos)) then
      Apply (Variable("xml", pos), [desugar (formExpr,ppos)], pos), [[]]
    else
      match formExpr with
        | `FormBinding (phrase, ppattern) -> desugar phrase, [[ppattern]]
        | `Xml ("#", [], contents) -> forest_to_form_expr contents None pos ppos
        | `Xml ("#", _, _) -> raise_data_pos_err pos
            "XML forest literals cannot have attributes"
        | `Xml(tag, attrs, contents) ->
            let form, bindings = forest_to_form_expr contents None pos ppos in
            let attrs' = alistmap (map desugar ->- make_links_list pos) attrs in
            (appPrim "plug" [make_xml_context tag attrs' pos; form],
             bindings)
              
        | `TextNode text -> 
            appPrim "xml" [appPrim "stringToXml" [Constant (String text, pos)]], [[]]
        | _ -> assert false

  and has_form_binding = function
    | `Xml (_, _, subnodes),_ -> exists has_form_binding subnodes
    | `FormBinding _,_      -> true
    |  _                    -> false

  and desugar_repeat _ : Regex.repeat -> phrasenode = function
    | Regex.Star      -> `ConstructorLit ("Star", None)
    | Regex.Plus      -> `ConstructorLit ("Plus", None)
    | Regex.Question  -> `ConstructorLit ("Question", None)

  and desugar_regex pos : regex' -> phrasenode = 
    (* Desugar a regex, making sure that only variables are embedded
       within.  Any expressions that are spliced into the regex must be
       let-bound beforehand.  *)
    let exprs = ref [] in
    let expr e = 
      let v = gensym ~prefix:"_regex_" () in
      begin
        exprs := (v, e) :: !exprs;
        `Var v, pos
      end in
    let rec aux : regex' -> phrasenode = 
      function
        | `Range (f, t)    -> `ConstructorLit ("Range", Some (`TupleLit [`CharLit f, pos; `CharLit t, pos], pos))
        | `Simply s        -> `ConstructorLit ("Simply", Some (`StringLit s, pos))
        | `Quote s        -> `ConstructorLit ("Quote", Some (aux s, pos))
        | `Any             -> `ConstructorLit ("Any", None)
        | `StartAnchor   -> `ConstructorLit ("StartAnchor", None)
        | `EndAnchor     -> `ConstructorLit ("EndAnchor", None)
        | `Seq rs          -> `ConstructorLit ("Seq", Some (`ListLit (List.map (fun s -> aux s, pos) 
                                                                        rs), pos))
        | `Alternate (r1, r2)  -> `ConstructorLit ("Alternate",  Some (`TupleLit [aux r1, pos; aux r2, pos], pos))
        | `Group s          -> `ConstructorLit ("Group", Some (aux s, pos))
        | `Repeat (rep, r) -> `ConstructorLit ("Repeat", Some (`TupleLit [desugar_repeat pos rep, pos; 
                                                                          aux r, pos], pos))
        | `Splice e        -> `ConstructorLit ("Quote", Some(`ConstructorLit ("Simply", Some (expr e)), pos))
	    | `Replace (re, (`Literal tmpl)) -> `ConstructorLit("Replace", Some(`TupleLit ([(aux re, pos); (`StringLit tmpl, pos)]), pos))
	    | `Replace (re, (`Splice e)) -> `ConstructorLit("Replace", Some(`TupleLit ([(aux re, pos); expr e]), pos))
    in fun e ->
      let e = aux e in
      `Block (List.map (fun (v, e1) -> `Binding ((`Variable v, pos), e1), pos) !exprs,
		      (e, pos))

  and simple_pattern_of_pattern var_env lookup_pos ((pat,pos') : ppattern) : simple_pattern = 
    let desugar = simple_pattern_of_pattern var_env lookup_pos
    and pos = `U (lookup_pos pos') in
    let rec aux = function
      | `Variable _
      | `Nil as p -> p, pos
      | `Any -> `Variable (unique_name ()), pos
      | `Constant (p,_) ->
          `Constant (match p with
                       | `IntLit v    -> Constant(Integer v, pos)
                       | `FloatLit v  -> Constant(Float v, pos)
                       | `StringLit v -> Constant(String v, pos)
                       | `BoolLit v   -> Constant(Boolean v, pos)
                       | `CharLit v   -> Constant(Char v,  pos)
                       | _ -> assert false),
          pos
      | `Cons (l,r) -> `Cons (desugar l, desugar r), pos
      | `List ps ->
          List.fold_right
            (fun pattern list ->
               `Cons (desugar pattern, list), pos)
            ps
            (`Nil, pos)
      | `As (name, p) -> `As (name, desugar p), pos
      | `HasType (p, datatype) -> `HasType (desugar p, desugar_datatype lookup_pos var_env datatype), pos
      | `Variant (l, Some v) ->
          `Variant (l, desugar v), pos
      | `Variant (l, None) ->
          if Settings.get_value cons_unit_hack then
            `Variant (l, (`HasType (((`Variable (unique_name ())), pos), Types.unit_type ()), pos)), pos
          else
            `Variant (l, (`Constant (unit_expression pos), pos)), pos
              (* 
                 When cons_unit_hack is enabled (the default), elimination of A is identified with
                 elimination of A(x:()) which allows us to have programs such as:

                 (-)  switch (A) {case A -> B; case x -> x;}

                 compile, even when unit_hack is disabled.

                 When cons_unit_hack is disabled (which makes sense
                 when unit_hack is enabled) we instead identify
                 elimination of A with elimination of A().
                 
                 If cons_unit_hack is disabled and unit_hack is enabled
                 then (-) compiles to:

                 let z = A in
                 case z of
                 A(y) -> if y = () then B
                 else let x = A(y) in x
                 x -> let _ = x:[|-A|rho|] in x

                 which does not type check as [|A:()|rho'|] cannot be unifed with [|-A|rho|].

                 If cons_unit_hack is disabled and unit_hack is enabled
                 then (-) compiles to:

                 let z = A in
                 case z of
                 A(y) -> B
                 x -> let _ = x:[|-A|rho|] in x

                 which does type check.

                 If cons_unit_hack is enabled and unit_hack is disabled (the default)
                 then (-) compiles to:

                 let z = A in
                 case z of
                 A(y) -> let _ = (y:()); B
                 x -> let _ = x:[|-A|rho|] in x
                 
                 which again type checks.

                 The latter case is chosen as the default, as it will remain sound even if we
                 disable static typing.
              *)
      | `Record (labs, base) ->
          List.fold_right
            (fun (label, patt) base ->
               `Record (label, desugar patt, base), pos)
            labs
            ((fromOption (`Constant (unit_expression pos), pos) (Utility.opt_map desugar base)))
      | `Tuple ps ->
          List.fold_right2
            (fun patt n base ->
               `Record (string_of_int n, desugar patt, base), pos)
            ps
            (Utility.fromTo 1 (1 + List.length ps))
            ((`Constant (unit_expression pos)), pos) in
    let p = aux pat in
    begin
      check_for_duplicate_names p;
      p
    end

  and desugar_DatabaseLit desugar pos pos' name (opt_driver, opt_args) =
    let e =
      match opt_driver with
        | None ->
            `RecordLit ([("name", name)],
                        Some (`FnAppl((`Var "getDatabaseConfig", pos'),
                                      ([], pos')), pos')), pos'
        | Some driver ->
            let args =
              match opt_args with
                | None -> `StringLit (""), pos'
                | Some args -> args
            in
            `RecordLit ([("name", name); ("driver", driver); ("args", args)], None), pos'
    in
    Database (desugar e, pos)

  and desugar_RecordLit desugar pos fields r =
    Record_intro (StringMap.from_alist (alistmap desugar fields),
                  opt_map desugar r,
                  pos) 

  and desugar_TupleLit desugar pos' fields=
    desugar (`RecordLit (List.map2 (fun exp n ->
                                      string_of_int n, exp)
                           fields (fromTo 1 (1 + length fields)), None), pos')

  and desugar_FunLit desugar pos pos' patternize patterns_lists body = function
    | None ->
        let patternized = (List.map (List.map patternize) patterns_lists) in
        ignore (List.fold_left
                  (List.fold_left check_for_duplicate_names')
                  StringSet.empty
                  patternized);
		if List.for_all (List.for_all is_variable_pattern) patternized then 
          (* No patterns in function args for Fable annotated functions *)
          List.fold_right 
			(fun patterns expr -> 
			   let names = List.map
			     (fun (pat, _) -> match pat with 
				      `HasType ((`Variable n, _), t) -> 
				        mk_variable n pos (Some t)
			        | `Variable n -> 
				        mk_variable n pos None
			        | _ -> raise Impos) patterns in
               Abstr (names, expr, pos))
			patternized
			(desugar body)
		else
          List.fold_right 
			(fun patterns expr -> 
			   let names = List.map
			     (fun _ -> mk_variable (unique_name()) pos None) patterns in
               Abstr (names,
                      List.fold_right 
                        (fun (pattern,name) expr ->
					       polylet pattern pos name expr)
                        (combine patterns names)
                        expr,
                      pos))
			patternized
			(desugar body)
     | Some name -> 		        
        Rec ([name, desugar (`FunLit (None, patterns_lists, body), pos'), None],
             Variable (name, pos),
             pos)

  and desugar_Block desugar pos patternize var_env lookup_pos es exp =
    let es = 
      List.map 
        (function (* pattern * untyped_expression * position * recursivep *)
		   | `UnpackBinding(p,e), pos -> 
			   (`Unpack (patternize p), desugar e, `U (lookup_pos pos), false)
		   | `PackBinding((p,e), t), pos -> 
			   (`Pack ((patternize p), desugar_datatype lookup_pos var_env t),
                desugar e,
                `U (lookup_pos pos), false)
           | `Binding (p, e), pos -> 
               (`Simple (patternize p), desugar e, `U (lookup_pos pos), false)
           | `FunLit (Some n, patts, body), fpos -> 
               (`Simple (`Variable n, pos), 
                desugar (`FunLit (None, patts, body), fpos), 
                `U (lookup_pos fpos), 
                true)
           | expr, epos -> 
               (`Simple (`HasType ((`Variable "__", pos), Types.unit_type ()), pos)), 
               desugar (expr, epos),
               `U (lookup_pos epos), false) es in
    polylets es (desugar exp)

  and desugar_SortBy_Conc desugar pos patternize patt expr sort_expr =
    match patternize patt with
      | `Variable var, _ -> 
          let abstr = Abstr([mk_variable var pos None], desugar sort_expr, pos) in
          SortBy (desugar expr, abstr, pos)
      | _ -> 
          raise_data_pos_err pos
            "orderby clause on non-simple pattern-matching for is not yet implemented."
              
  and desugar_Iteration desugar pos pos' patternize s = function
      (* Desugar DepTable *)
    | (`DepTable _, _, _, _) -> desugar (desugar_query (s, pos'))
    (* Desugar base case with no filter or sort expressions *)
    | (generator, body, None, None) -> 
        desugar_base generator body desugar pos pos' patternize
    (* Desugar sort expression *)
    | (generator, body, filter_cond, Some sort_expr) -> 
        desugar_sort generator body filter_cond sort_expr desugar pos'
    (* Desugar filter condition *)
    | (generator, body, Some filter_cond, sort_expr) ->
        desugar_filter generator body filter_cond sort_expr desugar pos'

  and desugar_dep desugar pos pos' s =
    desugar (desugar_query (s, pos'))

  and desugar_base generator body desugar pos pos' patternize =
    let pattern, from = as_list pos' generator in 
    let body' = desugar body in
    let from' = desugar from in
    let (expr, var) = (
      match patternize pattern with
        | `Variable var, _ -> (body', var)
        | pattern -> 
            let var = unique_name () in
            let var_expr = Variable (var, pos) in
            let expr = polylet pattern pos var_expr body' in
            (expr, var)
    ) in For (expr, var, from', pos)

  and desugar_sort generator body filter_cond sort_expr desugar pos' =
    let pattern, from = as_list pos' generator in
    let sortby = `SortBy_Conc (pattern, from, sort_expr) in
    let list = `List (pattern, (sortby, pos')) in
    desugar (`Iteration (list, body, filter_cond, None), pos')

  and desugar_filter generator body filter_cond sort_expr desugar pos' =
    let cond = `Conditional (filter_cond, body, (`ListLit [], pos')) in
    desugar (`Iteration (generator, (cond, pos'), None, sort_expr), pos')

  and desugar_DBInsert desugar pos' table rows =
      desugar (`FnAppl ((`Var "insertrows", pos'),
                        ([table; rows], pos')), pos')
      
  and desugar_DBDelete desugar pos' (pattern, table) condition =
    let t = unique_name () in
    let r = unique_name () in
    let tv = ((`Var t), pos') in
    let rv = ((`Var r), pos') in
    let generator =
      `Table ((`As (r, pattern), pos'), tv) in
    let rows = `Iteration (generator, ((`ListLit [rv]), pos'), condition, None), pos' in
    desugar (
      `Block ([(`Binding (((`Variable t), pos'), table)), pos'],
              (`FnAppl ((`Var "deleterows", pos'),
                        ([tv; rows ], pos')), pos')), pos')

  and desugar_DBUpdate desugar pos' (pattern, table) condition row =
    (* update (var pattern <-- table)
       where condition
       set (x1=e1,...,xn=en) *)
    let p = pos' in
    let t = unique_name () in
    let r = unique_name () in

    let tv = ((`Var t), p) in
    let rv = ((`Var r), p) in

    let generator =          (* var pattern as r <-- tv *)
      `Table ((`As (r, pattern), p), tv) in
    (* let ignorefields =  *)
    (* List.map (fun (name, _) -> name, ((`Variable (unique_name ())), p)) row in *)
    let body =               (* [(rv, (x1=e1,...,xn=en) )] *)
      (`ListLit
         [(`TupleLit
             [rv;
              (`RecordLit (row, None), p)]
          ), p]), p in
    (* for (generator)
       where condition
       body *)
    let row_pairs = `Iteration (generator, body, condition, None), p
    in
    (* { var t = table;
       updaterows(tv, row_pairs)
       } *)
    desugar (
      `Block ([(`Binding (((`Variable t), p), table)), p],
              (`FnAppl ((`Var "updaterows", p),
                        ([tv; row_pairs], p)), p)), p)

  (* [HACK]
     This isn't as flexible as it should be - it's just a
     quick hack to get things going. We should probably
     maintain the constraints in the IR and generate the
     actual table types during type inference.
  *)
  and desugar_TableLit desugar pos lookup_pos var_env name datatype constraints db = 
    let row = match datatype with
      | RecordType row -> row
      | UnitType -> raise_data_pos_err pos 
          "Tables must have at least one field"
      | _ -> raise_data_pos_err pos
          "Tables must take a non-empty record type"
    in
    let make_write_row (fields, rest) constraints = 
      let rec mr = function
        | [] -> []
        | ((name, body) :: fields) ->
            if List.mem_assoc name constraints
              && List.exists (function
                                | `Readonly -> true
					            | _ -> false) (List.assoc name constraints) then
                mr fields
            else
              (name, body) :: mr fields
      in
      (mr fields, rest) in
    let write_row = make_write_row row constraints in
    let primarykey_fields : string list =    (* bjc: rewrite this! *)
      let (fields, _) = row in
      let rec mr =
        function 
          | [] -> []
          | ((name, body) :: fields) -> try 
              let cs = List.assoc name constraints in
              if List.mem `PrimaryKey cs then name :: mr fields
              else raise Not_found
            with Not_found -> mr fields
      in mr fields in
	let marshallby = 
      let is_marshallby = function
        | `Marshalledby _ -> true
        | _ -> false
      in
      let folder (s, fcl) tbl = 
        try match List.find is_marshallby fcl with
		  | `Marshalledby e -> (s, desugar e)::tbl
		  |  _ -> raise Utility.Impos
		with	Not_found -> tbl
      in List.fold_right folder constraints []
    in
    let readtype = 
      Types.def_fable_annot 
        (`Record (desugar_row lookup_pos var_env row)) in
    let writetype = 
      Types.def_fable_annot 
        (`Record (desugar_row lookup_pos var_env write_row))
    in
    TableHandle (desugar db, desugar name, {
                   readtype=readtype; 
                   writetype=writetype; 
                   marshallby=marshallby;
                   primarykey=primarykey_fields
                 }, pos)



  and desugar_expression lookup_pos e : Syntax.untyped_expression = desugar_expression' ((generate_var_mapping -<- get_type_vars) e) lookup_pos e

  let desugar_definition lookup_pos ((s, pos') : phrase) : untyped_definition =
    let _, ((tenv, _) as var_env) = (generate_var_mapping -<- get_type_vars) (s, pos') in
    let pos = `U (lookup_pos pos') in
    let desugar_expression = desugar_expression lookup_pos in
    let ds : phrasenode -> _ Syntax.definition' = function
      | `TypeAnnotation ((`Definition (name, rhs, loc), _), t) ->
          let expr = match rhs with
            | (`FunLit (Some _, patterns, body),_) ->
                Rec ([name, 
                      desugar_expression 
                        (`FunLit (None, patterns, body), pos'), 
                      Some (desugar_datatype lookup_pos  var_env t)],
                     Variable (name, pos), pos)
            | _ -> 
                HasType(desugar_expression rhs, 
                        desugar_datatype lookup_pos var_env t, pos)
          in
          Define (name, expr, loc, pos)
      | `Definition (name, e, loc) -> 
          Define (name, desugar_expression e, loc, pos)
      | `TypeDeclaration (name, args, rhs) ->
          let get_var (arg, k) =
            match (Unionfind.find (fst (StringMap.find arg tenv))) with
              | Flexible var 
	          | Rigid var -> (var, FableType.string_as_kind k)
              | _ -> assert false
          in
          if alias_is_closed 
            (List.fold_right StringSet.add 
               (List.map fst args) StringSet.empty) rhs then
              Alias (name,
                     List.map get_var args,
                     desugar_datatype lookup_pos var_env rhs, pos)
          else
            failwith ("Free variable(s) in alias")
      | `Foreign (language, name, datatype) -> 
          Alien (language, name, 
                 desugar_assumption lookup_pos (generalize datatype), pos) 
      | `Include name -> Module (name, pos)
      | _ -> assert false in
    let result = ds s
    in
    (Debug.if_set show_desugared (fun ()-> string_of_definition result);
     result)

  let desugar_definitions lookup_pos =
    let rec desugar = function
      | [] -> []
      | (`InfixDecl, _) :: phrases -> desugar phrases
      | phrase :: phrases ->
          desugar_definition lookup_pos phrase :: desugar phrases
    in
    desugar

  let desugar_datatype lookup_pos = generalize ->- (desugar_assumption lookup_pos)
end 

include Desugarer
