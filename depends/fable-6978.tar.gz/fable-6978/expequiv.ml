(*pp deriving *)
open Utility
open Syntax
open Expression
open Expression.Expr
open Expression.DerivingSyntax

exception Equiv_failure of string
exception Try_reduce_again
  
(* let equiv_u : Typeenv.omega -> untyped_expression -> untyped_expression -> bool = *)
(*   fun _ -> Eq_uexp.eq *)
  
let equiv : Typeenv.omega -> expression -> expression -> bool =
  fun _ -> Syntax.Eq_expression.eq

type env = (string list * Typeenv.omega)

(* Very simple stub for the real reduction relation;
   Eventually, we'd want to use some version of Interpreter.interpret 
   to obtain a result. *)
let rec reduce_expression omega e = 
  let try_refine e =
    match Typeenv.refine Syntax.Eq_expression.eq e omega with
	    None -> 
	      begin
	        try 
	          match Fable.get_label_type_expr (Syntax.node_datatype e).Types.ftype with
		          Some e' -> e', not (equiv omega e e')
		        | None -> e, false
	        with
		        Not_found -> e, false
	      end
      | Some e' -> e', true in
  let rec reduce_until f e =
    let e',progress = reduce_expression omega e in 
      if not progress then None
      else 
	    try
	      Some(f e')
	    with 
	        Try_reduce_again -> reduce_until f e' in
  let special_cases exp = match exp with 
      Project(record, field, _) -> 
	    let rec project_record_intro = function
	      | Record_intro _ as e -> 
	          let rec get_field label = function 
 		          Record_intro (fmap, ext, _) -> 
		            if StringMap.mem field fmap then
		              StringMap.find field fmap, true
		            else
		              (match ext with 
			               None -> raise (Equiv_failure ("Projection out a record that doesn't contain the label: " ^label))
			             | Some e -> get_field label e)
		        | _ -> raise (Equiv_failure ("Projection out a record that doesn't contain the label: " ^label)) in (* could try reducing here too *)
		        get_field field e 
	      | _ -> raise Try_reduce_again in
	      (match record with 
	         | Record_intro _ as e -> project_record_intro e
	         | _ -> 
		         match reduce_until project_record_intro record with
		             None -> exp, false
		           | Some result -> result
	      )
    | Record_selection(label, lvar, _, value, Variable(bodyvar, _), data) when lvar = bodyvar -> 
	    Project(value, label, data), true
    | _ -> exp, false in
  let (e', progress) = try_refine e in
    if not progress then 
      special_cases e'
    else (e', progress)
      
      
(* For now allow the range of the substitution to contain arbitrary expressions ... not just values *)
(* Once we include the type evaluation relation, then consider changing this so that substitutions are limited to values *)
let unify : string list -> Typeenv.omega -> (expression * expression) -> Subst.subst = 
  fun phantoms omega -> 
    let env = (phantoms, omega) in
      
    let rename_bound_vars el er = 
      List.fold_left2 (fun sigma vl (Variable(n, _)) -> 
			             Subst.extend (n, vl) sigma) Subst.empty el er in
      
    let rec unify_lists sigma (l, r) =
      if List.length l = List.length r then
	    List.fold_left2 
	      (fun sigma argl argr -> 
	         let sigma' = unify (argl, Subst.apply_e sigma argr) in
	           Subst.union sigma sigma'
	      ) sigma l r
      else
	    raise (Equiv_failure "Unequal arg lists")
	      
    and unify (el, er) =
      try
	    unify_noreduce (el, er)
      with
	      Equiv_failure _ as exn -> 
	        let el', progress = reduce_expression omega el in
	        let er', progress' = reduce_expression omega er in
	          if progress || progress' then 
		        unify (el', er')
	          else
		        raise exn
		          
    and unify_noreduce (el, er) : Subst.subst = match el, er with
      | _,  Variable(n, _) when List.mem n phantoms -> Subst.extend (n, el) Subst.empty 
	      
      | Constant (l, _), Constant (r, _) when Expression.Eq_constant.eq l r  -> Subst.empty
	      
      | Variable (n, _), Variable (m, _) when n = m  -> Subst.empty
	      
      | Abs (el', _) , Abs (er', _) -> unify (el', er')
	      
      | App (el1, el2, _), App (er1, er2, _) ->
	      let sigma1 = unify (el1, er1) in
	      let sigma2 = unify (el2, Subst.apply_e sigma1 er2)  in
	        Subst.union sigma1 sigma2

      | Apply (el1, largs, _), Apply (er1, rargs, _) ->
	      let sigma1 = unify (el1, er1) in
	        unify_lists sigma1 (largs, rargs)

      | Condition (el1, el2, el3, _), Condition (er1, er2, er3, _) ->
	      unify_lists Subst.empty ([el1;el2;el3], [er1;er2;er3])
	        
      | Comparison (el1, cl, el2, _), Comparison (er1, cr, er2, _) ->
	      if Expression.Eq_comparison.eq cl cr then
	        unify_lists Subst.empty ([el1;el2], [er1;er2])	 
	      else
	        raise (Equiv_failure "Failed to unify comparisons with different comparison operators")

      | Abstr (el, bodyl, _), Abstr (er, bodyr, _) -> (* alpha convert? *)
	      let sig_alpha = rename_bound_vars el er in
	        unify (bodyl, Subst.apply_e sig_alpha bodyr) 

      | Let (sl, vl, bl, _),  Let (sr, vr, br, _) ->
	      let sigma = unify (vl, vr) in
	      let dat = Syntax.expression_data vl in
	      let sig_alpha = Subst.extend (sr, Variable(sl, dat)) Subst.empty in
	      let sigma' = unify (bl, Subst.apply_e (Subst.union sigma sig_alpha) br) in
	        Subst.union sigma sigma'

      | Record_intro (sml, xlopt, _), Record_intro (smr, xropt, _) ->
	      let keyset map =
	        StringMap.fold (fun k _ l -> StringSet.add k l) map StringSet.empty in
	      let lset, rset = keyset sml, keyset sml in
	        if StringSet.equal lset rset then
	          let sigma = StringSet.fold
		        (fun lab sigma  -> 
		           let expl, expr = StringMap.find lab sml, StringMap.find lab smr in
		           let sigma' = unify (expl, Subst.apply_e sigma expr) in
		             Subst.union sigma sigma')
		        lset Subst.empty in
		        match xlopt, xropt with
		            None, None -> sigma
		              
		          | Some el, Some er -> 
		              let sigma' = unify (el, Subst.apply_e sigma er) in
			            Subst.union sigma sigma'
			              
		          | _ -> raise (Equiv_failure "Failed to unify records with different extensions")
	        else
	          raise (Equiv_failure "Failed to unify records with different field sets")
		        
      | Record_selection (ls1, ls2, ls3, el1, el2, _), 
	      Record_selection (rs1, rs2, rs3, er1, er2, _) when (ls1, ls2, ls3) = (rs1, rs2, rs3) ->
	      unify_lists Subst.empty ([el1;el2], [er1; er2])
	        
      | Project (el, sl, _),  Project (er, sr, _) when sl=sr ->
	      unify (el, er)	    
	        
      | Variant_injection (sl, el, _),  Variant_injection (sr, er, _)  when sl = sr ->
	      unify (el, er)

      | Variant_selection (el1, sl1, sl2, el2, sl3, el3, _), 
	      Variant_selection (er1, sr1, sr2, er2, sr3, er3, _) 
	        when (sl1, sl2, sl3) = (sr1, sr2, sr3) -> 
	      unify_lists Subst.empty ([el1; el2; el3], [er1; er2; er3])

      | Variant_selection_empty (el, _), Variant_selection_empty (er, _) ->
	      unify (el, er)

      | Nil _, Nil _ -> Subst.empty
		  
      | List_of (el, _) , List_of (er, _) ->
	      unify (el, er)

      | Concat (el1, el2, _), Concat (er1, er2, _) ->
	      unify_lists Subst.empty ([el1;el2], [er1;er2])
	        
      | HasType (el, tl, _), HasType (er, tr, _)  ->
	      unify (el, er)
	        
      | For _, For _
      | Database _, Database _ 
      | TableQuery _, TableQuery _
      | TableHandle _, TableHandle _ 
      | SortBy _, SortBy _
      | Call_cc _, Call_cc _
      | Wrong _, Wrong _
      | Erase _, Erase _ 
      | Rec _, Rec _ 
      | Xml_node _, Xml_node _ ->
	      failwith "Expequiv.unify doesn't handle expression feature yet"
	        
      | _ -> 
	      raise (Equiv_failure "Unable to unify type-level expressions")
    in 
      unify
        

	    
        
        
