open Sys
open Num
open List

open Result
open Syntax
open Expression
open Expression.Types
open Utility
open Printf

(* Data structures/utilities for proc mgmt *)

type pid = int

type proc_state = Result.continuation * Result.result 

let suspended_processes = (Queue.create () : (proc_state * pid) Queue.t)
and blocked_processes = (Hashtbl.create 10000 : (pid, (proc_state * pid)) Hashtbl.t)
and messages = (Hashtbl.create 10000  : (int, Result.result Queue.t) Hashtbl.t)
and current_pid = (ref 0 :  pid ref)
and main_process_pid = 0

let cgi_parameters = ref []

(** http_response_headers: this is state for the webif interface. I hope we can
    find a better way for library functions to communicate with the web
    interface. *)
let http_response_headers = ref []
let http_response_code = ref 200

(* default database settings *)
let database_driver = Settings.add_string("database_driver", "", `User)
let database_args = Settings.add_string("database_args", "", `User)

let debug_process_status () =
  prerr_endline("processes : " ^ 
                  string_of_int (Queue.length suspended_processes));
  prerr_endline ("blocked processes : " ^ 
                   string_of_int (Hashtbl.length blocked_processes))

let _ =   Hashtbl.add messages 0 (Queue.create ())

let fresh_pid =
  let current_pid = (ref 0 : pid ref) in
    fun () -> 
      begin
	incr current_pid;
	!current_pid
      end

(** Format Links values as strings for insertion into the database.
    Inverse of Database.value_of_db_string.

    Falls back onto Result.string_of_result.

    This probably shouldn't be in library.ml
*)
let rec value_as_string' = function
    (* handle [Char] as String *)
  | #primitive_value as p -> primitive_as_string p
  | `List ((`Char _)::_) as c -> "box_string(\'" ^ charlist_as_string c ^ "\')"
  | `List ([])  -> "box_string(\'\')"
  | (`Variant _) as l ->                (* support for SELinks labels *)
      variant_as_string l
        (* "\'" ^ db # escape_string (Result.string_of_result l) ^ "\'" *)
  | `Record [] -> "\'(())\'"             (* hack to support (()) *)
  | `Record fields ->
      begin
        try tuple_as_string fields
        with Result.Not_tuple -> failwith "value_as_string: Record support nyi"
      end
  | a -> Result.string_of_result a

and primitive_as_string : primitive_value -> string = 
  fun p -> 
    let boxf = match p with
      | `Bool value -> "box_bool"
      | `Int value  -> "box_int"
      | `Float value -> "box_float"
      | _ -> failwith "Cannot yet save primitive to database"
    in boxf ^ "(" ^ string_of_primitive p ^ ")"

and variant_as_string : [< `Variant of 'a * 'b ] -> string
  = fun (`Variant (label, value)) ->
    sprintf "variant_init(\'%s\',%s)" label (value_as_string' value)
  
(* tuple_add(tuple_add(tuple_init(), v1), v2) *)
and tuple_as_string : (string * result) list -> string
      = fun fields ->
        let fields = map (function 
                            | x,y when numberp x -> (int_of_string x, y)
                            | _ -> raise Result.Not_tuple) fields in
        let sorted = sort (fun (x,_) (y,_) -> compare x y) fields in
        let numbers, values = split sorted in
        if ordered_consecutive numbers && length numbers > 1 && hd numbers = 1 then
          let f a (n, v) = sprintf "tuple_add(%s,%s)" a (value_as_string' v)
          in fold_left f "tuple_init()" sorted
        else raise Result.Not_tuple

let value_as_string db : result -> string
  = fun v -> 
    let s = 
      match v with
        | #primitive_value as p -> string_of_primitive p
        | `List ((`Char _)::_) as c -> "\'" ^ charlist_as_string c ^ "\'"
        | `List ([])  -> "\'\'"
        | v -> value_as_string' v
    in s (* db#escape_string s *)

(* k,v => "(k = v)" *)
let cond_from_field db (k, v) =
  "("^ k ^" = "^ value_as_string db v ^")"

let key_match db keys = function
  | `Record fields ->
      let fields' = match keys with
          [] -> fields   (* if no keys are specified, use all fields *)
        | _ -> List.filter (fun (k,_) -> List.mem k keys) fields
      in "(" ^ String.concat " AND " (map (cond_from_field db) fields') ^ ")"
  | r -> failwith ("Internal error: forming query from non-row (single_match): "^string_of_result r)
      
let single_match db = 
  function
    | `Record fields -> "("^ (String.concat " AND " (map (cond_from_field db) fields)) ^")"
    | r -> failwith ("Internal error: forming query from non-row (single_match): "^string_of_result r)

let row_columns = function
  | `List ((`Record fields)::_) -> map fst fields
  | r -> failwith ("Internal error: forming query from non-row (row_columns): "
                   ^string_of_result r)

and row_values db = function
  | `List records ->
      (List.map 
         (function
            | `Record fields -> map (value_as_string db -<- snd) fields
            | _ -> failwith "Internal error: forming query from non-row") 
         records)
  | r -> failwith ("Internal error: forming query from non-row (row_values): "
                   ^string_of_result r)

and delete_condition db = function
  | `List(rows) -> "("^ (String.concat " OR " (map (single_match db) rows)) ^")"
  | r -> failwith ("Internal error: forming query from non-row (delete_condition): "^string_of_result r)
and updates db : Result.result -> string = function
  | `Record fields -> 
      let field (k, v) = (k ^" = "^ value_as_string db v) in
        (String.concat ", " (map field fields))
  | r -> failwith ("Internal error: forming query from non-row: "^string_of_result r) 

type primitive_value = [
  result
| `PFun of result list -> result
]

type primitive =  [
  Result.result
| `PFun of result list -> Result.result ]

type located_primitive = [ `Client | `Server of primitive | primitive ]
    
let datatype = Parse.parse_string (Parse.checked_datatype Sugar.normalize_type)
  
let int_op impl : located_primitive * assumption = 
  (`PFun (fun [x;y] -> `Int (impl (unbox_int x) (unbox_int y)))),
  datatype "(Int, Int) -> Int"

let float_op impl : located_primitive * assumption = 
  `PFun (fun [x; y] -> `Float (impl (unbox_float x) (unbox_float y))),
  datatype "(Float, Float) -> Float"
    
let conversion_op' ~unbox ~conv ~(box :'a->result) : result list -> result =
  fun [x] -> (box (conv (unbox x)))

let make_type_variable = Expression.Types.make_type_variable

let fannot lt={ltype=lt;ftype=`Kind Expression.FableType.UKind}

let conversion_op ~from ~unbox ~conv ~(box :'a->result) ~into : located_primitive * Expression.Types.assumption =
  (`PFun (conversion_op' ~unbox:unbox ~conv:conv ~box:box),
   let a = Expression.Types.fresh_raw_variable () in
     ([`TypeVar a, FableType.UKind], fannot ( `Function (make_tuple_type [from], make_type_variable a, into))))

let string_to_xml : result -> result = function 
  | `List _ as c -> `List [`XML (Text (charlist_as_string c))]
  | _ -> failwith "internal error: non-string value passed to xml conversion routine"

let char_test_op fn = 
  (`PFun (fun [c] -> (`Bool (fn (unbox_char c)))),
   datatype "(Char) -> Bool")

let char_conversion fn = 
  (`PFun (fun [c] ->  (box_char (fn (unbox_char c)))),
   datatype "(Char) -> Char")

let float_fn fn = 
  (`PFun (fun [c] ->  (box_float (fn (unbox_float c)))),
   datatype "(Float) -> Float")

let p1 fn = 
  `PFun (fun ([a]) -> fn a)
and p2 fn = 
  `PFun (fun [a;b] -> fn a b)
and p3 fn = 
  `PFun (fun [a;b;c] -> fn a b c)

let client_only_1 fn = 
  p1 (fun _ -> failwith (Printf.sprintf "%s is not implemented on the server" fn))
let client_only_2 fn = 
  p2 (fun _ _ -> failwith (Printf.sprintf "%s is not implemented on the server" fn))

(* not ideal, but works for now *)
let eq_xml l r = failwith "Cannot compare XML values"
   (* string_of_result (`XML l) = string_of_result (`XML r) *)

let rec equal l r =
  match l, r with
    | `Int l   , `Int r    -> eq_num l r
    | `Float l , `Float r  -> l = r
    | `Char l  , `Char r   -> l = r
    | `XML l   , `XML r    -> eq_xml l r
    | `RecFunction _, `RecFunction _ -> 
        Pickle_result.pickleS l = Pickle_result.pickleS r
    | `Record lfields, `Record rfields -> 
        let rec one_equal_all = (fun alls (ref_label, ref_result) ->
                                   match alls with
                                     | [] -> false
                                     | (label, result) :: _ when label = ref_label -> equal result ref_result
                                     | _ :: alls -> one_equal_all alls (ref_label, ref_result)) in
          for_all (one_equal_all rfields) lfields && for_all (one_equal_all lfields) rfields
    | `Variant (llabel, lvalue), `Variant (rlabel, rvalue) -> llabel = rlabel && equal lvalue rvalue
    | `List (l), `List (r) -> length l = length r &&
            fold_left2 (fun result x y -> result && equal x y) true l r
    | `NativeString s1, `NativeString s2 -> s1 = s2
    | l, r ->  failwith ("Comparing "^ string_of_result l ^" with "^ string_of_result r ^" either doesn't make sense or isn't implemented")

let rec less l r =
  match l, r with
    | `Bool l, `Bool r   -> l < r
    | `Int l, `Int r     -> lt_num l r
    | `Float l, `Float r -> l < r
    | `Char l, `Char r -> l < r
    | `RecFunction _ , `RecFunction _
        -> Pickle_result.pickleS l < Pickle_result.pickleS r
        (* Compare fields in lexicographic order of labels *)
    | `Record lf, `Record rf -> 
        let order = sort (fun x y -> compare (fst x) (fst y)) in
        let lv, rv = map snd (order lf), map snd (order rf) in
        let rec compare_list = function
          | [] -> false
          | (l,r)::_ when less l r -> true
          | (l,r)::_ when less r l -> false
          | _::rest                -> compare_list rest in
          compare_list (combine lv rv)
    | `List (l), `List (r) -> less_lists (l,r)
    | `Variant (s1, r1), `Variant (s2, r2) ->
        if s1 = s2 then less r1 r2
        else s1 < s2
    | l, r ->  failwith ("Cannot yet compare "^ string_of_result l ^" with "^ string_of_result r)
and less_lists = function
  | _, [] -> false
  | [], (_::_) -> true
  | (l::_), (r::_) when less l r -> true
  | (l::_), (r::_) when less r l -> false
  | (_::l), (_::r) -> less_lists (l, r)

let less_or_equal l r = less l r || equal l r

(** Interface with a DB stored procedure. 
    Currently Postgres-only.
    Only supports stored procedures that return a base type
    The first arg is the database where the stored procedure resides
*)
(* Example:
  make_stored_proc "check_pw" (bool_type ()) "(Database, Int, String) -> Bool";
*)
let make_stored_proc sp_name ret_type signature =
  sp_name,
  (`PFun 
     (fun ((`Database(db,_):result)::args) ->
        (* set the return type *)
        let t = ret_type in
        let types = [(sp_name, (t, None))] in
          (* Translate the parameters to strings *)
        let args = map (value_as_string db) args in
          (* form the SQL query *)
        let query = "SELECT "^sp_name^"("^ String.concat "," args ^")" in
        let res = Database.execute_select types query db in
          (* translate Table Rows into singleton value *)
          ((function
              | `List [x] -> x
              | _ -> failwith "Internal error: expected singleton value")
           ->- recfields ->- hd ->- snd) res
     ),
   datatype signature)
  
let env : (string * (located_primitive * Expression.Types.assumption)) list = [
  "+", int_op (+/);
  "-", int_op (-/);
  "*", int_op ( */);
  "/", int_op (fun x y -> integer_num (x // y));
  "^", int_op ( **/ );
  "mod", int_op mod_num;
  "+.", float_op (+.);
  "-.", float_op (-.);
  "*.", float_op ( *.);
  "/.", float_op (/.);
  "^.", float_op ( ** );
  
  (** Lists and collections **)
  
  "hd",
  (p1 (unbox_list ->- List.hd),
   datatype "([a::M]) -> a::M");

  "tl",
  (p1 (unbox_list ->- List.tl ->- box_list),
   datatype "([a::M]) -> [a::M]");

  "drop",
  (p2 (fun n l ->
         box_list (Utility.drop (int_of_num (unbox_int n)) (unbox_list l))),
   datatype "(Int, [a::M]) -> [a::M]");

  "negate",
  (p1 (unbox_int ->- minus_num ->- box_int), datatype "(Int) -> Int");

  "error",
  (p1 (unbox_string ->- failwith), datatype "(String) -> a::M");

  (** Conversions (any missing?) **)
  "stringToInt",   conversion_op ~from:(Expression.Types.string_type ()) ~unbox:unbox_string ~conv:num_of_string ~box:box_int ~into:(fannot (`Primitive `Int));
  "intToFloat",    conversion_op ~from:(fannot (`Primitive `Int)) ~unbox:unbox_int ~conv:float_of_num ~box:box_float ~into:(fannot (`Primitive `Float));
  "intToString",   conversion_op ~from:(fannot (`Primitive `Int)) ~unbox:unbox_int ~conv:string_of_num ~box:box_string ~into:(Expression.Types.string_type());
  "floatToString", conversion_op ~from:(fannot (`Primitive `Float)) ~unbox:unbox_float ~conv:string_of_float ~box:box_string ~into:(Expression.Types.string_type());
  "stringToFloat",   conversion_op ~from:(Expression.Types.string_type()) ~unbox:unbox_string ~conv:float_of_string ~box:box_float ~into:(fannot (`Primitive `Float));
  "floatToInt",    conversion_op ~from:(fannot (`Primitive `Float)) ~unbox:unbox_float ~conv:(num_of_int -<- int_of_float) ~box:box_int ~into:(fannot (`Primitive `Int));
  
  "intToXml",
  (`PFun (string_to_xml -<-
            (conversion_op' ~unbox:unbox_int ~conv:(string_of_num) ~box:box_string)),
   datatype "(Int) -> Xml");
  
  "floatToXml",
  (`PFun (string_to_xml -<-
            (conversion_op' ~unbox:unbox_float ~conv:(string_of_float) ~box:box_string)),
   datatype "(Float) -> Xml");
  
  "stringToXml",
  ((p1 string_to_xml),
   datatype "(String) -> Xml");

  ("environment",
     (`PFun (fun [] ->
        let makestrpair (x1, x2) = `Record [("1", box_string x1); ("2", box_string x2)] in
        let is_internal s = Str.string_match (Str.regexp "^_") s 0 in
        `List (List.map makestrpair (List.filter (not -<- is_internal -<- fst) !cgi_parameters))),
	datatype "() -> [(String,String)]"));


  "redirect",
  (p1 (fun url ->
         let url = charlist_as_string url in
           (* This is all quite hackish, just testing an idea. --ez *)
           http_response_headers := ("Location", url) :: !http_response_headers;
           http_response_code := 302;
           `Record []
      ), datatype "(String) -> ()");   (* Should this function really return?
                                        I think not --ez*)

  (** reifyK: I choose an obscure name, for an obscure function, until
      a better one can be though up. It just turns a continuation into its
      string representation *)
  "reifyK",
  (p1 (function
           `Continuation k ->
             (match string_as_charlist(marshal_continuation k) with
                  `List _ as result -> result
                | _ -> assert(false))
         | _ -> failwith "argument to reifyK was not a continuation"
      ),
   datatype "((a) -> b) -> String"); (* arg type should actually be limited
                                      to continuations, but we don't have
                                      any way of specifying that in the
                                      type system. *)

  
  "exit",
  (`Continuation Result.toplevel_cont,
  (* Return type must be free so that it unifies with things that
     might be used alternatively. E.g.:
     if (test) exit(1) else 42 *)
   datatype "(a) -> b");

  (* Fable : relabeling operators *)
   ("unlabel",
     (`Server(p1 (fun v -> v)),
      Fable.unlabel_type));
   
   ("relabel",
    (`Server(p2 (fun v lab -> v)),
     Fable.relabel_type));

   "length",
  (p1 (unbox_list ->- List.length ->- num_of_int ->- box_int),
   datatype "([a]) -> Int");
   
  "take",
  (p2 (fun n l ->
         box_list (Utility.take (int_of_num (unbox_int n)) (unbox_list l))),
   datatype "(Int, [a]) -> [a]");

  "max",
  (p1 (let max2 x y = if less x y then y else x in
         function
           | `List [] -> `Variant ("None", `Record [])
           | `List (x::xs) -> `Variant ("Some", List.fold_left max2 x xs)
           | _ -> failwith "Internal error: non-list passed to max"),
   datatype "([a]) -> [|Some:a | None:()|]");

  "min",
  (p1 (let min2 x y = if less x y then x else y in
         function
           | `List [] -> `Variant ("None", `Record [])
           | `List (x::xs) -> `Variant ("Some", List.fold_left min2 x xs)
           | _ -> failwith "Internal error: non-list passed to min"),
   datatype "([a]) -> [|Some:a | None:()|]");

  (** XML **)
  "childNodes",
  (p1 (function
         | `List [`XML (Node (_, children))] ->
             let children = filter (function (Node _) -> true | _ -> false) children in
               `List (map (fun x -> `XML x) children)
         | _ -> failwith "non-XML given to childNodes"),
   datatype "(Xml) -> Xml");


  "print",
  (p1 (fun msg -> print_endline (unbox_string msg); flush stdout; `Record []),
   datatype "(String) -> ()");

  "not",
  (p1 (unbox_bool ->- not ->- box_bool),
   datatype "(Bool) -> Bool");

  "toUpper", char_conversion Char.uppercase;
  "toLower", char_conversion Char.lowercase;

  (* Database functions *)

  "getDatabaseConfig",
  (`PFun
     (fun _ ->
	let driver = Settings.get_value database_driver
	and args = Settings.get_value database_args in
	  if driver = "" then
	    failwith "Internal error: default database driver not defined"
	  else
	    `Record(["driver", string_as_charlist driver;
		     "args", string_as_charlist args])),
   datatype "() -> (driver:String, args:String)");


  "asList",
  (p1 (fun _ -> failwith "Unoptimized table access!!!"),
   datatype "(TableHandle(r, w)) -> [r]");

  (* "asView", *)
  (* (`Server  *)
  (*    (p2 (fun (`Database db) rows -> *)
  (*           `Table (db, "view", rows, { *)
  (*                     Expr.readtype = unit_type (); (\* 'a datatype *\) *)
  (*                     Expr.writetype = unit_type (); (\* 'a datatype *\) *)
  (*                     Expr.marshallby = []; *)
  (*                     Expr.primarykey = [] *)
  (*                   }))), *)
  (*  datatype "(Database, [a]) -> TableHandle (a, ())"); *)

  (* insertrows :: (TableHandle(r,w), [w]) -> () *)

  "insertrows",
  (`Server
     (p2 (fun table rows ->
            match table, rows with
              | `Table _, `List [] -> `Record []
              | `Table ((db, params), table_name, _, _), _ ->
                  let field_names = row_columns rows
                  and vss = row_values db rows
                  in Database.execute_insert (table_name, field_names, vss) db
              | _ -> failwith "Internal error: insert row into non-database")),
   datatype "(TableHandle(r, w), [w]) -> ()");


  (* updaterows :: (TableHandle(r,w), [(r,w)]) -> () *)

  "updaterows",
  (`Server
     (p2 (fun table rows ->
            match table, rows with
              | (_:result), (`List []:result) -> `Record []
              | `Table ((db, params), table_name, _, constraints), `List rows ->
                  List.iter 
                    (fun row ->
                       let keys = constraints.Expr.primarykey in
                       let query_string =
                         "UPDATE " ^ table_name
                         ^ " SET " ^ updates db (links_snd row)
                         ^ " WHERE " ^ key_match db keys (links_fst row)
                       in
                       prerr_endline("RUNNING UPDATE QUERY:\n" ^ query_string);
                       ignore (Database.execute_command query_string db))
                    rows;
                  `Record [])),
   datatype "(TableHandle(r, w), [(r, w)]) -> ()");

  (* deleterows :: (TableHandle(r,w), [r]) -> () *)

  "deleterows",
  (`Server
     (p2 (fun table rows ->
            match table, rows with
              | `Table _, `List [] -> `Record []
              | `Table ((db, params), table_name, _, _), _  ->
                  let condition = delete_condition db rows in
                  let query_string = "DELETE FROM " ^ table_name ^ " WHERE " ^ condition
                  in
                    prerr_endline("RUNNING DELETE QUERY:\n" ^ query_string);
                    (Database.execute_command query_string db)
              | _ -> failwith "Internal error: delete row from non-database")),
   datatype "(TableHandle(r, w), [r]) -> ()");

  (* misc string functions *)
  "string_split",
  (`PFun
     (fun [s;d] ->
	box_list (map box_string (Str.split (Str.regexp (unbox_string d)) (unbox_string s)))
     ),
     datatype "(String, String) -> [String]");

  (* get process ids *)
  "getpid",
  (`PFun
     (fun [] ->
	box_int (num_of_int (Unix.getpid ()))
     ),
     datatype "() -> Int");  

  "getppid",
  (`PFun
     (fun [] ->
	box_int (num_of_int (Unix.getppid ()))
     ),
     datatype "() -> Int");  

  (* random generation *)
  "rand_int",
  (`PFun
     (fun [] ->
	(Random.self_init ());
	box_int (num_of_int (Random.bits ()))
     ),
     datatype "() -> Int");

  (* socket comm *)
  ("proxy_open",
   (`Server
     (p2 (fun lhostname lport ->
	    let hostname = charlist_as_string lhostname in
	    let port     = int_of_num (unbox_int lport) in
	    let response = "opening socket comm at " ^ hostname ^ " port " ^ string_of_int (port) in
	    let p = Proxy.connect hostname port in
	      box_proxy p)),
     datatype "(String, Int) -> Proxy"));

  ("proxy_open_safe",
   (`Server
     (p2 (fun lhostname lport ->
	    let hostname = charlist_as_string lhostname in
	    let port     = int_of_num (unbox_int lport) in
	    let response = "opening socket comm at " ^ hostname ^ " port " ^ string_of_int (port) in
	      try 
		`Variant ("Just", box_proxy (Proxy.connect hostname port))
	      with
		| Unix.Unix_error(errno, name, more) -> `Variant ("Nothing", `Record [])
	 )),
     datatype "(String, Int) -> [| Just: Proxy | Nothing: () |]"));

  ("proxy_readline",
   (`Server
     (p1 (fun lproxy ->
	    let proxy = unbox_proxy(lproxy) in
	      box_string (Proxy.readline proxy))),
     datatype "(Proxy) -> String"));

  ("proxy_readline_safe",
   (`Server
     (p1 (fun lproxy ->
	    let proxy = unbox_proxy(lproxy) in
	      try `Variant ("Just", box_string (Proxy.readline proxy))
	      with | End_of_file -> `Variant ("Nothing", `Record [])
	 )),
     datatype "(Proxy) -> [| Just: String | Nothing: ()|]"));

  ("proxy_sendline",
   (`Server
     (p2 (fun lproxy lcommand ->
	    let proxy = unbox_proxy(lproxy) in
	    let command = charlist_as_string lcommand in
	      Proxy.sendline proxy command;
	      `Record []
	 )),
     datatype "(Proxy, String) -> ()"));

  ("proxy_send",
   (`Server
     (p2 (fun lproxy lcommand ->
	    let proxy = unbox_proxy(lproxy) in
	    let command = charlist_as_string lcommand in
	      Proxy.send proxy command;
	      `Record []
	 )),
     datatype "(Proxy, String) -> ()"));

  ("proxy_interact",
   (`Server
     (p2 (fun lproxy lcommand ->
	    let proxy = unbox_proxy(lproxy) in
	    let command = charlist_as_string lcommand in
	    let response = Proxy.interact proxy command in
	      box_string response)),
     datatype "(Proxy, String) -> String"));

  (* interact with proxy *)
  ("proxy_command",
   (`Server
      (p3 (fun lhostname lport lrequest ->
             let hostname = charlist_as_string lhostname in
             let port = int_of_num (unbox_int lport) in
             let request = charlist_as_string lrequest in
             let response = Proxy.command hostname port request in
             box_string response)),
    datatype "(String, Int, String) -> String"));

  (* interact with proxy *)
  (*
  ("proxy_command",
   (`Server
      (p3 (fun lhostname lport lrequest ->
             let hostname = charlist_as_string lhostname in
             let port = int_of_num (unbox_int lport) in
             let request = charlist_as_string lrequest in
             let response = Proxy.command hostname port request in
             box_string response)),
    datatype "(String, Int, String) -> String"));*)

  (* execSql :: (Database, String) -> () 
     Execute arbitrary SQL commands (for prototyping)
  *)
  "execSql",
  (p2 (
     function
       | `Database(db,_) -> unbox_string ->- (flip Database.execute_command) db
       | _ -> failwith "Internal error : expected Database"),
   datatype "(Database, String) -> ()");

  "getNextSequenceId",
  (p1 (function
        | `Table ((db, _), table_name, _, _) ->
        `Int (Num.num_of_int (db#nextval(table_name)))
        | _ -> failwith "Internal nextval error : expected Table"),
   datatype "(TableHandle(r, w)) -> Int");


  (* NativeString utilities *)
  ("char_at",
	(`Server (p2 (fun ((`NativeString ss) : result) ((`Int ix):result) -> `Char (ss.[Num.int_of_num ix]))),
	(datatype ("(NativeString, Int) -> Char"))));

  ("strlen",
     (`Server (p1 (fun s -> match s with
                     `NativeString ss -> `Int (Num.num_of_int (String.length ss))
	            |  _ -> failwith "Internal error: char_at got wrong arguments")),
	(datatype ("(NativeString) -> Int "))));

  ("to_native_string",
	(`Server (p1 (fun s -> let n = unbox_string s in (`NativeString n))),
	 (datatype ("(String) -> NativeString"))));
	
  ("from_native_string",
	(`Server (p1
	           (fun s-> match s with
	             (`NativeString ss) -> box_string ss
	             | _  -> failwith "Internal error: Bad coercion from native string")),
	 (datatype ("(NativeString) -> String"))));

   (* Serialize values to DB *)
  ("pickle_value",
     (`Server(p1 (fun v -> (box_string (marshal_value v)))),
	datatype "(a) -> String"));

  ("unpickle_value",
     (`Server(p1 (fun v -> unmarshal_value (unbox_string v))),
	datatype "(String) -> a"));

  "timestamp",
  (`PFun
     (fun [] ->
        let tm = Unix.gmtime (Unix.gettimeofday ()) in
        let s = Printf.sprintf "%d%02d%02d%02d%02d%02d"
        (1900+tm.Unix.tm_year) tm.Unix.tm_mon tm.Unix.tm_mday tm.Unix.tm_hour tm.Unix.tm_min tm.Unix.tm_sec
        in
        box_string s),
  datatype "() -> String");


  "getLocalTime",
  (`PFun
     (fun [] ->
        let tm = Unix.localtime (Unix.gettimeofday ()) in
        let s = Printf.sprintf "%02d:%02d:%02d"
        tm.Unix.tm_hour tm.Unix.tm_min tm.Unix.tm_sec
        in
        box_string s),
  datatype "() -> String");

  "getLocalDate",
  (`PFun
     (fun [] ->
        let tm = Unix.localtime (Unix.gettimeofday ()) in
        let s = Printf.sprintf "%d-%02d-%02d"
        (1900+tm.Unix.tm_year) tm.Unix.tm_mon tm.Unix.tm_mday
        in
        box_string s),
  datatype "() -> String");

  "toString",
  (p1 (string_of_result ->- box_string),
   datatype "(a) -> String");
  
        
  "startTransaction",
        (p1 (function
        | `Database(db,_) -> db#start_transaction(); `Record([])
        | _ -> failwith "Internal error : expected Database"),
        datatype "(Database) -> ()");

  "rollbackTransaction",
        (p1 (function
        | `Database(db,_) -> db#rollback_transaction(); `Record([])
        | _ -> failwith "Internal error : expected Database"),
        datatype "(Database) -> ()");

  "commitTransaction",
        (p1 (function
        | `Database(db,_) -> db#commit_transaction(); `Record([])
        | _ -> failwith "Internal error : expected Database"),
         datatype "(Database) -> ()");

  "getNextSequenceId",
  (p1 (function
        | `Table ((db, _), table_name, _,  _) -> 
        `Int (Num.num_of_int (db#nextval(table_name)))
        | _ -> failwith "Internal nextval error : expected Table"),
   datatype "(TableHandle(r, w)) -> Int");


  (* regular expression matching *)
  ("tilde",
   (p2 (fun s r ->
          let regex = Regex.compile_ocaml (Linksregex.Regex.ofLinks r)
          and string = unbox_string s in
            box_bool (Str.string_match regex string 0)),
    let qs, regex = datatype Linksregex.Regex.datatype in
    let mb = Types.fresh_raw_variable () in
    let arg_type = `Record (Types.row_with ("1", `Present (string_type()))
                              (Types.row_with ("2", `Present regex)
                                 (Types.make_empty_closed_row ()))) in
      ((`TypeVar mb, FableType.UKind) :: qs,
       (fannot (`Function (fannot arg_type, make_type_variable mb, Types.bool_type ()))))));

  (* All functions below are currenly server only; but client version should be relatively easy to provide *)
  ("ntilde",
   (p2 (fun s r ->
          let regex = Regex.compile_ocaml (Linksregex.Regex.ofLinks r)
	  and string = (match s with `NativeString ss -> ss | _ -> failwith "Internal error: expected NativeString") in
        box_bool (Str.string_match regex string 0)),
	let qs, regex = datatype Linksregex.Regex.datatype in
	let mb = Types.fresh_raw_variable () in
	let arg_type =
	`Record (Types.row_with ("1", `Present (native_string_type()))
                (Types.row_with ("2", `Present regex)
                (Types.make_empty_closed_row ()))) in
	((`TypeVar mb, FableType.UKind) :: qs,
	(fannot (`Function (fannot arg_type, make_type_variable mb, Types.bool_type ()))))));

  (* regular expression matching with grouped matched results as a list *)
  ("ltilde",
    (`Server (p2 (fun s r ->
        let (re, ngroups) = (Linksregex.Regex.ofLinksNGroups r)
        and string = unbox_string s in
	let regex = Regex.compile_ocaml re in
	match (Str.string_match regex string 0) with
	 false -> `List []
	| _ ->
	(let rec accumMatches l : int -> Result.result = function
           0 -> `List ((box_string (Str.matched_group 0 string))::l)
	|  i ->
	(try
	let m = Str.matched_group i string in
        accumMatches ((box_string m)::l) (i - 1)
	with
	   Not_found -> accumMatches ((`List [])::l) (i - 1)) in
	accumMatches [] ngroups))),
	let qs, regex = datatype Linksregex.Regex.datatype in
	let mb = Types.fresh_raw_variable () in
	let arg_type =
	`Record (Types.row_with ("1", `Present (string_type()))
                (Types.row_with ("2", `Present regex)
                (Types.make_empty_closed_row ()))) in
	((`TypeVar mb, FableType.UKind) :: qs,
	(fannot (`Function (fannot arg_type, make_type_variable mb, fannot (`Application ("List", [string_type()]))))))));

  ("lntilde",
    (`Server (p2 (fun s r ->
        let (re, ngroups) = (Linksregex.Regex.ofLinksNGroups r)
        and string = (match s with `NativeString ss -> ss | _ -> failwith "Internal error: expected NativeString") in
	let regex = Regex.compile_ocaml re in
	match (Str.string_match regex string 0) with
	 false -> `List []
	| _ ->
	(let rec accumMatches l : int -> Result.result = function
           0 -> `List ((box_string (Str.matched_group 0 string))::l)
	|  i ->
	(try
	let m = Str.matched_group i string in
        accumMatches ((box_string m)::l) (i - 1)
	with
	   Not_found -> accumMatches ((`List [])::l) (i - 1)) in
	accumMatches [] ngroups))),
	let qs, regex = datatype Linksregex.Regex.datatype in
	let mb = Types.fresh_raw_variable () in
	let arg_type =
	`Record (Types.row_with ("1", `Present (native_string_type()))
                (Types.row_with ("2", `Present regex)
                (Types.make_empty_closed_row ()))) in
	((`TypeVar mb, FableType.UKind) :: qs,
	(fannot (`Function (fannot arg_type, make_type_variable mb, fannot (`Application ("List", [string_type()]))))))));

  (* regular expression substitutions --- don't yet support global substitutions *)
  ("stilde",
   (`Server (p2 (fun s r ->
	let Regex.Replace(l, t) = Linksregex.Regex.ofLinks r in
	let (regex, tmpl) = Regex.compile_ocaml l, t in
        let string = unbox_string s in
        box_string (Utility.decode_escapes (Str.replace_first regex tmpl string)))),
	let qs, regex = datatype Linksregex.Regex.datatype in
	let mb = Types.fresh_raw_variable () in
	let arg_type =
	`Record (Types.row_with ("1", `Present (string_type()))
                (Types.row_with ("2", `Present regex)
                (Types.make_empty_closed_row ()))) in
	((`TypeVar mb, FableType.UKind) :: qs,
	(fannot (`Function (fannot arg_type, make_type_variable mb, string_type ()))))));
	
  ("sntilde",
   (`Server (p2 (fun s r ->
	let Regex.Replace(l, t) = Linksregex.Regex.ofLinks r in
	let (regex, tmpl) = Regex.compile_ocaml l, t in
	let string = (match s with `NativeString ss -> ss | _ -> failwith "Internal error: expected NativeString") in
	(`NativeString (Utility.decode_escapes (Str.replace_first regex tmpl string))))),
	let qs, regex = datatype Linksregex.Regex.datatype in
	let mb = Types.fresh_raw_variable () in
	let arg_type =
	`Record (Types.row_with ("1", `Present (native_string_type()))
        (Types.row_with ("2", `Present regex)
        (Types.make_empty_closed_row ()))) in
	((`TypeVar mb, FableType.UKind) :: qs,
	(fannot (`Function (fannot arg_type, make_type_variable mb, native_string_type()))))));

  (* Cookies *)
  "setCookie",
  (p2 (fun cookieName cookieVal ->
         let cookieName = charlist_as_string cookieName in
         let cookieVal = charlist_as_string cookieVal in
           http_response_headers :=
             ("Set-Cookie", cookieName ^ "=" ^ cookieVal) :: !http_response_headers;
           `Record []
             (* Note: perhaps this should affect cookies returned by
                getcookie during the current request. *)),
   datatype "(String, String) -> unit");

  "getCookie",
  (p1 (fun cookieName ->
         let cookieName = charlist_as_string cookieName in
           match getenv "HTTP_COOKIE" with
             | Some cookie_header ->
                 (let cookies = Str.split (Str.regexp ",") cookie_header in
                  let cookies = concat_map (fun str ->
                                       match Str.split (Str.regexp "=") str with
                                           [nm; vl] -> [nm, vl]
                                         | [nm] -> [nm, ""] (* ? *)
                                         | _ -> assert false) cookies in
                    box_string (snd (find (fun (nm, _) -> nm = cookieName)
                                       cookies)))
             | None -> `List []),
   datatype "(String) -> String");

  "debug",
  (p1 (fun message -> prerr_endline (unbox_string message); flush stderr;
                      `Record []),
   datatype "(String) -> ()");


  "objectType",
  (`Client, datatype "(a) -> String");

  "attribute",
  (p2 (let none = `Variant ("None", `Record []) in
         fun elem attr ->
             match elem with
               | `List ((`XML (Node (_, children)))::_) ->
                   let attr = charlist_as_string attr in
                   let attr_match = (function
                                       | Attr (k, _) when k = attr -> true
                                       | _ -> false) in
                     (try match find attr_match children with
                        | Attr (_, v) -> `Variant ("Some", string_as_charlist v)
                        | _ -> failwith "Internal error in `attribute'"
                      with NotFound _ -> none)
               | _ -> none),
   datatype "(Xml,String) -> [|Some:String | None:()|]");
  
  "alertDialog",
  (client_only_1 "alertDialog",
   datatype "(String) -> ()");


  "debugObj",
  (client_only_1 "debugObj", datatype "(a) -> ()");
  
  "dump",
  (client_only_1 "dump", datatype "(a) -> ()");
  
  "textContent",
  (client_only_1 "textContent", datatype "(a) -> String");
  (* FIXME: textContent should be from a type like DomNode, right? *)

  "javascript",
  (`Bool false, datatype "Bool");
  
  "negatef",
  (p1 (fun f -> box_float (-. (unbox_float f))), datatype "(Float) -> Float");

  
  (* HACK *)
  (*   [DEACTIVATED] *)
  (*   "callForeign", *)
  (*    (client_only_1 "callForeign", datatype "((a) -> b) -> (a) -> b"); *)

  (* DOM API *)

  "isElementNode",
  (`Client, datatype "(DomNode) -> Bool");


  (* [DEACTIVATED] *)
  (*   "domOp", *)
  (*   (p1 (fun message -> failwith("`domOp' is only available on the client."); *)
  (*          `Record []), *)
  (*    datatype "(a) -> ()"); *)

  "insertBefore",
  (`Client, datatype "(Xml, DomNode) -> ()");

  "appendChildren",
  (`Client, datatype "(Xml, DomNode) -> ()");

  "replaceNode",
  (`Client, datatype "(Xml, DomNode) -> ()");

  "replaceDocument",
  (`Client, datatype "(Xml) -> ()");

  "domInsertBeforeRef",
  (`Client, datatype "(DomNode, DomNode) -> ()");

  "domAppendChildRef",
  (`Client, datatype "(DomNode, DomNode) -> ()");

  "removeNode",
  (`Client, datatype "(DomNode) -> ()");

  "replaceChildren",
  (`Client, datatype "(Xml, DomNode) -> ()");

  "swapNodes",
  (`Client, datatype "(DomNode, DomNode) -> ()");

  "getDocumentNode",
  (`Client, datatype "() -> DomNode");

  "getNodeById",
  (`Client, datatype "(String) -> DomNode");

  "getValue",
  (`Client, datatype "(DomNode) -> Xml");

  "isNull",
  (`Client, datatype "(DomNode) -> Bool");

  (* Section: Accessors for XML *)
  "getTagName",
  (`Client, datatype "(Xml) -> String");

  "getTextContent",
  (`Client, datatype "(Xml) -> String");

  "getAttributes",
  (`Client, datatype "(Xml) -> [(String,String)]");

  "hasAttribute",
  (`Client, datatype "(Xml, String) -> Bool");

  "getAttribute",
  (`Client, datatype "(Xml, String) -> String");

  (* Section: Navigation for XML *)
  "getChildNodes",
  (`Client, datatype "(Xml) -> Xml");

  (* Section: Accessors for DomNodes *)
  "domGetNodeValueFromRef",
  (`Client, datatype "(DomNode) -> String");

  "domGetTagNameFromRef",
  (`Client, datatype "(DomNode) -> String");

  "domGetAttributeFromRef",
  (`Client, datatype "(DomNode, String) -> String");

  "domSetAttributeFromRef",
  (`Client, datatype "(DomNode, String, String) -> String");

  "domGetStyleAttrFromRef",
  (`Client, datatype "(DomNode, String) -> String");

  "domSetStyleAttrFromRef",
  (`Client, datatype "(DomNode, String, String) -> String");

  (* Section:  Navigation for DomNodes *)
  "parentNode",
  (`Client, datatype "(DomNode) -> DomNode");

  "firstChild",
  (`Client, datatype "(DomNode) -> DomNode");

  "nextSibling",
  (`Client, datatype "(DomNode) -> DomNode");

  (* Section: DOM Event API *)
  "getTarget",
  (`Client, datatype "(Event) -> DomNode");

  "getTargetValue",
  (`Client, datatype "(Event) -> String");

  "getTargetElement",
  (`Client, datatype "(Event) -> DomNode");

  (* getPageX : (Event) -> Int *)
  "getPageX",
  (`Client, datatype "(Event) -> Int");

  (* getPageY : (Event) -> Int *)
  "getPageY",
  (`Client, datatype "(Event) -> Int");

  (* getFromElement : (Event) -> DomNode *)
  "getFromElement",
  (`Client, datatype "(Event) -> DomNode");

  (* getToElement : (Event) -> DomNode *)
  "getToElement",
  (`Client, datatype "(Event) -> DomNode");

  (* getTime : (Event) -> Int *)
  "getTime",
  (`Client, datatype "(Event) -> Int");

  (* getCharCode : (Event) -> Char *)
  "getCharCode",
  (`Client, datatype "(Event) -> Char");

  "getInputValue",
  (`Client, datatype "(String) -> String");

(*   "event", *)
(*   (`Client, datatype "Event"); *)

  (* Yahoo UI library functions we don't implement: *)
  (* # stopEvent : ??? *)
  (* # stopPropagation : ??? *)
  (* # preventDefault : ??? *)

  (* getCommandOutput disabled for now; possible security risk. *)
  (*
    "getCommandOutput",
    (p1 ((unbox_string ->- Utility.process_output ->- box_string) :> result -> primitive),
    datatype "(String) -> String");
  *)

  "sleep",
  (* FIXME: This isn't right : it freezes all threads *)
  (p1 (fun duration -> Unix.sleep (int_of_num (unbox_int duration));
         `Record []),
   datatype "(Int) -> ()");


  (* [TODO]
       Implement server version of the timer
       (note: the OCaml unix time functionality is not portable
       so we shouldn't use that)
  *)
  "getCurrentTime",
  (`Client, datatype "() -> Int");


  (** some char functions **)
  "isAlpha",  char_test_op Char.isAlpha;
  "isAlnum",  char_test_op Char.isAlnum;
  "isLower",  char_test_op Char.isLower;
  "isUpper",  char_test_op Char.isUpper;
  "isDigit",  char_test_op Char.isDigit;
  "isXDigit", char_test_op Char.isXDigit;
  "isBlank",  char_test_op Char.isBlank;
  (* isCntrl, isGraph, isPrint, isPunct, isSpace *)
  

  "ord",
  (p1 (fun c -> box_int (num_of_int (Char.code (unbox_char c)))),
   datatype "(Char) -> Int");

  "chr",
  (p1 (fun n -> (box_char (Char.chr (int_of_num (unbox_int n))))),
   datatype "(Int) -> Char");

  (* some trig functions *)
  "floor",   float_fn floor;
  "ceiling", float_fn ceil;
  "cos",     float_fn cos;
  "sin",     float_fn sin;
  "tan",     float_fn tan;
  "log",     float_fn log;
  "sqrt",    float_fn sqrt;	
]
 

(*   "send", *)
(*   (p2 (fun pid msg ->  *)
(*          let pid = int_of_num (unbox_int pid) in *)
(*            (try  *)
(*               Queue.push msg (Hashtbl.find messages pid) *)
(*             with NotFound _ ->  *)
(*               (\* Is this really an internal error? Maybe target has finished? *\) *)
(*               failwith ("Internal error while sending message: no mailbox for " *)
(*                         ^ string_of_int pid)); *)
(*            (try  *)
(*               Queue.push(Hashtbl.find blocked_processes pid) suspended_processes; *)
(*               Hashtbl.remove blocked_processes pid *)
(*             with NotFound - -> ()); *)
(*            `Record []), *)
(*    datatype "(Mailbox (a), a) -{b}-> ()"); *)

(*   "self", *)
(*   (`PFun (fun _ -> `Int (num_of_int !current_pid)), *)
(*    datatype "() -{a}-> Mailbox (a)"); *)

(*   "recv", *)
(*   (\* this function is not used, as its application is a special case *)
(*      in the interpreter. But we need it here, for now, because of its *)
(*      type.  Ultimately we should probably not special-case it, but *)
(*      rather provide a way to implement this primitive from here. *)
(*      (Ultimately, it should perhaps be a true primitive (an AST node), *)
(*      because it uses a different evaluation mechanism from functions. *)
(*      -- jdy) *\) *)
(*     (p1 (fun _ -> assert false), *)
(*      datatype "() -{a}-> (a)"); *)

(*   "spawn", *)
(*   (\* This should also be a primitive, as described in the ICFP paper. *\) *)
(*   (p1 (fun f -> *)
(*          let new_pid = fresh_pid () in *)
(*            Hashtbl.add messages new_pid (Queue.create ()); *)
(*            Queue.push ((ApplyCont(empty_env, []) :: toplevel_cont, f), new_pid) suspended_processes; *)
(*            (`Int (num_of_int new_pid))), *)
(*    (\* *)
(*      a: spawn's mailbox type (ignored, since spawn doesn't recv) *)
(*      b: the mailbox type of the spawned process *)
(*      c: the parameter expected by the process function *)
(*      d: the return type of the spawned process function (ignored) *)
(*    *\) *)
(*    datatype "(() -{b}-> d) -> Mailbox (b)"); *)
(* (\*   datatype "Mailbox (a) -> (Mailbox (b) -> c -> d) -> Mailbox (a) -> c -> Mailbox (b)");*\) *)


  

(*   (\* Fable : relabeling operators *\) *)
(*   ("unlabel", *)
(*     (`Server(p1 (fun v -> v)),  *)
(*       Fable.unlabel_type)); *)
  
(*   ("relabel", *)
(*     (`Server(p2 (fun v lab -> v)),  *)
(*       Fable.relabel_type)) *)
(* ] *)

let mailbox_assumption = 
  (`Int (num_of_int 0),
   let u = fresh_type_variable () in
     (* Deliberately non-quantified type.  Mailboxes are
        non-polymorphic, so this is a so-called "weak type
        variable". *)
     ([], u))
    
let impl : located_primitive -> primitive option = function
  | `Client -> None
  | `Server p
  | (#primitive as p) -> Some p
      
(* Value environment reference *)
(* This is a reference to all primitives (taken from env, above) *)
let value_env = 
  let venv = 
    (List.fold_right
       (fun (name, (p,_)) env -> 
	      match impl p with
            | None -> env
            | Some p -> StringMap.add name p env)
       env
       StringMap.empty) in
  let venv' =  StringMap.add "_MAILBOX_" (fst mailbox_assumption) venv in
    ref venv'

let primitive_location (name:string) = match fst (assoc name env) with
  | `Client ->  `Client
  | `Server _ -> `Server
  | #primitive -> `Unknown

(* primitive stubs are defined in library (e.g., stringToInt) *)
let primitive_stub (name : string): result =
  match StringMap.find name (!value_env) with
    | #result as r -> r
    | _ -> `PrimitiveFunction name

(* apply a primitive function *)
let apply_pfun name args = 
  match StringMap.find name (!value_env) with
    | #result -> failwith ("Attempt to apply primitive non-function (" ^name ^")")
    | `PFun p -> p args
        
let type_env : Typeenv.environment =
  (List.map (fun (n, (_,t)) -> (n,t)) env)
and alias_env : Typeenv.alias_environment =
  List.fold_right
    (fun (name, assumption) env ->
       StringMap.add name assumption env)
    (List.map (fun (s, (tvl, t)) -> (s, (tvl, fannot t)))
	 [
	   "DomNode", ([], `Primitive `Abstract);
	   "Event", ([], `Primitive `Abstract);
	   "Proxy", ([], `Primitive `Abstract);
	   "List", ([`TypeVar (Expression.Types.fresh_raw_variable ()), FableType.MKind], `Primitive `Abstract);
	   "String", ([], `Application ("List", [fannot (`Primitive `Char)]));
	   "Xml", ([], `Application ("List", [fannot (`Primitive `XmlItem)]));
	   "Mailbox", ([`TypeVar (Expression.Types.fresh_raw_variable ()), FableType.UKind], `Primitive `Abstract)
	 ])
    StringMap.empty
    
    
let type_env_old = (("_MAILBOX_", (snd mailbox_assumption))::type_env, alias_env)

let type_env = 
  let omega = Typeenv.initial_env (type_env, alias_env) in
    Typeenv.add_normal_binding "_MAILBOX_" (snd mailbox_assumption) omega

let is_primitive name = List.mem_assoc name env

(** Output the headers and content to stdout *)
let print_http_response headers body =
  let headers = headers @ !http_response_headers @
    if (!http_response_code <> 200) then
      [("Status", string_of_int !http_response_code)] else []
  in
    for_each headers
      (fun (name, value) -> print_endline(name ^ ": " ^ value));
    print_endline "";
    print_string body


(* ************************************************************ *)

exception TopLevel of (environment * result)
exception RuntimeUndefVar of string

(* Lookup name in locals, globals, and primitives *)
(* This is used by both Doquery and Interpreter *)
let lookup (globals:environment) (locals:environment) (name:string) : result = 
  try 
    match Utility.lookup name locals with
      | Some v -> v
      | None -> match Utility.lookup name globals with
          | Some v -> v
          | None -> primitive_stub name
  with NotFound _ -> 
    (* may be thrown by primitive_stub *)
    raise (RuntimeUndefVar name)

(* ************************************************************ *)
