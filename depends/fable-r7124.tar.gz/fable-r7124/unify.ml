(*pp deriving *)

open Utility
open Syntax
open Expression
open Expression.Expr
open Expression.Types
open Expression.FableType
open Instantiate
open Typevarcheck
open Typeenv
open Printsyntax

(* Debugging flags *)
let show_unification = Settings.add_bool("show_unification", false, `User)
let show_row_unification = Settings.add_bool("show_row_unification", false, `User)
let show_recursion = Instantiate.show_recursion

let infer_recursive_types = Settings.add_string("infer_recursive_types", "guarded", `User)

exception Unify_failure of string

let occurs_check alias_env var t =
  match Settings.get_value infer_recursive_types with
    | "all" -> true
    | "guarded" -> is_guarded alias_env var t
    | "positive" -> not (is_negative alias_env var t)
    | s -> failwith ("user setting infer_recursive_types ("^ s ^") must be set to 'all', 'guarded' or 'positive'")
        
let occurs_check_row alias_env var row =
  match Settings.get_value infer_recursive_types with
    | "all" -> true
    | "guarded" -> is_guarded_row alias_env var row
    | "positive" -> not (is_negative_row alias_env var row)
    | s -> failwith ("user setting infer_recursive_types ("^ s ^") must be set to 'all', 'guarded' or 'positive'")

let var_is_free_in_type var datatype = TypeVarSet.mem var (free_type_vars datatype)

(* a special kind of structural equality on types that doesn't look
   inside points *)
let rec eq_types : (datatype * datatype) -> bool =
  fun (t1, t2) ->
    match (t1.Types.ltype, t2.Types.ltype) with
      | `Not_typed, `Not_typed -> true
      | `Primitive x, `Primitive y -> x = y
      | `MetaTypeVar lpoint, `MetaTypeVar rpoint ->
          Unionfind.equivalent lpoint rpoint
      | `Function (lfrom, lm, lto), `Function (rfrom, rm, rto) ->
          eq_types (lfrom, rfrom) && eq_types (lto, rto) && eq_types (lm, rm)
      | `Record l, `Record r -> eq_rows (l, r)
      | `Variant l, `Variant r -> eq_rows (l, r)
      | `Application (s, ts), `Application (s', ts') when s = s' -> List.for_all2 (Utility.curry eq_types) ts ts'
      | _, _ -> false
and eq_rows : (row * row) -> bool =
  fun ((lfield_env, lrow_var), (rfield_env, rrow_var)) ->
    eq_field_envs (lfield_env, rfield_env) && eq_row_vars (lrow_var, rrow_var)
and eq_field_envs (lfield_env, rfield_env) =
  let compare_specs = fun a b -> 
    match (a,b) with
      | `Absent, `Absent -> true
      | `Present t1, `Present t2 -> eq_types (t1, t2)
      | _, _ -> false
  in
  StringMap.equal compare_specs lfield_env rfield_env
and eq_row_vars (lpoint, rpoint) =
  (* [QUESTION]
     Do we need to deal with closed rows specially?
  *)
  match Unionfind.find lpoint, Unionfind.find rpoint with
    | ClosedRow, ClosedRow -> true
    | FlexibleRow var, FlexibleRow var'
    | RigidRow var, RigidRow var'
    | RecursiveRow (var, _), RecursiveRow (var', _) -> var=var'
    | _, _ -> Unionfind.equivalent lpoint rpoint

(*
  unification environment:
  for stopping cycles during unification
  and for type aliases
*)
type unify_type_env = (datatype list) IntMap.t
type unify_row_env = (row list) IntMap.t
type unify_env = {rec_types : unify_type_env;
                  rec_rows : unify_row_env;
                  omega : Typeenv.omega;
                  phantoms : string list;
		          exp : expression option;
		          polarity : [`Pos | `Neg];
		          subtype : bool}
    
let add_rec_types var tl uenv = {uenv with rec_types=IntMap.add var tl uenv.rec_types}
let add_rec_rows var rl uenv = {uenv with rec_rows=IntMap.add var rl uenv.rec_rows}
let contains_phantom n uenv = List.mem n uenv.phantoms
let flip_polarity env = {env with polarity = (match env.polarity with `Pos -> `Neg | `Neg -> `Pos)}
let set_expression env e = {env with exp = Some e}
let clear_expression env  = {env with exp = None}
  
let rec unify' : unify_env -> (datatype * datatype) -> Subst.subst = 
  (*     let rec_types, rec_rows, alias_env = rec_env in *)
  let check_polarity uenv = assert_msg (uenv.polarity = `Pos) "unification polarity failure" in

  let is_unguarded_recursive t =
    let rec is_unguarded rec_types t = 
      match t with
        | `MetaTypeVar point ->
            begin
              match Unionfind.find point with
                | Recursive (var, _) when IntSet.mem var rec_types -> true
                | Recursive (var, body) -> is_unguarded (IntSet.add var rec_types) (body.Types.ltype)
                | Body t -> is_unguarded rec_types (t.Types.ltype)
                | _ -> false
            end
        |  _ -> false
    in
    is_unguarded IntSet.empty t in
  
  let unify_rec uenv ((var, body), t) =
    (*       check_polarity uenv; *)
    let ts =
      if IntMap.mem var uenv.rec_types then
        IntMap.find var uenv.rec_types
      else
        [body]
    in
    (* break cycles *)
    if List.exists (fun t' -> eq_types (t, t')) ts then
      Subst.empty
    else
      unify' (add_rec_types var (t::ts) uenv) (body, t) in
  
  let unify_rec2 uenv ((lvar, lbody), (rvar, rbody)) =
    (*       check_polarity uenv; *)
    let lts =
      if IntMap.mem lvar uenv.rec_types then
        IntMap.find lvar uenv.rec_types
      else
        [lbody] in
    
    let rts =
      if IntMap.mem rvar uenv.rec_types then
        IntMap.find rvar uenv.rec_types
      else
        [rbody]
    in
    (* break cycles *)
    if (List.exists (fun t -> eq_types (t, rbody)) lts
        || List.exists (fun t -> eq_types (t, lbody)) rts) then
      Subst.empty
    else
      unify' ((add_rec_types lvar (rbody::lts) ->- add_rec_types rvar (lbody::rts)) uenv) (lbody, rbody) in
  

  (* introduce a recursive type
     give an error if it is non-well-founded and
     non-well-founded type inference is switched off

     preconditions:
     - Unionfind.find point = t
     - var is free in t
  *)
  let rec_intro uenv point (var, t) =
    (*       check_polarity uenv; *)
    if occurs_check (Typeenv.alias_env uenv.omega) var t then
      Unionfind.change point (Recursive (var, t))
    else
      raise (Unify_failure ("Cannot unify type variable "^string_of_int var^" with datatype "^string_of_datatype t^
                              " because "^
                              match Settings.get_value infer_recursive_types with
                                | "guarded" -> "the type variable occurs unguarded inside the datatype"
                                | "positive" -> "the type variable occurs in a negative position inside the datatype"
                                | _ -> assert false)) in
  
  let lookup_alias (s, ts) uenv =
    try 
	  let (q,d) = Typeenv.lookup_alias (s, ts) uenv.omega in
	  (q, Subst.rename_bound_vars d)
    with
        AliasMismatch msg -> raise (Unify_failure msg) in

  let unify_mtv uenv (mtv : datatype) (t:datatype) : Subst.subst = 
    (*       check_polarity uenv; *)
    if not ((Fable.is_empty mtv.ftype) && Fable.is_empty t.ftype) then
      raise (Unify_failure "Unable to unify fable qualifiers")
    else
      match mtv.ltype with 
          `MetaTypeVar point as mtv_l -> 
            begin
              (match (Unionfind.find point) with
                 | Rigid l -> 
                     raise (Unify_failure ("Couldn't unify the rigid type variable "^ string_of_int l ^" with the type "^ string_of_datatype t))
                 | Flexible var ->
                     begin
                       if var_is_free_in_type var t then
                         begin
                           Debug.if_set (show_recursion)
                             (fun () -> "rec intro3 ("^string_of_int var^","^string_of_datatype t^")");
                           if not (Fable.is_empty t.ftype) then 
                             raise (Unify_failure "Unification of fable qualifiers in recursive types is not currently supported");
                           let point' = Unionfind.fresh (Body t)
                           in
                           rec_intro uenv point' (var, t);
                           Unionfind.union point point'
                         end
                       else
                         (Debug.if_set (show_recursion) (fun () -> "non-rec intro (" ^ string_of_int var ^ ")");
                          Unionfind.change point (Body t))
                     end;
                     Subst.empty
                 | Recursive (var, t') ->
                     Debug.if_set (show_recursion) (fun () -> "rec single (" ^ (string_of_int var) ^ ")");
                     if not (Fable.is_empty t.ftype) then 
                       raise (Unify_failure "Unification of fable qualifiers in recursive types is not currently supported")
                     else
                       begin
                         if is_unguarded_recursive mtv_l then 
                           raise (Unify_failure ("Couldn't unify the unguarded recursive type "^
                                                   string_of_datatype mtv ^
                                                   " with the non-recursive type "^ string_of_datatype t))
                         else                   
                           unify_rec uenv ((var, t'), t)
                       end
                         (* It's tempting to try to do this, but it isn't sound
                            as point may appear inside t
                            
                            Unionfind.change point t;
                         *)
                 | Body t' -> 
                     if not (Fable.is_empty t.ftype) then 
                       raise (Unify_failure "Failed to unify fable qualifiers")
                     else
                       unify' uenv (t', t))
            end
        | _ -> failwith "Impossible" in
  
  let unify_app uenv app t : Subst.subst = match app.ltype with 
    | `Application (s, ts) -> 
        let vars, alias = lookup_alias (s, ts) uenv in
        begin
          match alias.ltype with
            | `Primitive `Abstract ->
                raise (Unify_failure
                         ("Cannot unify abstract type '"^ string_of_datatype app  ^"' with type '"^string_of_datatype t^"'"))
            | _ ->
                unify' uenv (instantiate_alias s (Typeenv.alias_env uenv.omega) (vars, alias) ts, t)
        end
    | _ -> failwith "Impossible" in

  let check_empty_quals (t1,t2) =
    if not (Fable.is_empty t1.ftype && Fable.is_empty t2.ftype) then
	  raise (Unify_failure "Could not unify fable qualifiers") in
  (*         match (concrete_type t1).ltype, (concrete_type t2).ltype with (\* fable quals were not completely unified; *\) *)
  (*             `MetaTypeVar _, _ (\* only possibility is for the remaining quals to be unified with an mtv *\) *)
  (*           | _, `MetaTypeVar _ -> () *)
  (*           | _ -> raise (Unify_failure "Could not unify fable qualifiers") *)
  (*       else () in *)

  let assert_empty_quals (t1,t2) = 
    if not (Fable.is_empty t1.ftype && Fable.is_empty t2.ftype) then
      raise (Unify_failure "Could not unify fable qualifiers") 
    else () in
  
  let unify_l uenv (t1, t2) : Subst.subst =
    check_polarity uenv;
    (Debug.if_set (show_unification) (fun () -> "Unifying "^string_of_datatype t1^" with "^string_of_datatype t2);
     check_empty_quals (t1,t2);
     let sigma = 
	   (match (t1.ltype, t2.ltype) with
          | `Not_typed, _ | _, `Not_typed -> failwith "Internal error: `Not_typed' passed to `unify'"
          | `Primitive x, `Primitive y when x = y -> Subst.empty
          | `MetaTypeVar lpoint, `MetaTypeVar rpoint -> 
		      if Unionfind.equivalent lpoint rpoint then
		        ()
		      else
                begin
                  let unify_flex_t ((_ : datatype), point1, var) ((t2:datatype), point2) =
		            (if var_is_free_in_type var t2 then (* no fable types remain to be unified *)
                       (Debug.if_set (show_recursion) (fun () -> "rec intro1 (" ^ (string_of_int var) ^ ")");
                        rec_intro uenv rpoint (var, Types.concrete_type t2))
		             else
                       Unionfind.union point1 point2)                    
                  in
                  match (Unionfind.find lpoint, Unionfind.find rpoint) with
			        | Rigid l, Rigid r ->
                        if l <> r then 
                          raise (Unify_failure ("Rigid type variables "^ string_of_int l ^" and "^ string_of_int r ^" do not match"))
                        else 
                          failwith "Unreachable case reached"
				            (*                          Unionfind.union lpoint rpoint (\* Question : Is this case ever reachable? *\) *)
			        | Flexible _, Flexible _ ->
                        Unionfind.union lpoint rpoint

			        | Flexible var, _ -> unify_flex_t (t1, lpoint, var) (t2, rpoint)
			        | _, Flexible var -> unify_flex_t (t2, rpoint, var) (t1, lpoint)
                        
			        | Rigid l, _ ->
                        raise (Unify_failure ("Couldn't unify the rigid type variable "^
                                                string_of_int l ^" with the type "^ string_of_datatype t2))
			        | _, Rigid r ->
                        raise (Unify_failure ("Couldn't unify the rigid type variable "^
                                                string_of_int r ^" with the type "^ string_of_datatype t1))
			        | Recursive (lvar, t), Recursive (rvar, t') ->
                        assert(lvar <> rvar);
                        assert_empty_quals (t1,t2);
                        Debug.if_set (show_recursion)
                          (fun () -> "rec pair (" ^ (string_of_int lvar) ^ "," ^ (string_of_int rvar) ^")");
                        begin
                          if is_unguarded_recursive (`MetaTypeVar lpoint) then
				            begin
                              if not (is_unguarded_recursive (`MetaTypeVar rpoint)) then
                                raise (Unify_failure ("Couldn't unify the unguarded recursive type "^
                                                        string_of_datatype t1 ^
                                                        " with the guarded recursive type "^ string_of_datatype t2))
				            end
                          else if is_unguarded_recursive (`MetaTypeVar lpoint) then
				            raise (Unify_failure ("Couldn't unify the unguarded recursive type "^
							                        string_of_datatype t2 ^
							                        " with the guarded recursive type "^ string_of_datatype t1));
                          ignore(unify_rec2 uenv ((lvar, t), (rvar, t')))
                        end;
                        Unionfind.union lpoint rpoint
                          
			        | Recursive (var, t'), Body t ->
                        assert_empty_quals (t1,t2);
                        Debug.if_set (show_recursion) (fun () -> "rec left (" ^ (string_of_int var) ^ ")");
                        begin
                          if is_unguarded_recursive (`MetaTypeVar lpoint) then
				            raise (Unify_failure ("Couldn't unify the unguarded recursive type "^
							                        string_of_datatype t1  ^
							                        " with the non-recursive type "^ string_of_datatype t2))
                          else                   
				            ignore(unify_rec uenv ((var, t'), t))
                        end;
                        Unionfind.union rpoint lpoint
                          
			        | Body t, Recursive (var, t') ->
                        assert_empty_quals (t1,t2);
                        Debug.if_set (show_recursion) (fun () -> "rec right (" ^ (string_of_int var) ^ ")");
                        begin
                          if is_unguarded_recursive (`MetaTypeVar rpoint) then
				            raise (Unify_failure ("Couldn't unify the unguarded recursive type "^
							                        string_of_datatype t2 ^
							                        " with the non-recursive type "^ string_of_datatype t1))
                          else                   
				            ignore(unify_rec (flip_polarity uenv) ((var, t'), t))
                        end;
                        Unionfind.union lpoint rpoint
			        | Body t, Body t' -> 
                        assert_empty_quals (t1,t2);
                        ignore(unify' uenv (t, t')); 
                        Unionfind.union lpoint rpoint
                end;
		      Subst.empty
          | `MetaTypeVar _, _ -> unify_mtv uenv t1 t2
          | _, `MetaTypeVar _ -> unify_mtv (flip_polarity uenv) t2 t1 
          | `Function (lfrom, lm, lto), `Function (rfrom, rm, rto) ->
		      let phl, noptl = Fable.get_name_bindings lfrom.ftype in
		      let phr, noptr = Fable.get_name_bindings rfrom.ftype in
		      let lfrom, rfrom = Fable.strip_name_bindings_type lfrom, Fable.strip_name_bindings_type rfrom in
		      let sigma0 = 
                if (List.length phl <> List.length phr) then
                  raise (Unify_failure "Couldn't unify function types with different number of phantom variables")
                else
                  List.fold_left2 (fun sub nl nr -> 
                                     Subst.extend (nr, Variable(nl, `T(dummy_position, Fable.fresh_label_type(), None))) sub)
                    Subst.empty phl phr in
		      let sigma0 = 
                match noptl, noptr with
                    None, None -> sigma0
                  | Some nl, Some nr -> Subst.extend (nr, Variable(nl, `T(dummy_position, Fable.fresh_label_type(), None))) sigma0 
                  | _ -> raise (Unify_failure "Couldn't unify function types with incompatible name bindings") in
		      let uenv = clear_expression uenv in
		      let sigma1 = unify' uenv (lfrom, Subst.apply sigma0 rfrom) in
		      let sigma01 = Subst.union sigma0 sigma1 in
		      let sigma2 = unify' uenv (lto, Subst.apply sigma01 rto) in
		      let sigma012 = Subst.union sigma01 sigma2 in
		      let sigma3 = unify' uenv (lm, Subst.apply sigma012 rm) in
              Subst.union sigma012 sigma3 
          | `Record l, `Record r -> unify_record_rows uenv (l, r)
          | `Variant l, `Variant r -> unify_variant_rows uenv (l, r)
          | `Table (lr, _), `Table (rr, _) ->
		      let uenv = clear_expression uenv in
		      let sigma = unify' uenv (lr, rr) in
		      let sigma' = unify' uenv (lr, Subst.apply sigma rr) in
		      Subst.union sigma sigma'
          | `Application (ls, lts), `Application (rs, rts) when ls = rs -> 
		      let uenv = clear_expression uenv in 
		      List.fold_left2 (fun sigma lt rt -> let sigma' = unify' uenv (lt, Subst.apply sigma rt) in Subst.union sigma sigma') Subst.empty lts rts
          | `Application (ls, lts), `Application (rs, rts) ->
		      let lvars, lalias = lookup_alias (ls, lts) uenv
		      and rvars, ralias = lookup_alias (rs, rts) uenv in
              begin
                match lalias.ltype, ralias.ltype with
                  | `Primitive `Abstract, `Primitive `Abstract ->
                      raise (Unify_failure
                               ("Cannot unify abstract type '"^string_of_datatype t1^
                                  "' with abstract type '"^string_of_datatype t2^"'"))
                  | `Primitive `Abstract, _ ->
                      unify' uenv (t1, instantiate_alias rs (Typeenv.alias_env uenv.omega) (rvars, ralias) rts)
                  | _, `Primitive `Abstract ->
                      unify' uenv (instantiate_alias ls (Typeenv.alias_env uenv.omega) (lvars, lalias) lts, t2)
                  | _, _ ->
                      unify' uenv (instantiate_alias ls (Typeenv.alias_env uenv.omega) (lvars, lalias) lts,
                                   instantiate_alias rs (Typeenv.alias_env uenv.omega) (rvars, ralias) rts)
              end
          | `Application _, _  -> unify_app uenv t1 t2
          | _, `Application _ -> unify_app (flip_polarity uenv) t2 t1
          | _, _ ->
		      raise (Unify_failure ("Couldn't match "^ string_of_datatype t1 ^" against "^ string_of_datatype t2))) in
	 Debug.if_set (show_unification) (fun () -> "Unified types: " ^ string_of_datatype t1);
	 sigma) in

  let unify_ftype uenv (tf1, tf2) : ((fable_type * fable_type) * Subst.subst) = 
    check_polarity uenv;
    let fail _ = raise (Unify_failure ("Could not unify types; incompatible fable qualifiers: " ^ 
					                       (Expression.DerivingSyntax.Show_fable_type.show tf1) ^ " <> " ^
					                       (Expression.DerivingSyntax.Show_fable_type.show tf2) ^ " : " )) in
    let rec aux sigma = function 
        `Name _, `Name _
      | `Phantom _, `Phantom _ -> failwith "Unexpected top-level name binding in fable type qualifier"
	      
	  |  q1, q2 when q1 = q2 -> (`Empty, `Empty), sigma 
	       
	  | `Kind k1, `Kind k2 when Fable.sub_kind (k1,k2) -> (`Empty, `Empty), sigma 

	  | (`Kind _ as tf1), `Label(`Inferred pt, tf2) -> 
	      Unionfind.change pt `Nothing;
	      aux sigma (tf1, tf2)

	  | (`KindVar _ as tf1), `Label(`Inferred pt, tf2) -> 
	      Unionfind.change pt `Nothing;
	      aux sigma (tf1, tf2)

	  | `KindVar kv1, `KindVar kv2 when Unionfind.equivalent kv1 kv2 -> 
	      (`Empty, `Empty), sigma

	  | `KindVar kv1, `KindVar kv2 ->
	      begin
	        match Unionfind.find kv1, Unionfind.find kv2 with
		        `FixedKind k1, `FlexKind (_, k2) -> 
		          if  Fable.sub_kind (Fable.kind_qual k1,k2) then () 
		          else fail()
			        
		      | `FlexKind (_, k1), `FixedKind k2 -> 
		          if  Fable.sub_kind (Fable.kind_qual k2,k1) then
			        Unionfind.change kv1 (`FixedKind k2)
		          else fail()
			        
		      | `FlexKind (_, k1), `FlexKind (_, k2) -> 
		          if (Fable.sub_kind (k1,k2)) then
		            Unionfind.union kv2 kv1 
		          else 
			        Unionfind.union kv1 kv2 
			          
		      | `FixedKind k1, `FixedKind k2 -> 
		          let _, sigma' = aux sigma (k1, k2) in
			      if (sigma <> sigma') then fail (k1,k2) 
	      end;
	      (`Empty, `Empty), sigma
	        
	  | fq1, `KindVar kv2 -> 
	      (match Unionfind.find kv2 with 
	         | `FixedKind fq2 -> aux sigma (fq1, fq2)
	         | `FlexKind (_, kb) when Fable.sub_kind (Fable.kind_qual fq1, kb) ->
		         Unionfind.change kv2 (`FixedKind fq1); (`Empty, `Empty), sigma
	         | _ -> fail ())
	        
	  | `KindVar kv1, fq2 -> 
	      let _ = match Unionfind.find kv1 with 
	        | `FixedKind fq1 -> aux sigma (fq1, fq2)
	        | `FlexKind (_, kb) when Fable.sub_kind (kind_qual fq2, kb) ->
		        Unionfind.change kv1 (`FixedKind fq2); (`Empty, `Empty), sigma
	        | _ -> fail () in
	      (`Empty, `Empty), sigma
	        
      | `Label (e1opt, tf1), `Label(e2opt, tf2) ->
          let sigma' = match e1opt, e2opt with 
	        | `Nothing, `Nothing -> sigma
	        | `Nothing, `Required e2 -> 
		        (match uenv.exp with 
		             None -> fail ()
		           | Some e1 -> (* subtype e:lab <: e:lab~e *)
			           let sigma' = Expequiv.unify uenv.phantoms uenv.omega (e1, e2) in
			           Subst.union sigma sigma' )

	        | `Required _, `Nothing -> sigma

	        | `Nothing, `Inferred pt ->
		        Unionfind.change pt `Nothing; sigma
	        | `Inferred pt, `Nothing -> 
		        if not (uenv.subtype) then 
		          Unionfind.change pt `Nothing; 
		        sigma
		          
            | `Inferred p1, `Inferred p2 -> 
		        (match Unionfind.find p1, Unionfind.find p2 with
		             `Nothing, `Nothing -> sigma
		           | `Something _, `Nothing -> 
			           if not uenv.subtype then
			             Unionfind.change p1 `Nothing; 
			           sigma
		           | `Nothing, `Something _ -> Unionfind.change p2 `Nothing; sigma
		           | `Something e1, `Something e2 -> 
			           try
			             let sigma' = Expequiv.unify uenv.phantoms uenv.omega (e1,e2) in
			             Subst.union sigma sigma'
			           with
			               Expequiv.Equiv_failure _ -> 
			                 Unionfind.change p2 `Nothing; 
			                 if not uenv.subtype then
				               Unionfind.change p1 `Nothing;
			                 sigma)
		          
            | `Inferred pt, `Required(e2) -> 
		        (match Unionfind.find pt with
		             `Nothing -> fail ()
		           | `Something e1 -> 
			           let sigma' = Expequiv.unify uenv.phantoms uenv.omega (e1, e2) in
			           Subst.union sigma sigma')
                  
	        | `Required(e1), `Required(e2) -> 
		        let sigma' = Expequiv.unify uenv.phantoms uenv.omega (e1, e2) in
		        Subst.union sigma sigma'
		          
	        | `Required _, `Inferred _ -> raise Impos
                
	      in
          let tf1' = Subst.apply_fq sigma' tf1 in
          let tf2' = Subst.apply_fq sigma' tf2 in
          aux sigma' (tf1', tf2')
		    
	  | `Label(_, tf1), (`Kind _ as tf2) -> aux sigma (tf1, tf2)
          (* 	| `Label(_, tf1), (`KindVar _ as tf2) -> aux sigma (tf1, tf2) *)

	  | (`Kind _ as tf1), `Label(`Nothing, tf2) -> aux sigma (tf1, tf2)
          (* 	| (`KindVar _ as tf1), `Label(`Nothing, tf2) -> aux sigma (tf1, tf2) *)
	      
      | `Labeling(e1, tf1), `Labeling(e2, tf2) -> 
          let sigma' = Expequiv.unify uenv.phantoms uenv.omega (e1, e2) in
          let sigma' = Subst.union sigma sigma' in
          let tf1' = Subst.apply_fq sigma' tf1 in
          let tf2' = Subst.apply_fq sigma' tf2 in
          aux sigma' (tf1', tf2')

      | `Empty,  tf2 ->
	      (match tf2 with
		       `Kind MKind 
	         | `Kind UKind -> (`Empty, `Empty), sigma 
 	         | _ -> fail ())

      |  tf1, `Empty -> 
	       (match tf1 with
		        `Kind _ -> (`Empty, `Empty), sigma 
		      | `Label(_, tf1') -> aux sigma (tf1', `Empty)
 		      | _ -> fail())
	         
  	  | _ -> fail () in
	try 
      aux Subst.empty (tf1, tf2)
	with 
	    Expequiv.Equiv_failure msg -> raise (Unify_failure msg) in
  fun uenv (t1,t2) -> 
	match uenv.polarity with 
	    `Neg -> unify' (flip_polarity uenv) (t2, t1)
	  | `Pos -> 
          let (f1', f2'), sigma = unify_ftype uenv (t1.ftype,t2.ftype) in
          let t1' = Subst.apply sigma {ltype = t1.ltype; ftype = f1'} in
          let t2' = {ltype = t2.ltype; ftype = f2'} in 
		  assert_msg (list_intersect (Subst.domain sigma) (Fable.free_names uenv.omega t2') = []) "Domain sigma contains unexpected names"; 
		  let sigma' = unify_l uenv (t1',t2') in
		  Subst.union sigma sigma' 
		    
and unify_variant_rows : unify_env -> (row * row) -> Subst.subst = 
  fun unify_env (lrow, rrow) -> 
    
    (* 
       [NOTE]

       - All calls to fail_on_absent_fields are currently disabled,
       as under the current model absent fields have
       to be allowed in closed rows (although they're ignored).

       - There's no way of getting rid of absent variables as they're stored in the field
       environment rather than the row variable (good argument for moving them into the
       row variable).
    *)
    (*
      let fail_on_absent_fields field_env =
      StringMap.iter
      (fun _ -> function
      | `Present _ -> ()
      | `Absent ->
      failwith "Internal error: closed row with absent variable"
      ) field_env in
    *)

    let is_unguarded_recursive row =
      let rec is_unguarded rec_rows (field_env, row_var) =
        StringMap.is_empty field_env &&
          (match Unionfind.find row_var with
             | ClosedRow
             | FlexibleRow _
             | RigidRow _ -> false
             | RecursiveRow (var, _) when IntSet.mem var rec_rows -> true
             | RecursiveRow (var, row) -> is_unguarded (IntSet.add var rec_rows) row
             | BodyRow row -> is_unguarded rec_rows row)
      in
      is_unguarded IntSet.empty row in
    
    (* extend_field_env traversal_env extending_env
       extends traversal_env with all the fields in extending_env

       Matching `Present fields are unified.

       Any fields in extending_env, but not in traversal_env are
       added to an extension environment which is returned.
    *)
    let extend_field_env
        (uenv : unify_env)
        (traversal_env : field_spec_map)
        (extending_env : field_spec_map) =
      StringMap.fold
        (fun label field_spec (extension, sigma) ->
           if StringMap.mem label extending_env then
             (match field_spec, (StringMap.find label extending_env) with
                | `Present t, `Present t' ->
                    let sigma' = unify' uenv (t, Subst.apply sigma t') in
                    extension, Subst.union sigma (Subst.restrict sigma' uenv.phantoms)
                | `Absent, `Absent ->
                    extension, sigma
                | `Present _, `Absent
                | `Absent, `Present _ ->
                    raise (Unify_failure ("Rows\n "^ string_of_row lrow
                                          ^"\nand\n "^ string_of_row rrow
                                          ^"\n could not be unified because they have conflicting fields"))
             )
           else
             StringMap.add label field_spec extension, sigma
        ) traversal_env (StringMap.empty, Subst.empty) in
	
    let unify_compatible_field_environments uenv (field_env1, field_env2) =
      extend_field_env uenv field_env1 field_env2 in
	
    (* introduce a recursive row
       give an error if it is non-well-founded and
       non-well-founded type inference is switched off
    *)
    let rec_row_intro uenv point (var, row) =
	  let alias_env = Typeenv.alias_env uenv.omega in
      if occurs_check_row alias_env var row then
        Unionfind.change point (RecursiveRow (var, row))
      else
        raise (Unify_failure ("Cannot unify row variable "^string_of_int var^" with row "^string_of_row row^
                                " because "^
                                match Settings.get_value infer_recursive_types with
					              | "guarded" -> "the row variable occurs unguarded inside the row"
					              | "positive" -> "the row variable occurs in a negative position inside the row"
					              | _ -> assert false)) in
	
    (*
      unify_row_var_with_row rec_env (row_var, row)
      attempts to unify row_var with row
      
      However, row_var may already have been instantiated, in which case
      it is unified with row.
    *)
    let unify_row_var_with_row : unify_env -> row_var * row -> unit =
      fun uenv (row_var, ((extension_field_env, extension_row_var) as extension_row)) ->
        (* unify row_var with `RowVar None *)
        let close_empty_row_var : row_var -> unit = fun point ->
          match Unionfind.find point with
            | ClosedRow -> ()
            | FlexibleRow _ ->
                Unionfind.change point ClosedRow
            | RigidRow _ ->
                raise (Unify_failure ("Closed row var cannot be unified with rigid row var\n"))
            | _ -> assert false in

        (* unify row_var with `RigidRowVar var *)
        let rigidify_empty_row_var var : row_var -> unit = fun point ->
          match Unionfind.find point with
            | ClosedRow ->
                raise (Unify_failure ("Rigid row var cannot be unified with empty closed row\n"))
            | FlexibleRow _ ->
                Unionfind.change point (RigidRow var)
            | RigidRow var' when var=var' -> ()
            | RigidRow _ ->
                raise (Unify_failure ("Incompatible rigid row variables cannot be unified\n"))
            | _ -> assert false in

        let rec extend = function
          | point ->
              (* point should be a row variable *)
              let row_var = Unionfind.find point in
              match row_var with
                | ClosedRow ->
                    if is_empty_row extension_row then
                      close_empty_row_var extension_row_var
                    else
                      raise (Unify_failure ("Closed row cannot be extended with non-empty row\n"
                                            ^string_of_row extension_row))
                | RigidRow var ->
                    if is_empty_row extension_row then
                      rigidify_empty_row_var var extension_row_var
                    else
                      raise (Unify_failure ("Rigid row variable cannot be unified with non-empty row\n"
                                            ^string_of_row extension_row))
                | FlexibleRow var ->
                    if TypeVarSet.mem var (free_row_type_vars extension_row) then
                      rec_row_intro uenv point (var, extension_row)
                    else if StringMap.is_empty extension_field_env then
                      match extension_row_var with
                        | point' ->
                            Unionfind.union point point'
                    else
                      Unionfind.change point (BodyRow extension_row)
                | RecursiveRow _ ->
                    ignore (unify_variant_rows uenv ((StringMap.empty, point), extension_row)) (* TODO: check this *)
                | BodyRow row ->
                    ignore (unify_variant_rows uenv (row, extension_row))  (* TODO: check this *)
        in
        extend row_var in
	

    (* 
       matching_labels (big_field_env, small_field_env)
       return the set of labels that appear in both big_field_env and small_field_env

       precondition: big_field_env contains small_field_env
    *)
    let matching_labels : field_spec_map * field_spec_map -> StringSet.t = 
      fun (big_field_env, small_field_env) ->
        StringMap.fold (fun label _ labels ->
                          if StringMap.mem label small_field_env then
                            StringSet.add label labels
                          else
                            labels) big_field_env StringSet.empty in

    let row_without_labels : StringSet.t -> row -> row =
      fun labels (field_env, row_var) ->
        let restricted_field_env =
          StringSet.fold (fun label field_env ->
                            StringMap.remove label field_env) labels field_env
        in
        (restricted_field_env, row_var) in

    (*
      register a recursive row in the rec_env environment
      
      return:
      None if the recursive row already appears in the environment
      Some rec_env, otherwise, where rec_env is the updated environment
    *)
    let register_rec_row (wrapped_field_env, unwrapped_field_env, rec_row, unwrapped_row') : unify_env -> unify_env option =
      fun uenv -> (* ((rec_types, rec_rows, alias_env) as rec_env) -> *)
        match rec_row with
          | Some row_var ->
              begin
                match Unionfind.find row_var with
                  | RecursiveRow (var, _) ->
                      let restricted_row = row_without_labels (matching_labels (unwrapped_field_env, wrapped_field_env)) unwrapped_row' in
                      let rs =
                        if IntMap.mem var uenv.rec_rows then
                          IntMap.find var uenv.rec_rows
                        else
                          [(StringMap.empty, row_var)]
                      in
                      if List.exists (fun r ->
                                        eq_rows (r, restricted_row)) rs then
                        None
                      else
                        Some (add_rec_rows var (restricted_row::rs) uenv)
                  | _ -> assert false
              end
          | None ->
              Some uenv in

    (*
      register two recursive rows and return None if one of them is already in the environment
    *)
    let register_rec_rows p1 p2 : unify_env -> unify_env option = fun uenv ->
      let uenv' = register_rec_row p1 uenv in
      match uenv' with
        | None -> None
        | Some uenv -> register_rec_row p2 uenv in

    let unify_both_rigid_with_rec_env uenv ((lfield_env, _ as lrow), (rfield_env, _ as rrow)) =
      let get_present_labels (field_env, row_var) =
        let rec get_present' rec_vars (field_env, row_var) =
          let top_level_labels = 
            StringMap.fold (fun label field_spec labels ->
                              match field_spec with
                                | `Present _ -> StringSet.add label labels
                                | `Absent -> labels) field_env StringSet.empty
          in
          StringSet.union top_level_labels 
            (match Unionfind.find row_var with
               | RecursiveRow (var, body) when (not (IntSet.mem var rec_vars)) ->
                   get_present' (IntSet.add var rec_vars) body
               | _ -> StringSet.empty) in
        get_present' IntSet.empty (field_env, row_var) in
      
      let fields_are_compatible (lrow, rrow) =
        (StringSet.equal (get_present_labels lrow) (get_present_labels rrow)) in
      
      let (lfield_env', lrow_var') as lrow', lrec_row = unwrap_row lrow in
      let (rfield_env', rrow_var') as rrow', rrec_row = unwrap_row rrow in
      (*
        fail_on_absent_fields lfield_env;
        fail_on_absent_fields rfield_env;
      *)
      match Unionfind.find lrow_var', Unionfind.find rrow_var' with
        | RigidRow lvar, RigidRow rvar when lvar <> rvar ->
            raise (Unify_failure ("Rigid rows\n "^ string_of_row lrow
                                  ^"\nand\n "^ string_of_row lrow
                                  ^"\n could not be unified because they have distinct rigid row variables"))
        | _, _ ->
            if fields_are_compatible (lrow', rrow') then
              let uenv' =
                (register_rec_rows
                   (lfield_env, lfield_env', lrec_row, rrow')
                   (rfield_env, rfield_env', rrec_row, lrow')
                   uenv)
              in
              match uenv' with
                | None -> Subst.empty
                | Some uenv ->
                    snd (unify_compatible_field_environments uenv (lfield_env', rfield_env'))
            else
              raise (Unify_failure ("Rigid rows\n "^ string_of_row lrow
                                    ^"\nand\n "^ string_of_row rrow
                                    ^"\n could not be unified because they have different fields")) in

    let unify_both_rigid uenv = unify_both_rigid_with_rec_env uenv in

    let unify_one_rigid uenv ((rigid_field_env, _ as rigid_row), (open_field_env, _ as open_row)) =
      let (rigid_field_env', rigid_row_var') as rigid_row', rigid_rec_row = unwrap_row rigid_row in
      let (open_field_env', open_row_var') as open_row', open_rec_row = unwrap_row open_row in 
      (* check that the open row contains no extra fields *)
      StringMap.iter
        (fun label field_spec ->
           if (StringMap.mem label rigid_field_env') then
             ()
           else
             match field_spec with
               | `Present _ ->
                   raise (Unify_failure
                            ("Rows\n "^ string_of_row rigid_row
                             ^"\nand\n "^ string_of_row open_row
                             ^"\n could not be unified because the former is rigid"
                             ^" and the latter contains fields not present in the former"))
               | `Absent -> ()
        ) open_field_env';
      
      (* check that the closed row contains no absent fields *)
      (*          fail_on_absent_fields closed_field_env; *)
      
      let uenv' =
        (register_rec_rows
           (rigid_field_env, rigid_field_env', rigid_rec_row, open_row')
           (open_field_env, open_field_env', open_rec_row, rigid_row')
           uenv)
      in
      match uenv' with
        | None -> Subst.empty
        | Some uenv ->
            let open_extension, sigma = extend_field_env uenv rigid_field_env' open_field_env' in
            let _ = unify_row_var_with_row uenv (open_row_var', (open_extension, rigid_row_var')) in
		    sigma in

    let unify_both_open uenv ((lfield_env, _ as lrow), (rfield_env, _ as rrow)) =
      let (lfield_env', lrow_var') as lrow', lrec_row = unwrap_row lrow in
      let (rfield_env', rrow_var') as rrow', rrec_row = unwrap_row rrow in
      let uenv' =
        (register_rec_rows
           (lfield_env, lfield_env', lrec_row, rrow')
           (rfield_env, rfield_env', rrec_row, lrow')
           uenv)
      in
      match uenv' with
        | None -> Subst.empty
        | Some uenv ->
            if (get_row_var lrow = get_row_var rrow) then     
              unify_both_rigid_with_rec_env uenv ((lfield_env', Unionfind.fresh ClosedRow),
                                                  (rfield_env', Unionfind.fresh ClosedRow))
            else
              begin
                let fresh_row_var = fresh_row_variable() in          
                (* each row can contain fields missing from the other; 
                   thus we call extend_field_env once in each direction *)
                let rextension, sigma =
                  extend_field_env uenv lfield_env' rfield_env' in
                (* [NOTE]
                   extend_field_env may change rrow_var' or lrow_var', as either
                   could occur inside the body of lfield_env' or rfield_env'
                *)
                unify_row_var_with_row uenv (rrow_var', (rextension, fresh_row_var));
                let lextension, sigma' = extend_field_env uenv rfield_env' lfield_env' in
                let _ = unify_row_var_with_row uenv (lrow_var', (lextension, fresh_row_var)) in
			    Subst.union sigma sigma'
              end in
    
    (* report an error if an attempt is made to unify
       an unguarded recursive row with a row that is not
       unguarded recursive
    *)
    let check_unguarded_recursion lrow rrow =      
      if is_unguarded_recursive lrow then
        (if not (is_unguarded_recursive rrow) then
           raise (Unify_failure
                    ("Could not unify unguarded recursive row"^ string_of_row lrow
                     ^"\nwith row "^ string_of_row rrow)))
      else if is_unguarded_recursive rrow then
        raise (Unify_failure
                 ("Could not unify unguarded recursive row"^ string_of_row rrow
                  ^"\nwith row "^ string_of_row lrow)) in

	let uenv = clear_expression unify_env in
    Debug.if_set (show_row_unification) (fun () -> "Unifying row: " ^ (string_of_row lrow) ^ " with row: " ^ (string_of_row rrow));
	
    let sigma = 
	  check_unguarded_recursion lrow rrow;
	  
	  if is_rigid_row lrow then
	    if is_rigid_row rrow then
		  unify_both_rigid uenv (lrow, rrow)
	    else
		  unify_one_rigid uenv (lrow, rrow)
	  else if is_rigid_row rrow then
	    unify_one_rigid (flip_polarity uenv) (rrow, lrow)           
	  else
	    unify_both_open uenv (lrow, rrow)
    in
	Debug.if_set (show_row_unification)
	  (fun () -> "Unified rows: " ^ (string_of_row lrow) ^ " and: " ^ (string_of_row rrow));
	sigma
      
and unify_record_rows uenv (lrow, rrow) = 
  let unify_dependent_rows uenv (lrow, rrow) = 
	
    let rec get_field_expression label = function
	  | Some (Record_intro (fmap, ext, _)) -> 
	      if StringMap.mem label fmap then
	        Some (StringMap.find label fmap)
	      else
	        get_field_expression label ext
	  | _ -> None in
	
    (* Precondition : must be an unwrapped row *)
    let get_present_labels (field_env, row_var) =
      let rec get_present' rec_vars (field_env, row_var) =
        let top_level_labels = 
          StringMap.fold (fun label field_spec labels ->
                            match field_spec with
                              | `Present _ -> StringSet.add label labels
                              | `Absent -> labels) field_env StringSet.empty
        in
        StringSet.union top_level_labels 
          (match Unionfind.find row_var with
             | RecursiveRow (var, _) when (not (IntSet.mem var rec_vars)) ->
                 raise (Unify_failure "Unexpected recursive row variable in a record with fable qualifiers")
             | _ -> StringSet.empty) in
      get_present' IntSet.empty (field_env, row_var) in

    let unify_field_envs
        (uenv : unify_env)
        (labels : string list)
        (fsml, fsmr) = 
      (*         let labels = List.sort compare labels in *)
      let get_fsm_types label = 
        match StringMap.find label fsml, StringMap.find label fsmr with
            `Present t, `Present s -> t,s
          | _ -> raise (Unify_failure "Unexpected `Absent field qualifier") in
      let unify_field (sigma_in, sig_inv) label =
        let (ti, si) = get_fsm_types label in
        let pi, xi = Fable.get_name_bindings ti.ftype in
        let qi, yi = Fable.get_name_bindings si.ftype in
        let _ = match pi, qi with 
            [], [] -> ()
          | _ -> raise (Unify_failure "Unexpected phantom variables in record field type") in
        let ti' = Fable.strip_name_bindings_type ti in
        let si' = Fable.strip_name_bindings_type si in
	    let field_exp = get_field_expression label uenv.exp in
        let sigma' = unify' ({uenv with exp=field_exp}) (ti', Subst.apply sigma_in si') in
	    let sigma' = Subst.union sigma_in sigma' in
        let sigma_out, sig_inv' = match xi, yi with
          | Some(xi), Some(yi) -> 
              Subst.extend (yi, Variable(xi, `T(dummy_position, ti', None))) sigma', 
		      Subst.extend (xi, Variable(yi, `T(dummy_position, ti', None))) sig_inv
	      | None, Some(yi) -> (* Intro dependent product *)
		      let lte = try Fable.get_label_type_expr ti'.ftype with Not_found -> None in
		      (match lte, field_exp with 
		           None, None -> 
			         raise (Unify_failure "Unable to infer dependent product introduction; try using \"var v = pack e as t\"")
 		         | Some e, _ 
		         | _, Some e -> Subst.extend (yi, e) sigma', sig_inv)
	      | _ -> sigma', sig_inv in
        sigma_out, sig_inv' in
      List.fold_left unify_field (Subst.empty, Subst.empty) labels in
	
    (************* Record unification rule for both rigid rows:

                   sigma_0 = {}            
                   p, Om |- ti < sigma_{i-1} (si) : sigma_i'
                   sigma_i = sigma_0, ..., sigma_{i-1}, sigma_i', (yi -> xi)
                   ------------------------------------------------------------------------
                   p, Om |- (f1: ~x1:t1, ..., fn :tn) < (f1: ~y1:s1, ..., fn :sn) 
    *************)                                    

    let unify_both_rigid uenv (lrow, rrow) =
      let fields_are_compatible (lrow, rrow) =
        let llabs = get_present_labels lrow in
        let rlabs = get_present_labels rrow in
        if StringSet.equal llabs rlabs then
          List.map fst (Fable.row_labels_inorder ~filter_absent:true (fst rrow))
        else 
          raise (Unify_failure ("Rigid rows\n "^ string_of_row lrow
                                ^"\nand\n "^ string_of_row rrow
                                ^"\n could not be unified because they have different fields")) in
      
      let (lfield_env', lrow_var') as lrow', lrec_row = unwrap_row lrow in
      let (rfield_env', rrow_var') as rrow', rrec_row = unwrap_row rrow in
      let _ = match lrec_row, rrec_row with
          None, None -> ()
        | _ -> raise (Unify_failure "Unexpected recursive row variable in a record with fable qualifiers") in
	  
      match Unionfind.find lrow_var', Unionfind.find rrow_var' with
        | RigidRow lvar, RigidRow rvar when lvar <> rvar ->
            raise (Unify_failure ("Rigid rows\n "^ string_of_row lrow
                                  ^"\nand\n "^ string_of_row lrow
                                  ^"\n could not be unified because they have distinct rigid row variables"))
        | _, _ ->
            let fields = fields_are_compatible (lrow', rrow') in
            let sigma, _ = unify_field_envs uenv fields (lfield_env', rfield_env') in
		    sigma
    in
	
    let unify_row_var_with_row : unify_env -> row_var * row -> unit = 
	  fun uenv (row_var, ((extension_field_env, extension_row_var) as extension_row)) ->
	    (* unify row_var with `RowVar None *)
	    let close_empty_row_var : row_var -> unit = fun point ->
	      match Unionfind.find point with
            | ClosedRow -> ()
            | FlexibleRow _ ->
		        Unionfind.change point ClosedRow
            | RigidRow _ ->
		        raise (Unify_failure ("Closed row var cannot be unified with rigid row var\n"))
            | _ -> assert false in

	    (* unify row_var with `RigidRowVar var *)
	    let rigidify_empty_row_var var : row_var -> unit = fun point ->
	      match Unionfind.find point with
            | ClosedRow ->
		        raise (Unify_failure ("Rigid row var cannot be unified with empty closed row\n"))
            | FlexibleRow _ ->
		        Unionfind.change point (RigidRow var)
            | RigidRow var' when var=var' -> ()
            | RigidRow _ ->
		        raise (Unify_failure ("Incompatible rigid row variables cannot be unified\n"))
            | _ -> assert false in

	    let rec extend point =
	      (* point should be a row variable *)
	      let row_var = Unionfind.find point in
	      match row_var with
		    | ClosedRow ->
		        if is_empty_row extension_row then
		          close_empty_row_var extension_row_var
		        else
		          raise (Unify_failure ("Closed row cannot be extended with non-empty row\n"
					                    ^string_of_row extension_row))
		    | RigidRow var ->
		        if is_empty_row extension_row then
		          rigidify_empty_row_var var extension_row_var
		        else
		          raise (Unify_failure ("Rigid row variable cannot be unified with non-empty row\n"
					                    ^string_of_row extension_row))
		    | FlexibleRow var ->
		        if TypeVarSet.mem var (free_row_type_vars extension_row) then
		          raise (Unify_failure ("Unexpected recursive row variable"))
		        else if StringMap.is_empty extension_field_env then
		          match extension_row_var with
			        | point' ->
			            Unionfind.union point point'
		        else
		          Unionfind.change point (BodyRow extension_row)
		    | RecursiveRow _ ->
		        raise (Unify_failure ("Unexpected recursive row variable"))
		    | BodyRow row ->
		        ignore (unify_record_rows uenv (row, extension_row))  (* TODO: check this *)
	    in
	    extend row_var in

    let make_extension_field_env sigma ext_labs ext_fsm =
	  List.fold_left (fun fsm lab -> match StringMap.find lab ext_fsm with
			            | `Absent -> raise Impos
			            | `Present t -> 
			                let t' = Subst.apply sigma t in
				            StringMap.add lab (`Present t') fsm
		             ) StringMap.empty ext_labs in

    let get_all_name_bindings labs (fsm, _) = 
      List.fold_left (fun names lab -> match StringMap.find lab fsm with
                          `Absent -> names
                        | `Present t -> (match Fable.get_name_bindings t.ftype with
                                             [], None -> names
                                           | [], Some n -> StringSet.add n names
                                           | _ -> raise Impos)
                     ) StringSet.empty labs 
    in
    let get_all_free_names omega labs (fsm, _) = 
      List.fold_left (fun names lab -> match StringMap.find lab fsm with
                          `Absent -> names
                        | `Present t -> 
                            let nlist = Fable.free_names omega t in
                            StringSet.union names (StringSet.from_list nlist)
                     ) StringSet.empty labs 
    in

	
    (************* Record unification rule for one rigid and one open row
		           
                   sigma_0 = {}            
                   i \in 1..n   p, Om |- ti < sigma_{i-1} (si) : sigma_i'
                   sigma_i = sigma_0, ..., sigma_{i-1}, sigma_i', (yi -> xi)
		           sigma_n* = sigma_n^{-1}   rv = sigma_n*(fn+1:tn+1, ..., fm:tm)
                   ------------------------------------------------------------------------
                   p, Om |- (f1: ~x1:t1, ..., fm :tm) < (f1: ~y1:s1, ..., fn :sn | rv) 
    *************)                                    
    let unify_one_open uenv (rigid_row, open_row) = 
      let fields_are_compatible (lrow, rrow) =
        let llabs = List.map fst (Fable.row_labels_inorder ~filter_absent:true (fst lrow)) in (* List.sort compare (StringSet.elements (get_present_labels lrow)) in *)
        let rlabs = List.map fst (Fable.row_labels_inorder ~filter_absent:true (fst rrow)) in (* List.sort compare (StringSet.elements (get_present_labels rrow)) in *)
	    let extension_labels l r = 
	      let rec drop_lprefix pfx (l,r) = match l,r with
	        | hd1::_, hd2::_ when hd1=hd2 -> pfx, l
	        | hd1::tl, _ -> drop_lprefix (hd1::pfx) (tl, r)
	        | _ -> pfx, l in
	      let rec find_lsuffix (l,r) = match l,r with
	        | _, [] -> l
	        | hl::tl, hr::tr when hl=hr -> find_lsuffix (tl,tr)
	        | _ -> raise (Unify_failure ("Open row\n "^ string_of_row rrow
					                     ^"\nand dependent rigid row\n "^ string_of_row lrow
					                     ^"\n could not be unified because the former contains labels not in the latter")) in
	      let pfx, l' = drop_lprefix [] (l,r) in
	      let bindings = get_all_name_bindings pfx lrow in
	      let fns = get_all_free_names uenv.omega rlabs rrow in
	      if (StringSet.inter bindings fns) <> StringSet.empty then 
		    raise (Unify_failure ("Projection of a field with free names is not permitted; use \"open e as x\" instead"));
	      pfx@(find_lsuffix (l',r))
	    in 
	    (rlabs, extension_labels llabs rlabs) 
	  in
	  if not(is_rigid_row rigid_row && not(is_rigid_row open_row)) then
	    failwith "unify_one_open polarity screwed up";
      let (lfield_env', rigid_row_var') as lrow', rigid_rec_row = unwrap_row lrow in
      let (rfield_env', open_row_var') as rrow', open_rec_row = unwrap_row rrow in
      let _ = match rigid_rec_row, open_rec_row with
          None, None -> ()
        | _ -> raise (Unify_failure "Unexpected recursive row variable in a record with fable qualifiers") in
      let (common, extension) = fields_are_compatible (lrow', rrow') in
      let sigma, _ = unify_field_envs uenv common (lfield_env', rfield_env') in
	  let open_extension = make_extension_field_env sigma extension lfield_env' in
      let _ = unify_row_var_with_row uenv (open_row_var', (open_extension, rigid_row_var')) in
	  sigma  in
	
    let unify_both_open uenv (lrow, rrow) = 
      let fields_are_compatible (lrow, rrow) =
        let llabs = List.map fst (Fable.row_labels_inorder ~filter_absent:true (fst lrow)) in (* List.sort compare (StringSet.elements (get_present_labels lrow)) in *)
        let rlabs = List.map fst (Fable.row_labels_inorder ~filter_absent:true (fst rrow)) in (* List.sort compare (StringSet.elements (get_present_labels rrow)) in *)
        let rec common_prefix pfx = function
            h1::t1, h2::t2 ->
              if h1=h2 then
                common_prefix (h1::pfx) (t1,t2)
              else 
                List.rev pfx, (t1, t2)
          | l1, l2 -> 
              List.rev pfx, (l1, l2) in
        let pfx, (llabs', rlabs') = common_prefix [] (llabs,rlabs) in
        let bindings = StringSet.union (get_all_name_bindings llabs' lrow) (get_all_name_bindings rlabs' rrow) in
        if bindings <> StringSet.empty then
          raise (Unify_failure "Unification of open rows only permitted when the missing fields of each don't have name bindings");
        let commonlabs = list_intersect llabs' rlabs' in
        let llabs' = list_difference llabs' commonlabs in
        let rlabs' = list_difference rlabs' commonlabs in
        (pfx, commonlabs, llabs', rlabs') in

      let (lfield_env', lrow_var'), lrec_row = unwrap_row lrow in
      let (rfield_env', rrow_var'), rrec_row = unwrap_row rrow in
      let _ = match lrec_row, rrec_row with
          None, None -> ()
        | _ -> raise (Unify_failure "Unexpected recursive row variable in a record with fable qualifiers") in
	  let (pfx, common, llabs, rlabs) = fields_are_compatible (lrow, rrow) in
	  let sigma, sigma_inv = unify_field_envs uenv (pfx@common) (lfield_env', rfield_env') in
	  let fv = fresh_row_variable() in
	  if (Unionfind.equivalent lrow_var' rrow_var') then
		match llabs, rlabs with (* row vars are the same; so, cannot extend each other *)
		    [], [] -> 
		      let _ = unify_row_var_with_row uenv (lrow_var', (StringMap.empty, fv)) in
			  sigma
		  |  _ -> raise (Unify_failure "Unification of identical open rows with unequal extensions")
	  else
		let extends_r = make_extension_field_env sigma llabs lfield_env' in
		let extends_l = make_extension_field_env sigma_inv rlabs rfield_env' in
		unify_row_var_with_row uenv (lrow_var', (extends_l, fv));
 		unify_row_var_with_row uenv (rrow_var', (extends_r, fv));
        (* 		  let examine_row_var pfx rv = match Unionfind.find rv with *)
        (* 		  	| ClosedRow -> Debug.print (pfx ^ "Closed row var") *)
        (* 		  	| FlexibleRow i -> Debug.print (pfx ^ "Flexible row var" ^ (string_of_int i) ^ "") *)
        (* 		  	| RigidRow i -> Debug.print (pfx ^ "Rigid row var" ^ (string_of_int i) ^ "") *)
        (* 		  	| RecursiveRow (i, tdr) -> Debug.print (pfx ^ "Recursive row var" ^ (string_of_int i) ^ "") *)
        (* 		  	| BodyRow tdr ->  Debug.print (pfx ^ "Body row var") in *)
        (* 		  examine_row_var "lrow_var: " lrow_var'; *)
        (* 		  examine_row_var "rrow_var: " rrow_var'; *)
        (* 		  examine_row_var "fresh_row_var: " fv; *)
		sigma
    in
	
	if is_rigid_row lrow then
	  if is_rigid_row rrow then
        unify_both_rigid uenv (lrow, rrow)
	  else
	    unify_one_open uenv (lrow, rrow)
	else
	  if is_rigid_row rrow then 
	    unify_one_open (flip_polarity uenv) (rrow, lrow)
	  else
	    unify_both_open uenv (lrow, rrow)
  in
  
(*   let is_empty_fquals row =  *)
(*     let rec check_empty_fquals rec_vars (fsm, rv) =  *)
(*       (StringMap.iter  *)
(*          (fun _  -> function *)
(* 		    | `Absent -> () *)
(* 		    | `Present t ->  *)
(*                 if not (Fable.is_empty t.ftype) then  *)
(*                   raise (Unify_failure "Unification of non-rigid rows with fable qualifiers; not yet supported")) *)
(*          fsm; *)
(*        match Unionfind.find rv with  *)
(*          | RecursiveRow (v, r) when not (IntMap.mem v rec_vars) ->  *)
(* 		     check_empty_fquals (IntMap.add v r rec_vars) r *)
(*          | BodyRow r ->  *)
(* 		     check_empty_fquals rec_vars r *)
(*          | _ -> ()) in *)
(* 	try *)
(* 	  let _ = check_empty_fquals IntMap.empty row in *)
(* 	  true *)
(* 	with  *)
(* 	    Unify_failure _ -> false in *)
  match uenv.polarity with 
	  `Neg -> unify_dependent_rows (flip_polarity uenv) (rrow, lrow)
	| `Pos -> unify_dependent_rows uenv (lrow, rrow)
        
let initial_uenv phantoms omega exp_opt sub = 
  {rec_types = IntMap.empty;
   rec_rows = IntMap.empty;
   omega = omega;
   phantoms = phantoms;
   exp = exp_opt;
   polarity = `Pos;
   subtype = sub} 
    
let unify phantoms omega exp_opt sub (t1, t2) =
  let uenv = initial_uenv phantoms omega exp_opt sub  in
  unify' uenv (t1, t2) 
    
(* Debug.if_set (show_unification) (fun () -> "Unified types: " ^ string_of_datatype t1) *)
and unify_rows omega sub (row1, row2) =
  let uenv = initial_uenv [] omega None sub in
  unify_variant_rows uenv (row1, row2)

let unify_old omega ts = ignore (unify [] omega None false ts)
