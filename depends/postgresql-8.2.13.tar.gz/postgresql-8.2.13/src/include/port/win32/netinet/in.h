/* $PostgreSQL: pgsql/src/include/port/win32/netinet/in.h,v 1.3 2006/03/11 04:38:39 momjian Exp $ */

#include <sys/socket.h>
