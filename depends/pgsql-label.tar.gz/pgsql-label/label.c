#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "postgres.h"
#include "fmgr.h"
#include "libpq/pqformat.h"		/* needed for send/recv functions */
//#define SET_VARSIZE(_PTR, _SIZE)  (((varattrib *)(_PTR))->va_header = _SIZE)
#define SET_VARSIZE(_PTR, _SIZE)  (((varattrib *)(_PTR))->va_header = _SIZE)

#include "executor/spi.h"

PG_MODULE_MAGIC;

typedef struct Variant {
    char vl_len_[4];
    int32 name_len;
    char data[1];
    /* char* name */             /* (should be) zero-terminated string */
                                 /* BUG: this isn't always true! */
                                 /* However, name_len - 1 is always strlen */
    /* Expression expr */
} Variant;

typedef struct Record {
    char vl_len_[4];
    int32 num_args;
    int32 head_offset;         /* not currently used; always 0 */
    int32 tail_offset;
    char data[1];
    /* char* arg_name */
    /* Expression expr */
    /* Record rec */
} Record;

typedef struct Expression {
    char vl_len_[4];
    int32 type;             /* should this be OID? */
    union { 
        int32   integer;
        text    string;
        Variant variant;
        Record  record;
        bool    boolean;
    } expr;
} Expression;

typedef enum expr_type { 
    expr_wildcard = 0,
    expr_integer  = 1,
    expr_string   = 2,
    expr_variant  = 3,
    expr_record   = 4,
    expr_list     = 5,
    expr_bool     = 6,
} expr_type;

char expr_type_names[7][32] = {
    "wildcard",
    "integer",
    "string",
    "variant",
    "record",
    "list",
    "boolean"
};
    
typedef Variant Label;


/* Label Postgres operations */

Datum label_in(PG_FUNCTION_ARGS);        /* char* -> label */
Datum label_out(PG_FUNCTION_ARGS);       /* label -> char* */
Datum label_abs_eq(PG_FUNCTION_ARGS);    /* label -> label -> bool */
Datum label_abs_neq(PG_FUNCTION_ARGS);   /* label -> label -> bool */
Datum label_get_name(PG_FUNCTION_ARGS);  /* label -> text */
Datum label_get_tuple(PG_FUNCTION_ARGS); /* label -> tuple */
Datum label_get_appl(PG_FUNCTION_ARGS);  /* label -> label */
Datum label_init(PG_FUNCTION_ARGS);      /* a -> label */

/* Record Postgres operations */

Datum tuple_in(PG_FUNCTION_ARGS);       /* char* -> tuple */
Datum tuple_out(PG_FUNCTION_ARGS);      /* tuple -> char* */
Datum tuple_tail(PG_FUNCTION_ARGS);     /* tuple -> tuple */
Datum tuple_get_int(PG_FUNCTION_ARGS);  /* tuple -> int -> int */
Datum tuple_get_str(PG_FUNCTION_ARGS);  /* tuple -> int -> text */
Datum tuple_get_lab(PG_FUNCTION_ARGS);  /* tuple -> int -> label */
Datum tuple_get_list(PG_FUNCTION_ARGS); /* tuple -> int -> list */
Datum tuple_get_bool(PG_FUNCTION_ARGS); /* tuple -> int -> bool */
Datum tuple_num_args(PG_FUNCTION_ARGS); /* tuple -> int */

/* List Postgres operations */

Datum list_in(PG_FUNCTION_ARGS);        /* char* -> list */
Datum list_out(PG_FUNCTION_ARGS);       /* list -> char* */

Datum list_tl(PG_FUNCTION_ARGS);      /* list -> list */
Datum list_head_int(PG_FUNCTION_ARGS);  /* list -> int */
Datum list_head_bool(PG_FUNCTION_ARGS);  /* list -> bool */
Datum list_head_str(PG_FUNCTION_ARGS);  /* list -> text */
Datum list_head_lab(PG_FUNCTION_ARGS);  /* list -> label */
Datum list_len(PG_FUNCTION_ARGS);    /* list -> int */
Datum list_cons_int(PG_FUNCTION_ARGS);  /* int -> list -> list */
Datum list_cons_str(PG_FUNCTION_ARGS);  /* str -> list -> list */
Datum list_cons_bool(PG_FUNCTION_ARGS); /* bool -> list -> list */
Datum list_cons_lab(PG_FUNCTION_ARGS);  /* lab -> list -> list */

/* Variant operations */

static text       * var_get_name(Variant*);
static Expression * var_get_expr(Variant*);
static char       * var_to_string(Variant*);
static Variant * var_init(const char*, Expression*);
static Variant * var_parse(const char*, size_t);
static bool      var_match(Variant*, Variant*);

/* Expression operations */

static Record  * expr_get_rec(Expression*);
static Record  * expr_get_list(Expression*);
static Variant * expr_get_var(Expression*);
static int32     expr_get_int(Expression*);
static text    * expr_get_str(Expression*);
static bool      expr_get_bool(Expression*);
static char    * expr_to_string(Expression*, char**, int*, char*);
static Expression * expr_init_rec(Record*);
static Expression * expr_init_list(Record*);
static Expression * expr_init_int(int32);
static Expression * expr_init_text(text*);
static Expression * expr_init_str(char*);
static Expression * expr_init_bool(bool);
static Expression * expr_init_var(Variant*);
static Expression * expr_init_wc(void);
static Expression * expr_parse(const char*, size_t);
static bool         expr_match(Expression*, Expression*);

/* Record operations */

static Expression * rec_head(Record*);
static Record     * rec_tail(Record*);
static int          rec_num_args(Record*);
static Expression * rec_get(Record *, int);
static char       * rec_to_string(Record*, char**, int*, char*);
static Record * rec_nil(void);
static Record * rec_cons(Expression*, Record*);
static Record * rec_parse(const char*, size_t);
static bool     rec_match(Record*, Record*);
/* static Expression* rec_get_named_item(Record*, text*); */


/* ------------------------------------------------------------ */

PG_FUNCTION_INFO_V1(label_in);

Datum
label_in(PG_FUNCTION_ARGS) {
    const char *input = PG_GETARG_CSTRING(0);
    Label *result = var_parse(input, strlen(input));
    PG_RETURN_POINTER(result);
}

PG_FUNCTION_INFO_V1(label_out);

Datum
label_out(PG_FUNCTION_ARGS) {
    Label *l = (Label *) PG_GETARG_POINTER(0);
    char *result = var_to_string(l);
    PG_RETURN_POINTER(result);
}

PG_FUNCTION_INFO_V1(label_abs_eq);

Datum 
label_abs_eq(PG_FUNCTION_ARGS) {
    Label *l1 = (Label *) PG_GETARG_POINTER(0);
    Label *l2 = (Label *) PG_GETARG_POINTER(1);

    PG_RETURN_BOOL(var_match(l1,l2));
}

PG_FUNCTION_INFO_V1(label_abs_neq);

Datum 
label_abs_neq(PG_FUNCTION_ARGS) {
    Label *l1 = (Label *) PG_GETARG_POINTER(0);
    Label *l2 = (Label *) PG_GETARG_POINTER(1);

    PG_RETURN_BOOL(!var_match(l1,l2));
}

PG_FUNCTION_INFO_V1(label_get_name);

Datum 
label_get_name(PG_FUNCTION_ARGS) {
    Label *l = (Label *) PG_GETARG_POINTER(0);
    text *result;
    size_t result_size;

    char *name;
    
    name = l->data;

    /* copy name */
    result_size = (VARHDRSZ + l->name_len - 1);
    result = (text*) palloc(result_size);
    SET_VARSIZE(result, result_size);
    memcpy(VARDATA(result), name, l->name_len - 1);

    PG_RETURN_TEXT_P(result);
}

PG_FUNCTION_INFO_V1(label_get_tuple);

Datum 
label_get_tuple(PG_FUNCTION_ARGS) {
    Label *l = (Label *) PG_GETARG_POINTER(0);
    Record *result;
    
    result = expr_get_rec(var_get_expr(l));
    PG_RETURN_POINTER(result);
}

PG_FUNCTION_INFO_V1(label_get_appl);

Datum 
label_get_appl(PG_FUNCTION_ARGS) {
    Label *l = (Label *) PG_GETARG_POINTER(0);
    Label *result;
    
    result = expr_get_var(var_get_expr(l));
    PG_RETURN_POINTER(result);
}

static inline void string_of_oid(Oid element_type, char *buf)
{
    int ret;

    SPI_connect();
    
    snprintf(buf, 511, "SELECT typname FROM pg_type WHERE oid = %d", 
             element_type);
    
    ret = SPI_execute(buf, true, 0);
    /* int proc = SPI_processed; */
    
    if (ret > 0 && SPI_tuptable != NULL)
    {
        TupleDesc tupdesc = SPI_tuptable->tupdesc;
        SPITupleTable *tuptable = SPI_tuptable;
        
        HeapTuple tuple = tuptable->vals[0];
        
        strncpy(buf, SPI_getvalue(tuple, tupdesc, 1), 511);
    }
    
    SPI_finish();
}


PG_FUNCTION_INFO_V1(label_init);

Datum label_init(PG_FUNCTION_ARGS) {
    
    Expression *expr;
    void *input_data;
    Variant *var;
    
    char buf[512];

    Oid element_type = get_fn_expr_argtype(fcinfo->flinfo,1);

    /* process name */
    text *tname = (text*) PG_GETARG_POINTER(0);
    int size = VARSIZE(tname) - VARHDRSZ;
    char *name = (char*)palloc(size + 1);
    memcpy(name, VARDATA(tname), size);
    *(name + size) = '\0';

    if (!OidIsValid(element_type))
        elog(ERROR, "could not determine data type of input");

    if (element_type == INT4OID) {
        expr = expr_init_int(PG_GETARG_INT32(1));
        expr = expr_init_rec(rec_cons(expr, rec_nil()));
    } else if (element_type == BOOLOID) {
        expr = expr_init_bool(PG_GETARG_BOOL(1));
        expr = expr_init_rec(rec_cons(expr, rec_nil()));
    } else if (element_type == TEXTOID
               || element_type == VARCHAROID
               || element_type == BPCHAROID) {
        input_data = (void*) PG_GETARG_POINTER(1);
        expr = expr_init_text(input_data);
        expr = expr_init_rec(rec_cons(expr, rec_nil()));
    } else {
        string_of_oid(element_type, buf);
        input_data = (void*) PG_GETARG_POINTER(1);

        if (strcmp(buf, "tuple") == 0)
            expr = expr_init_rec(input_data);
        else if (strcmp(buf, "list") == 0)
            expr = expr_init_list(input_data);
        else if (strcmp(buf, "label") == 0)
            expr = expr_init_var(input_data);
        else
            elog(ERROR, "could not determine data type of input");
        var = var_init(name, expr);
    }
    var = var_init(name, expr);

    pfree(expr);
    pfree(name);
    PG_RETURN_POINTER(var);
}

/* ------------------------------------------------------------ */

static text* var_get_name(Variant* var) {
    text *result;
    size_t name_len;
    size_t result_size;
    char *name;

    name = var->data;
    name_len = strlen(name);

    result_size = VARHDRSZ + name_len;
    result = (text*) palloc(result_size);
    SET_VARSIZE(result, result_size);
    memcpy(VARDATA(result), name, VARSIZE(result) - VARHDRSZ);

    return result;
}

static inline Expression* var_get_expr_fast(Variant* var) {
    return (Expression*)((char*)var->data + var->name_len);
}

static Expression* var_get_expr(Variant* var) {
    Expression * expr;
    Expression * result; 

    expr = var_get_expr_fast(var);
    
    result = (Expression*) palloc(VARSIZE(expr));
    memcpy(result, expr, VARSIZE(expr));

    return result;
}

static char * var_to_string(Variant *var) {

    char *result, *p;
    Expression *expr;
    int32 result_size = var->name_len + 2; /* 3 for ()\0 */
    
    result = (char*) palloc(result_size); 
    memcpy(result, var->data, var->name_len - 1);
    p = result + var->name_len - 1;

    expr = (Expression*)(var->data + var->name_len);

    *(p++) = '(';
    p = expr_to_string(expr, &result, &result_size, p);
    *(p++) = ')';
    *(p++) = '\0';

    return result;
}

Variant * var_init(const char *name, Expression *expr) {
    Variant *var;
    int32 var_size;
    int name_len;

    name_len = strlen(name) + 1;

    var_size = VARHDRSZ + sizeof(int32) + name_len + VARSIZE(expr);
    var = (Variant*) palloc(var_size);
    SET_VARSIZE(var, var_size);
    var->name_len = name_len;
    strncpy(var->data, name, name_len - 1);
    memcpy(var->data + name_len, expr, VARSIZE(expr));

    return var;
} 

Variant * var_parse(const char *input, size_t len) {
    char *name;
    int name_len;
    Expression *expr;
    
    char *index = memchr(input, '(', len);

    if (index == 0) {
        name_len = len;
        expr = expr_init_rec(rec_nil());
    } else {
        name_len = index - input;
        expr = expr_parse(index + 1, len - name_len - 2);
    }
    name = (char*) palloc(name_len+1);
    memcpy(name, input, name_len);
    *(name + name_len) = '\0';
    return var_init(name, expr);
}

static bool var_match(Variant *v1, Variant *v2) {
    Expression *expr1, *expr2;

    if (v1->name_len == v2->name_len 
        && strncmp(v1->data, v2->data, v1->name_len-1) == 0) {
        expr1 = var_get_expr_fast(v1);
        expr2 = var_get_expr_fast(v2);
        return expr_match(expr1, expr2);
    } else {
        return false;
    }
}

/* ------------------------------------------------------------ */

Record * rec_parse(const char *input, size_t len) {
    const char *start;
    int pcount = 0;
    bool quoted = false;
    int i;
    
    Record *rec = rec_nil();
    Record *rec2;

    /* artificial limit of ten expressions per record */
    Expression *exprs[10];
    int expr_count = 0;

    if (len == 0)
        return rec;

    start = input;
    for (i = 0; i < len; ++i) {
        if (quoted) {
            if (input[i] == '"')
                quoted = false;
            continue;
        }
                
        switch (input[i]) {
        case '"':
            quoted = true;
            break;
        case '(':
        case '[':
            pcount++;
            break;
        case ' ':
            /* ignore spaces in ", " */
            if (pcount == 0)
                start = input + i + 1;
            break;
        case ')':
        case ']':
            pcount--;
            break;
        case ',':
            if (pcount == 0) {
                exprs[expr_count++] = expr_parse(start, i-(start-input));
                start = input + i + 1;
            }
            break;
        }
    }
    exprs[expr_count++] = expr_parse(start, i-(start-input));
    
    /* reverse and cons all exprs */
    for (i = expr_count - 1; i >= 0; --i) {
        rec2 = rec_cons(exprs[i], rec);
        pfree(rec);
        pfree(exprs[i]);
        rec = rec2;
    }

    return rec;
}

/* Tuples */

PG_FUNCTION_INFO_V1(tuple_in);

Datum 
tuple_in(PG_FUNCTION_ARGS) {
    char  *str = PG_GETARG_CSTRING(0);
    Record *result;
    result = rec_parse(str, strlen(str));
    PG_RETURN_POINTER(result);
}

PG_FUNCTION_INFO_V1(tuple_out);

Datum 
tuple_out(PG_FUNCTION_ARGS) {
    Record *rec = (Record *) PG_GETARG_POINTER(0);
    char *result = (char*) palloc(1);
    char *p;
    int result_size = 1;

    p = rec_to_string(rec, &result, &result_size, result);
    *p = '\0';
    
    PG_RETURN_POINTER(result);
}


PG_FUNCTION_INFO_V1(tuple_tail);

Datum 
tuple_tail(PG_FUNCTION_ARGS) {
    Record *rec = (Record *) PG_GETARG_POINTER(0);
    Record *result = rec_tail(rec);
    PG_RETURN_POINTER(result);
}

PG_FUNCTION_INFO_V1(tuple_get_int);

Datum 
tuple_get_int(PG_FUNCTION_ARGS) {
    Record *rec = (Record *) PG_GETARG_POINTER(0);
    int i = PG_GETARG_INT32(1);
    
    Expression *expr = rec_get(rec, i);
    int result = expr_get_int(expr);
    pfree(expr);
    PG_RETURN_INT32(result);
}

PG_FUNCTION_INFO_V1(tuple_get_bool);

Datum 
tuple_get_bool(PG_FUNCTION_ARGS) {
    Record *rec = (Record *) PG_GETARG_POINTER(0);
    int i = PG_GETARG_INT32(1);
    
    Expression *expr = rec_get(rec, i);
    bool result = expr_get_bool(expr);
    pfree(expr);
    PG_RETURN_BOOL(result);
}

PG_FUNCTION_INFO_V1(tuple_get_str);

Datum tuple_get_str(PG_FUNCTION_ARGS) {
    Record *rec = (Record *) PG_GETARG_POINTER(0);
    int i = PG_GETARG_INT32(1);
    
    Expression *expr = rec_get(rec, i);
    text *result = expr_get_str(expr);
    pfree(expr);
    PG_RETURN_POINTER(result);
}

PG_FUNCTION_INFO_V1(tuple_get_lab);

Datum tuple_get_lab(PG_FUNCTION_ARGS) {
    Record *rec = (Record *) PG_GETARG_POINTER(0);
    int i = PG_GETARG_INT32(1);
    
    Expression *expr = rec_get(rec, i);
    Label *result = expr_get_var(expr);
    pfree(expr);
    PG_RETURN_POINTER(result);
}

PG_FUNCTION_INFO_V1(tuple_get_list);

Datum tuple_get_list(PG_FUNCTION_ARGS) {
    Record *rec = (Record *) PG_GETARG_POINTER(0);
    int i = PG_GETARG_INT32(1);
    
    Expression *expr = rec_get(rec, i);
    Record *result = expr_get_list(expr);
    pfree(expr);
    PG_RETURN_POINTER(result);
}

PG_FUNCTION_INFO_V1(tuple_num_args);

Datum tuple_num_args(PG_FUNCTION_ARGS) {
    Record *rec = (Record *) PG_GETARG_POINTER(0);
    int result = rec_num_args(rec);

    PG_RETURN_INT32(result);
}

/* Lists */

PG_FUNCTION_INFO_V1(list_in);

/* assume str is '[' ... ']' */
Datum 
list_in(PG_FUNCTION_ARGS) {
    char  *str = PG_GETARG_CSTRING(0);
    Record *result;
    result = rec_parse(str+1, strlen(str)-2);
    PG_RETURN_POINTER(result);
}

PG_FUNCTION_INFO_V1(list_out);

Datum 
list_out(PG_FUNCTION_ARGS) {
    Record *rec = (Record *) PG_GETARG_POINTER(0);
    char *result = (char*) palloc(1);
    char *p;
    int result_size = 1;

    p = rec_to_string(rec, &result, &result_size, result);
    *result = '[';
    *(p-1) = ']';
    *p = '\0';
    
    PG_RETURN_POINTER(result);
}


PG_FUNCTION_INFO_V1(list_tl);

Datum 
list_tl(PG_FUNCTION_ARGS) {
    Record *rec = (Record *) PG_GETARG_POINTER(0);
    Record *result = rec_tail(rec);
    PG_RETURN_POINTER(result);
}

PG_FUNCTION_INFO_V1(list_head_int);

Datum 
list_head_int(PG_FUNCTION_ARGS) {
    Record *rec = (Record *) PG_GETARG_POINTER(0);
    
    Expression *expr = rec_get(rec, 0);
    int result = expr_get_int(expr);
    pfree(expr);
    PG_RETURN_INT32(result);
}

PG_FUNCTION_INFO_V1(list_head_bool);

Datum 
list_head_bool(PG_FUNCTION_ARGS) {
    Record *rec = (Record *) PG_GETARG_POINTER(0);
    
    Expression *expr = rec_get(rec, 0);
    bool result = expr_get_bool(expr);
    pfree(expr);
    PG_RETURN_BOOL(result);
}

PG_FUNCTION_INFO_V1(list_head_str);

Datum list_head_str(PG_FUNCTION_ARGS) {
    Record *rec = (Record *) PG_GETARG_POINTER(0);
    
    Expression *expr = rec_get(rec, 0);
    text *result = expr_get_str(expr);
    pfree(expr);
    PG_RETURN_POINTER(result);
}

PG_FUNCTION_INFO_V1(list_head_lab);

Datum list_head_lab(PG_FUNCTION_ARGS) {
    Record *rec = (Record *) PG_GETARG_POINTER(0);
    
    Expression *expr = rec_get(rec, 0);
    Label *result = expr_get_var(expr);
    pfree(expr);
    PG_RETURN_POINTER(result);
}

PG_FUNCTION_INFO_V1(list_len);

Datum list_len(PG_FUNCTION_ARGS) {
    Record *rec = (Record *) PG_GETARG_POINTER(0);
    int result = rec_num_args(rec);

    PG_RETURN_INT32(result);
}

PG_FUNCTION_INFO_V1(list_cons_int);

Datum
list_cons_int(PG_FUNCTION_ARGS) {
    int hd = PG_GETARG_INT32(0);
    Record *tl = (Record *) PG_GETARG_POINTER(1);
    
    Expression *expr;
    Record *result;

    expr = expr_init_int(hd);
    result = rec_cons(expr, tl);
    pfree(expr);
    
    PG_RETURN_POINTER(result);
}

PG_FUNCTION_INFO_V1(list_cons_bool);

Datum
list_cons_bool(PG_FUNCTION_ARGS) {
    bool hd = PG_GETARG_BOOL(0);
    Record *tl = (Record *) PG_GETARG_POINTER(1);
    
    Expression *expr;
    Record *result;

    expr = expr_init_bool(hd);
    result = rec_cons(expr, tl);
    pfree(expr);
    
    PG_RETURN_POINTER(result);
}

PG_FUNCTION_INFO_V1(list_cons_str);

Datum
list_cons_str(PG_FUNCTION_ARGS) {
    text *hd = (text*) PG_GETARG_POINTER(0);
    Record *tl = (Record*) PG_GETARG_POINTER(1);
    
    Expression *expr;
    Record *result;

    expr = expr_init_text(hd);
    result = rec_cons(expr, tl);
    pfree(expr);
    
    PG_RETURN_POINTER(result);
}

PG_FUNCTION_INFO_V1(list_cons_lab);

Datum
list_cons_lab(PG_FUNCTION_ARGS) {
    Variant *hd = (Variant*) PG_GETARG_POINTER(0);
    Record *tl = (Record*) PG_GETARG_POINTER(1);
    
    Expression *expr;
    Record *result;

    expr = expr_init_var(hd);
    result = rec_cons(expr, tl);
    pfree(expr);
    
    PG_RETURN_POINTER(result);
}

/* ------------------------------------------------------------ */

Expression * expr_parse(const char *input, size_t len) {
    Expression *expr;
    char *tmp;

    if (len == 0) {
        return expr_init_rec(rec_nil());
    }

    switch (input[0]) {
    case '_':
        expr = expr_init_wc();
        break;
    case '(': 
        expr = expr_init_rec(rec_parse(input+1, len-2));
        break;
    case '[': 
        expr = expr_init_list(rec_parse(input+1, len-2));
        break;
    case '"': 
        tmp = (char*) palloc(len-1);
        memcpy(tmp, input+1, len-2);
        tmp[len-2] = '\0';
        expr = expr_init_str(tmp);
        pfree(tmp);
        break;
    case 't':
    case 'f':
        if (strncmp(input, "true", len) == 0) {
            expr = expr_init_bool(true);
            break;
        }
        if (strncmp(input, "false", len) == 0) {
            expr = expr_init_bool(false);            
            break;
        }
        /* fall through */
    default:
        if ('0' <= input[0] && input[0] <= '9') {
            char buf[100];
            int val;
            memcpy(buf, input, len);
            buf[len] = '\0';
            sscanf(buf, "%d", &val);
            expr = expr_init_int(val);
        } else {
            expr = expr_init_var(var_parse(input, len));
        }
    }

    return expr;
}


/* ------------------------------------------------------------ */

static inline void expr_check_type(Expression *expr, expr_type type) {
    /* what about wildcards? */
    if (expr->type != type) 
        ereport(ERROR,
                (errcode(ERRCODE_DATATYPE_MISMATCH),
                 errmsg("expected type \"%s\", but has type \"%s\"",
                        expr_type_names[type],
                        expr_type_names[expr->type])));
}

static int32 expr_get_int(Expression *expr) {
    expr_check_type(expr, expr_integer);
    return expr->expr.integer;
}

static bool expr_get_bool(Expression *expr) {
    expr_check_type(expr, expr_bool);
    return expr->expr.boolean;
}

static text * expr_get_str(Expression *expr) {
    text *result, *str;
    expr_check_type(expr, expr_string);

    str = &(expr->expr.string);
    result = (text*) palloc(VARSIZE(str));
    memcpy(result, str, VARSIZE(str));

    return result;
}

static Variant * expr_get_var(Expression *expr) {
    Variant *result, *var;
    expr_check_type(expr, expr_variant);

    var = &(expr->expr.variant);
    result = (Variant*) palloc(VARSIZE(var));
    memcpy(result, var, VARSIZE(var));

    return result;
}

static Record* expr_get_rec(Expression *expr) {
    Record *result, *rec;
    expr_check_type(expr, expr_record);

    rec = &(expr->expr.record);
    result = (Record*) palloc(VARSIZE(rec));
    memcpy(result, rec, VARSIZE(rec));

    return result;
}

/* same as above, but different check */
static Record* expr_get_list(Expression *expr) {
    Record *result, *rec;
    expr_check_type(expr, expr_list);

    rec = &(expr->expr.record);
    result = (Record*) palloc(VARSIZE(rec));
    memcpy(result, rec, VARSIZE(rec));

    return result;
}

char * 
expr_to_string(Expression *expr, char **result, int *result_size, char *p)
{
    char *tmp;
    int str_size, old_size;
    text *str;
    char *res_tmp;

    switch (expr->type)  {
    case expr_integer:
        str_size = 100;
        tmp = (char*) palloc(str_size);
        
        str_size = snprintf(tmp, str_size, "%d", expr->expr.integer);
        
        *result_size += str_size;
        res_tmp = (char*) repalloc(*result, *result_size);
        p = p - *result + res_tmp; /* update p to reflect repalloc */
        *result = res_tmp;

        memcpy(p, tmp, str_size);
        p += str_size;
        pfree(tmp);
        break;

    case expr_bool:
        if (expr->expr.boolean)
            tmp = "true";
        else 
            tmp = "false";
        str_size = strlen(tmp);

        *result_size += str_size;
        res_tmp = (char*) repalloc(*result, *result_size);
        p = p - *result + res_tmp; /* update p to reflect repalloc */
        *result = res_tmp;

        memcpy(p, tmp, str_size);
        p += str_size;
        break;

    case expr_string:
        str = &(expr->expr.string);
        str_size = VARSIZE(str) - VARHDRSZ;
        *result_size += str_size + 2; /* for quotes */
        res_tmp = (char*) repalloc(*result, *result_size);
        p = p - *result + res_tmp; /* update p to reflect repalloc */
        *result = res_tmp;
        *(p++) = '"';
        memcpy(p, &(VARDATA(str)), str_size);
        p += str_size;
        *(p++) = '"';
        break;

    case expr_variant:
        tmp = var_to_string(&(expr->expr.variant));
        str_size = strlen(tmp);
        
        *result_size += str_size;
        res_tmp = (char*) repalloc(*result, *result_size);
        p = p - *result + res_tmp; /* update p to reflect repalloc */
        *result = res_tmp;
        memcpy(p, tmp, str_size);
        p += str_size;
        pfree(tmp);
        break;

    case expr_record:
        p = rec_to_string(&(expr->expr.record), result, result_size, p);
        break;

    case expr_list:
        old_size = *result_size;
        p = rec_to_string(&(expr->expr.record), result, result_size, p);
        /* this is an ugly hack */
        *(p-(*result_size-old_size)) = '[';
        *(p-1) = ']';
        break;
    }

    return p;
}

Expression * expr_init_int(int32 n) {
    Expression *expr;
    int expr_size = VARHDRSZ + (sizeof(int32) * 2);

    expr = (Expression*) palloc(expr_size);
    SET_VARSIZE(expr, expr_size);
    expr->type = expr_integer;
    expr->expr.integer = n;

    return expr;
}

Expression * expr_init_bool(bool b) {
    Expression *expr;
    int expr_size = VARHDRSZ + (sizeof(int32) * 2);

    expr = (Expression*) palloc(expr_size);
    SET_VARSIZE(expr, expr_size);
    expr->type = expr_bool;
    expr->expr.boolean = b;

    return expr;
}

Expression * expr_init_text(text *str) {
    int expr_size;
    Expression *expr;

    expr_size = VARHDRSZ + sizeof(int32) + VARSIZE(str);
    
    expr = (Expression*) palloc(expr_size);
    SET_VARSIZE(expr, expr_size);
    expr->type = expr_string;
    memcpy(&(expr->expr.string), str, VARSIZE(str));
    
    return expr;
}

Expression * expr_init_str(char *s) {
    text *str;
    int size;
    Expression *expr;

    size = strlen(s);
    str = (text*) palloc(VARHDRSZ + size);
    SET_VARSIZE(str, VARHDRSZ + size);
    memcpy(&(VARDATA(str)), s, size);

    expr = expr_init_text(str);
    pfree(str);
    
    return expr;
}

Expression * expr_init_var(Variant *var) {
    Expression *expr;
    int expr_size = VARHDRSZ + sizeof(int32) + VARSIZE(var);

    expr = (Expression*) palloc(expr_size);
    SET_VARSIZE(expr, expr_size);
    expr->type = expr_variant;
    memcpy(&(expr->expr.variant), var, VARSIZE(var));
    pfree(var);

    return expr;
}

Expression * expr_init_rec(Record *rec) {
    Expression *expr;
    
    int expr_size = VARHDRSZ + sizeof(int32) + VARSIZE(rec);

    expr = (Expression*) palloc(expr_size);
    SET_VARSIZE(expr, expr_size);
    expr->type = expr_record;
    memcpy(&(expr->expr.record), rec, VARSIZE(rec));

    return expr;
}

Expression * expr_init_list(Record *rec) {
    Expression *expr;
    
    int expr_size = VARHDRSZ + sizeof(int32) + VARSIZE(rec);

    expr = (Expression*) palloc(expr_size);
    SET_VARSIZE(expr, expr_size);
    expr->type = expr_list;
    memcpy(&(expr->expr.record), rec, VARSIZE(rec));

    return expr;
}

static Expression * expr_init_wc() {
    Expression *expr;
    
    int expr_size = VARHDRSZ + sizeof(int32);

    expr = (Expression*) palloc(expr_size);
    SET_VARSIZE(expr, expr_size);
    expr->type = expr_wildcard;

    return expr;
}

bool expr_match(Expression *expr1, Expression *expr2) {
    if ((expr1->type == expr_wildcard) || (expr2->type == expr_wildcard)) {
        return true;
    } else if (expr1->type == expr2->type) {
        switch (expr1->type) {
        case expr_string:
            return strncmp(VARDATA(&(expr1->expr.string)),
                           VARDATA(&(expr2->expr.string)),
                           VARSIZE(&(expr1->expr.string)) - VARHDRSZ) == 0;
        case expr_integer:
            return (expr1->expr.integer == expr2->expr.integer);
        case expr_bool:
            return (expr1->expr.boolean == expr2->expr.boolean);
        case expr_record:
        case expr_list:
            return rec_match(&expr1->expr.record, &expr2->expr.record);
        case expr_variant:
            return var_match(&expr1->expr.variant, &expr2->expr.variant);
        default:
            return false;   /* error */
        }
    } else {
        return false;
    }
}


/* ------------------------------------------------------------ */

static inline Expression * rec_head_fast(Record *rec) {
    return (Expression*)(rec->data + rec->head_offset);
}

static Expression * rec_head(Record *rec) {
    Expression *expr, *result;

    expr = rec_head_fast(rec);
    result = (Expression*) palloc(VARSIZE(expr));
    memcpy(result, expr, VARSIZE(expr));

    return result;
}

static inline Record * rec_tail_fast(Record *rec) {
    return (Record*)(rec->data + rec->tail_offset);
}

static Record * rec_tail(Record *rec) {
    Record *result, *tmp;

    tmp = rec_tail_fast(rec);
    result = (Record*) palloc(VARSIZE(tmp));
    memcpy(result, tmp, VARSIZE(tmp));

    return result;
}

static int32 rec_num_args(Record *rec) {
    return rec->num_args;
}

/* 0-indexed */
static Expression * rec_get(Record *rec, int n) {
    int i;

    /* assert n < rec->num_args */
    if (n >= rec->num_args) 
        ereport(ERROR,
                (errcode(ERRCODE_ARRAY_SUBSCRIPT_ERROR),
                 errmsg("requested element %d; only %d elements",
                        n, rec->num_args)));
    
    for (i = 0; i < n; ++i) {
        rec = rec_tail_fast(rec);
    }
    return rec_head(rec);
}

/* static Expression* rec_get_named_item(Record*, text*); */

char * rec_to_string(Record *rec, char **result, int *result_size, char *p) {
    Expression *expr;
    int i, n;
    char *res_tmp;
    
/*     if (rec->num_args == 0) { */
/*         return p; */
/*     } */

    /* space for '(' ')' and ','s */
    *result_size += rec->num_args + 1;
    if (rec->num_args == 0)
        *result_size++;
    res_tmp = (char*) repalloc(*result, *result_size);
    p = p - *result + res_tmp; /* update p to reflect repalloc */
    *result = res_tmp;

    *(p++) = '(';

    n = rec->num_args;
    for (i = 0; i < n; ++i) {
        expr = (Expression*)(rec->data + rec->head_offset);
        p = expr_to_string(expr, result, result_size, p);
        if (i+1 < n)
            *(p++) = ',';
        rec = (Record*)(rec->data + rec->tail_offset);
    }

    *(p++) = ')';

    return p;
}

static Record * rec_nil() {
    Record *rec = palloc(sizeof(Record));
    SET_VARSIZE(rec, sizeof(Record));
    rec->num_args = 0;

    return rec;
}

static Record * rec_cons(Expression *expr, Record *tail) {
    Record *rec;
    int rec_size;

    rec_size = sizeof(Record) - 1 + VARSIZE(expr) + VARSIZE(tail);
    rec = (Record*) palloc(rec_size);
    SET_VARSIZE(rec, rec_size);
    rec->num_args = tail->num_args + 1;
    rec->head_offset = 0;
    rec->tail_offset = 0 + VARSIZE(expr);
    memcpy(rec->data + rec->head_offset, expr, VARSIZE(expr));
    memcpy(rec->data + rec->head_offset + rec->tail_offset, 
           tail, VARSIZE(tail));
        
    return rec;
}

bool rec_match(Record *rec1, Record *rec2) {
    int i, n;

    if (rec1->num_args == rec2->num_args) {
        n = rec1->num_args;
        for (i = 0; i < n; ++i) {
            if (!expr_match(rec_head_fast(rec1), rec_head_fast(rec2))) {
                return false;
            }
            rec1 = rec_tail_fast(rec1);
            rec2 = rec_tail_fast(rec2);
        }
        return true;
    } else {
        return false;
    }
}
